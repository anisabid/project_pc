# Refonte MYPC - Mock

For run mock server we use [json-server](https://www.npmjs.com/package/json-server)

All files mock placed in `/mock/`

For config mock update `/src/environments/environment.ts` in `options.mock` section, in `data` options disabled/enabled mock for service

```
options: {
    mock: {
      api: {
        schemes: '',
        host: '',
        basePath: 'mocks/',
        paths: {},
      },
      data: {
        login: false,
        requests: true,
      },
    },
  },
```

`basePath` used for config proxy, that's why we must not forget to configure `proxy.conf.json`

```
{
  ...
  "/mocks": {
    "target": "http://localhost:3000/",
    "secure": false,
    "pathRewrite": {
      "^/mocks": ""
    },
    "logLevel": "debug"
  },
  ...
}
```
