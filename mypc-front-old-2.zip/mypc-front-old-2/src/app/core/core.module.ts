/**
 * Core Feature Module
 *
 * ### STYLE 04-11 Angular 04: https://v4.angular.io/guide/styleguide#style-04-11
 *
 * Suit les guidelines Angular officielles.
 * Ce module permet de regrouper les éléments transverses à toute l'application :
 *   - Services/singletons au niveau de l'application ("provide app-wide singletons, depuis angular 6 on peut avoir un singleton avec  providedIn: 'root' ")
 *   - Composants partagés ("application-wide, single use components"), comme des modales, spinners, ...
 *
 * ### STYLE 04-12 Angular 04: https://v4.angular.io/guide/styleguide#style-04-12
 *
 * Le CoreModule ne pourra pas être chargé plus d'une fois
 *
 * ### Surcharge de la configuration
 *
 * La configuration de ce module peut être surchargée en providant un service CoreModuleConfigurationService
 *
 * Exemple :
 *
 * @NgModule({
 *   declarations: [
 *     AppComponent,
 *     HomeComponent ],
 *   imports: [
 *     CoreModule ],
 *   providers: [
 *     // on initialise le coreModule avec la conf présente dans environnement
 *     { provide: CoreModuleConfigurationService, useValue: environment.coreModuleConfiguration} ],
 *   bootstrap: [AppComponent]
 * })
 * export class AppModule {}
 *
 */

import { NgModule, Optional, SkipSelf } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from '@shared/shared.module';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [],
  imports: [CommonModule, SharedModule, HttpClientModule, FormsModule],
  exports: [],
  providers: [],
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only'
      );
    }
  }
}
