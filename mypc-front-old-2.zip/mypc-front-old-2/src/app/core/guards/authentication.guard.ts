import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanActivateChild,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { AuthenticationService } from '@core/services/authentication.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationGuard implements CanActivate, CanActivateChild {
  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private environmentService: EnvironmentService
  ) {}

  public canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.isLoggedIn();
  }

  public canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.isLoggedIn();
  }

  public isLoggedIn(): boolean {
    if (this.authenticationService.isLoggedIn()) {
      if (
        this.authenticationService.isSessionExpired() ||
        !this.authenticationService.isValidInfos()
      ) {
        //session is expired, we have to logout the user
        this.authenticationService.logout().then((result: boolean) => {
          if (result) {
            this.router.navigateByUrl(this.redirectTogglingLogin);
            return false;
          }
        });
        return false;
      } else return true; // the session is not expired so we can continue
    }
    this.router.navigateByUrl(this.redirectTogglingLogin);
    return false;
  }

  get redirectTogglingLogin(): string {
    // Redirect to autologin if config onlyAutoLogin set to true else redirect to ManualLogin
    return this.environmentService.config.modules.login.onlyAutoLogin
      ? ConstRoutesPath.AUTOLOGIN
      : ConstRoutesPath.LOGIN;
  }
}
