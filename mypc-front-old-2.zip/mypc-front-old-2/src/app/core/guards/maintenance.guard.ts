import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanActivateChild,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { SessionService } from '@shared/services/session/session.service';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { AccessService } from '../services/access.service';

@Injectable({
  providedIn: 'root',
})
export class MaintenanceGuard implements CanActivate, CanActivateChild {
  constructor(
    private router: Router,
    private accessService: AccessService,
    private sessionService: SessionService,
    private environmentService: EnvironmentService
  ) {}

  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.isHasAccess();
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    return this.isHasAccess();
  }

  isHasAccess(): boolean {
    if (this.accessService.lockAppAccess()) {
      this.router.navigateByUrl(ConstRoutesPath.EXTRA.SOON.PATH);
      return false;
    }
    /**
     * @todo remove redirect condition for partner
     */
    /*
    if (
      this.sessionService.session?.user?.isPartner &&
      this.environmentService.access.redirect.partner.enable
    ) {
      
      window.location.href =
        this.environmentService.access.redirect.partner.url;
      return false;
      
    }
    */
    return true;
  }
}
