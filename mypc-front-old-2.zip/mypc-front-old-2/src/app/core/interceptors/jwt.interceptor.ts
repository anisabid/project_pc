import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { JwtService } from '@core/services/jwt.service';
import { LoaderService } from '@shared/modules/loader/loader.service';
import { SessionService } from '@shared/services/session/session.service';
import { EMPTY, Observable, of, throwError } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  constructor(
    private router: Router,
    private jwtService: JwtService,
    private loaderService: LoaderService,
    private sessionService: SessionService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    //this.loaderService.show();
    if (this.jwtService.getInfos()) {
      if (this.jwtService.isTokenExpired()) {
        // check if the token is expired
        this.router.navigateByUrl(ConstRoutesPath.LOGOUT + '?cause=expired'); // navigate to logout the user and show message
        return EMPTY; // return empty observable
      }
      this.sessionService.session = this.jwtService.getInfos();
      req = req.clone({
        headers: req.headers.set(
          'Authorization',
          'Bearer ' + this.jwtService.getJwtFromLocalStorage()
        ),
      });
    }
    return next.handle(req).pipe(
      tap((resp: HttpResponse<any>) => {
        if (resp.headers && resp.headers.get('Authorization')) {
          this.jwtService.putJwtInLocalStorage(
            resp.headers.get('Authorization').substring('Bearer '.length)
          );
        }
        finalize(() => {
          this.loaderService.hide();
        });
      }),

      catchError((err) => this.handleAuthError(err))
    );
  }

  private handleAuthError(err: HttpErrorResponse): Observable<any> {
    if (err.status === 401 || err.status === 403) {
      this.router.navigateByUrl(ConstRoutesPath.LOGOUT);
      return of(err.message);
    }
    return throwError(err);
  }
}
