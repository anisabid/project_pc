import { Injectable } from '@angular/core';
import { SwUpdate, UpdateAvailableEvent } from '@angular/service-worker';
import { SnackBarMessageService } from '@app/shared/modules/snack-bar-message/snack-bar-message.service';

@Injectable({
  providedIn: 'root',
})
export class AppUpdateService {
  constructor(
    private readonly updates: SwUpdate,
    private snackBarMessageService: SnackBarMessageService
  ) {}

  checkUpdate() {
    this.updates.available.subscribe((event: UpdateAvailableEvent) => {
      this.showAppUpdateAlert();
    });
  }
  showAppUpdateAlert() {
    this.snackBarMessageService.success({
      message: 'Mise à jour de MyPC',
      action: null,
      duration: 1000,
    });
    this.doAppUpdate();
  }
  doAppUpdate() {
    this.updates.activateUpdate().then(() => document.location.reload());
  }
}
