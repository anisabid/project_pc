import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { AuthenticationGuard } from '@app/core/guards/authentication.guard';
import { LoginGuard } from '@app/core/guards/login.guard';
import { DefaultLayoutComponent } from '@shared/modules/layout/components/templates/default/default-layout.component';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { UiLayoutComponent } from '@shared/modules/layout/components/templates/ui/ui-layout.component';
import { AdminGuard } from './core/guards/admin.guard';
import { MaintenanceGuard } from './core/guards/maintenance.guard';

const routes: Routes = [
  {
    path: '',
    canActivate: [MaintenanceGuard, AuthenticationGuard],
    component: DefaultLayoutComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: ConstRoutesPath.DEFAULT,
      },
      {
        path: ConstRoutesPath.ADMINISTRATION,
        canActivate: [AdminGuard],
        loadChildren: () =>
          import('./modules/administration/administration.module').then(
            (m) => m.AdministrationModule
          ),
      },
      {
        path: ConstRoutesPath.APPLICATIONS,
        loadChildren: () =>
          import('./modules/applications/applications.module').then(
            (m) => m.ApplicationsModule
          ),
      },
      {
        path: ConstRoutesPath.DASHBOARD.PATH,
        loadChildren: () =>
          import('./modules/dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
      },

      {
        path: ConstRoutesPath.DELEGATIONS,
        loadChildren: () =>
          import('./modules/delegations/delegations.module').then(
            (m) => m.DelegationsModule
          ),
      },
      {
        path: ConstRoutesPath.PORTAL,
        loadChildren: () =>
          import('./modules/portal/portal.module').then((m) => m.PortalModule),
      },
      {
        path: ConstRoutesPath.PROFILE,
        loadChildren: () =>
          import('./modules/profile/profile.module').then(
            (m) => m.ProfileModule
          ),
      },
      {
        path: ConstRoutesPath.REQUESTS,
        loadChildren: () =>
          import('./modules/requests/requests.module').then(
            (m) => m.RequestsModule
          ),
      },
    ],
  },
  {
    path: ConstRoutesPath.EXTRA.SOON.PATH,
    loadChildren: () =>
      import('./modules/extra/extra.module').then((m) => m.ExtraModule),
  },
  {
    path: ConstRoutesPath.SECURE.AUTOLOGIN,
    canActivate: [LoginGuard],
    loadChildren: () =>
      import('./modules/secure/autologin/autologin.module').then(
        (m) => m.AutologinModule
      ),
  },
  {
    path: ConstRoutesPath.SECURE.PATH,
    canActivate: [MaintenanceGuard],
    loadChildren: () =>
      import('./modules/secure/secure.module').then((m) => m.SecureModule),
  },
  {
    path: 'ui',
    component: UiLayoutComponent,
    canActivate: [MaintenanceGuard, AuthenticationGuard],
    loadChildren: () => import('./ui/ui.module').then((m) => m.UiModule),
  },
  {
    path: '**',
    redirectTo: ConstRoutesPath.DEFAULT,
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      preloadingStrategy: PreloadAllModules,
      relativeLinkResolution: 'legacy',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
