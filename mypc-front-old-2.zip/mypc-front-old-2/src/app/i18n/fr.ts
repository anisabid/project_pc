export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      app: {
        title: 'MYPC',
      },
      global: {
        clipboard: {
          copied: 'Copied : ',
          copy: 'Copy to clipboard',
        },
      },
      navigation: {
        admin: 'Admin',
        applications: 'Catalogue Applicatif',
        dashboard: 'Tableau de bord',
        follow_up: 'Suivis',
        help: 'Aide',
        home: 'Accueil',
        logout: 'Se déconnecter',
        my_delegations: 'Mes Délégations',
        my_groups: 'Mes Groupes',
        partner_portal: 'Portail partenaire',
        profile: 'Mon Profil',
        reporting_my_groups: 'Reporting de mes groupes',
        requests: 'Mes Demandes',
        useful_links: 'Liens utiles',
        blog: {
          default: 'Blog bureautique',
          media: 'Blog bureautique',
          partner: 'Blog partenaire',
        },
        rest_password: 'Reset mot de passe',
        office_security: 'Sécurité Bureautique',
        changes: 'Changements',
      },
      user: {
        firstName: 'Prénom',
        fullName: 'Nom complet',
        id: 'ID',
        lastName: 'Nom',
        perId: 'ID',
        profile: 'Profil',
        uPerId: 'UperID',
        profilesList: {
          partner: 'Partenaire',
          media: 'Média',
          internal: 'interne',
          default: 'interne',
        },
      },
      catalog: {
        cds: {
          description:
            'Vous pouvez parcourir notre catalogue de services. Ex : Je souhaite commander du matériel. Je souhaite créer ou modifier un poste bureautique, une liste de diffusion…',
          name: 'Faire une demande',
          subtitle: 'Je commande quelque chose ou demande un service',
          title: 'catalogue de services',
        },
        esup: {
          description:
            'Résolvez votre problème en consultant nos fiches tutorielles. Ex : comment vider mon historique ? Comment réinitialiser mon mot de passe ?',
          name: 'Besoin d’aide',
          subtitle: 'J’ai besoin d’aide !',
          title: 'aide',
        },
      },
      workflow: {
        step: 'etape {{param}}',
        steps: {
          step_1: {
            label: 'Que souhaitez-vous faire ?',
          },
          step_2: {
            label: 'Choisissez le sujet de votre demande',
          },
          step_3: {
            label: 'Veuillez préciser votre demande…',
          },
          step_4: {
            label: {
              cds: 'Quel service souhaitez-vous ?',
              esup: 'Quel problème rencontrez-vous ?',
              service: 'Quel service souhaitez-vous ?',
              user_guide: 'Quel problème rencontrez-vous ?',
            },
          },
          step_5: {
            label: 'Formulaire',
          },
          step_6: {
            label: 'Que souhaitez-vous faire ?',
          },
        },
        create_generic_type_incident: 'Créer un incident de type générique',
      },
    },
  },
};
