import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sfr-side',
  templateUrl: './side.component.html',
  styleUrls: ['./side.component.scss']
})
export class SideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
