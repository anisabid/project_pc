export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        profile: {
          name: 'Mon profil',
          global: {},
        },
      },
    },
  },
};
