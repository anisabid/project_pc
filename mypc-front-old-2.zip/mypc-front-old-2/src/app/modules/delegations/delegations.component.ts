import { Component, OnInit } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
} from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ConstCRUD, CRUD } from '@shared/consts/crud.const';
import { ConstDateFormatFront } from '@shared/consts/date.const';
import { UserSearch } from '@shared/models/user';
import { ValidatorHelperService } from '@shared/services/helper/validator-helper.service';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { Page } from '@shared/models/page';
import { ApiService } from '@shared/services/api/v2/api.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import {
  debounceTime,
  distinctUntilChanged,
  filter,
  finalize,
  switchMap,
  tap,
} from 'rxjs/operators';
import {
  ConstRoutesPathDelegations,
  Delegation,
  DelegationDialogData,
  RoutesPathDelegations,
} from './delegation.model';
import { DelegationsService } from './delegations.service';
import { locale as localFrench } from './i18n/fr';
import { ModalDelegationComponent } from './modal/modal-delegation/modal-delegation.component';
import {
  ConfirmDialogComponent,
  ConfirmDialogModel,
} from '@shared/components/confirm-dialog/confirm-dialog.component';
import { AccessPipe } from '@shared/pipes/access.pipe';
import { ConstAccess, EnumAccess, Access } from '@shared/consts/access.const';

@Component({
  selector: 'sfr-delegation',
  templateUrl: './delegations.component.html',
  styleUrls: ['./delegations.component.scss'],
})
export class DelegationsComponent implements OnInit {
  public constRoutesPathDelegations: RoutesPathDelegations;
  public currentIdDelegate: string;
  public delegationFG: UntypedFormGroup;
  public delegations: Page<Delegation>;
  public constCrud: CRUD;
  public isLoading = false;
  public users: Array<any>;
  public errorMsg!: string;
  public delegate: UserSearch;
  public constDateFormat: string;
  public currentUser: UserSearch;
  public constAccess: Access;
  public minLengthTerm: number;
  private confirmDialogRef: MatDialogRef<ConfirmDialogComponent>;
  private confirmDialogConfig: MatDialogConfig;

  constructor(
    private activatedRoute: ActivatedRoute,
    private delegationsService: DelegationsService,
    private formBuilder: UntypedFormBuilder,
    private matDialog: MatDialog,
    private router: Router,
    private translationLoaderService: TranslationLoaderService,
    private validatorHelperService: ValidatorHelperService,
    private apiService: ApiService,
    private accessPipe: AccessPipe
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.constRoutesPathDelegations = ConstRoutesPathDelegations;
    this.constCrud = ConstCRUD;
    this.delegations = new Page();
    this.delegate = null;
    this.minLengthTerm = 3;
    this.currentUser = null;
    this.constDateFormat = ConstDateFormatFront;
    this.constAccess = ConstAccess;
  }

  ngOnInit(): void {
    this.currentIdDelegate =
      this.activatedRoute.snapshot.paramMap.get('idDelegate');
    this.delegationFG = this.formBuilder.group({
      idDelegate: new UntypedFormControl(
        '',
        Validators.pattern(this.validatorHelperService.uPerIdPattern)
      ),
      value: new UntypedFormControl(''),
    });
    this.delegationsService.onDelegationsChanged.subscribe((delegations) => {
      this.delegations = delegations;
    });
    this.delegationsService.onDelegateChanged.subscribe((delegate) => {
      this.delegate = delegate;
    });

    this.delegationFG
      .get('value')
      .valueChanges.pipe(
        filter((res) => {
          if (res.length <= this.minLengthTerm) {
            this.users = [];
          }
          return res !== null && res.length >= this.minLengthTerm;
        }),
        distinctUntilChanged(),
        debounceTime(1000),
        tap(() => {
          this.errorMsg = '';
          this.users = [];
          this.isLoading = true;
        }),
        switchMap((value) =>
          this.apiService.users.getUsers(value).pipe(
            finalize(() => {
              this.isLoading = false;
            })
          )
        )
      )
      .subscribe((data: any) => {
        if (data['users'] == undefined) {
          this.errorMsg = data['Error'];
          this.users = [];
        } else {
          this.errorMsg = '';
          this.users = data['users']['data'];
        }
      });
  }

  public displayWith(value: any) {
    return value?.name;
  }

  public onSelected() {
    this.currentUser = <UserSearch>this.delegationFG.get('value').value;
  }

  public clearDelegation(): void {
    this.delegationFG.get('value').patchValue('');
    this.users = [];
    this.currentUser = null;
    this.updateDelegate();
  }

  public updateDelegate(): void {
    this.currentUser = <UserSearch>this.delegationFG.get('value').value;
    if (this.currentUser.uperid) {
      let path =
        ConstRoutesPath.DELEGATIONS +
        '/' +
        (this.currentUser.uperid ? this.currentUser.uperid + '/' : '') +
        this.activatedRoute.children[0].routeConfig.path;
      this.router.navigateByUrl(path);
    }
  }

  public backToMyDelegations() {
    let path =
      ConstRoutesPath.DELEGATIONS +
      '/' +
      this.activatedRoute.children[0].routeConfig.path;
    this.router.navigateByUrl(path);
  }

  public openModalDelegation(action: string, delegation: Delegation = null) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.width = '50vw';

    if (delegation) {
      if (delegation.isCanBeEditing()) {
        dialogConfig.data = <DelegationDialogData>{
          action: action,
          delegate: this.delegate,
          delegation: delegation,
        };
        this.matDialog.open(ModalDelegationComponent, dialogConfig);
      }
    } else {
      if (action === this.constCrud.CREATE) {
        dialogConfig.data = <DelegationDialogData>{
          action: action,
          delegate: this.delegate,
          delegation: null,
        };
        this.matDialog.open(ModalDelegationComponent, dialogConfig);
      }
    }
  }

  public deleteDelegation(delegation: Delegation): void {
    if (delegation.id && delegation.isCanBeDeleted()) {
      this.confirmDialogConfig = new MatDialogConfig();
      this.confirmDialogConfig.width = '40vw';
      this.confirmDialogConfig.panelClass = 'sfr-dialog';
      this.confirmDialogConfig.data = new ConfirmDialogModel({
        title: "Suppresion d'une Délégation",
        message: 'Étes-vous sûr de vouloir supprimer',
      });
      this.confirmDialogRef = this.matDialog.open(
        ConfirmDialogComponent,
        this.confirmDialogConfig
      );
      this.confirmDialogRef.afterClosed().subscribe((result) => {
        if (result) {
          this.delegationsService.deleteDelegation(delegation.id);
        }
      });
    }
  }

  public stopDelegation(delegation: Delegation): void {
    if (delegation.id && delegation.isCanBeStopped()) {
      delegation.dateEnd = new Date();
      this.delegationsService.putDelegation(
        delegation.id,
        delegation.toApiDTO(this.delegate.id)
      );
    }
  }

  public get isTheConnectedDelegate(): boolean {
    return this.delegationsService.isTheConnectedDelegate;
  }

  public get title(): string {
    return this.isTheConnectedDelegate
      ? 'i18n.module.delegations.title'
      : 'i18n.module.delegations.title_with_idDelegate';
  }

  public get hasAccessToActions(): boolean {
    return this.accessPipe.transform(EnumAccess.ADMIN)
      ? true
      : this.delegationsService.pathParams.isIGive
      ? true
      : false;
  }
}
