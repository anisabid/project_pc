export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        delegations: {
          name: 'Mes Délégations',
          title: 'Mes Délégations',
          title_with_idDelegate: 'Les Délégations de {{user}}',
          that_i_gave: "Les délégations que j'ai données",
          given_to_me: "Les délégations qui m'ont été données",
          add_delegation: 'Ajouter une nouvelle Délégation',
          update_delegation: 'Modifier la Délégation',
          back_to_my_delegations: 'Retour à Mes Délégations',
          modal: {
            title: {
              add: 'Ajouter une nouvelle Délégation',
              update: 'Modifier la Délégation {{id}}',
              add_with_idDelegate:
                'Ajouter une nouvelle Délégation par : {{user}}',
              update_with_idDelegate:
                'Modifier la Délégation N° {{id}} par : {{user}}',
            },
            form: {
              user: {
                label: 'Personne',
                placeholder: 'Personne',
              },
              for: {
                label: 'À',
                placeholder: 'Ex. u999999',
              },
              date_range: {
                label: 'Entrez une plage de dates Début et Fin',
                placeholder: 'MM/DD/YYYY – MM/DD/YYYY',
              },
              date_begin: {
                label: 'Date de Début',
                placeholder: 'Ex. MM/DD/YYYY',
              },
              date_end: {
                label: 'Date de Fin',
                placeholder: 'Ex. MM/DD/YYYY',
              },
            },
          },
          global: {},
          form: {
            search: {
              delegate: {
                placeholder: 'Se substituer à un délégant...',
              },
            },
          },
          components: {
            list: {
              table: {
                columns: {
                  user: 'Personne',
                  date_begin: 'Date de Début',
                  date_end: 'Date de Fin',
                  in_progress: 'En cours',
                  actions: 'Actions',
                },
                emty: 'Pas de délégation',
              },
            },
          },
        },
      },
    },
  },
};
