import { Component, Inject, OnInit } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConstCRUD, CRUD } from '@shared/consts/crud.const';
import { Crud } from '@shared/models/crud';
import { UserSearch } from '@shared/models/user';
import { ApiService } from '@shared/services/api/v2/api.service';
import {
  debounceTime,
  distinctUntilChanged,
  filter,
  finalize,
  switchMap,
  tap,
} from 'rxjs/operators';
import { DelegationDialogData, Delegation } from '../../delegation.model';
import { DelegationsService } from '../../delegations.service';

@Component({
  selector: 'sfr-modal-delegation',
  templateUrl: './modal-delegation.component.html',
  styleUrls: ['./modal-delegation.component.scss'],
})
export class ModalDelegationComponent implements OnInit {
  private _titleTranslate: string;
  public constCrud: CRUD;
  public delegationFG: UntypedFormGroup;
  public today: Date;

  public isLoading = false;
  public users: Array<any>;
  public errorMsg!: string;
  public currentUser: UserSearch;
  public isUpdate: boolean;
  public saving: boolean = false;
  private minLengthTerm: number;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: DelegationDialogData,
    public dialogRef: MatDialogRef<ModalDelegationComponent>,
    private formBuilder: UntypedFormBuilder,
    private apiService: ApiService,
    private delegationsService: DelegationsService
  ) {
    this.saving = false;
    this.isUpdate = new Crud(this.data.action).isUpdate;
    this.constCrud = ConstCRUD;
    this.today = new Date();
    this.delegationFG = this.formBuilder.group({
      id: new UntypedFormControl(this.data?.delegation?.id),
      user: new UntypedFormControl({
        value: this.data?.delegation?.user,
        disabled: this.isUpdate,
      }),
      dateBegin: new UntypedFormControl(
        this.data?.delegation?.dateBegin ?? new Date(),
        Validators.required
      ),
      dateEnd: new UntypedFormControl(
        this.data?.delegation?.dateEnd ?? '',
        Validators.required
      ),
    });
    this.minLengthTerm = 3;
    this.currentUser = null;
  }

  ngOnInit(): void {
    this.delegationFG
      .get('user')
      .valueChanges.pipe(
        filter((res) => {
          if (res.length <= this.minLengthTerm) {
            this.users = [];
          }
          return res !== null && res.length >= this.minLengthTerm;
        }),
        distinctUntilChanged(),
        debounceTime(1000),
        tap(() => {
          this.errorMsg = '';
          this.users = [];
          this.isLoading = true;
        }),
        switchMap((value) =>
          this.apiService.users.getUsers(value).pipe(
            finalize(() => {
              this.isLoading = false;
            })
          )
        )
      )
      .subscribe((data: any) => {
        if (data['users'] == undefined) {
          this.errorMsg = data['Error'];
          this.users = [];
        } else {
          this.errorMsg = '';
          this.users = data['users']['data'];
        }
      });
  }

  public displayWith(user: any) {
    return user?.name;
  }

  public onSelected() {
    this.currentUser = new UserSearch(this.delegationFG.get('user').value);
  }

  public get titleTranslate(): string {
    this.data.action;
    switch (this.data.action) {
      case this.constCrud.CREATE:
        this._titleTranslate = this.data.delegate.uperid
          ? 'i18n.module.delegations.modal.title.add_with_idDelegate'
          : 'i18n.module.delegations.modal.title.add';
        break;
      case this.constCrud.UPDATE:
        this._titleTranslate = this.data.delegate.uperid
          ? 'i18n.module.delegations.modal.title.update_with_idDelegate'
          : 'i18n.module.delegations.modal.title.update';
        break;
      default:
        this._titleTranslate = 'i18n.module.delegations.modal.title.add';
    }
    return this._titleTranslate;
  }

  public saveDelegation() {
    this.saving = true;
    const newDelegation: Delegation = new Delegation(
      {
        dateBegin: this.delegationFG.get('dateBegin').value,
        dateEnd: this.delegationFG.get('dateEnd').value,
        id: this.delegationFG.get('id').value,
        user: this.delegationFG.get('user').value,
      },
      false
    );
    if (this.isUpdate) {
      this.delegationsService
        .putDelegation(
          this.data?.delegation?.id,
          newDelegation.toApiDTO(this.data.delegate.id)
        )
        .then(() => {
          this.dialogRef.close();
          this.saving = false;
        })
        .catch(() => {
          this.saving = false;
        });
    } else {
      this.delegationsService
        .postDelegation(newDelegation.toApiDTO(this.data.delegate.id))
        .then(() => {
          this.dialogRef.close();
          this.saving = false;
        })
        .catch(() => {
          this.saving = false;
        });
    }
  }
}
