import { CommonModule } from '@angular/common';
import { DelegationRoutingModule } from './delegations-routing.module';
import { DelegationsComponent } from './delegations.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalDelegationComponent } from './modal/modal-delegation/modal-delegation.component';
import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { MaterialModule } from '@shared/modules/material/material.module';
import { MatAutocompleteModule } from '@angular/material/autocomplete';

@NgModule({
  declarations: [DelegationsComponent, ModalDelegationComponent],
  imports: [CommonModule, SharedModule, DelegationRoutingModule, FormsModule, ReactiveFormsModule, MaterialModule, MatAutocompleteModule],
})
export class DelegationsModule {}
