import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { Counter } from '@shared/models/counter';
import { Source } from '@shared/models/source';
import { StringHelperService } from '@shared/services/helper/string-helper.service';
import { ConstStatutes } from '@shared/consts/statutes.const';
import { Operation, OPERATIONS } from './widget-requests-model';
import { EnumRequestsRoutesPath } from '@app/modules/requests/const/request.const.routes';
import { RequestQueryActions } from '@app/modules/requests/enums/request-query-actions.enum';
import { DashboardService } from '../../dashboard.service';

@Component({
  selector: 'sfr-widget-requests',
  templateUrl: './widget-requests.component.html',
  styleUrls: ['./widget-requests.component.scss'],
})
export class WidgetRequestsComponent implements OnInit {
  public counter: Counter;
  public selected: OPERATIONS;
  public operations: { approvals: Operation; requests: Operation };

  /**
   * Constructor
   * @param dashboardService Dashboard Service
   * @param stringHelperService String Helper Service
   * @param router Router
   */
  constructor(
    private dashboardService: DashboardService,
    private stringHelperService: StringHelperService,
    private router: Router
  ) {
    this.counter = null;
    this.operations = { approvals: null, requests: null };
  }

  ngOnInit(): void {
    this.operations.approvals = new Operation(
      OPERATIONS.APPROVALS,
      'my-approvals',
      null
    );
    this.operations.requests = new Operation(
      OPERATIONS.REQUESTS,
      'my-requests',
      null
    );
    this.selected = this.operations.requests.name;
    this.dashboardService
      .getWidgetRequests({
        action: 'requests',

        status:
          ConstStatutes.DONE.statusCode +
          ',' +
          ConstStatutes.ESCALATION.statusCode +
          ',' +
          ConstStatutes.FINISHED.statusCode +
          ',' +
          ConstStatutes.CANCELED.statusCode +
          ',' +
          ConstStatutes.REJECTED.statusCode,
      })
      .subscribe((result) => {
        this.operations.requests.dataSource = new Source(result.requests);
      });
    this.dashboardService
      .getWidgetRequests({
        action: 'actions',
        status:
          ConstStatutes.ESCALATION.statusCode +
          ',' +
          ConstStatutes.FINISHED.statusCode +
          ',' +
          ConstStatutes.CANCELED.statusCode +
          ',' +
          ConstStatutes.REJECTED.statusCode,
      })
      .subscribe((result) => {
        this.operations.approvals.dataSource = new Source(result.requests);
      });
  }
  public toAcronym(value: string): string {
    return this.stringHelperService.toAcronym(value);
  }

  /**
   * Navigate to Request Life cycle
   * @param requestId Request ID
   */
  public navigate(requestId: string): void {
    this.router.navigateByUrl(
      `${ConstRoutesPath.REQUESTS}/${EnumRequestsRoutesPath.LIFECYCLE}/${requestId}`,
      {
        state: {
          actionType: this.selectedActionType,
        },
      }
    );
  }

  get selectedOperation(): Operation {
    return this.operations[this.selected];
  }

  get selectedActionType(): RequestQueryActions {
    return this.selected === OPERATIONS.APPROVALS
      ? RequestQueryActions.ACTIONS
      : RequestQueryActions.REQUESTS;
  }
}
