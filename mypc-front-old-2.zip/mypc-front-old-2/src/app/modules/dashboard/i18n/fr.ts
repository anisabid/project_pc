export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        dashboard: {
          faq: {
            title: 'Questions fréquentes',
          },
          global: {
            welcome: 'Bonjour {{param}}, bienvenue sur MyPC',
          },
          help: {
            title:
              'Je suis Alfred, votre aide virtuelle. Comment puis-je vous aider ?',
            caption:
              'Je suis à votre service pour trouver ensemble ce dont vous avez besoin ou résoudre votre problème !',
          },
          name: 'Tableau de bord',
          requests: {
            title: 'Mes demandes',
          },
          search: {
            placeholder: 'Dites nous ici ce dont vous avez besoin…',
          },
          workflow: {},
          widgets: {
            requests: {
              title: 'Mes dossiers',
              nav: {
                requests: 'demandes',
                approvals: 'approbations',
              },
            },
          },
        },
      },
    },
  },
};
