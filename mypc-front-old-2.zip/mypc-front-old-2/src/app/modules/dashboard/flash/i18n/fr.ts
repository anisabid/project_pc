export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        flash: {
          modal: { title: 'Information flash' },
        },
      },
    },
  },
};
