import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Flash } from '../flash.model';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from '../i18n/fr';

@Component({
  selector: 'sfr-modal-flash',
  templateUrl: './modal-flash.component.html',
  styleUrls: ['./modal-flash.component.scss'],
})
export class ModalFlashComponent implements OnInit {
  constructor(@Inject(MAT_DIALOG_DATA) public data: Flash, public dialogRef: MatDialogRef<ModalFlashComponent>, private translationLoaderService: TranslationLoaderService) {}

  ngOnInit(): void {
    this.translationLoaderService.loadTranslations(localFrench);
  }
}
