import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from '@shared/shared.module';
import { WidgetFaqComponent } from './widgets/widget-faq/widget-faq.component';
import { WidgetNotificationsComponent } from './widgets/widget-notifications/widget-notifications.component';
import { WidgetRequestsComponent } from './widgets/widget-requests/widget-requests.component';
import { WorkflowModule } from './workflow/workflow.module';
import { SearchModule } from './search/search.module';
import { FlashModule } from './flash/flash.module';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { WidgetInformationComponent } from './widgets/widget-information/widget-information.component';

@NgModule({
  declarations: [DashboardComponent, WidgetFaqComponent, WidgetNotificationsComponent, WidgetRequestsComponent, WidgetInformationComponent],
  imports: [CommonModule, MatProgressSpinnerModule, DashboardRoutingModule, SearchModule, SharedModule, WorkflowModule, FlashModule],
})
export class DashboardModule {}
