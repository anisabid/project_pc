export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        search: {
          placeholder: 'Dites nous ici ce dont vous avez besoin…',
          services: 'Services',
          help: 'Aide',
        },
      },
    },
  },
};
