import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
import { MyApprovalsComponent } from './list/my-approvals/my-approvals.component';
import { DetailsComponent } from '@app/modules/requests/details/details.component';
import { CompeteDetailsComponent } from '@app/modules/requests/details/request-processing/compete-details/compete-details.component';
import { OriginFormComponent } from '@app/modules/requests/details/request-processing/origin-form/origin-form.component';
import {
  ConstRequestsRoutesPath,
  EnumRequestsRoutesPath,
  EnumRequestTypePath,
} from './const/request.const.routes';
import { MyRequestsComponent } from './list/my-requests/my-requests.component';

const routes: Routes = [
  {
    path: `${EnumRequestsRoutesPath.LIFECYCLE}/:idRequest`,
    component: DetailsComponent,
    children: [
      {
        path: EnumRequestsRoutesPath.LIFECYCLE,
        component: CompeteDetailsComponent,
      },
      {
        path: EnumRequestsRoutesPath.ORIGIN_FORM,
        component: OriginFormComponent,
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: EnumRequestsRoutesPath.LIFECYCLE,
      },
    ],
  },
  {
    path: ConstRequestsRoutesPath.APPROVALS,
    component: ListComponent,
    children: [
      { path: '', component: MyApprovalsComponent },
      { path: EnumRequestTypePath.HISTORY, component: MyApprovalsComponent },
    ],
  },
  {
    path: ConstRequestsRoutesPath.REQUESTS,
    component: ListComponent,
    children: [
      { path: '', component: MyRequestsComponent },
      { path: EnumRequestTypePath.HISTORY, component: MyRequestsComponent },
    ],
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: ConstRequestsRoutesPath.REQUESTS,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RequestsRoutingModule {}
