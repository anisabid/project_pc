import {
  Component,
  EventEmitter,
  HostBinding,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { ConstStatutesFilter } from '@shared/consts/statutes.const';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from '@app/modules/requests/i18n/fr';
import {
  AppliedFilter,
  availableFilterList,
  Filter,
  FilterFormat,
  FilterTypes,
  SearchFilter,
} from './advanced-filter.model';
import {
  EnvironmentConfigRequestsAdvancedFilter,
  EnvironmentService,
} from '@shared/services/environment/environment.service';
import { finalize } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { UserSearch, UserSearchResult } from '@shared/models/user';
import { AdvancedFilterService } from './advanced-filter.service';
import { HttpErrorResponse } from '@angular/common/http';
import { SnackBarMessageService } from '@shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@shared/services/errors/common-errors.service';

@Component({
  selector: 'sfr-advanced-filter',
  templateUrl: './advanced-filter.component.html',
  styleUrls: ['./advanced-filter.component.scss'],
  encapsulation: ViewEncapsulation.None,
})

/**
 * Advanced Filter Component
 */
export class AdvancedFilterComponent implements OnInit, OnDestroy {
  @HostBinding('class') class = 'sfr-advanced-filter';
  @Input() filterItemList: FilterTypes[] = [];
  @Output() searchEvent = new EventEmitter<SearchFilter>();

  /**
   * Filter Lists
   */
  public filterList: Filter[];
  public appliedFilterList: AppliedFilter[];
  public activeFilterList: AppliedFilter[];

  public userList: UserSearch[] = [];

  /**
   * Enums/Consts
   */
  private subscription: Subscription = new Subscription();
  public statusOption = ConstStatutesFilter;
  public FilterFormat = FilterFormat;
  public FilterTypes = FilterTypes;
  public searchFilter: SearchFilter;
  public environmentConfigRequestsAdvancedFilter: EnvironmentConfigRequestsAdvancedFilter;
  private localStorageRequestsPreviousSearchId: string;
  public removable = true;
  public eventFilter = false;
  public isLoading = false;
  private minLengthTerm: number = 3;

  /**
   * Constructor
   * @param advancedFilterService Api Service
   * @param translationLoaderService Translation Loader Service
   * @param environmentService Environment Service
   * @param snackBarMessageService Material SnackBar Message Service
   * @param commonErrorsService Common Request Error Service
   */
  constructor(
    private advancedFilterService: AdvancedFilterService,
    private translationLoaderService: TranslationLoaderService,
    private environmentService: EnvironmentService,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.environmentConfigRequestsAdvancedFilter =
      this.environmentService.config.modules.requests.advancedFilter;
    this.localStorageRequestsPreviousSearchId =
      this.environmentService.options.localStorage.requestsPreviousSearch;
  }

  /**
   * On Init
   */
  ngOnInit(): void {
    this.initFilters();
  }

  /**
   * Init Filter List
   */
  private initFilters(): void {
    this.filterList = [];
    this.filterItemList.forEach((filterType: FilterTypes) => {
      const foundFilter = availableFilterList.find(
        (availableFilter: Filter) => availableFilter.id === filterType
      );
      if (foundFilter) {
        this.filterList.push(foundFilter);
      }
    });
    this.resetFilters();
    this.savePreviousSearchToLocalStorage();
  }

  /**
   * Save Previous Search to Local Storage
   */
  private savePreviousSearchToLocalStorage(): void {
    localStorage.setItem(
      this.localStorageRequestsPreviousSearchId,
      JSON.stringify(this.searchFilter)
    );
  }

  /**
   * Get Previous Search from Local Storage
   */
  private getPreviousSearchFromLocalStorage(): SearchFilter {
    return JSON.parse(
      localStorage.getItem(this.localStorageRequestsPreviousSearchId)
    );
  }

  /**
   * Select Filter From Filter List
   * @param filter Filter
   */
  public selectFilter(filter: Filter): void {
    this.appliedFilterList.push(new AppliedFilter(filter));
    this.enableOrDisableFilter(filter, true);
  }

  /**
   * Enable/Disable Filter In Filter List
   * @param filter Filter
   * @param state to enable or disable filter
   */
  private enableOrDisableFilter(filter: Filter, state: boolean): void {
    this.filterList = this.filterList.map((availableFilter: Filter) => {
      if (filter.id === availableFilter.id) {
        return {
          ...filter,
          isDisabled: state,
        };
      }
      return availableFilter;
    });
  }

  /**
   * Reset Filters
   */
  public resetFilters(): void {
    this.activeFilterList = [];
    this.appliedFilterList = [];
    this.searchFilter = new SearchFilter();
    this.reEnableFilters();
  }

  /**
   * Reset Filter List to "Enabled" state
   */
  private reEnableFilters(): void {
    this.filterList = this.filterList.map((filter: Filter) => {
      if (filter.isDisabled) {
        return {
          ...filter,
          isDisabled: false,
        };
      }
      return filter;
    });
  }

  /**
   * Checks Input Validity
   * @param appliedFilter
   */
  public checkInputValidity(appliedFilter: AppliedFilter): boolean {
    return (
      !appliedFilter.value ||
      appliedFilter.value === null ||
      appliedFilter.value === 'null' ||
      appliedFilter.value.length === 0
    );
  }

  /**
   * Confirm Filter
   * @param filter selected Filter to confirm
   */
  public confirmFilter(filter: AppliedFilter): void {
    this.activeFilterList.push(filter);
    this.removeEditableFilter(filter, false);
    this.createFilterObject();
    this.searchEvent.emit(this.searchFilter);
    this.eventFilter = true;
    this.savePreviousSearchToLocalStorage();
  }

  /**
   * Create Search Filter Object
   */
  private createFilterObject(): void {
    this.searchFilter = new SearchFilter();
    this.activeFilterList.forEach((filter: AppliedFilter) => {
      this.searchFilter = {
        ...this.searchFilter,
        [filter.filter.id]: filter.value,
      };
    });
    this.loadFilterPreset(this.searchFilter);
  }

  /**
   * Remove Editable Filter
   * @param filterToRemove Filter to Remove
   */
  public removeEditableFilter(
    filterToRemove: AppliedFilter,
    reEnable: boolean
  ): void {
    this.appliedFilterList = this.appliedFilterList.filter(
      (filter: AppliedFilter) => filter.filter.id !== filterToRemove.filter.id
    );
    if (reEnable) {
      this.enableOrDisableFilter(filterToRemove.filter, false);
    }
  }

  /**
   * Remove Filter Chip
   * @param filterToRemove Filter to Remove
   */
  public removeFilterChip(filterToRemove: AppliedFilter): void {
    this.activeFilterList = this.activeFilterList.filter(
      (filter: AppliedFilter) => filter.filter.id !== filterToRemove.filter.id
    );
    this.enableOrDisableFilter(filterToRemove.filter, false);
    this.createFilterObject();
    this.searchEvent.emit(this.searchFilter);
    this.savePreviousSearchToLocalStorage();
  }

  /**
   * Reset Filters
   */
  public reset(): void {
    this.resetFilters();
    if (this.eventFilter) {
      this.createFilterObject();
      this.searchEvent.emit(this.searchFilter);
      this.eventFilter = false;
      this.savePreviousSearchToLocalStorage();
    }
  }

  /**
   * Roll-back the filter configuration
   */
  public rollBack(): void {
    if (this.canRollBack() && this.getPreviousSearchFromLocalStorage()) {
      this.resetFilters();
      this.loadFilterPreset(this.getPreviousSearchFromLocalStorage());
    }
  }

  /**
   * Check if the Search action can be RollBack
   */
  public canRollBack(): boolean {
    return (
      this.environmentConfigRequestsAdvancedFilter.rollBack &&
      this.appliedFilterList?.length !== 0 &&
      JSON.stringify(this.getPreviousSearchFromLocalStorage()) !==
        JSON.stringify(new SearchFilter())
    );
  }

  /**
   * Check if the Search action can be Reset
   */
  public canReset(): boolean {
    return this.environmentConfigRequestsAdvancedFilter.reset;
  }

  /**
   * Check if is Partial Validation
   */
  public isPartialValidation(): boolean {
    return this.environmentConfigRequestsAdvancedFilter.validation.partial;
  }

  /**
   * Load Filter Preset from previous Search
   * @param eventSearch Previous Search
   */
  private loadFilterPreset(eventSearch: SearchFilter): void {
    const presetActiveTable: AppliedFilter[] = [];
    for (const [key, value] of Object.entries(eventSearch)) {
      if (value !== '') {
        const foundFilter = this.searchFilterById(key as FilterTypes);
        if (foundFilter) {
          presetActiveTable.push(new AppliedFilter(foundFilter, value));
          this.enableOrDisableFilter(foundFilter, true);
        }
      }
    }
    this.activeFilterList = presetActiveTable;
  }

  /**
   * Search Filter By ID
   * @param filterId Filter ID
   */
  private searchFilterById(filterId: FilterTypes): Filter | undefined {
    return this.filterList.find(
      (availableFilter: Filter) => availableFilter.id === filterId
    );
  }

  /**
   * On User Input Change
   * @param event User Input Event
   */
  onUserInputChange(event: string): void {
    this.userList = [];
    if (event.length > this.minLengthTerm) {
      this.isLoading = true;
      this.subscription.add(
        this.advancedFilterService
          .getUsers(event)
          .pipe(
            finalize(() => {
              this.isLoading = false;
            })
          )
          .subscribe(
            (result: UserSearchResult) => {
              this.userList = !result.users.data ? [] : [...result.users.data];
            },
            (error: HttpErrorResponse) => {
              this.snackBarMessageService.error({
                message: this.commonErrorsService.getCommonRequestError(error),
                action: null,
                duration: 1000,
              });
            }
          )
      );
    }
  }

  /**
   *  On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
