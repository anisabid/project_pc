import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@shared/shared.module';
import { AdvancedFilterComponent } from './advanced-filter.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatAutocompleteModule } from '@angular/material/autocomplete';

@NgModule({
  declarations: [AdvancedFilterComponent],
  imports: [CommonModule, SharedModule, FormsModule, ReactiveFormsModule, MatFormFieldModule, MatAutocompleteModule],
  exports: [AdvancedFilterComponent],
})
export class AdvancedFilterModule {}
