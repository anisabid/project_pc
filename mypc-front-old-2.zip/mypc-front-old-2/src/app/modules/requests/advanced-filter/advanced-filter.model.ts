/**
 * Filter Types
 */
export enum FilterTypes {
  STATUS = 'status',
  REQUESTER = 'emet',
  ELEMENT = 'element',
  RESUME = 'resume',
  FOLDER_NUMBER = 'req',
  RECIPIENT = 'benef',
  GROUP = 'grp',
  START_DATE = 'date_begin',
  END_DATE = 'date_end',
}

/**
 * Filter Input Format
 */
export enum FilterFormat {
  TEXT,
  DATE,
  SELECT,
  AUTOCOMPLETE,
}

/**
 * Filter Item
 */
export class Filter {
  id: FilterTypes;
  name: string;
  format: FilterFormat;
  isDisabled: boolean;

  /**
   * Constructor
   * @param id ID
   * @param name Name
   * @param format Filter Format
   * @param isDisabled Is Disabled
   */
  constructor(
    id: FilterTypes,
    name: string,
    format: FilterFormat = FilterFormat.TEXT,
    isDisabled: boolean = false
  ) {
    this.id = id;
    this.name = name;
    this.format = format;
    this.isDisabled = isDisabled;
  }
}

/**
 * Applied Filter Item
 */
export class AppliedFilter {
  filter: Filter;
  value: string;

  constructor(filter: Filter, value: string = undefined) {
    this.filter = filter;
    this.value = value;
  }
}

/**
 * Search Filter Object
 */
export class SearchFilter {
  resume: string;
  element: string;
  status: string;
  emet: string;
  benef: string;
  date_begin: string;
  date_end: string;
  req: string;
  grp: string;

  constructor(
    resume: string = '',
    element: string = '',
    status: string = '',
    emet: string = '',
    benef: string = '',
    date_begin: string = '',
    date_end: string = '',
    req: string = '',
    grp: string = ''
  ) {
    this.resume = resume;
    this.element = element;
    this.status = status;
    this.emet = emet;
    this.benef = benef;
    this.date_begin = date_begin;
    this.date_end = date_end;
    this.req = req;
    this.grp = grp;
  }
}

/**
 * Available Filter List
 */
export const availableFilterList: Filter[] = [
  new Filter(
    FilterTypes.START_DATE,
    'i18n.module.requests.components.list.filter.date_begin',
    FilterFormat.DATE
  ),
  new Filter(
    FilterTypes.END_DATE,
    'i18n.module.requests.components.list.filter.date_end',
    FilterFormat.DATE
  ),
  new Filter(
    FilterTypes.RESUME,
    'i18n.module.requests.components.list.filter.resume'
  ),
  new Filter(
    FilterTypes.ELEMENT,
    'i18n.module.requests.components.list.filter.element'
  ),
  new Filter(
    FilterTypes.STATUS,
    'i18n.module.requests.components.list.filter.status',
    FilterFormat.SELECT
  ),
  new Filter(
    FilterTypes.FOLDER_NUMBER,
    'i18n.module.requests.components.list.filter.req'
  ),
  new Filter(
    FilterTypes.REQUESTER,
    'i18n.module.requests.components.list.filter.emet',
    FilterFormat.AUTOCOMPLETE
  ),
  new Filter(
    FilterTypes.RECIPIENT,
    'i18n.module.requests.components.list.filter.benef',
    FilterFormat.AUTOCOMPLETE
  ),
  new Filter(
    FilterTypes.GROUP,
    'i18n.module.requests.components.list.filter.grp'
  ),
];
