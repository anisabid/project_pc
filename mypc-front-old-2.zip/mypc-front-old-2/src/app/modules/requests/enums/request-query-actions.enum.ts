/**
 * Request Query Actions Enum
 */
export enum RequestQueryActions {
  REQUESTS = 'requests',
  REQUESTS_HISTORY = 'requests_histories',
  ACTIONS = 'actions',
  ACTIONS_HISTORY = 'actions_histories',
}
