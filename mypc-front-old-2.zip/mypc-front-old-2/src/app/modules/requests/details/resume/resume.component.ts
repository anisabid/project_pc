import { Component, Input } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './../../i18n/fr';

@Component({
  selector: 'sfr-resume',
  templateUrl: './resume.component.html',
  styleUrls: ['./resume.component.scss'],
})
export class ResumeComponent {
  @Input() resume;

  constructor(private translationLoaderService: TranslationLoaderService) {
    this.translationLoaderService.loadTranslations(localFrench);
  }
}
