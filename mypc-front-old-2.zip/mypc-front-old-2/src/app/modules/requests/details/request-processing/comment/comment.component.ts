import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import {
  FormGroup,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { DataType } from '@app/modules/requests/enums/dataType.enum';
import { RequestQueryActions } from '@app/modules/requests/enums/request-query-actions.enum';
import { RequestsService } from '@app/modules/requests/requests.service';
import { SnackBarMessageService } from '@shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@shared/services/errors/common-errors.service';
import { User } from '@shared/models/user';
import { ApiService } from '@shared/services/api/v2/api.service';
import { SessionService } from '@shared/services/session/session.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'sfr-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.scss'],
})
export class CommentComponent implements OnInit, OnDestroy {
  @Input() comments;
  @Input() isComplement: boolean = false;
  @Input() isAnswer: boolean = false;
  @Input() idAction: any;
  @Input() currentStep;
  @Input() actionType: RequestQueryActions;

  public vfile = undefined;
  isShowConversation: boolean = false;
  addComment: boolean = true;
  items = Array.from({ length: 100000 }).map((_, i) => `Item #${i}`);

  public user: User;
  public commentFG: UntypedFormGroup = new FormGroup({});
  private subscription: Subscription = new Subscription();
  private dataType: DataType;
  public showNoteButton: boolean = true;

  /**
   * Constructor
   * @param sessionService Session Service
   * @param apiService API Service
   * @param requestsService Requests Service
   * @param formBuilder Form Builder
   * @param router Router
   * @param snackBarMessageService Snackbar Message Service
   * @param commonErrorsService Common Errors Service
   */
  constructor(
    private sessionService: SessionService,
    private apiService: ApiService,
    private requestsService: RequestsService,
    private formBuilder: UntypedFormBuilder,
    private router: Router,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService
  ) {
    this.user = this.sessionService.user;
  }

  /**
   * Init Function
   */
  ngOnInit(): void {
    this.getAvatars();
    this.commentFG = this.commentFormInit();
  }

  /**
   * Check if it's a conversation start
   */
  isStartConversation(): void {
    this.dataType = DataType.NOTE;
    this.isShowConversation = true;
    this.showNoteButton = false;
    this.isAnswer = false;
    this.isComplement = false;
  }

  /**
   * Check if it's a Comment Answer
   */
  isShowAddCommentAnswer(): void {
    this.dataType = DataType.ACTION;
    this.isAnswer = false;
    this.isComplement = false;
    this.showNoteButton = false;
  }

  /**
   * Check if it's a Information Complement
   */
  isShowAddCommentComplement(): void {
    this.dataType = DataType.ACTION;
    this.isComplement = false;
    this.isAnswer = false;
    this.showNoteButton = false;
  }

  /**
   * Check if is current user
   * @param perId person ID
   */
  isCurrentUser(perId): boolean {
    return perId.includes(this.user.perId);
  }

  /**
   * Init Comment Form
   */
  commentFormInit(): UntypedFormGroup {
    return this.formBuilder.group({
      note: ['', Validators.required],
      vfile: [''],
    });
  }

  /**
   * Add Note
   */
  addNote(): void {
    const idDemande = localStorage.getItem('idRequest');
    const formData = new FormData();
    formData.append('vfile', this.vfile);
    formData.append('note', this.commentFG.get('note').value);
    this.subscription.add(
      this.requestsService
        .postAddCommentLifeCycle(idDemande, formData)
        .subscribe(
          (result) => {
            result?.requests?.note?.success === 'true'
              ? this.snackBarMessageService.success({
                  message: 'Votre note a été envoyée avec succès !',
                  action: null,
                  duration: 1000,
                })
              : this.snackBarMessageService.error({
                  message: "Echec d'envoi du note",
                  action: null,
                  duration: 1000,
                });
            this.reloadCurrentRoute();
          },
          (error: HttpErrorResponse) => {
            this.snackBarMessageService.error({
              message: this.commonErrorsService.getCommonRequestError(error),
              action: null,
              duration: 1000,
            });
            this.reloadCurrentRoute();
          }
        )
    );
  }

  /**
   * Add Action
   */
  addAction(): void {
    const idDemande = localStorage.getItem('idRequest');
    const formData = new FormData();
    formData.append('vfile', this.vfile);
    formData.append('user_comment', this.commentFG.get('note').value);
    formData.append('wf_status', this.idAction.id);
    formData.append('lmd', this.idAction.dateUpdate);

    this.subscription.add(
      this.requestsService.postActionLifeCycle(idDemande, formData).subscribe(
        (result) => {
          result?.requests?.action?.success === 'true'
            ? this.snackBarMessageService.success({
                message: 'Votre note a été envoyée avec succès !',
                action: null,
                duration: 1000,
              })
            : this.snackBarMessageService.error({
                message: "Echec d'envoi du note",
                action: null,
                duration: 1000,
              });
          this.reloadCurrentRoute();
        },
        (error: HttpErrorResponse) => {
          this.snackBarMessageService.error({
            message: this.commonErrorsService.getCommonRequestError(error),
            action: null,
            duration: 1000,
          });
          this.reloadCurrentRoute();
        }
      )
    );
  }

  /**
   * Send Data
   */
  sendData(): void {
    if (this.dataType === DataType.ACTION) {
      if (this.idAction) {
        this.addAction();
      }
    } else {
      this.addNote();
    }
  }

  /**
   * On File Change
   * @param event Event
   */
  onFileChange(event): void {
    if (event.target.files && event.target.files.length) {
      this.vfile = event.target.files[0];
    }
  }

  /**
   * Get Users Avatars
   */
  getAvatars(): void {
    if (this.comments) {
      const uids = [...new Set(this.comments.map((item) => item.user_uperid))]; // table of unique uids for comments
      uids.forEach((user: string) => {
        // For each uid we recover the avatar with the api
        this.subscription.add(
          this.apiService.users
            .getAvatar({ uPerId: user })
            .subscribe((result: { avatar: string }) => {
              this.comments
                .filter((comment) => comment.user_uperid == user)
                .forEach((element) => {
                  element.avatarStyle = this.getStyleBackgroundImageAvatar(
                    result.avatar
                  );
                  element.avatar = !(element.avatarStyle == '');
                }); // For each comment, we attribute a style depending on the user
            })
        );
      });
    }
  }

  /**
   * Get Background Avatar
   * @param value value
   */
  getStyleBackgroundImageAvatar(value: string) {
    return value
      ? 'background-image: url("data:image/png;base64,' + value + '");'
      : '';
  }

  /**
   * Reload Current Route
   */
  reloadCurrentRoute(): void {
    const currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigateByUrl(currentUrl, {
        state: {
          actionType: this.actionType,
        },
      });
    });
  }

  /**
   * Get File URL
   * @param filePath Relative file path
   */
  getFileURL(filePath: string): string {
    return filePath && filePath !== ''
      ? this.requestsService.getFullFileURL(filePath)
      : '';
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
