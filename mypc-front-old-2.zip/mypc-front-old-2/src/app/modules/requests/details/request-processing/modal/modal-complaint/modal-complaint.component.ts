import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import {
  AbstractControl,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RequestsService } from '@app/modules/requests/requests.service';
import { SnackBarMessageService } from '@shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@shared/services/errors/common-errors.service';

@Component({
  selector: 'sfr-modal-complaint',
  templateUrl: './modal-complaint.component.html',
  styleUrls: ['./modal-complaint.component.scss'],
})
export class ModalComplaintComponent implements OnInit {
  change: any;
  public complaintForm: UntypedFormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ModalComplaintComponent>,
    private formBuilder: UntypedFormBuilder,
    private requestsService: RequestsService,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.change = this.data.change;
    this.complaintForm = this.createForm();
  }

  /**
   * Create Complaint Form
   */
  createForm(): UntypedFormGroup {
    return this.formBuilder.group({
      complaintDescription: ['', Validators.required],
    });
  }

  /**
   * Submit Complaint
   */
  submitComplaint(): void {
    if (this.complaintForm.valid && this.complaintDescription?.value !== '') {
      this.requestsService
        .postComplaintRequest(
          this.change.change_id,
          this.complaintDescription.value
        )
        .subscribe(
          (result) => {
            result?.requests?.action?.success === 'true'
              ? this.snackBarMessageService.success({
                  message: 'Votre réclamation a été envoyée avec succès !',
                  action: null,
                  duration: 1000,
                })
              : this.snackBarMessageService.error({
                  message: "Echec d'envoi de réclamation",
                  action: null,
                  duration: 1000,
                });
            this.reloadCurrentRoute();
          },
          (error: HttpErrorResponse) => {
            this.snackBarMessageService.error({
              message: this.commonErrorsService.getCommonRequestError(error),
              action: null,
              duration: 1000,
            });
            this.reloadCurrentRoute();
          }
        );
      this.dialogRef.close();
    }
  }

  /**
   * Reload Current Route
   */
  reloadCurrentRoute(): void {
    const currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigateByUrl(currentUrl, {
        state: {
          actionType: this.data.actionType,
        },
      });
    });
  }

  get complaintDescription(): AbstractControl {
    return this.complaintForm.get('complaintDescription');
  }
}
