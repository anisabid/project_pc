import { Component, Input } from '@angular/core';
import { RequestQueryActions } from '@app/modules/requests/enums/request-query-actions.enum';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './../../../i18n/fr';

@Component({
  selector: 'sfr-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.scss'],
})
export class LifeCycleComponent {
  @Input() numFolder;
  @Input() resume;
  @Input() actionType: RequestQueryActions;

  constructor(private translationLoaderService: TranslationLoaderService) {
    this.translationLoaderService.loadTranslations(localFrench);
  }
}
