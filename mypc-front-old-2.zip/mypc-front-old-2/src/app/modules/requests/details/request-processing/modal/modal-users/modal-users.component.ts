import {Component, Inject, OnInit, ViewEncapsulation} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";

@Component({
  selector: 'sfr-modal-users',
  templateUrl: './modal-users.component.html',
  styleUrls: ['./modal-users.component.scss'],
    encapsulation: ViewEncapsulation.None,

})
export class ModalUsersComponent implements OnInit {
 users;
  constructor(
      @Inject(MAT_DIALOG_DATA) public data: any,
      public dialogRef: MatDialogRef<ModalUsersComponent>,
  ) { }

  ngOnInit(): void {
    this.users = this.data.users;
  }



}
