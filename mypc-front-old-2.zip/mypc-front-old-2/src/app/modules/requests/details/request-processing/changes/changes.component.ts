import { Component, Input } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from '@app/modules/requests/i18n/fr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ModalComplaintComponent } from '../modal/modal-complaint/modal-complaint.component';
import { RequestQueryActions } from '@app/modules/requests/enums/request-query-actions.enum';

@Component({
  selector: 'sfr-changes',
  templateUrl: './changes.component.html',
  styleUrls: ['./changes.component.scss'],
})
export class ChangesComponent {
  @Input() changes;
  @Input() actionType: RequestQueryActions;

  /**
   * Constructor
   * @param translationLoaderService Translation Loader Service
   * @param matDialog Material Dialog
   */
  constructor(
    private translationLoaderService: TranslationLoaderService,
    private matDialog: MatDialog
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
  }

  /**
   * Check if the change is a complaint
   * @param complaint change to verify
   * @param isShowComplaint determine if to show/hide
   */
  isComplaint(complaint: boolean, isShowComplaint: boolean): boolean {
    return complaint && isShowComplaint;
  }

  /**
   * Insert Line Breaks to replace <br>
   * @param comment Comment to format
   */
  insertLineReturn(comment: string): string {
    return comment && comment !== ''
      ? comment.replace(/<\s*\/?br>/gi, '\r\n')
      : '';
  }

  /**
   * Get Arrow Position Icon
   * @param show determines show/hide mode
   */
  getArrowPosition(show: boolean): string {
    return show ? 'keyboard_arrow_up' : 'keyboard_arrow_down';
  }

  /**
   * Open a file new Complaint Dialog
   */
  public complaintAction(change: any): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.data = { change, actionType: this.actionType };
    dialogConfig.autoFocus = false;
    this.matDialog.open(ModalComplaintComponent, dialogConfig);
  }
}
