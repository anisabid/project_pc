import {
  Component,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { BusIframe } from '@shared/models/bus-iframe';
import { RequestsService } from '@app/modules/requests/requests.service';
import { RequestQueryActions } from '@app/modules/requests/enums/request-query-actions.enum';
import { Subscription } from 'rxjs';
import { JsonHelper } from '@shared/helpers/json.helper';

@Component({
  selector: 'sfr-compete-details',
  templateUrl: './compete-details.component.html',
  styleUrls: ['./compete-details.component.scss'],
})
export class CompeteDetailsComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  status;
  changes;
  actions;
  isSowComplement = false;
  isShowAnswer = false;
  idAction;
  resume;
  @Input() actionType: RequestQueryActions;

  public idRequest;

  constructor(private requestsService: RequestsService) {}

  ngOnInit(): void {
    this.getRequestId();
    this.getLifeCycle();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle() {
    this.subscription.add(
      this.requestsService
        .getLifeCycle(RequestQueryActions.REQUESTS, this.idRequest)
        .subscribe((result) => {
          this.status = result.requests.status;
          this.changes = result.requests.changes;
          this.actions = result.requests.actions;
          this.resume = result.requests.resume;
          this.isComplement(this.actions);
        })
    );
  }

  /**
   * Get Request ID
   */
  getRequestId(): void {
    this.idRequest = +localStorage.getItem('idRequest');
  }

  @HostListener('window:message', ['$event'])
  onMessage(event) {
    let data: BusIframe;
    if (event && event.data && JsonHelper.isJson(event.data)) {
      data = new BusIframe(JSON.parse(event.data));
    }

    if (data && data.actions) {
      if (data.hasAction('CLOSE_MATDIALOG')) {
        // traitement
        this.getLifeCycle();
      }
    }
  }

  isComplement(actions) {
    if (actions) {
      for (let i = 0; i <= actions.length; i++) {
        if (
          this.actions[i] &&
          actions[i].libelle_btn.includes(
            "Demander un complément d'information"
          )
        ) {
          this.isSowComplement = true;
          this.idAction = {
            id: actions[i].id_action,
            dateUpdate: this.resume.lmd,
          };
        }
        if (
          this.actions[i] &&
          actions[i].libelle_btn.includes(
            "Répondre au complément d'information"
          )
        ) {
          this.isShowAnswer = true;
          this.idAction = {
            id: actions[i].id_action,
            dateUpdate: this.resume.lmd,
          };
        }
      }
    }
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
