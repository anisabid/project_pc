import { Component, HostListener, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { BusIframe } from '@shared/models/bus-iframe';

@Component({
  selector: 'sfr-origin-form',
  templateUrl: './origin-form.component.html',
  styleUrls: ['./origin-form.component.scss'],
})
export class OriginFormComponent implements OnInit {
  public idRequest;
  public src: SafeResourceUrl;

  constructor(private urlHelperService: UrlHelperService, private domSanitizer: DomSanitizer) {}

  @HostListener('window:message', ['$event'])
  onMessage(event) {
    const data: BusIframe = new BusIframe(JSON.parse(event.data));
    if (data && data.actions) {
      if (data.hasAction('CLOSE_MATDIALOG')) {
        // traitement
        this.ngOnInit();
      }
    }
  }

  public ngOnInit(): void {
    this.processedDocument();
  }

  /**
   * Create IFrame link source
   */
  processedDocument(): void {
    let url = this.urlHelperService.transformParameters('mypc/index.php?p=ps%2Fview_form&item_id=${id}', {
      '${id}': localStorage.getItem('idRequest'),
    });
    this.src = this.domSanitizer.bypassSecurityTrustResourceUrl(this.urlHelperService.toBackOffice(url));
  }
}
