import {
  AfterContentInit,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RequestTitleService } from '@app/modules/requests/list/request-title.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ModalActionsComponent } from '@app/modules/requests/details/request-processing/modal/modal-actions/modal-actions.component';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { Subscription } from 'rxjs';
import { RequestsService } from '../requests.service';
import { RequestQueryActions } from '../enums/request-query-actions.enum';
import {
  EnumRequestsRoutesPath,
  EnumRequestTypePath,
} from '../const/request.const.routes';

@Component({
  selector: 'sfr-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss'],
})
export class DetailsComponent implements OnInit, AfterContentInit, OnDestroy {
  private subscription: Subscription = new Subscription();
  public idRequest: string;
  public titleRequest: string;
  public statusCode: string;
  public actionType: RequestQueryActions;
  resume;
  numFolder;
  status;
  changes;
  actions;

  /**
   * Constructor
   * @param route Route
   * @param titleService Title Service
   * @param cdref CdRef
   * @param requestsService Requests Service
   * @param matDialog Material Dialog
   */
  constructor(
    private route: ActivatedRoute,
    private titleService: RequestTitleService,
    private cdref: ChangeDetectorRef,
    private requestsService: RequestsService,
    private matDialog: MatDialog,
    private router: Router
  ) {
    this.actionType =
      this.router.getCurrentNavigation()?.extras?.state?.actionType;
  }

  /**
   * On Init
   */
  ngOnInit(): void {
    this.getRequestId();
    this.getLifeCycle();
    this.getTitle();
    this.getStatusCode();
  }

  /**
   * Get Request ID
   */
  getRequestId(): void {
    this.idRequest = this.route.snapshot.paramMap.get('idRequest');
    window.localStorage.removeItem('idRequest');
    localStorage.setItem('idRequest', this.idRequest);
  }

  /**
   * Get Title
   */
  getTitle(): void {
    this.subscription.add(
      this.titleService.titleSubject.subscribe((title: string) => {
        this.titleRequest = title;
      })
    );
  }

  /**
   * Get Status Code
   */
  getStatusCode(): void {
    this.subscription.add(
      this.titleService.statusCode.subscribe((status: string) => {
        this.statusCode = status;
      })
    );
  }

  /**
   * After Content Init
   */
  ngAfterContentInit(): void {
    this.cdref.detectChanges();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle(): void {
    this.subscription.add(
      this.requestsService
        .getLifeCycle(RequestQueryActions.REQUESTS, this.idRequest)
        .subscribe((result) => {
          this.resume = result.requests.resume;
          this.actions = result.requests.actions;
          this.titleService.sendTitle(this.resume.object);
          this.titleService.sendStatus(this.resume.etape_code);
          this.numFolder = this.resume.req_id;
        })
    );
  }

  /**
   * Select Action
   * @param data Data
   */
  public selectAction(data): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.width = '30vw';
    dialogConfig.data = {
      action: data,
      idRequest: this.numFolder,
      dateUpdate: this.resume.lmd,
    };
    this.matDialog.open(ModalActionsComponent, dialogConfig);
  }

  /**
   * Get Return Route
   */
  get getReturnRoute(): string {
    let subRoute: string;
    switch (this.actionType) {
      case RequestQueryActions.REQUESTS:
        subRoute = `/${EnumRequestsRoutesPath.REQUESTS}`;
        break;
      case RequestQueryActions.REQUESTS_HISTORY:
        subRoute = `/${EnumRequestsRoutesPath.REQUESTS}/${EnumRequestTypePath.HISTORY}`;
        break;
      case RequestQueryActions.ACTIONS:
        subRoute = `/${EnumRequestsRoutesPath.APPROVALS}`;
        break;
      case RequestQueryActions.ACTIONS_HISTORY:
        subRoute = `/${EnumRequestsRoutesPath.APPROVALS}/${EnumRequestTypePath.HISTORY}`;
        break;
      default:
        subRoute = '';
    }
    return `/${ConstRoutesPath.REQUESTS}` + subRoute;
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
