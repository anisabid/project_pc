import { Component, OnDestroy, OnInit } from '@angular/core';
import { Source } from '@shared/models/source';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './../../i18n/fr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ModalActionComponent } from './../modal/modal-action/modal-action.component';
import { Request, RequestResult } from '@shared/models/request';
import { PageEvent } from '@angular/material/paginator';
import { ActionEvent } from '@shared/models/action-event';
import { ActionsService } from '@shared/services/actions/actions.service';
import { Router } from '@angular/router';
import {
  EnumRequestsRoutesPath,
  EnumRequestTypePath,
} from '../../const/request.const.routes';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import {
  FilterTypes,
  SearchFilter,
} from '../../advanced-filter/advanced-filter.model';
import { RequestsService } from '../../requests.service';
import { Subscription } from 'rxjs';
import { RequestQueryActions } from '../../enums/request-query-actions.enum';
import { SnackBarMessageService } from '@shared/modules/snack-bar-message/snack-bar-message.service';
import { HttpErrorResponse } from '@angular/common/http';
import { CommonErrorsService } from '@shared/services/errors/common-errors.service';

@Component({
  selector: 'sfr-my-requests',
  templateUrl: './my-requests.component.html',
})

/**
 * Current/History Request List Component
 */
export class MyRequestsComponent implements OnInit, OnDestroy {
  public dataSource: { actions: Source; requests: Source };
  public show = false;
  private isHistory: boolean;
  public action: RequestQueryActions;
  public itemsFilter: SearchFilter;
  private subscription: Subscription = new Subscription();

  private defaultPageSize = 10;
  public totalRows = 0;
  public pageSize = this.defaultPageSize;
  public currentPage = 0;
  public offsetPage = 0;
  public pageSizeOptions = [5, 10, 25, 100];

  /**
   * Filter List for Advanced Filter
   */
  public filterItemList: FilterTypes[] = [
    FilterTypes.REQUESTER,
    FilterTypes.RECIPIENT,
    FilterTypes.FOLDER_NUMBER,
    FilterTypes.STATUS,
    FilterTypes.ELEMENT,
    FilterTypes.RESUME,
    FilterTypes.START_DATE,
    FilterTypes.END_DATE,
  ];

  /**
   * Constructor
   * @param translationLoaderService Translation Loader Service
   * @param requestsService Requests Service
   * @param matDialog Mat Dialog
   * @param actionsService Actions Service
   * @param router Router
   * @param snackBarMessageService Material SnackBar Message Service
   * @param commonErrorsService Common Request Error Service
   */
  constructor(
    private translationLoaderService: TranslationLoaderService,
    private requestsService: RequestsService,
    private matDialog: MatDialog,
    private actionsService: ActionsService,
    private router: Router,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.dataSource = { actions: new Source(), requests: new Source() };
  }

  /**
   * On Init
   */
  ngOnInit(): void {
    this.setIsHistory();
    this.setAction();
    this.setPageTitle();
    this.getRequests();
  }

  /**
   * Get/Search Requests
   * @param filter Filter
   * @param limit Limit
   * @param offset Offset
   */
  getRequests(
    filter?: SearchFilter,
    limit: number = this.pageSize > 0 ? this.pageSize : this.defaultPageSize,
    offset: number = 0
  ): void {
    this.show = true;
    this.currentPage =
      JSON.stringify(filter) === JSON.stringify(this.itemsFilter)
        ? this.currentPage
        : 0;
    this.itemsFilter = filter ? filter : undefined;
    this.dataSource.actions.requestSent;

    this.subscription.add(
      this.requestsService
        .getRequests(this.action, limit, offset, this.itemsFilter)
        .subscribe(
          (result: RequestResult) => {
            this.show = false;
            this.dataSource.requests = new Source(result?.requests);
            this.dataSource.actions = new Source(result?.actions);
            this.pageSize = this.dataSource.requests.limit;
            this.totalRows = this.dataSource.requests.total;
            this.offsetPage = this.dataSource.requests.offset;
          },
          (error: HttpErrorResponse) => {
            this.show = false;
            this.snackBarMessageService.error({
              message: this.commonErrorsService.getCommonRequestError(error),
              action: null,
              duration: 1000,
            });
          }
        )
    );
  }

  /**
   * Request Select Action
   * @param selectedRequest Selected Request
   */
  public selectRequest(selectedRequest = null): void {
    const request = new Request(selectedRequest);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.maxWidth = '96vw';
    dialogConfig.data = {
      title: request.resume,
      action: request.paramItem,
    };
    this.matDialog.open(ModalActionComponent, dialogConfig);
  }

  /**
   * On Page Changed Event
   * @param event Event
   */
  pageChanged(event: PageEvent): void {
    this.currentPage = this.pageSize !== event.pageSize ? 0 : event.pageIndex;
    this.pageSize = event.pageSize;
    const offset = this.currentPage * this.pageSize;
    this.getRequests(this.itemsFilter, this.pageSize, offset);
  }

  /**
   * Apply Request Title
   * @param title Title
   */
  actionEvent(title: string): void {
    this.actionsService.onEvents.next(
      new ActionEvent({
        component: 'component.request.list',
        key: 'title',
        value: title,
      })
    );
  }

  /**
   * Navigate to Request Life cycle
   * @param requestId Request ID
   */
  navigate(requestId: string): string {
    return `/${ConstRoutesPath.REQUESTS}/${EnumRequestsRoutesPath.LIFECYCLE}/${requestId}`;
  }

  /**
   * Set Requests Data Mode
   */
  setIsHistory(): void {
    this.isHistory = !!this.router.url.includes(EnumRequestTypePath.HISTORY);
  }

  /**
   * Set Action
   */
  setAction(): void {
    this.action = this.isHistory
      ? RequestQueryActions.REQUESTS_HISTORY
      : RequestQueryActions.REQUESTS;
  }

  /**
   * SetPageTitle
   */
  setPageTitle(): void {
    this.actionEvent(
      this.isHistory
        ? 'i18n.module.requests.history_demande'
        : 'i18n.module.requests.request'
    );
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
