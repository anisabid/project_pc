import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './../i18n/fr';
import { ActionsService } from '@shared/services/actions/actions.service';
import { ActionEvent } from '@shared/models/action-event';
import { Subscription } from 'rxjs';
import {
  EnumRequestsRoutesPath,
  EnumRequestTypePath,
} from '../const/request.const.routes';
import { NavigationEnd, Router } from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';

@Component({
  selector: 'sfr-list',
  templateUrl: './list.component.html',
})

/**
 * Request List Main Component
 */
export class ListComponent implements OnInit, OnDestroy {
  /**
   * Title
   */
  titleRequest: string;
  /**
   * Subscription
   */
  private subscription: Subscription = new Subscription();
  /**
   * Check if is History mode
   */
  isHistory: boolean = false;
  /**
   * Routes Enum
   */
  EnumRequestsRoutesPath = EnumRequestsRoutesPath;

  /**
   * Constructor
   * @param translationLoaderService Translation Loader Service
   * @param actionsService Actions Service
   * @param router Router
   */
  constructor(
    private translationLoaderService: TranslationLoaderService,
    private actionsService: ActionsService,
    private router: Router
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
  }

  /**
   * On Init
   */
  ngOnInit(): void {
    this.setIsHistory(); // Check On Init
    this.routerChangeListener(); // Check when if route changed
    this.getTitle();
  }

  /**
   * Get Title
   */
  getTitle(): void {
    this.subscription.add(
      this.actionsService.onEvents.subscribe((actionEvent: ActionEvent) => {
        if (
          actionEvent.component === 'component.request.list' &&
          actionEvent.key === 'title'
        ) {
          this.titleRequest = actionEvent.value.toString();
        }
      })
    );
  }

  /**
   * Listen to route change
   */
  private routerChangeListener(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.setIsHistory();
      }
    });
  }

  /**
   * Set Requests Data Mode
   */
  private setIsHistory(): void {
    this.isHistory = !!this.router.url.includes(EnumRequestTypePath.HISTORY);
  }

  /**
   * Get Requests/Approvals Route when switching
   * between Current and History
   * @param requestType Request Type (Requests/Approvals)
   */
  getRoute(requestType: EnumRequestsRoutesPath): string {
    return this.isHistory
      ? `/${ConstRoutesPath.REQUESTS}/${requestType}/${EnumRequestTypePath.HISTORY}`
      : `/${ConstRoutesPath.REQUESTS}/${requestType}`;
  }

  /**
   * Get Return Route
   */
  get getReturnRoute(): string {
    return !!this.router.url.includes(EnumRequestsRoutesPath.REQUESTS)
      ? `/${ConstRoutesPath.REQUESTS}/${EnumRequestsRoutesPath.REQUESTS}`
      : `/${ConstRoutesPath.REQUESTS}/${EnumRequestsRoutesPath.APPROVALS}`;
  }

  /**
   * Get Tooltip text
   */
  get getTooltipText(): string {
    return !!this.router.url.includes(EnumRequestsRoutesPath.REQUESTS)
      ? 'i18n.module.requests.back_to_my_requests'
      : 'i18n.module.requests.back_to_my_approbations';
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
