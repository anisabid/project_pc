export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        applications: {
          name: 'Catalogue Applicatif',
          global: {},
        },
      },
    },
  },
};
