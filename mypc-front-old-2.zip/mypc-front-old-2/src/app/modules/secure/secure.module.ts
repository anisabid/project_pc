import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { secureRoutingModule } from './secure-routing.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from '@shared/shared.module';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    secureRoutingModule,
    FlexLayoutModule,
    SharedModule,
    MatProgressSpinnerModule,
  ],
})
export class SecureModule {}
