import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '@core/services/authentication.service';
import {
  EnvironmentService,
  EnvironmentConfigLogin,
} from '@shared/services/environment/environment.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './i18n/fr';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { LoginForm } from '@shared/models/user';
import { SessionService } from '@shared/services/session/session.service';

@Component({
  selector: 'sfr-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm: UntypedFormGroup;
  isSubmitted = true;
  authFailedMessage: string;
  public showLoader: boolean;
  public environmentConfigLogin: EnvironmentConfigLogin;

  constructor(
    private router: Router,
    private fb: UntypedFormBuilder,
    private authenticationService: AuthenticationService,
    private environmentService: EnvironmentService,
    private translationLoaderService: TranslationLoaderService,
    private matSnackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute,
    private sessionService: SessionService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.showLoader = false;
    this.environmentConfigLogin = this.environmentService.config.modules.login;
  }

  ngOnInit(): void {
    if (
      this.authenticationService.isLoggedIn() &&
      this.authenticationService.isSessionExpired()
    ) {
      this.authenticationService.logoutClear();
    }
    this.loginForm = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  public onLogin() {
    this.showLoader = true;
    const user: LoginForm = {
      userName: this.loginForm.get('userName').value,
      password: this.loginForm.get('password').value,
    };

    this.authenticationService.login(user, this.accessEnvironment).subscribe(
      (data: HttpResponse<any>) => {
        const response = JSON.parse(data.body.login);
        if (response && response.success == false) {
          // show error message
          this.authFailedMessage = response.message;
          this.showLoader = false;
          this.matSnackBar.open(response.message, null, {
            duration:
              this.environmentService.config.modules.login
                .snackBarErrorDuration,
            verticalPosition: 'top',
            panelClass: 'mat-snack-bar-error',
          });
        } else {
          this.authFailedMessage = null;
          this.sessionService.init();
          /**
           * @todo remove redirect condition for partner
           */
          if (
            this.sessionService.session.user.isPartner &&
            this.environmentService.access.redirect.partner.enable
          ) {
            this.router.navigateByUrl(ConstRoutesPath.LOGOUT + '?partner=true');
          } else {
            this.router.navigateByUrl(ConstRoutesPath.DEFAULT);
          }

          //this.showLoader = false;
        }
        this.loginForm.reset();
      },
      (error) => {
        this.showLoader = false;
        this.matSnackBar.open(JSON.stringify(error), null, {
          duration:
            this.environmentService.config.modules.login.snackBarErrorDuration,
          verticalPosition: 'top',
          panelClass: 'mat-snack-bar-error',
        });
        console.error(error);
      }
    );
  }

  get accessEnvironment(): string {
    return this.environmentService.accessEnvironment(
      this.activatedRoute.snapshot.queryParams
    );
  }
}
