import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { LoginComponent } from './login.component';
import { LoginRoutingModule } from './login-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@shared/shared.module';
import { ControlMessagesComponent } from './control-messages/control-messages.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@NgModule({
  declarations: [LoginComponent, ControlMessagesComponent],
  imports: [CommonModule, LoginRoutingModule, FlexLayoutModule, SharedModule, FormsModule, ReactiveFormsModule, MatFormFieldModule, MatProgressSpinnerModule],
  exports: [],
})
export class LoginModule {}
