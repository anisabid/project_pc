export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        login: {
          auto_login: 'Connexion automatique',
          login: 'Connexion',
          subtitle: "Se connecter avec ses identifiants d'entreptrise",
          title: 'Se connecter avec identifiant et mot de passe',
          form: {
            login: {
              label: 'Login *',
              placeholder: 'Saisir votre uperid ou pnom',
            },
            password: {
              label: 'Mot de passe *',
              placeholder: '',
            },
          },
        },
      },
    },
  },
};
