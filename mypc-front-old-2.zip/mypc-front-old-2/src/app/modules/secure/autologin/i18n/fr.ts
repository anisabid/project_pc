export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        autologin: {
          autologin: 'Connexion automatique',
          login: 'Connexion',
          title: "Se connecter avec ses identifiants d'entreprise",
        },
      },
    },
  },
};
