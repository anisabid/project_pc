import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '@app/core/services/authentication.service';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { of } from 'rxjs';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'sfr-autologin',
  templateUrl: './autologin.component.html',
  styleUrls: ['./autologin.component.scss'],
})
export class AutologinComponent implements OnInit {
  constructor(
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private environmentService: EnvironmentService,
    private router: Router,
    private translationLoaderService: TranslationLoaderService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
  }

  ngOnInit(): void {
    if (
      this.authenticationService.isLoggedIn() &&
      this.authenticationService.isSessionExpired()
    ) {
      this.authenticationService.logoutClear();
    }
    this.checkAutoLogged();
  }

  private checkAutoLogged() {
    if (this.activatedRoute.snapshot.queryParams?.token) {
      of(this.authenticationService.interceptTokenFromQueryParams()).subscribe(
        () => {
          this.redirectToApp();
        }
      );
    } else {
      this.onAutoLogin();
    }
  }

  private onAutoLogin() {
    this.authenticationService.autoLogin(this.accessEnvironment);
  }

  private redirectToApp(): void {
    this.router.navigateByUrl(ConstRoutesPath.DEFAULT);
  }

  get accessEnvironment(): string {
    return this.environmentService.accessEnvironment(
      this.activatedRoute.snapshot.queryParams
    );
  }
}
