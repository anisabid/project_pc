import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '@core/services/authentication.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './i18n/fr';
import { ActivatedRoute, Router } from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import {
  MatSnackBarConfig,
  MatSnackBarDismiss,
} from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';
import { SnackBarMessageService } from '@shared/modules/snack-bar-message/snack-bar-message.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';

@Component({
  selector: 'sfr-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss'],
})
export class LogoutComponent implements OnInit {
  configExpiredSession: MatSnackBarConfig = {
    horizontalPosition: 'right',
    verticalPosition: 'top',
    panelClass: ['style-light'],
  };
  public showLoader: boolean;
  public urlLogoutBackOfficeMyPC: SafeResourceUrl;
  public urlLogoutBackOfficeMyAssistance: SafeResourceUrl;
  public showBtnLogin: boolean;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private translationLoaderService: TranslationLoaderService,
    private urlHelperService: UrlHelperService,
    private domSanitizer: DomSanitizer,
    private snackBarMessageService: SnackBarMessageService,
    private environmentService: EnvironmentService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.showLoader = true;
    this.showBtnLogin = false;
  }

  ngOnInit(): void {
    if (this.activatedRoute.snapshot.queryParams?.cause === 'expired') {
      this.showExpirationMessage();
    }
    this.urlLogoutBackOfficeMyPC =
      this.domSanitizer.bypassSecurityTrustResourceUrl(
        this.urlHelperService.toBackOffice(
          this.environmentService.config.modules.logout.path.myPc
        )
      );
    this.urlLogoutBackOfficeMyAssistance =
      this.domSanitizer.bypassSecurityTrustResourceUrl(
        this.urlHelperService.toBackOffice(
          this.environmentService.config.modules.logout.path.myAssistance
        )
      );
    this.authenticationService
      .logout()
      .then((result: boolean) => {
        if (result) {
          setTimeout(() => {
            /**
             * @todo remove redirect condition for partner
             */
            if (
              this.activatedRoute.snapshot.queryParams?.partner &&
              this.activatedRoute.snapshot.queryParams?.partner === 'true' &&
              this.environmentService.access.redirect.partner.enable
            ) {
              window.location.href =
                this.environmentService.access.redirect.partner.url;
            } else {
              this.redirectToLogin();
            }
          }, this.environmentService.config.modules.logout.duration);
        }
      })
      .catch((error: HttpErrorResponse) => {
        this.snackBarMessageService
          .error({
            message: error.error.message,
            action: null,
            duration: 1000,
          })
          .afterDismissed()
          .subscribe(
            (matSnackBarDismiss: MatSnackBarDismiss) => {
              if (
                this.environmentService.config.modules.logout
                  .autoRedirectToLogin
              ) {
                this.showBtnLogin = false;
                this.redirectToLogin();
              } else {
                this.showBtnLogin = true;
              }
            },
            (error) => {
              console.error(error);
              if (
                this.environmentService.config.modules.logout
                  .autoRedirectToLogin
              ) {
                this.showBtnLogin = false;
                this.redirectToLogin();
              } else {
                this.showBtnLogin = true;
              }
            }
          );
      });
  }
  private showExpirationMessage() {
    this.snackBarMessageService.info({
      message: this.translationLoaderService.translate(
        'i18n.module.logout.messages.expired_session'
      ),
      action: null,
      duration: 3000,
    });
  }

  public redirectToLogin(): void {
    this.router.navigateByUrl(ConstRoutesPath.LOGIN);
  }
}
