import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogoutComponent } from './logout.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from '@shared/shared.module';
import { logoutRoutingModule } from './logout-routing.module';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@NgModule({
  declarations: [LogoutComponent],
  imports: [CommonModule, logoutRoutingModule, FlexLayoutModule, SharedModule, MatProgressSpinnerModule],
})
export class LogoutModule {}
