import { Component, OnInit } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'sfr-extra',
  templateUrl: './extra.component.html',
  styleUrls: ['./extra.component.scss'],
})
export class ExtraComponent implements OnInit {
  constructor(private translationLoaderService: TranslationLoaderService) {
    this.translationLoaderService.loadTranslations(localFrench);
  }

  ngOnInit(): void {}
}
