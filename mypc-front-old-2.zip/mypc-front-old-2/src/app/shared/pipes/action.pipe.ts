import { Pipe, PipeTransform } from "@angular/core";
import { Action } from "@shared/models/action";
import { ConstActions } from "@shared/consts/action.const";

@Pipe({
    name: "action",
})
export class ActionPipe implements PipeTransform {
    private action: Action;
    private response: any;

    /**
     * Transform
     *
     * @param value
     * @param {string} desc
     * @returns {any}
     */
    transform(value: string, desc: string): any {
        if (value.toUpperCase()) {
            switch (value.toUpperCase()) {
                case ConstActions.DONE.code.toUpperCase():
                    this.action = ConstActions.DONE;
                    break;

                case ConstActions.SEND.code.toUpperCase():
                    this.action = ConstActions.DONE;
                    break;

                case ConstActions.CANCELED.code.toUpperCase():
                    this.action = ConstActions.CANCELED;
                    break;

                case ConstActions.CANCELED_Folder.code.toUpperCase():
                    this.action = ConstActions.CANCELED_Folder;
                    break;

                case ConstActions.COMPLEMENT.code.toUpperCase():
                    this.action = ConstActions.COMPLEMENT;
                    break;

                case ConstActions.REJECT.code.toUpperCase():
                    this.action = ConstActions.REJECT;
                    break;

                case ConstActions.DONE_FINISHED.code.toUpperCase():
                    this.action = ConstActions.DONE_FINISHED;
                    break;

                case ConstActions.SUBMIT.code.toUpperCase():
                    this.action = ConstActions.SUBMIT;
                    break;

                case ConstActions.CREATE.code.toUpperCase():
                    this.action = ConstActions.CREATE;
                    break;

                case ConstActions.SAVE.code.toUpperCase():
                    this.action = ConstActions.SAVE;
                    break;

                case ConstActions.SUBMIT_DEROGATION.code.toUpperCase():
                    this.action = ConstActions.SUBMIT_DEROGATION;
                    break;


                case ConstActions.SUBMIT_VALIDATION_TECH.code.toUpperCase():
                    this.action = ConstActions.SUBMIT_VALIDATION_TECH;
                    break;

                case ConstActions.VALIDATE_FONCT.code.toUpperCase():
                    this.action = ConstActions.VALIDATE_FONCT;
                    break;

                case ConstActions.VALIDATE_TECH.code.toUpperCase():
                    this.action = ConstActions.VALIDATE_TECH;
                    break;


                case ConstActions.SUBMIT_VALIDATION_TECH_PRE.code.toUpperCase():
                    this.action = ConstActions.SUBMIT_VALIDATION_TECH_PRE;
                    break;


                case ConstActions.SUBMIT_VALIDATION_SUP.code.toUpperCase():
                    this.action = ConstActions.SUBMIT_VALIDATION_SUP;
                    break;


                case ConstActions.SUBMIT_VALIDATION_SUP_PRE.code.toUpperCase():
                    this.action = ConstActions.SUBMIT_VALIDATION_SUP_PRE;
                    break;


                case ConstActions.TRAITE.code.toUpperCase():
                    this.action = ConstActions.TRAITE;
                    break;


                case ConstActions.FINISHED.code.toUpperCase():
                    this.action = ConstActions.FINISHED;
                    break;


                case ConstActions.RELANCE_PRE.code.toUpperCase():
                    this.action = ConstActions.RELANCE_PRE;
                    break;


                case ConstActions.RELANCE_REA.code.toUpperCase():
                    this.action = ConstActions.RELANCE_REA;
                    break;


                case ConstActions.RELAUNCH.code.toUpperCase():
                    this.action = ConstActions.RELAUNCH;
                    break;


                case ConstActions.CLAIMED.code.toUpperCase():
                    this.action = ConstActions.CLAIMED;
                    break;


                case ConstActions.FROZEN.code.toUpperCase():
                    this.action = ConstActions.FROZEN;
                    break;


                case ConstActions.PLANNED.code.toUpperCase():
                    this.action = ConstActions.PLANNED;
                    break;


                case ConstActions.RELANCE_REPRISE.code.toUpperCase():
                    this.action = ConstActions.RELANCE_REPRISE;
                    break;

                case ConstActions.WAITING_CLOSE.code.toUpperCase():
                    this.action = ConstActions.WAITING_CLOSE;
                    break;

                case ConstActions.REJECT_PRIO.code.toUpperCase():
                    this.action = ConstActions.REJECT_PRIO;
                    break;

                case ConstActions.ACCEPT_PRIO.code.toUpperCase():
                    this.action = ConstActions.ACCEPT_PRIO;
                    break;

                case ConstActions.REJECTED_TRAITEMENT.code.toUpperCase():
                    this.action = ConstActions.REJECTED_TRAITEMENT;
                    break;

                case ConstActions.ASK_APPOINTMENT.code.toUpperCase():
                    this.action = ConstActions.ASK_APPOINTMENT;
                    break;

                case ConstActions.ASK_DEROGATION.code.toUpperCase():
                    this.action = ConstActions.ASK_DEROGATION;
                    break;

                case ConstActions.REJECT_TO_OPEN.code.toUpperCase():
                    this.action = ConstActions.REJECT_TO_OPEN;
                    break;

                case ConstActions.RECORD.code.toUpperCase():
                    this.action = ConstActions.RECORD;
                    break;

                case ConstActions.RECORD_MANUALY.code.toUpperCase():
                    this.action = ConstActions.RECORD_MANUALY;
                    break;

                case ConstActions.GO.code.toUpperCase():
                    this.action = ConstActions.GO;
                    break;

                case ConstActions.ESCALATION.code.toUpperCase():
                    this.action = ConstActions.ESCALATION;
                    break;

                case ConstActions.ECHEC.code.toUpperCase():
                    this.action = ConstActions.ECHEC;
                    break;

                case ConstActions.VERIFY.code.toUpperCase():
                    this.action = ConstActions.VERIFY;
                    break;

                case ConstActions.WAIT.code.toUpperCase():
                    this.action = ConstActions.WAIT;
                    break;

                case ConstActions.CONCEPTION.code.toUpperCase():
                    this.action = ConstActions.CONCEPTION;
                    break;
                case ConstActions.PRIORITY.code.toUpperCase():
                    this.action = ConstActions.PRIORITY;
                    break;


                default:
                    this.action = new Action();
            }

            switch (desc.toLowerCase()) {
                case "code":
                    this.response = this.action.code;
                    break;
                case "translate":
                    this.response = this.action.translate;
                    break;
                default:
                    this.response = this.action.code;
            }
            return this.response;
        }
        return null;
    }
}
