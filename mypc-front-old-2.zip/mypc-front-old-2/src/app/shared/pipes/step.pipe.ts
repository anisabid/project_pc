import { Pipe, PipeTransform } from "@angular/core";
import { ConstStatutes } from "@shared/consts/statutes.const";
import { Step } from "@shared/models/step";
import { ConstSteps } from '@shared/consts/steps.const';

@Pipe({
  name: "step",
})
export class StepPipe implements PipeTransform {
  private step: Step;
  private response: any;

  /**
   * Transform
   *
   * @param value
   * @param {string} desc
   * @returns {any}
   */
  transform(value: string, desc: string): any {
    if (value) {
      switch (value.toUpperCase()) {
        case ConstSteps.DRAFT.code.toUpperCase():
          this.step = ConstSteps.DRAFT;
          break;
        case ConstSteps.DONE.code.toUpperCase():
          this.step = ConstSteps.DONE;
          break;
        case ConstSteps.PENDING.code.toUpperCase():
          this.step = ConstSteps.PENDING;
          break;
        case ConstSteps.QUALIFYING.code.toUpperCase():
          this.step = ConstSteps.QUALIFYING;
          break;
        case ConstSteps.WAITING_APPROVAL.code.toUpperCase():
          this.step = ConstSteps.WAITING_APPROVAL;
          break;
        case ConstSteps.WAITING_FUNCTIONNAL_APPROVAL_N1.code.toUpperCase():
          this.step = ConstSteps.WAITING_FUNCTIONNAL_APPROVAL_N1;
          break;
        case ConstSteps.WAITING_FUNCTIONNAL_APPROVAL_N2.code.toUpperCase():
          this.step = ConstSteps.WAITING_FUNCTIONNAL_APPROVAL_N2;
          break;
        case ConstSteps.WAITING_TECHNICAL_APPROVAL.code.toUpperCase():
          this.step = ConstSteps.WAITING_TECHNICAL_APPROVAL;
          break;
        case ConstSteps.WAITING_MANAGER_APPROVAL_N1.code.toUpperCase():
          this.step = ConstSteps.WAITING_MANAGER_APPROVAL_N1;
          break;
        case ConstSteps.WAITING_SLA_EXEMPTION.code.toUpperCase():
          this.step = ConstSteps.WAITING_SLA_EXEMPTION;
          break;
        case ConstSteps.WAITING_ADDITIONAL_APPROVAL.code.toUpperCase():
          this.step = ConstSteps.WAITING_ADDITIONAL_APPROVAL;
          break;
        case ConstSteps.EXEMPTION_ASKED.code.toUpperCase():
          this.step = ConstSteps.EXEMPTION_ASKED;
          break;
        case ConstSteps.PRIORISATION_UNDER_VALIDATION.code.toUpperCase():
          this.step = ConstSteps.PRIORISATION_UNDER_VALIDATION;
          break;
        case ConstSteps.WAITING_FOR_GO.code.toUpperCase():
          this.step = ConstSteps.WAITING_FOR_GO;
          break;
        case ConstSteps.MANUAL_REWORKING.code.toUpperCase():
          this.step = ConstSteps.MANUAL_REWORKING;
          break;
        case ConstSteps.WAITING_MANAGER_APPROVAL_N2.code.toUpperCase():
          this.step = ConstSteps.WAITING_MANAGER_APPROVAL_N2;
          break;
        case ConstSteps.REOPENED.code.toUpperCase():
          this.step = ConstSteps.REOPENED;
          break;
        case ConstSteps.FINISHED.code.toUpperCase():
          this.step = ConstStatutes.FINISHED;
          break;
        case ConstSteps.IN_PROGRESS.code.toUpperCase():
          this.step = ConstSteps.IN_PROGRESS;
          break;
        case ConstSteps.FROZEN.code.toUpperCase():
          this.step = ConstSteps.FROZEN;
          break;
        case ConstSteps.PRIORISATION_VALIDATED_FUNCTIONNALLY.code.toUpperCase():
          this.step = ConstSteps.PRIORISATION_VALIDATED_FUNCTIONNALLY;
          break;
        case ConstSteps.COMPLETED.code.toUpperCase():
          this.step = ConstSteps.COMPLETED;
          break;
        case ConstSteps.APPOINTMENT_SCHEDULING.code.toUpperCase():
          this.step = ConstSteps.APPOINTMENT_SCHEDULING;
          break;
        case ConstSteps.SCHEDULED.code.toUpperCase():
          this.step = ConstSteps.SCHEDULED;
          break;
        case ConstSteps.PLANNING.code.toUpperCase():
          this.step = ConstSteps.PLANNING;
          break;
        case ConstSteps.WAITING_FOR_REAL.code.toUpperCase():
          this.step = ConstSteps.WAITING_FOR_REAL;
          break;
        case ConstSteps.DESIGN_PROGRESS.code.toUpperCase():
          this.step = ConstSteps.DESIGN_PROGRESS;
          break;
        case ConstSteps.RERUN_ACCEPTED.code.toUpperCase():
          this.step = ConstSteps.RERUN_ACCEPTED;
          break;
        case ConstSteps.RERUN_IN_PROGRESS.code.toUpperCase():
          this.step = ConstSteps.RERUN_IN_PROGRESS;
          break;
        case ConstSteps.EN_COURS_DE_FINALISATION.code.toUpperCase():
          this.step = ConstSteps.EN_COURS_DE_FINALISATION;
          break;
        case ConstSteps.FAILED.code.toUpperCase():
          this.step = ConstSteps.FAILED;
          break;
        case ConstSteps.CLAIMED.code.toUpperCase():
          this.step = ConstSteps.CLAIMED;
          break;
        case ConstSteps.RELANCE.code.toUpperCase():
          this.step = ConstSteps.RELANCE;
          break;
        case ConstSteps.TO_BE_CHECKED.code.toUpperCase():
          this.step = ConstSteps.TO_BE_CHECKED;
          break;
        case ConstSteps.VALIDATED_CLICK_TO_CALL.code.toUpperCase():
          this.step = ConstSteps.VALIDATED_CLICK_TO_CALL;
          break;
        case ConstSteps.WAITING_PLANNING.code.toUpperCase():
          this.step = ConstSteps.WAITING_PLANNING;
          break;
        case ConstSteps.WAITING.code.toUpperCase():
          this.step = ConstSteps.WAITING;
          break;
        case ConstSteps.IN_PREPARATION.code.toUpperCase():
          this.step = ConstSteps.IN_PREPARATION;
          break;
        case ConstSteps.IN_PROGRESS_MANUAL.code.toUpperCase():
          this.step = ConstSteps.IN_PROGRESS_MANUAL;
          break;
        case ConstSteps.FINALIZATION_IN_PROGRESS.code.toUpperCase():
          this.step = ConstSteps.FINALIZATION_IN_PROGRESS;
          break;
        case ConstSteps.IN_PROGRESS_TECHNICAL.code.toUpperCase():
          this.step = ConstSteps.IN_PROGRESS_TECHNICAL;
          break;
          break;
        case ConstSteps.FINISHED_REOPENING_REFUSAL.code.toUpperCase():
          this.step = ConstSteps.FINISHED_REOPENING_REFUSAL;
          break;
        case ConstSteps.FINISHED_ESCALATION_FOLLOWING_REFUSAL.code.toUpperCase():
          this.step = ConstSteps.FINISHED_ESCALATION_FOLLOWING_REFUSAL;
          break;
        case ConstSteps.FINISHED_PENDDING.code.toUpperCase():
          this.step = ConstSteps.FINISHED_PENDDING;
          break;
        case ConstSteps.REJECTED_DEFINITELY.code.toUpperCase():
          this.step = ConstSteps.REJECTED_DEFINITELY;
          break;
        case ConstSteps.REJECTED.code.toUpperCase():
          this.step = ConstSteps.REJECTED;
          break;
        case ConstSteps.AUTOMATICALLY_CANCELED.code.toUpperCase():
          this.step = ConstSteps.AUTOMATICALLY_CANCELED;
          break;
        case ConstSteps.AUTO_PROCESS_CHANGE_3.code.toUpperCase():
          this.step = ConstSteps.AUTO_PROCESS_CHANGE_3;
          break;
        case ConstSteps.AUTO_PROCESS_CHANGE_1.code.toUpperCase():
          this.step = ConstSteps.AUTO_PROCESS_CHANGE_1;
          break;
        case ConstSteps.PROCESS_ID_AUTO_CHANGED_REFUSED.code.toUpperCase():
          this.step = ConstSteps.PROCESS_ID_AUTO_CHANGED_REFUSED;
          break;
        case ConstSteps.AUTO_PROCESS_CHANGED.code.toUpperCase():
          this.step = ConstSteps.AUTO_PROCESS_CHANGED;
          break;
        case ConstSteps.NO_ACTION.code.toUpperCase():
          this.step = ConstSteps.NO_ACTION;
          break;
        case ConstSteps.AUTO_IN_PROGRESS.code.toUpperCase():
          this.step = ConstSteps.AUTO_IN_PROGRESS;
          break;
        case ConstSteps.REJECT_PRIO.code.toUpperCase():
          this.step = ConstSteps.REJECT_PRIO;
          break;
        case ConstSteps.REJECT_PRIO_DEROG.code.toUpperCase():
          this.step = ConstSteps.REJECT_PRIO_DEROG;
          break;
        case ConstSteps.REJECT_PRIO_DEROG_VALIDATED.code.toUpperCase():
          this.step = ConstSteps.REJECT_PRIO_DEROG_VALIDATED;
          break;
        case ConstSteps.NEW.code.toUpperCase():
          this.step = ConstSteps.NEW;
          break;
        case ConstSteps.CANCELED.code.toUpperCase():
          this.step = ConstSteps.CANCELED;
          break;
        default:
          this.step = new Step();
      }

      switch (desc.toLowerCase()) {
        case "code":
          this.response = this.step.code;
          break;
        case "label":
          this.response = this.step.label;
          break;
        case "name":
          this.response = this.step.name;
          break;
        case "translate":
          this.response = this.step.translate;
          break;
        default:
          this.response = this.step.code;
      }
      return this.response;
    }
    return null;
  }
}
