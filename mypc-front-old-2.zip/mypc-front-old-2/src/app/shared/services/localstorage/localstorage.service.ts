import { Injectable } from '@angular/core';
import { EnvironmentService } from '../environment/environment.service';
interface App {
  name: string;
  version: string;
}

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {
  readonly _app: App;
  readonly item: string;
  readonly currentApp: App;

  constructor(private environmentService: EnvironmentService) {
    this.item = 'ng_app';
    this.currentApp = {
      name: 'MYPC',
      version: '1.2.0',
    };
  }

  public check() {
    // Check ng-app
    if (!localStorage.getItem(this.item)) {
      this.update(false);
      localStorage.setItem(this.item, JSON.stringify(this.currentApp));
    } else {
      const ngAppItem = <App>JSON.parse(localStorage.getItem(this.item));
      // Check version
      if (ngAppItem.version !== this.currentApp.version) {
        this.update();
      }
    }
    const updatedNgAppItem = <App>JSON.parse(localStorage.getItem(this.item));
    console.log(updatedNgAppItem.name + ' : ' + updatedNgAppItem.version);
  }

  public update(item = true) {
    if (item) {
      localStorage.removeItem(this.item);
    }
    this.clear(
      this.environmentService.options.localStorage.clearAfterUpdateAppVersion
    );
    localStorage.setItem(this.item, JSON.stringify(this.currentApp));
  }

  public clear(elements: Array<string>) {
    elements.forEach((element) => {
      try {
        localStorage.removeItem(element);
      } catch (error) {
        console.error(error);
      }
    });
  }

  get app(): App {
    return this._app;
  }
}
