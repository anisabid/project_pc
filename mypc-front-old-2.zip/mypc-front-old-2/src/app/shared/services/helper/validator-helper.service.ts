import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ValidatorHelperService {
  private _uPerIdPattern = /^((u|U)\d{6})$/gm;
  constructor() {}

  /**
   *
   * this method check if uPerId have valid format ^(u\d{6})$
   * @param {string} uPerId
   * @returns {boolean}
   */
  isValidFormatUPerId(uPerId: string): boolean {
    const regex = /^(u\d{6})$/gm;
    return regex.test(uPerId.toLowerCase());
  }

  get uPerIdPattern(): RegExp {
    return this._uPerIdPattern;
  }
}
