import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class StringHelperService {
  constructor() {}

  /**
   *
   * This method is similar pipe "str | string : substr"
   * @param {string} str
   * @param {string} substr
   * @returns {string}
   */
  boldSubstr(str: string, substr: string): string {
    if (substr !== '') {
      var strRegExp = new RegExp(substr, 'gi');
      return str.replace(strRegExp, '<b>' + substr + '</b>');
    }
    return str;
  }

  /**
   *
   * This method get acronym of a supplied string
   * @param {string} str
   * @returns {string}
   */
  toAcronym(str: string): string {
    return str.match(/\b(\w)/g).join('');
  }

  /**
   *
   * This method clear accents in string by replacing the accents
   * @param {string} str
   * @returns {string}
   */
  clearAccents(str: string): string {
    var accent = [
      /[\300-\306]/g,
      /[\340-\346]/g, // A, a
      /[\310-\313]/g,
      /[\350-\353]/g, // E, e
      /[\314-\317]/g,
      /[\354-\357]/g, // I, i
      /[\322-\330]/g,
      /[\362-\370]/g, // O, o
      /[\331-\334]/g,
      /[\371-\374]/g, // U, u
      /[\321]/g,
      /[\361]/g, // N, n
      /[\307]/g,
      /[\347]/g, // C, c
    ];
    var noaccent = ['A', 'a', 'E', 'e', 'I', 'i', 'O', 'o', 'U', 'u', 'N', 'n', 'C', 'c'];

    for (var i = 0; i < accent.length; i++) {
      str = str.replace(accent[i], noaccent[i]);
    }

    return str;
  }

  /**
   *
   * This method replace all occurence of a pattern with something else
   * @param {string} str
   * @param {string} pattern
   * @param {string} replacement
   * @returns {string}
   */
  replaceAll(str: string, pattern: string, replacement: string): string {
    return str.replace(new RegExp(pattern, 'g'), replacement);
  }
}
