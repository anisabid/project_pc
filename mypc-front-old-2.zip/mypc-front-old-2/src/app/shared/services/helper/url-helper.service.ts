import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { JwtService } from '@app/core/services/jwt.service';
import { NavigationItemUrlConfig } from '@shared/models/navigation';
import { Observable, Subscriber } from 'rxjs';
import { map } from 'rxjs/operators';
import { EnvironmentService } from '../environment/environment.service';

@Injectable({
  providedIn: 'root',
})
export class UrlHelperService {
  constructor(
    private httpClient: HttpClient,
    private environmentService: EnvironmentService,
    private jwtService: JwtService,
    private sanitizer: DomSanitizer
  ) {}

  toJwt(url: string): string {
    return url + this.jwtService.getJwtFromLocalStorage();
  }

  transformParameters(path: string, parameters: any = {}): string {
    Object.keys(parameters).forEach((key: string) => {
      path = path.replace(key, parameters[key]);
    });
    return path;
  }

  /**
   * Add parameters to a path
   * @param path URL Path
   * @param parameters Path Parameters
   */
  addParameters(path: string, parameters: Object): string {
    if (parameters) {
      for (const [key, value] of Object.entries(parameters)) {
        if (value && value !== '') {
          path += this.getParametersConcatenate(path) + `${key}=${value}`;
        }
      }
    }
    return path;
  }

  /**
   *
   * @param path
   * @param haveUrlPrefixToBackOffice
   * @param haveOriginRecast
   * @param haveJwt
   * @returns new path
   */

  toBackOffice(path: string, config?: NavigationItemUrlConfig): string {
    let url_config = new NavigationItemUrlConfig(config);
    let url = url_config.haveUrlPrefixToBackOffice
      ? this.environmentService.backOffice.baseUrl + path
      : path;
    if (url_config.haveOriginRecast)
      url += this.getParametersConcatenate(url) + 'origin=refonte';
    if (!url_config.isFrame)
      url += this.getParametersConcatenate(url) + 'frame=false';
    if (url_config.haveJwt)
      url +=
        this.getParametersConcatenate(url) +
        'token=' +
        this.jwtService.getJwtFromLocalStorage();
    if (url_config.hash)
      url += this.getParametersConcatenate(url) + '#' + url_config.hash;
    return this.cleanUrl(url);
  }

  post(url: string): Observable<any> {
    return new Observable((observer: Subscriber<any>) => {
      const body = {
        headerdata: this.jwtService.getJwtFromLocalStorage(),
      };

      this.httpClient
        .post(url, body, { observe: 'response', responseType: 'text' })
        .pipe(
          map((res: any) => {
            return res.body;
          })
        )
        .subscribe((m) => {
          observer.next(this.sanitizer.bypassSecurityTrustHtml(m));
        });
    });
  }

  private getParametersConcatenate(url: string): string {
    return url.indexOf('?') === -1 ? '?' : '&';
  }

  private cleanUrl(url: string): string {
    const regex = /(?<!http:)(?<!https:)(\/){2,}/gm;
    const subst = `/`;
    return url.replace(regex, subst);
  }
}
