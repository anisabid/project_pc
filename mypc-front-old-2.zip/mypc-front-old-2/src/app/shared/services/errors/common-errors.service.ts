import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  CommonErrorDescription,
  commonRequestErrors,
} from '@shared/enums/common-error-types.enum';
import { CommonRequestError } from '@shared/models/common-request-error.model';

@Injectable({
  providedIn: 'root',
})
export class CommonErrorsService {
  /**
   * Get Request Error
   * @param error Error
   */
  getCommonRequestError(error: HttpErrorResponse): string {
    if (error.error?.message) {
      const errorFound = commonRequestErrors.find(
        (requestError: CommonRequestError) =>
          requestError.type === error.error?.message
      );
      return errorFound
        ? errorFound.label
        : CommonErrorDescription.NETWORK_ERROR;
    }
    switch (error.status) {
      case 400: {
        return CommonErrorDescription.ERROR_400;
      }
      case 401: {
        return CommonErrorDescription.ERROR_401;
      }
      case 403: {
        return CommonErrorDescription.ERROR_403;
      }
      case 404: {
        return CommonErrorDescription.ERROR_404;
      }
      case 500: {
        return CommonErrorDescription.ERROR_500;
      }
      default: {
        return CommonErrorDescription.NETWORK_ERROR;
      }
    }
  }
}
