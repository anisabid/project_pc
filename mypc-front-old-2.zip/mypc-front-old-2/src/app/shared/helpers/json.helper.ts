export class JsonHelper {
  constructor() {}

  /**
   * Check if Element is a valid JSON
   * @param item Element
   */
  public static isJson(item: any): boolean {
    item = typeof item !== 'string' ? JSON.stringify(item) : item;

    try {
      item = JSON.parse(item);
    } catch (e) {
      return false;
    }

    return typeof item === 'object' && item !== null;
  }
}
