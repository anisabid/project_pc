import { DatePipe } from '@angular/common';
import { ConstDateFormatBack, ConstDateFormatLocaleId } from '@shared/consts/date.const';

export class DateHelper {
  constructor() {}

  // 22/04/2022 12:00 => Date
  static normalizeDateFromBackToFront(fullDate: string): Date {
    const splitFullDate = fullDate.split(' ');
    const date = splitFullDate[0].split('/');
    const hour = splitFullDate[1].split(':');
    return new Date(parseInt(date[2]), parseInt(date[1]) - 1, parseInt(date[0]), parseInt(hour[0]), parseInt(hour[1]));
  }

  // Date => 22/04/2022 12:00
  static normalizeDateFromFrontToBack(date: Date): string {
    return new DatePipe(ConstDateFormatLocaleId).transform(date, ConstDateFormatBack);
  }
}
