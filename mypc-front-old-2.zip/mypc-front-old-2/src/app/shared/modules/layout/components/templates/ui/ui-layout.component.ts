import { Component, OnInit } from '@angular/core';
import { NavigationItems } from '@shared/models/navigation';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { SidebarService } from '@layout/components/sidebar/sidebar.service';
import { locale as localFrench } from '@ui/i18n/fr';
import { EnumNavigationItemType } from '@shared/consts/navigation.const';

@Component({
  selector: 'ui-layout',
  templateUrl: './ui-layout.component.html',
  styleUrls: ['./ui-layout.component.scss'],
})
export class UiLayoutComponent implements OnInit {
  public sidebarOpened: boolean;
  public navigation: NavigationItems;
  constructor(private sidebarService: SidebarService, private translationLoaderService: TranslationLoaderService) {
    this.navigation = {
      menu: [
        {
          id: 'page-header',
          type: EnumNavigationItemType.ITEM,
          title: 'Page Header',
          translate: 'i18n.ui.navigation.page.header',
          url: '/ui/page/header',
        },
      ],
    };
    this.translationLoaderService.loadTranslations(localFrench);
  }

  ngOnInit(): void {
    this.sidebarService.onSidebarToggleChanged.subscribe((val) => {
      this.sidebarOpened = val;
    });
  }
}
