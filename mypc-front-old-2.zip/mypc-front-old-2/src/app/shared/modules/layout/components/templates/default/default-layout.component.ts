import { Component, OnInit } from '@angular/core';
import { NavigationItems } from '@shared/models/navigation';
import { SidebarService } from '@layout/components/sidebar/sidebar.service';
import { NAVIGATION_MAIN } from '@shared/consts/navigation.const';

@Component({
  selector: 'default-layout',
  templateUrl: './default-layout.component.html',
  styleUrls: ['./default-layout.component.scss'],
})
export class DefaultLayoutComponent implements OnInit {
  public sidebarOpened: boolean;
  public navigation: NavigationItems;
  constructor(private sidebarService: SidebarService) {
    this.navigation = NAVIGATION_MAIN;
  }

  ngOnInit(): void {
    this.sidebarService.onSidebarToggleChanged.subscribe((val) => {
      this.sidebarOpened = val;
    });
  }
}
