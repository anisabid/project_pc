import { ClipboardModule } from '@angular/cdk/clipboard';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { PasswordModule } from '@app/modules/password/password.module';
import { DirectivesModule } from '@shared/directives/directives.module';
import { MaterialModule } from '@shared/modules/material/material.module';
import { PipesModule } from '@shared/pipes/pipes.module';
import { TranslateModule } from '@ngx-translate/core';
import { NavigationIconModule } from '../navigation-icon/navigation-icon.module';
import { SidebarComponent } from './sidebar.component';

@NgModule({
  declarations: [SidebarComponent],
  imports: [CommonModule, RouterModule, TranslateModule, FlexLayoutModule, MaterialModule, PipesModule, ClipboardModule, DirectivesModule, NavigationIconModule, PasswordModule],
  exports: [SidebarComponent],
})
export class SidebarModule {}
