import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { Injectable } from '@angular/core';
import { SnackBarMessageComponent } from './snack-bar-message.component';

interface SnackBarMessageData {
  msg: string;
  icon: string;
  theme: string;
}

@Injectable({
  providedIn: 'root',
})
export class SnackBarMessageService {
  private configExpiredSession: MatSnackBarConfig<SnackBarMessageData>;
  constructor(private snackBar: MatSnackBar) {
    this.configExpiredSession = {
      horizontalPosition: 'right',
      verticalPosition: 'top',
      panelClass: ['style-light'],
    };
  }

  /**
   * @param duration - duration in seconds.
   */
  open(obj: any) {
    let message: string = obj?.message,
      action: string = obj?.action;

    return this.snackBar.openFromComponent(SnackBarMessageComponent, {
      data: { message, action },
      duration: obj.duration,
    });
  }

  /**
   * @todo Add SnackBar mode error with style
   * @param obj
   * @returns
   */

  error(obj: any) {
    let message: string = obj?.message,
      action: string = obj?.action;
    return this.snackBar.openFromComponent(SnackBarMessageComponent, {
      data: { message, action },
      duration: obj.duration,
    });
  }

  /**
   * @todo Add SnackBar mode success with style
   * @param obj
   * @returns
   */

  success(obj: any) {
    let message: string = obj?.message,
      action: string = obj?.action;
    return this.snackBar.openFromComponent(SnackBarMessageComponent, {
      data: { message, action },
      duration: obj.duration,
    });
  }

  /**
   * @todo Add SnackBar mode info with style
   * @param obj
   * @returns
   */

  info(obj: any) {
    let message: string = obj?.message,
      action: string = obj?.action;
    return this.snackBar.openFromComponent(SnackBarMessageComponent, {
      data: { message, action },
      duration: obj.duration,
    });
  }

  /**
   * @todo Add SnackBar mode warning with style
   * @param obj
   * @returns
   */

  warning(obj: any) {
    let message: string = obj?.message,
      action: string = obj?.action;
    return this.snackBar.openFromComponent(SnackBarMessageComponent, {
      data: { message, action },
      duration: obj.duration,
    });
  }
}
