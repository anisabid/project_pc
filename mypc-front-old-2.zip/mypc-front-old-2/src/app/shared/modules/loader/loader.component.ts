import { Component } from '@angular/core';
import { LoaderService, LoaderState } from './loader.service';

@Component({
  selector: 'loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent {
  color = 'primary';
  mode = 'indeterminate';
  value = 50;
  isLoading: boolean;

  constructor(private loaderService: LoaderService) {
    setTimeout(() => {
      this.loaderService.onLoading.subscribe((state: LoaderState) => {
        this.isLoading = state.show;
      });
    });
  }
}
