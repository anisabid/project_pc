import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export class LoaderState {
  _length: number;
  _show: boolean;

  constructor(data: { length: number; show: boolean } = { length: 0, show: false }) {
    this._length = data.length;
    this._show = data.show;
  }

  public increment() {
    this._length++;
    this._show = true;
  }

  public decrement() {
    this._length--;
    if (this._length === 0) {
      this._show = false;
    }
  }

  public reset() {
    this._length = 0;
    this._show = false;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  get show(): boolean {
    return this._show;
  }

  get length(): number {
    return this._length;
  }

  get value(): { length: number; show: boolean } {
    return {
      length: this._length,
      show: this._show,
    };
  }
}
@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  public _loaderState: LoaderState;
  public onLoading: BehaviorSubject<LoaderState>;
  private log: boolean;

  constructor() {
    this._loaderState = new LoaderState();
    this.onLoading = new BehaviorSubject(this._loaderState);
    this.consoleLog('init : ', this._loaderState);
    this.log = false;
  }

  reset() {
    this._loaderState.reset();
    this.consoleLog('reset : ', this._loaderState);
    this.onLoading.next(this._loaderState);
  }

  increment() {
    this._loaderState.increment();
    this.consoleLog('increment : ', this._loaderState);
    this.onLoading.next(this._loaderState);
  }

  decrement() {
    this._loaderState.decrement();
    this.consoleLog('decrement : ', this._loaderState);
    this.onLoading.next(this._loaderState);
  }

  show() {
    if (!this._loaderState._show) {
      this._loaderState.increment();
    }
    this.consoleLog('show : ', this._loaderState);
    this.onLoading.next(this._loaderState);
  }

  hide() {
    this._loaderState.reset();
    this.consoleLog('hide : ', this._loaderState);
    this.onLoading.next(this._loaderState);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private consoleLog(message?: any, ...optionalParams: any[]): void {
    if (this.log) {
      console.log(message, ...optionalParams);
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------
  get loaderState(): LoaderState {
    return this._loaderState;
  }
}
