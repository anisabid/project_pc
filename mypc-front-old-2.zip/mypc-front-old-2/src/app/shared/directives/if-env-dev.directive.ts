import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { EnvironmentService } from '../services/environment/environment.service';

@Directive({
  selector: '[ifEnvDev]',
})
export class IfEnvDevDirective {
  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private environmentService: EnvironmentService
  ) {}

  ngOnInit() {
    this.updateView(
      !this.environmentService.production &&
        !this.environmentService.integration
    );
  }

  private updateView(display: boolean) {
    if (display) {
      this.displayView();
    } else {
      this.hideView();
    }
  }

  private hideView() {
    this.viewContainer.clear();
  }

  private displayView() {
    this.viewContainer.createEmbeddedView(this.templateRef);
  }
}
