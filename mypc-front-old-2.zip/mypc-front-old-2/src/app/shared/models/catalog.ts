import { ConstTypesCatalogs } from '../consts/catalog.const';

export class CatalogAction {
  classId: string;
  ctnerId: string;
  formId: string;
  id: string;
  name: string;
  parentId?: string;
  reqformtype: string;
  title: string;
  isParent: boolean;

  constructor(data?: any, parentId?: string) {
    this.classId = !data?.classId ? '' : data.classId;
    this.ctnerId = !data?.ctnerId ? '' : data.ctnerId;
    this.formId = !data?.formId ? '' : data.formId;
    this.id = !data?.id ? '' : data.id;
    this.name = !data?.name ? '' : data.name;
    this.parentId = !parentId ? null : parentId;
    this.reqformtype = !data?.reqformtype ? '' : data.reqformtype;
    this.title = !data?.title ? '' : data.title;
    this.isParent = false;
  }
}

export class Catalog {
  actions?: Array<CatalogAction>;
  children?: Map<string, Catalog>;
  classCss?: string;
  description?: string;
  descriptionI18n: string;
  display?: string;
  groups: Array<string>;
  icon: string;
  id: string;
  isParent: boolean;
  mergedWithNext?: boolean;
  mergedWithPrevious?: boolean;
  module: string;
  name: string;
  nameI18n: string;
  parentId?: string;
  subtitleI18n?: string;
  title: string;
  titleI18n?: string;
  type: string;

  constructor(data?: any, parentId: string = null) {
    this.actions = null;
    if (data && data?.action) {
      this.actions = data.action.map((item) => {
        return new CatalogAction(item, data.id);
      });
    }
    this.children = new Map();
    if (data && data?.children) {
      data.children.forEach((element: Catalog) => {
        this.children.set(element.id, new Catalog(element, data.id));
      });
    }
    this.classCss = !data?.classCss ? '' : data.classCss;
    this.description = !data?.description ? null : data?.description;
    this.descriptionI18n = !data?.descriptionI18n
      ? null
      : data?.descriptionI18n;
    this.display = !data?.display ? null : data.display;
    this.groups = !data?.groups ? null : data.groups;
    this.icon = !data?.icon ? null : data.icon;
    this.id = !data?.id ? null : data.id;
    this.isParent = !data?.isParent ? false : data.isParent;
    this.mergedWithNext = !data?.mergedWithNext ? false : data.mergedWithNext;
    this.mergedWithPrevious = !data?.mergedWithPrevious
      ? false
      : data.mergedWithPrevious;
    this.module = !data?.module ? null : data.module;
    this.name = !data?.name ? null : data.name;
    this.nameI18n = !data?.nameI18n ? null : data.nameI18n;
    this.parentId = parentId;
    this.title = !data?.title ? null : data.title;
    this.titleI18n = !data?.titleI18n ? null : data.titleI18n;
    this.type = !data?.type ? null : data.type;
    this.subtitleI18n = !data?.subtitleI18n ? null : data.subtitleI18n;
  }

  public isCDS(): boolean {
    return this.module && this.module.toLowerCase() === ConstTypesCatalogs.CDS;
  }

  public isESUP(): boolean {
    return this.module && this.module.toLowerCase() === ConstTypesCatalogs.ESUP;
  }
}

export class Catalogs {
  cds: Catalog;
  esup: Catalog;

  constructor(data?: any) {
    this.cds = new Catalog({
      children: !data?.catalog?.message?.CdS ? [] : data.catalog.message.CdS,
      classCss: ConstTypesCatalogs.CDS,
      descriptionI18n: 'i18n.catalog.cds.description',
      display: 'string',
      groups: [],
      icon: 'edit_note',
      id: ConstTypesCatalogs.CDS,
      isParent: true,
      module: ConstTypesCatalogs.CDS,
      nameI18n: 'i18n.catalog.cds.name',
      subtitleI18n: 'i18n.catalog.cds.subtitle',
      titleI18n: 'i18n.catalog.cds.title',
      type: ConstTypesCatalogs.CDS,
    });

    this.esup = new Catalog({
      children: !data?.catalog?.message?.ESup ? [] : data.catalog.message.ESup,
      classCss: ConstTypesCatalogs.ESUP,
      descriptionI18n: 'i18n.catalog.esup.description',
      display: 'string',
      groups: [],
      icon: 'info',
      id: ConstTypesCatalogs.ESUP,
      isParent: true,
      module: ConstTypesCatalogs.ESUP,
      nameI18n: 'i18n.catalog.esup.name',
      subtitleI18n: 'i18n.catalog.esup.subtitle',
      titleI18n: 'i18n.catalog.esup.title',
      type: ConstTypesCatalogs.ESUP,
    });
  }
}

/**
 * SearchCDS Entity
 */
export interface SearchCDS {
  ctnerId: string;
  classId: string;
  actionId: string;
  formId: string;
  catalogue: string;
  Libelle: string;
}

/**
 * SearchESUP Entity
 */
export interface SearchESUP {
  ctnerId: string;
  classId: string;
  actionId: string;
  formId: string;
  Libelle: string;
}

/**
 * Search Results Entity
 */
export class SearchResults {
  searchCDS: SearchCDS[];
  searchESUP: SearchESUP[];

  constructor() {
    this.searchCDS = [];
    this.searchESUP = [];
  }
}
