export class Search {

  status?: string;
  step?: string;
  emet?: string;
  benef?: string;
  element?: string;
  date_begin?: string;
  date_end?: string;
  resume?: string;
  req?: string;
  grp?:string;


constructor(status: string, step: string, emet: string, benef: string, element: string, date_begin: string, date_end: string, resume: string, req: string, grp: string) {
  this.status = status;
  this.step = step;
  this.emet = emet;
  this.benef = benef;
  this.element = element;
  this.date_begin = date_begin;
  this.date_end = date_end;
  this.resume = resume;
  this.req = req;
  this.grp = grp;
}
}
