export class Source {
  filter(arg0: (tag: any) => boolean) {
    throw new Error('Method not implemented.');
  }
  data: Array<any>;
  limit?: number;
  offset?: number;
  total: number;
  page?: number;

  private _pending: boolean;

  constructor(data?: any) {
    this.data = !data ? null : data.data;
    this.limit = !data ? null : parseInt(data.limit);
    this.offset = !data ? null : parseInt(data.offset);
    this.total = !data ? null : parseInt(data.total);
    this.page = !data ? null : parseInt(data.page);
  }

  public requestSent() {
    this._pending = true;
  }

  public requestDone() {
    this._pending = false;
  }

  set pending(pending: boolean) {
    this._pending = pending;
  }

  get pending(): boolean {
    return this._pending;
  }
}
