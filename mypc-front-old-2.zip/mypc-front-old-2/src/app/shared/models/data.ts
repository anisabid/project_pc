export class Data<T> {
  data: Array<T>;
  limit: number;
  offset: number;
  total: number;

  constructor(data: any) {
    this.data = !data || !data.data ? [] : data.data;
    this.limit = !data || !data.limit ? null : Number(data.limit);
    this.offset = !data || !data.offset ? null : Number(data.offset);
    this.total = !data || !data.total ? null : Number(data.total);
  }

  get isEmpty(): boolean {
    return this.data.length === 0;
  }
}
