import {
  CommonErrorDescription,
  CommonErrorType,
} from '../enums/common-error-types.enum';

/**
 * Common Request Error Model
 */
export interface CommonRequestError {
  /**
   * Common Request Error Type
   */
  type: CommonErrorType;
  /**
   * Common Request Error Description
   */
  label: CommonErrorDescription;
}
