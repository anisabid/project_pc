/**
 * Status
 */
export class Status {
  background?: string;
  code: string;
  color?: string;
  icon?: string;
  label?: string;
  name?: string;
  text_color?: string;
  translate?: string;
  statusCode?: string;

  constructor(obj: Object = {}) {
    let params = {
      background: '',
      code: '',
      color: '',
      icon: '',
      label: '',
      name: '',
      text_color: '#FFFFFF',
      translate: '',
      statusCode: '',
    };
    Object.assign(params, obj);

    this.background = params.background;
    this.code = params.code;
    this.color = params.color;
    this.icon = params.icon;
    this.label = params.label;
    this.name = params.name;
    this.translate = params.translate;
    this.statusCode = params.statusCode;
  }
}
