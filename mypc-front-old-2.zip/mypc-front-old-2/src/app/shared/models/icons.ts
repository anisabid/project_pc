/**
 * Icons
 */
export class Icons {
    code: string;
    translate?: string;

    constructor(obj: Object = {}) {
        let params = {
            code: "",
            translate: "",
        };
        Object.assign(params, obj);

        this.code = params.code;
        this.translate = params.translate;
    }
}
