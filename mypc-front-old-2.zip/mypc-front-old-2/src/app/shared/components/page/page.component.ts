import { Attribute, Component, Input, OnInit, Optional } from '@angular/core';

@Component({
  selector: 'sfr-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.scss'],
})
export class PageComponent implements OnInit {
  @Input() pageClass: string;
  @Input() pageNoGutters: boolean;
  @Input() pageTitle: string;

  constructor() {}

  ngOnInit(): void {
    if (this.pageNoGutters !== undefined && this.pageNoGutters.toString() === '') {
      this.pageNoGutters = true;
    }
  }
}
