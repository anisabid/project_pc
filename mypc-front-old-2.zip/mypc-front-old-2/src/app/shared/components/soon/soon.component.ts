import { ChangeDetectionStrategy, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { TranslateService } from '@ngx-translate/core';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'soon',
  templateUrl: './soon.component.html',
  styleUrls: ['./soon.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SoonComponent implements OnInit {
  @Input() type: string;
  @Input() component: string;

  constructor(private translateService: TranslateService, private translationLoaderService: TranslationLoaderService) {
    // Set the global translations
    this.translationLoaderService.loadTranslations(localFrench);
    // Set default type
    this.type = this.type ?? this.translateService.instant('i18n.global.component');
  }

  ngOnInit(): void {}
}
