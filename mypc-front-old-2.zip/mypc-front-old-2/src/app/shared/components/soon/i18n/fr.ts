export const locale = {
  lang: "fr",
  data: {
    i18n: {
      shared: {
        soon: {
          message:
            "Ce n’est pas encore tout à fait prêt, mais nous travaillons fort",
          message_component:
            "Le {{type}} <strong>{{name}}</strong> n’est pas encore tout à fait prêt, mais nous travaillons fort",
        },
      },
    },
  },
};
