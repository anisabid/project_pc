import { Step } from '@shared/models/step';

/**
 * Color Steps
 */
export interface steps {
  DONE: Step;
  DRAFT: Step;
  PENDING: Step;
  QUALIFYING: Step;
  WAITING_APPROVAL: Step;
  WAITING_FUNCTIONNAL_APPROVAL_N1: Step;
  WAITING_FUNCTIONNAL_APPROVAL_N2: Step;
  WAITING_MANAGER_APPROVAL_N2: Step;
  WAITING_MANAGER_APPROVAL_N1: Step;
  WAITING_SLA_EXEMPTION: Step;
  WAITING_TECHNICAL_APPROVAL: Step;
  WAITING_ADDITIONAL_APPROVAL: Step;
  WAITING_FUNCTIONNAL_APPROVAL_N3: Step;
  PRIORISATION_UNDER_VALIDATION: Step;
  WAITING_FOR_GO: Step;
  MANUAL_REWORKING: Step;
  REOPENED: Step;
  EXEMPTION_ASKED: Step;
  PRIORISATION_VALIDATED_FUNCTIONNALLY: Step;
  PLANNING: Step;
  COMPLETED: Step;
  APPOINTMENT_SCHEDULING: Step;
  FROZEN: Step;
  SCHEDULED: Step;
  WAITING_FOR_REAL: Step;
  DESIGN_PROGRESS: Step;
  IN_PROGRESS: Step;
  RERUN_ACCEPTED: Step;
  RERUN_IN_PROGRESS: Step;
  EN_COURS_DE_FINALISATION: Step;
  FAILED: Step;
  CLAIMED: Step;
  TO_BE_CHECKED: Step;
  RELANCE: Step;
  FINISHED: Step;
  VALIDATED_CLICK_TO_CALL: Step;
  WAITING_PLANNING: Step;
  WAITING: Step;
  IN_PREPARATION: Step;
  IN_PROGRESS_MANUAL: Step;
  FINALIZATION_IN_PROGRESS: Step;
  IN_PROGRESS_TECHNICAL: Step;
  FINISHED_REOPENING_REFUSAL: Step;
  FINISHED_ESCALATION_FOLLOWING_REFUSAL: Step;
  FINISHED_PENDDING: Step;
  REJECTED_DEFINITELY: Step;
  REJECTED: Step;
  AUTOMATICALLY_CANCELED: Step;
  AUTO_PROCESS_CHANGE_3: Step;
  AUTO_PROCESS_CHANGE_1: Step;
  PROCESS_ID_AUTO_CHANGED_REFUSED: Step;
  AUTO_PROCESS_CHANGED: Step;
  NO_ACTION: Step;
  AUTO_IN_PROGRESS: Step;
  REJECT_PRIO: Step;
  REJECT_PRIO_DEROG: Step;
  REJECT_PRIO_DEROG_VALIDATED: Step;
  NEW: Step;
  CANCELED: Step;
  CANCELED_EN: Step;
}

/**
 * ConstColorSteps Const
 */

export const ConstSteps = {
  DRAFT: new Step({
    code: 'draft',
    label: '',
    name: '',
    translate: 'i18n.step.draft',
  }),
  FINISHED: new Step({
    code: 'closed',
    label: '',
    name: '',
    translate: 'i18n.step.closed',
  }),

  QUALIFYING: new Step({
    code: 'qualifying',
    label: '',
    name: '',
    translate: 'i18n.step.qualifying',
  }),
  PENDING: new Step({
    code: 'pending',
    label: '',
    name: '',
    translate: 'i18n.step.pending',
  }),
  WAITING_APPROVAL: new Step({
    code: 'waiting_approval',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_approval',
  }),
  WAITING_FUNCTIONNAL_APPROVAL_N1: new Step({
    code: 'waiting_functionnal_approval_n1',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_functionnal_approval_n1',
  }),
  WAITING_FUNCTIONNAL_APPROVAL_N2: new Step({
    code: 'waiting_functionnal_approval_n2',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_functionnal_approval_n2',
  }),
  WAITING_MANAGER_APPROVAL_N1: new Step({
    code: 'waiting_manager_approval_n1',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_manager_approval_n1',
  }),
  WAITING_MANAGER_APPROVAL_N2: new Step({
    code: 'waiting_manager_approval_n2',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_manager_approval_n2',
  }),
  WAITING_SLA_EXEMPTION: new Step({
    code: 'waiting_sla_exemption',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_sla_exemption',
  }),
  WAITING_TECHNICAL_APPROVAL: new Step({
    code: 'waiting_technical_approval',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_technical_approval',
  }),
  WAITING_ADDITIONAL_APPROVAL: new Step({
    code: 'waiting_additional_approval',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_additional_approval',
  }),
  WAITING_FOR_GO: new Step({
    code: 'waiting_for_go',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_for_go',
  }),
  MANUAL_REWORKING: new Step({
    code: 'manual_reworking',
    label: '',
    name: '',
    translate: 'i18n.step.manual_reworking',
  }),
  REOPENED: new Step({
    code: 'reopened',
    label: '',
    name: '',
    translate: 'i18n.step.reopened',
  }),
  IN_PROGRESS: new Step({
    code: 'in_progress',
    label: '',
    name: '',
    translate: 'i18n.step.in_progress',
  }),
  RERUN_IN_PROGRESS: new Step({
    code: 'rerun_in_progress',
    label: '',
    name: '',
    translate: 'i18n.step.rerun_in_progress',
  }),
  RERUN_ACCEPTED: new Step({
    code: 'rerun_accepted',
    label: '',
    name: '',
    translate: 'i18n.step.rerun_accepted',
  }),
  EN_COURS_DE_FINALISATION: new Step({
    code: 'en_cours_de_finalisation',
    label: '',
    name: '',
    translate: 'i18n.step.en_cours_de_finalisation',
  }),
  FAILED: new Step({
    code: 'failed',
    label: '',
    name: '',
    translate: 'i18n.step.failed',
  }),
  CLAIMED: new Step({
    code: 'claimed',
    label: '',
    name: '',
    translate: 'i18n.step.claimed',
  }),
  TO_BE_CHECKED: new Step({
    code: 'to_be_checked',
    label: '',
    name: '',
    translate: 'i18n.step.to_be_checked',
  }),

  RELANCE: new Step({
    code: 'relance',
    label: '',
    name: '',
    translate: 'i18n.step.relance',
  }),
  DESIGN_PROGRESS: new Step({
    code: 'design_progress',
    label: '',
    name: '',
    translate: 'i18n.step.design_progress',
  }),
  WAITING_FOR_REAL: new Step({
    code: 'waiting_for_real',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_for_real',
  }),
  SCHEDULED: new Step({
    code: 'scheduled',
    label: '',
    name: '',
    translate: 'i18n.step.scheduled',
  }),
  FROZEN: new Step({
    code: 'frozen',
    label: '',
    name: '',
    translate: 'i18n.step.frozen',
  }),
  APPOINTMENT_SCHEDULING: new Step({
    code: 'appointment_scheduling',
    label: '',
    name: '',
    translate: 'i18n.step.appointment_scheduling',
  }),
  COMPLETED: new Step({
    code: 'completed',
    label: '',
    name: '',
    translate: 'i18n.step.completed',
  }),
  PLANNING: new Step({
    code: 'planning',
    label: '',
    name: '',
    translate: 'i18n.step.planning',
  }),
  PRIORISATION_VALIDATED_FUNCTIONNALLY: new Step({
    code: 'priorisation_validated_functionnally',
    label: '',
    name: '',
    translate: 'i18n.step.priorisation_validated_functionnally',
  }),
  EXEMPTION_ASKED: new Step({
    code: 'exemption_asked',
    label: '',
    name: '',
    translate: 'i18n.step.exemption_asked',
  }),
  WAITING_FUNCTIONNAL_APPROVAL_N3: new Step({
    code: 'waiting_functionnal_approval_n3',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_functionnal_approval_n3',
  }),
  PRIORISATION_UNDER_VALIDATION: new Step({
    code: 'priorisation_under_validation',
    label: '',
    name: '',
    translate: 'i18n.step.priorisation_under_validation',
  }),
  VALIDATED_CLICK_TO_CALL: new Step({
    code: 'validated_click_to_call',
    label: '',
    name: '',
    translate: 'i18n.step.validated_click_to_call',
  }),
  WAITING_PLANNING: new Step({
    code: 'waiting_planning',
    label: '',
    name: '',
    translate: 'i18n.step.waiting_planning',
  }),
  WAITING: new Step({
    code: 'waiting',
    label: '',
    name: '',
    translate: 'i18n.step.waiting',
  }),
  IN_PREPARATION: new Step({
    code: 'in_preparation',
    label: '',
    name: '',
    translate: 'i18n.step.in_preparation',
  }),
  IN_PROGRESS_MANUAL: new Step({
    code: 'in_progress_manual',
    label: '',
    name: '',
    translate: 'i18n.step.in_progress_manual',
  }),
  FINALIZATION_IN_PROGRESS: new Step({
    code: 'finalization_in_progress',
    label: '',
    name: '',
    translate: 'i18n.step.finalization_in_progress',
  }),
  IN_PROGRESS_TECHNICAL: new Step({
    code: 'in_progress_technical',
    label: '',
    name: '',
    translate: 'i18n.step.in_progress_technical',
  }),
  FINISHED_REOPENING_REFUSAL: new Step({
    code: 'finished_reopening_refusal',
    label: '',
    name: '',
    translate: 'i18n.step.finished_reopening_refusal',
  }),
  FINISHED_ESCALATION_FOLLOWING_REFUSAL: new Step({
    code: 'finished_escalation_following_refusal',
    label: '',
    name: '',
    translate: 'i18n.step.finished_escalation_following_refusal',
  }),

  FINISHED_PENDDING: new Step({
    code: 'finished_pendding',
    label: '',
    name: '',
    translate: 'i18n.step.finished_pendding',
  }),
  REJECTED: new Step({
    code: 'rejected',
    label: '',
    name: '',
    translate: 'i18n.step.rejected',
  }),
  REJECTED_DEFINITELY: new Step({
    code: 'rejected_definitely',
    label: '',
    name: '',
    translate: 'i18n.step.rejected_definitely',
  }),
  AUTOMATICALLY_CANCELED: new Step({
    code: 'automatically_canceled',
    label: '',
    name: '',
    translate: 'i18n.step.automatically_canceled',
  }),
  AUTO_PROCESS_CHANGE_1: new Step({
    code: 'auto_process_change_1',
    label: '',
    name: '',
    translate: 'i18n.step.auto_process_change_1',
  }),
  AUTO_PROCESS_CHANGE_3: new Step({
    code: 'auto_process_change_3',
    label: '',
    name: '',
    translate: 'i18n.step.auto_process_change_3',
  }),
  PROCESS_ID_AUTO_CHANGED_REFUSED: new Step({
    code: 'process_id_auto_changed_refused',
    label: '',
    name: '',
    translate: 'i18n.step.process_id_auto_changed_refused',
  }),
  AUTO_PROCESS_CHANGED: new Step({
    code: 'auto_process_changed',
    label: '',
    name: '',
    translate: 'i18n.step.auto_process_changed',
  }),
  NO_ACTION: new Step({
    code: 'no_action',
    label: '',
    name: '',
    translate: 'i18n.step.no_action',
  }),
  AUTO_IN_PROGRESS: new Step({
    code: 'auto_in_progress',
    label: '',
    name: '',
    translate: 'i18n.step.auto_in_progress',
  }),
  REJECT_PRIO: new Step({
    code: 'reject_prio',
    label: '',
    name: '',
    translate: 'i18n.step.reject_prio',
  }),
  REJECT_PRIO_DEROG: new Step({
    code: 'reject_prio_derog',
    label: '',
    name: '',
    translate: 'i18n.step.reject_prio_derog',
  }),
  REJECT_PRIO_DEROG_VALIDATED: new Step({
    code: 'reject_prio_derog_Validated',
    label: '',
    name: '',
    translate: 'i18n.step.reject_prio_derog_Validated',
  }),
  NEW: new Step({
    code: 'new',
    label: '',
    name: '',
    translate: 'i18n.step.new',
  }),
  CANCELED: new Step({
    code: 'canceled',
    label: '',
    name: '',
    translate: 'i18n.step.canceled',
  }),
  DONE: new Step({
    code: 'finished',
    label: '',
    name: '',
    translate: 'i18n.step.finished',
  }),
};
