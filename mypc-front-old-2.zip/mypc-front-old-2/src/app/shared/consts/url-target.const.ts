/*
_self: the current browsing context. (Default)
_blank: usually a new tab, but users can configure browsers to open a new window instead.
_parent: the parent browsing context of the current one. If no parent, behaves as _self.
_top: the topmost browsing context (the "highest" context that's an ancestor of the current one). If no ancestors, behaves as _self.
*/
interface UrlTarget {
  SELF: string;
  BLANK: string;
  PARENT: string;
  TOP: string;
}

export enum EnumUrlTarget {
  SELF = '_self',
  BLANK = '_blank',
  PARENT = '_parent',
  TOP = '_top',
  POPUP = '_popup',
}

export const ConstUrlTarget: UrlTarget = {
  SELF: EnumUrlTarget.SELF,
  BLANK: EnumUrlTarget.BLANK,
  PARENT: EnumUrlTarget.PARENT,
  TOP: EnumUrlTarget.TOP,
};
