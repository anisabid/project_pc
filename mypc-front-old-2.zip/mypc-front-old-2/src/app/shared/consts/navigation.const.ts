import { environment } from '@environments/environment';
import { NavigationItems } from '@shared/models/navigation';
import { ConstAccess, EnumAccess, Access } from './access.const';
import { ConstRoutesPath } from './routes.const';
import { EnumUrlTarget } from './url-target.const';

export interface NavigationItemType {
  ITEM: string;
  GROUP: string;
  COLLAPSABLE: string;
  DIVIDER: string;
}

export enum EnumNavigationItemType {
  ITEM = 'item',
  GROUP = 'group',
  COLLAPSABLE = 'collapsable',
  DIVIDER = 'divider',
}

export const ConstNavigationItemType: NavigationItemType = {
  ITEM: EnumNavigationItemType.ITEM,
  GROUP: EnumNavigationItemType.GROUP,
  COLLAPSABLE: EnumNavigationItemType.COLLAPSABLE,
  DIVIDER: EnumNavigationItemType.DIVIDER,
};

// Export const NAVIGATION_MAIN
export const NAVIGATION_MAIN: NavigationItems = {
  profile: {
    id: 'profile',
    type: EnumNavigationItemType.ITEM,
    title: 'Profile',
    translate: 'i18n.navigation.profile',
    iconClass: 'icon-user-line',
    url: ConstRoutesPath.PROFILE,
    access: [ConstAccess.RSC_INVENTORY],
    accessPartner: false,
  },
  profileMenu: [
    {
      id: 'follow-up',
      type: EnumNavigationItemType.ITEM,
      title: 'Follow Up',
      translate: 'i18n.navigation.follow_up',
      iconName: 'done_all',
      url: '/mypc/index.php?p=ps/csl_suivis&frame=false',
      url_target: EnumUrlTarget.BLANK,
      access: [ConstAccess.CSL_FOLLOW_UP],
      accessPartner: false,
    },
    {
      id: 'changes',
      type: EnumNavigationItemType.ITEM,
      title: 'Changes',
      translate: 'i18n.navigation.changes',
      iconName: 'published_with_changes',
      url: '/mypc/index.php?p=ps/csl_actions',
      url_target: EnumUrlTarget.BLANK,
      url_config: {
        haveUrlPrefixToBackOffice: true,
        hash: 'selfActionsChg',
      },
      accessPartner: false,
    },
    {
      id: 'admin',
      type: EnumNavigationItemType.ITEM,
      title: 'Admin',
      translate: 'i18n.navigation.admin',
      iconName: 'admin_panel_settings',
      classes: 'accent',
      url: ConstRoutesPath.ADMINISTRATION,
      access: [ConstAccess.ADMIN, ConstAccess.ADMIN_MENU],
      accessPartner: false,
    },
    {
      id: 'reporting-my-groups',
      type: EnumNavigationItemType.ITEM,
      title: 'Reporting my groups',
      translate: 'i18n.navigation.reporting_my_groups',
      iconName: 'flag',
      url: '/mypc/index.php?p=ps/CreateExcelFile',
      url_target: EnumUrlTarget.BLANK,
      url_config: {
        haveUrlPrefixToBackOffice: true,
      },
      access: [ConstAccess.MY_REPORTS],
      accessPartner: false,
    },
    {
      id: 'my-delegation',
      type: EnumNavigationItemType.ITEM,
      title: 'My Delegation',
      translate: 'i18n.navigation.my_delegations',
      iconName: 'event',
      url: ConstRoutesPath.DELEGATIONS,
      access: [ConstAccess.MY_DELEGATIONS],
    },
    {
      id: 'my-groups',
      type: EnumNavigationItemType.ITEM,
      title: 'My groups',
      translate: 'i18n.navigation.my_groups',
      iconName: 'group',
      url: '/mypc/index.php?p=ps/adm_spe_groupes',
      url_target: EnumUrlTarget.BLANK,
      url_config: {
        haveUrlPrefixToBackOffice: true,
      },
      access: [
        ConstAccess.ADMIN_SPE_GROUPS,
        ConstAccess.GRP_MEMBER,
        ConstAccess.GRP_GEST,
      ],
      accessAllGranted: false,
    },
    {
      id: 'profile-menu-divider-a',
      type: EnumNavigationItemType.DIVIDER,
      hidden: environment.config.modules.login.disableLogout,
    },
    {
      id: 'logout',
      type: EnumNavigationItemType.ITEM,
      title: 'Logout',
      translate: 'i18n.navigation.logout',
      iconName: 'logout',
      url: ConstRoutesPath.LOGOUT,
      hidden: environment.config.modules.login.disableLogout,
    },
  ],
  menu: [
    {
      id: 'ng-home',
      type: EnumNavigationItemType.ITEM,
      title: 'Home',
      translate: 'i18n.navigation.home',
      iconClass: 'icon-home-line',
      url: ConstRoutesPath.DASHBOARD.HOME.ROUTE,
    },
    {
      id: 'ng-applications',
      type: EnumNavigationItemType.ITEM,
      title: 'Applications',
      translate: 'i18n.navigation.applications',
      iconClass: 'icon-apps-line',
      url: ConstRoutesPath.APPLICATIONS,
      accessPartner: false,
    },
    {
      id: 'ng-requests',
      type: EnumNavigationItemType.ITEM,
      title: 'Requests',
      translate: 'i18n.navigation.requests',
      iconClass: 'icon-folder-line',
      url: ConstRoutesPath.REQUESTS,
    },
    {
      id: 'ng-portal',
      type: EnumNavigationItemType.ITEM,
      title: 'Partener Portal',
      translate: 'i18n.navigation.partner_portal',
      iconClass: 'icon-partner',
      url: ConstRoutesPath.PORTAL,
      accessMedia: false,
    },
    {
      id: 'ng-security',
      type: EnumNavigationItemType.ITEM,
      title: 'Office Security',
      translate: 'i18n.navigation.office_security',
      iconClass: 'icon-lock-line',
      url: ConstRoutesPath.DASHBOARD.OFFICE_SECURITY.ROUTE,
      accessMedia: false,
      accessPartner: false,
    },
  ],
  footer: {
    header: {
      translate: 'i18n.navigation.useful_links',
    },
    menu: [
      {
        id: 'footer-blog',
        type: EnumNavigationItemType.ITEM,
        title: 'Blog bureautique',
        translate: 'i18n.navigation.blog',
        url_target: EnumUrlTarget.BLANK,
        url: 'https://intranetgroupe.private.sfr.com/xwiki/bin/view/Bureautique/',
        url_config: {
          haveJwt: false,
          haveOriginRecast: false,
          haveUrlPrefixToBackOffice: false,
        },
      },
      // {
      //   id: 'footer-reset-password',
      //   type: EnumNavigationItemType.ITEM,
      //   title: 'Reset mot de passe',
      //   translate: 'i18n.navigation.rest_passwort',
      //   url_target: EnumUrlTarget.BLANK,
      //   url: 'https://igepv002.encara.local.ads/tools/v0.3/index.html?uperid=${uperid}',
      //   url_config: {
      //     haveJwt: false,
      //     haveOriginRecast: false,
      //     haveUrlPrefixToBackOffice: false,
      //   },
      // },
      {
        id: 'footer-reset-password',
        type: EnumNavigationItemType.ITEM,
        title: 'Reset mot de passe',
        url_target: EnumUrlTarget.POPUP,
        translate: 'i18n.navigation.rest_password',
        url: 'https://igepv002.encara.local.ads/tools/v0.3/index.html?uperid=${uperid}',
        url_config: {
          haveJwt: false,
          haveOriginRecast: false,
          haveUrlPrefixToBackOffice: false,
        },
        accessMedia: false,
        accessPartner: false,
      },
    ],
  },
};
