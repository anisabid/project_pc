import { Status } from '@shared/models/status';

/**
 * Color States
 */
export interface statutes {
  DRAFT: Status;
  FINISHED: Status;
  IN_PROGRESS: Status;
  ESCALATION: Status;
  WAITING: Status;
  PLANNED: Status;
  RELAUNCH: Status;
  A_TRAITER: Status;
  FROZEN: Status;
  CLAIMED: Status;
  CANCELED: Status;
  DONE: Status;
  REJECTED: Status;
  WAITING_FUNCTIONNAL_APPROVAL_N1?: Status;
  WAITING_MANAGER_APPROVAL_N2?: Status;
  WAITING_MANAGER_APPROVAL_N1?: Status;
}

/**
 * ConstColorStates Const
 */

export const ConstStatutes: statutes = {
  DRAFT: new Status({
    background: '#9e9e9e',
    code: 'DRAFT',
    color: '#9e9e9e',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.draft',
  }),
  A_TRAITER: new Status({
    background: '#64C37E',
    code: 'done',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.done',
  }),
  ESCALATION: new Status({
    background: '#E40D29',
    code: 'escalation',
    statusCode: 'escalation',
    color: '#E40D29',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.escalation',
  }),
  FINISHED: new Status({
    background: '#E40D29',
    code: 'closed',
    statusCode: 'closed',
    color: '#E40D29',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.closed',
  }),
  IN_PROGRESS: new Status({
    background: '#647EC3',
    code: 'IN_PROGRESS',
    color: '#647EC3',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.in_progress',
  }),
  WAITING: new Status({
    background: '#E38C4D',
    code: 'WAITING',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.waiting',
  }),
  PLANNED: new Status({
    background: '#E38C8D',
    code: 'planned',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.planned',
  }),
  RELAUNCH: new Status({
    background: '#E38C8D',
    code: 'relaunch',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.relaunch',
  }),
  FROZEN: new Status({
    background: '#E38C9D',
    code: 'frozen',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.frozen',
  }),
  CLAIMED: new Status({
    background: '#E38C9D',
    code: 'claimed',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.claimed',
  }),
  CANCELED: new Status({
    background: '#FFA500',
    code: 'canceled',
    statusCode: 'canceled',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.canceled',
  }),

  DONE: new Status({
    background: '#64C37E',
    code: 'finished',
    statusCode: 'done',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.done_finished',
  }),

  REJECTED: new Status({
    background: '#8B0000',
    code: 'refusal',
    statusCode: 'refusal',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.rejected',
  }),

  WAITING_FUNCTIONNAL_APPROVAL_N1: new Status({
    background: '#8B0000',
    code: 'waiting_functionnal_approval_n1',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.waiting_functionnal_approval_n1',
  }),
  WAITING_MANAGER_APPROVAL_N1: new Status({
    background: '#64C37E',
    code: 'waiting_manager_approval_n1',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.waiting_manager_approval_n1',
  }),
  WAITING_MANAGER_APPROVAL_N2: new Status({
    background: '#64C37E',
    code: 'waiting_manager_approval_n2',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.waiting_manager_approval_n2',
  }),
};

export const ConstStatutesFilter: statutes = {
  DRAFT: new Status({
    background: '#9e9e9e',
    code: 'DRAFT',
    color: '#9e9e9e',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.draft',
  }),
  A_TRAITER: new Status({
    background: '#64C37E',
    code: 'done',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.done',
  }),
  ESCALATION: new Status({
    background: '#E40D29',
    code: 'escalation',
    statusCode: 'escalation',
    color: '#E40D29',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.escalation',
  }),
  FINISHED: new Status({
    background: '#E40D29',
    code: 'closed',
    statusCode: 'closed',
    color: '#E40D29',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.closed',
  }),
  IN_PROGRESS: new Status({
    background: '#647EC3',
    code: 'IN_PROGRESS',
    color: '#647EC3',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.in_progress',
  }),
  WAITING: new Status({
    background: '#E38C4D',
    code: 'WAITING',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.waiting',
  }),
  PLANNED: new Status({
    background: '#E38C8D',
    code: 'planned',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.planned',
  }),
  RELAUNCH: new Status({
    background: '#E38C8D',
    code: 'relaunch',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.relaunch',
  }),
  FROZEN: new Status({
    background: '#E38C9D',
    code: 'frozen',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.frozen',
  }),
  CLAIMED: new Status({
    background: '#E38C9D',
    code: 'claimed',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.claimed',
  }),
  CANCELED: new Status({
    background: '#FFA500',
    code: 'canceled',
    statusCode: 'canceled',
    color: '#E38C4D',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.canceled',
  }),

  DONE: new Status({
    background: '#64C37E',
    code: 'finished',
    statusCode: 'done',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.done_finished',
  }),

  REJECTED: new Status({
    background: '#8B0000',
    code: 'refusal',
    statusCode: 'refusal',
    color: '#64C37E',
    icon: '',
    label: '',
    name: '',
    text_color: '#FFFFFF',
    translate: 'i18n.status.rejected',
  }),
};
