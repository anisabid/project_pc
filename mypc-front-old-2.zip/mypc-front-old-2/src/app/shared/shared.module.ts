import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { PageComponent } from './components/page/page.component';
import { SnackBarComponent } from './components/snack-bar/snack-bar.component';
import { SoonComponent } from './components/soon/soon.component';
import { DirectivesModule } from './directives/directives.module';
import { LayoutModule } from './modules/layout/layout.module';
import { LoaderModule } from './modules/loader/loader.module';
import { MaterialModule } from './modules/material/material.module';
import { SnackBarMessageModule } from './modules/snack-bar-message/snack-bar-message.module';
import { PipesModule } from './pipes/pipes.module';

@NgModule({
  declarations: [
    ConfirmDialogComponent,
    PageComponent,
    SnackBarComponent,
    SoonComponent,
  ],
  imports: [
    CommonModule,
    DirectivesModule,
    FlexLayoutModule,
    FormsModule,
    LayoutModule,
    LoaderModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MaterialModule,
    MatIconModule,
    MatNativeDateModule,
    MatOptionModule,
    MatSelectModule,
    PerfectScrollbarModule,
    PipesModule,
    ReactiveFormsModule,
    RouterModule,
    SnackBarMessageModule,
    TranslateModule,
  ],
  exports: [
    ConfirmDialogComponent,
    DirectivesModule,
    FlexLayoutModule,
    LayoutModule,
    LoaderModule,
    MaterialModule,
    PageComponent,
    PerfectScrollbarModule,
    PipesModule,
    SnackBarMessageModule,
    SoonComponent,
    TranslateModule,
  ],
  providers: [DatePipe],
})
export class SharedModule {}
