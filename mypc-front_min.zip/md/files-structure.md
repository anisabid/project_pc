# Refonte MYPC - Files Structure

In this section we will describe a project logic and data.

We will focus on the `app/` folder inside the `src/` folder.

Angular components, templates, and styles go here (`app/`).

| `SRC/APP/[FILES OR FOLDERS]` | ROUTING                                       | PURPOSE          |
| :--------------------------- | :-------------------------------------------- | :--------------- |
| dashboard                    | [/dashboard](http://localhost:4200/dashboard) | Module Dashboard |
| profile                      | [/profile](http://localhost:4200/profile)     | Module Profile   |

## Lazy-loading && Preloading modules :

You can activate lazy loader by import `preloadingStrategy: PreloadAllModules`, in `app-routing.module.ts` :

> For angular.io documentation [click here](https://angular.io/guide/lazy-loading-ngmodules)

```
...
import { ..., PreloadAllModules } from '@angular/router';
...
const routes: Routes = [
  {
    path: 'path_module',
    loadChildren: () =>
      import('./name_of_module/name_of_module.module').then((m) => m.NameOfModule),
  },
  ...
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full',
  },
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
    relativeLinkResolution: 'legacy'
}),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
```

> You can activate **Preloading component data** by `resolver`. for more details [click here](https://angular.io/guide/lazy-loading-ngmodules#preloading-modules)

## Shared Module

## Translate

- In `shared` module we have i18n folder `src/app/shared/i18n/` for default translate items values.

**file `fr.ts`**

```
export const locale = {
  lang: "fr",
  data: {
    i18n: {
      global: {
        ...
        active: "Actif",
        actions: "Actions",
        add: "Ajouter",
        ...
      },
      ...
      otherGroupItems: {
        ...
        otherItem: "ItemTranslateValue"
        ...
      }
      ...
    },
  },
};
```

- In `app`module we have i18n folder `src/app/i18n/` for global translate items values

```
export const locale = {
  lang: "fr",
  data: {
    i18n: {
      global: {
        ...
        addOtherItemToGlobalGroup: "ItemTranslateValue"
        ...
      },
      ...
      otherGroupItems: {
        ...
        otherItem: "ItemTranslateValue"
        ...
      }
      ...
    },
  },
};
```

- For each module you can add i18n folder `moduleName/i18n/`

> To add file translate in your component :

1.  Import translate file, for exemple :
    `import { locale as localFrench } from "./i18n/fr";`
2.  Inject `Translate Loader Service` :
    `private translationLoaderService: TranslationLoaderService)`
3.  Use loader service for load translate file :
    `this.translationLoaderService.loadTranslations(localFrench);`

## Theme Typography

1. Define config

```
$sfr-typography: mat.define-typography-config(
  $font-family: $document-body-font-family,
);
```

2. Set config

```
@include mat.core($sfr-typography);
```

> More Documentaation
>
> - https://material.angular.io/guide/typography
> - https://github.com/angular/components/blob/master/src/material/core/typography/_typography.scss

## Next Item
