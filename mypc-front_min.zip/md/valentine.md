# CI/CD

## NameSpace

- **namespace** : mypc-dev

## Package - Docker

- [Module Package Docker](https://valentine-docs.private.sfr.com/valentine-docs/latest/cicd/package-docker.html)

## Deploy - Helm

- [Module de déploiement Helm](https://valentine-docs.private.sfr.com/valentine-docs/latest/cicd/deploy-helm.html)

## Tutoriels

- [CI/CD : premier pipeline - Création d’un premier pipeline pour déployer une application sous k8s](https://valentine-docs.private.sfr.com/valentine-docs/latest/tutoriels/pipeline_debutant.html)
- [CI/CD : Deuxième pipeline - Personnalisation du déploiement et mise en place des bonnes pratiques](https://valentine-docs.private.sfr.com/valentine-docs/latest/tutoriels/pipeline_intermediaire.html)

## Notes

- mypc-front.mypc-dev.ctn1.pic.services.pack

- [name of project gitlab].[namespace].[branche].ctn1.pic.services.pack

- [branche] : si je ne suis pas sur une branche defaut (main/master)

- .ctn1.pic.services.pack : ne change pas

- exemple pour la branche mypc-361 : mypc-front.mypc-dev.mypc-361.ctn1.pic.services.pack

- exemple pour la branche pack : mypc-front.mypc-dev.pack.ctn1.pic.services.pack

- exemple pour la branche develop : mypc-front.mypc-dev.develop.ctn1.pic.services.pack

- exemple pour la branche master ou main : mypc-front.mypc-dev.ctn1.pic.services.pack

- mypc-dev : dev ou autre branche

- mypc-int : master or main

- mypc: stagin + prod => tags

- readinessProbe : pour tester si l'application répond après le déploiement
- livenessProbe : périodiquement kubernetes test si l'application répond, si le node ne répond pas il va créer un autre
