# Refonte MYPC - Forms

## Inpout display column

> `form-field` with `column` class

```
<div class="form-field column">
    <div class="form-field-wrapper">
        <label class="form-label required">Label</label>
        <input
            type="text"
            class="form-control"
            ...
        />
        <mat-error class="form-error"> Error description</mat-error>
    </div>
</div>
```

> `form-field` with `row` class

```
<div class="form-field row">
    <div class="form-field-wrapper">
        <label class="form-label required">Label</label>
        <input
            type="text"
            class="form-control"
            ...
        />
        <mat-error class="form-error"> Error description</mat-error>
    </div>
</div>
```
