export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        extra: {
          soon: {
            title: 'Relooking pour MyPC',
            message:
              'Encore un peu de patience, la nouvelle interface de MyPC sera accessible à partir du <span class="important">15 Décembre</span>',
          },
        },
      },
    },
  },
};
