import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExtraComponent } from './extra.component';
import { extraRoutingModule } from './extra-routing.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [ExtraComponent],
  imports: [CommonModule, extraRoutingModule, FlexLayoutModule, SharedModule],
})
export class ExtraModule {}
