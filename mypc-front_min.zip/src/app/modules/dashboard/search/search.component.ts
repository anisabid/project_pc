import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { CatalogService } from '@app/modules/catalog/catalog.service';
import { CatalogAction, SearchCDS, SearchESUP, SearchResults } from '@shared/models/catalog';
import { EnumCatalogSearch } from '@shared/consts/catalog.const';
import { ActionsService } from '@shared/services/actions/actions.service';
import { StringHelperService } from '@shared/services/helper/string-helper.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { ActionEvent } from '@shared/models/action-event';
import { from, Observable, of } from 'rxjs';
import { map, startWith, switchMap } from 'rxjs/operators';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'sfr-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
})
export class SearchComponent implements OnInit {
  @ViewChild('sfrSearchWrapper') sfrSearchWrapper: ElementRef;
  public catalogs: Map<string, Array<CatalogAction>>;
  public catalogsSearchFG: UntypedFormGroup;
  public filteredActions: Observable<SearchResults> = new Observable<SearchResults>();
  public isQuickSearchFocused: boolean;
  private _searchWrapperOffsetWidth: string;
  public EnumCatalogSearch = EnumCatalogSearch;
  constructor(
    private translationLoaderService: TranslationLoaderService,
    private catalogService: CatalogService,
    private formBuilder: UntypedFormBuilder,
    private stringHelperService: StringHelperService,
    private actionsService: ActionsService
  ) {
    this.isQuickSearchFocused = false;
    this.translationLoaderService.loadTranslations(localFrench);
    this.catalogs = this.catalogService.getCatalogsActions();
    this.catalogsSearchFG = this.formBuilder.group({
      quickSearch: new UntypedFormControl(''),
    });
  }

  @HostListener('window:resize', ['$event'])
  onResize(): void {
    this.setSearchWrapperOffsetWidth();
  }

  ngOnInit(): void {
    this.filteredActions = this.catalogsSearchFG.get('quickSearch').valueChanges.pipe(
      startWith(''),
      map((term: string) => {
        if (term.length > 2) {
          return this.catalogService.searchCatalogs(term).then((searchResults: SearchResults) => searchResults);
        }
        this.onClosedAutocomplete();
        return of(null);
      }),
      switchMap((searchResults) => {
        return from(searchResults);
      })
    );
    this.setSearchWrapperOffsetWidth();
  }

  public formatActionName(value: string): string {
    return this.stringHelperService.boldSubstr(value, this.catalogsSearchFG.get('quickSearch').value.trim());
  }

  public getTransliterationGroup(value: string): string {
    switch (value) {
      case EnumCatalogSearch.ESUP:
        return 'i18n.module.search.help';
      case EnumCatalogSearch.CDS:
        return 'i18n.module.search.services';
      default:
        return 'i18n.module.search.services';
    }
  }

  public onOpenedAutocomplete(): void {
    this.actionsService.onEvents.next(
      new ActionEvent({
        component: 'component.search.AutocompletE',
        key: 'display',
        value: 'opened',
      })
    );
  }

  public onClosedAutocomplete(): void {
    this.actionsService.onEvents.next(
      new ActionEvent({
        component: 'component.search.Autocomplete',
        key: 'display',
        value: 'closed',
      })
    );
  }

  public displayQuickSearch(action: SearchCDS | SearchESUP): string {
    return action && action.Libelle ? action.Libelle : '';
  }

  public onOptionSelected(): void {
    this.actionsService.onEvents.next(
      new ActionEvent({
        component: 'component.search.autocomplete',
        key: 'optionSelected',
        value: this.catalogsSearchFG.get('quickSearch').value,
      })
    );
  }

  public clearQuickSearch(): void {
    this.catalogsSearchFG.get('quickSearch').setValue('');
    this.onClosedAutocomplete();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private
  // -----------------------------------------------------------------------------------------------------

  private setSearchWrapperOffsetWidth(): void {
    if (this.sfrSearchWrapper) this.searchWrapperOffsetWidth = this.sfrSearchWrapper.nativeElement.offsetWidth;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Getters & Setters methods
  // -----------------------------------------------------------------------------------------------------

  get searchWrapperOffsetWidth(): string {
    return this._searchWrapperOffsetWidth;
  }

  set searchWrapperOffsetWidth(value: string) {
    this._searchWrapperOffsetWidth = value + 'px';
  }
}
