import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { ModalActionComponent } from './modal/modal-action/modal-action.component';
import { WorkflowComponent } from './workflow.component';

@NgModule({
    declarations: [WorkflowComponent, ModalActionComponent],
    imports: [CommonModule, SharedModule],
    exports: [WorkflowComponent]
})
export class WorkflowModule {}
