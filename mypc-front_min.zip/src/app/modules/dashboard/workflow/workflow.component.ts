import {
  AfterViewInit,
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatLegacyDialog as MatDialog, MatLegacyDialogConfig as MatDialogConfig } from '@angular/material/legacy-dialog';
import { ActivatedRoute } from '@angular/router';
import { CatalogService } from '@app/modules/catalog/catalog.service';
import { SessionService } from '@shared/services/session/session.service';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { ActionEvent } from '@shared/models/action-event';
import {
  Catalog,
  CatalogAction,
  Catalogs,
  SearchCDS,
  SearchESUP,
} from '@shared/models/catalog';
import { SidebarService } from '@shared/modules/layout/components/sidebar/sidebar.service';
import { ActionsService } from '@shared/services/actions/actions.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { Subscription } from 'rxjs';
import { locale as localFrench } from './i18n/fr';
import { ModalActionComponent } from './modal/modal-action/modal-action.component';
import { ConstTypesCatalogs } from '@app/shared/consts/catalog.const';

@Component({
  selector: 'sfr-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.scss'],
})
export class WorkflowComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('sfrStepItemsRoot') sfrStepItemsRoot: ElementRef;
  public catalogs: Catalogs;
  public catalogsSelected: Array<Catalog>;
  public currentStep: number;
  public selectedAction: string;
  public steps: Array<string>;
  private _stepItemsOffsetWidth: string;
  private sidebarServiceOnItemClickSubscription: Subscription;
  private actionsServiceOnEventsSubscription: Subscription;

  constructor(
    private translationLoaderService: TranslationLoaderService,
    private catalogService: CatalogService,
    private matDialog: MatDialog,
    private actionsService: ActionsService,
    private sidebarService: SidebarService,
    private activatedRoute: ActivatedRoute,
    private sessionService: SessionService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.catalogs = this.catalogService.catalogs;
    this.currentStep = 0;
    this.selectedAction = null;
    this.steps = [];
  }
  //https://dev.to/nikosanif/how-to-set-dynamic-height-at-element-with-angular-directive-5986

  @HostListener('window:resize', ['$event'])
  onResize() {
    this.setStepItemsOffsetWidth();
  }

  ngOnInit(): void {
    this.listenForAutocompleteSelectActionEvent();
    this.listenForSidebarItemClickEvent();
    if (
      this.activatedRoute.snapshot.routeConfig.path ===
      ConstRoutesPath.DASHBOARD.OFFICE_SECURITY.PATH
    ) {
      this.goToScurityWorkflow();
    }
  }

  ngAfterViewInit() {
    this.setStepItemsOffsetWidth();
  }

  ngOnDestroy(): void {
    if (this.sidebarServiceOnItemClickSubscription) {
      this.sidebarServiceOnItemClickSubscription.unsubscribe();
    }
    if (this.actionsServiceOnEventsSubscription) {
      this.actionsServiceOnEventsSubscription.unsubscribe();
    }
  }

  public selectStep(step: number = null, id: string = null): void {
    this.steps.splice(step);
    if (step !== null && id !== null) {
      this.steps.push(id);
    }
    this.currentStep = this.steps.length;
    this.getCatalogsBySteps();
  }

  public selectAction(action: CatalogAction = null) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.data = {
      action: action,
      requestType: this.steps[0],
    };
    this.matDialog
      .open(ModalActionComponent, dialogConfig)
      .afterClosed()
      .subscribe((rollBack: boolean) => {
        if (rollBack) {
          this.resetWorkflow();
        }
      });
  }

  public getCatalogsBySteps() {
    this.catalogsSelected = this.catalogService.getCatalogsBySteps(this.steps);
  }

  // Fix order display issue
  // Bug with Map loop in view
  public catalogsSelectedChildrenToJson(children: Map<string, Catalog>) {
    let arr: Array<Catalog> = [];
    children.forEach(function (value) {
      arr.push(value);
    });
    return arr;
  }

  public isStepInProgress(step: number = null): boolean {
    return step !== null ? this.currentStep === step : false;
  }

  public isStepDone(step: number = null): boolean {
    return step !== null ? step < this.currentStep : false;
  }

  public createNewGenericIncident(val: Catalog) {
    const catalog: Catalog = new Catalog(val);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.data = {
      catalog: catalog,
      requestType: this.steps[0],
    };
    this.matDialog
      .open(ModalActionComponent, dialogConfig)
      .afterClosed()
      .subscribe((rollBack: boolean) => {
        if (rollBack) {
          this.resetWorkflow();
        }
      });
  }

  public displayBtnCreateNewGenericIncident(val: Catalog): boolean {
    const catalog: Catalog = new Catalog(val);
    return (
      catalog.isESUP() &&
      !this.sessionService.session.user.isPartner &&
      !this.sessionService.session.user.isMedia
    );
  }

  public isDisplay(item: Catalog): boolean {
    if (
      item.id === ConstTypesCatalogs.CDS &&
      this.sessionService.session.user.isPartner
    )
      return false;
    return true;
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Private
  // -----------------------------------------------------------------------------------------------------

  private setStepItemsOffsetWidth() {
    this.stepItemsOffsetWidth = this.sfrStepItemsRoot.nativeElement.offsetWidth;
  }

  /**
   * Find Catalog Action By Form ID
   * @param actionFromSearch Selected Action from Search
   */
  private findCatalogActionByFormId(
    actionFromSearch: SearchCDS | SearchESUP
  ): CatalogAction | null {
    let foundAction: CatalogAction;
    this.catalogService.getCatalogsActions().forEach((catalogAction) =>
      catalogAction.map((action) => {
        if (action.formId.toString() === actionFromSearch.formId.toString()) {
          foundAction = action;
        }
      })
    );
    return foundAction ? foundAction : null;
  }

  /**
   * Listen For Autocomplete Select Action Event
   */
  private listenForAutocompleteSelectActionEvent(): void {
    this.actionsServiceOnEventsSubscription =
      this.actionsService.onEvents.subscribe((actionEvent: ActionEvent) => {
        if (
          actionEvent.component ===
            (<string>'component.search.autocomplete').toLowerCase() &&
          actionEvent.key === (<string>'optionSelected').toLowerCase()
        ) {
          if (actionEvent.value) {
            const foundCatalogAction: CatalogAction =
              this.findCatalogActionByFormId(actionEvent.value);
            if (foundCatalogAction) {
              this.steps =
                this.catalogService.getStepsByAction(foundCatalogAction);
              this.currentStep = this.steps.length;
              this.getCatalogsBySteps();
              this.selectedAction = foundCatalogAction.id;
              this.selectAction(foundCatalogAction);
            }
          }
        }
      });
  }

  private listenForSidebarItemClickEvent(): void {
    this.sidebarServiceOnItemClickSubscription =
      this.sidebarService.onItemClick.subscribe((id: string) => {
        if (id === (<string>'ng-home').toLowerCase()) {
          this.resetWorkflow();
        }
        if (id === (<string>'ng-security').toLocaleLowerCase()) {
          this.goToScurityWorkflow();
        }
      });
  }

  private resetWorkflow(): void {
    this.selectStep(0);
  }

  private goToScurityWorkflow(): void {
    this.steps = ['esup', '1499'];
    this.currentStep = this.steps.length;
    this.getCatalogsBySteps();
  }

  /**
   * Separate Name Parts (replace / with / with space)
   * @param name Category name
   */
  public separateNameParts(name: string): string {
    if (name?.includes('/')) {
      return name.split('/').join(' / ');
    }
    return name;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Getters & Setters methods
  // -----------------------------------------------------------------------------------------------------

  get stepItemsOffsetWidth(): string {
    return this._stepItemsOffsetWidth;
  }

  set stepItemsOffsetWidth(value: string) {
    this._stepItemsOffsetWidth = value + 'px';
  }
}
