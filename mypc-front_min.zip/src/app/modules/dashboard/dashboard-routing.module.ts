import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CatalogService } from '@app/modules/catalog/catalog.service';
import { ConstRoutesPath } from '@shared/consts/routes.const';

import { DashboardComponent } from './dashboard.component';

const routes: Routes = [
  {
    path: ConstRoutesPath.DASHBOARD.HOME.PATH,
    component: DashboardComponent,
    resolve: {
      data: CatalogService,
    },
  },
  {
    path: ConstRoutesPath.DASHBOARD.OFFICE_SECURITY.PATH,
    component: DashboardComponent,
    resolve: {
      data: CatalogService,
    },
  },
  {
    path: '',
    redirectTo: ConstRoutesPath.DASHBOARD.HOME.PATH,
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
