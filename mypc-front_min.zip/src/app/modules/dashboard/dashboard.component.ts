import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActionEvent } from '@shared/models/action-event';
import { User } from '@shared/models/user';
import { ActionsService } from '@shared/services/actions/actions.service';
import { SessionService } from '@shared/services/session/session.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'sfr-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit, OnDestroy {
  public user: User;
  public isBlurWorkflow: boolean;

  constructor(private translationLoaderService: TranslationLoaderService, private sessionService: SessionService, private actionsService: ActionsService) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.user = this.sessionService.user;
    //this.isBlurWorkflow = false;
  }

  ngOnInit(): void {
    this.actionsService.onEvents.subscribe((actionEvent: ActionEvent) => {
      if (actionEvent.component === (<string>'component.search.autocomplete').toLowerCase() && actionEvent.key === (<string>'display').toLowerCase()) {
        this.isBlurWorkflow = actionEvent.value === 'opened' ? true : false;
      }
    });
  }

  ngOnDestroy(): void {
    // this.actionsService.onEvents.unsubscribe();
  }
}
