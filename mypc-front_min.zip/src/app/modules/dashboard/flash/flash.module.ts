import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { FlashComponent } from './flash.component';
import { ModalFlashComponent } from './modal-flash/modal-flash.component';

@NgModule({
  declarations: [FlashComponent, ModalFlashComponent],
  imports: [CommonModule, SharedModule],
  exports: [FlashComponent],
})
export class FlashModule {}
