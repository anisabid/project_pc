import { Component, OnInit } from '@angular/core';
import { MatLegacyDialog as MatDialog, MatLegacyDialogConfig as MatDialogConfig } from '@angular/material/legacy-dialog';
import { DashboardService } from '../dashboard.service';
import { Flash } from './flash.model';
import { ModalFlashComponent } from './modal-flash/modal-flash.component';

@Component({
  selector: 'sfr-flash',
  templateUrl: './flash.component.html',
  styleUrls: ['./flash.component.scss'],
})
export class FlashComponent implements OnInit {
  show: boolean = true;
  flash: Flash;

  /**
   * Constructor
   * @param dashboardService Dashboard Service
   * @param matDialog Material Dialog
   */
  constructor(
    private dashboardService: DashboardService,
    private matDialog: MatDialog
  ) {
    this.flash = null;
  }

  ngOnInit(): void {
    this.dashboardService.getInformationFlash().subscribe((result: any) => {
      this.flash = new Flash(result.informationflash);
    });
  }
  closeFlash(): void {
    this.show = false;
  }
  openDialog(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.width = '40vw';
    dialogConfig.data = this.flash;
    this.matDialog.open(ModalFlashComponent, dialogConfig);
  }

  public displayFlash(): boolean {
    return this.show && this.flash && this.flash?.success;
  }
}
