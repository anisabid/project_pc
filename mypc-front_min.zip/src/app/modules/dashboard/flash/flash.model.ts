export interface IFlash {
  date: String;
  message: String;
  dateEnd: String;
  type: EnumFlashType;
}

export class Flash implements IFlash {
  success: boolean;
  date: String;
  message: String;
  type: EnumFlashType;
  dateEnd: String;
  constructor(data?: any, fromApi: boolean = true) {
    this.date = !data?.date ? null : data.date;
    if (data?.message) {
      this.message =
        '<div>' +
        data.message.replace(new RegExp('color', 'g'), '"color') +
        '</div>';
    }
    this.dateEnd = !data?.dateEnd ? null : data.dateEnd;
    this.success = !data?.success ? false : data.success === 'true';
    this.type = !data?.type
      ? EnumFlashType.INFO
      : Object.values(EnumFlashType).includes(data.type)
      ? data.type
      : EnumFlashType.INFO; // la valeur par défaut est 'info'.
  }
}

export enum EnumFlashType {
  DANGER = 'danger',
  DARK = 'dark',
  INFO = 'info',
  SUCCESS = 'success',
  WARNING = 'warning',
}
