import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EndpointService } from '@shared/services/api/v2/endpoint.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  private _endpointWidgetRequests: EndpointService;
  private _endpointFlash: EndpointService;
  private _endpointInformation: EndpointService;

  /**
   * Constructor
   * @param httpClient Http Client
   * @param environmentService Environment Service
   * @param urlHelperService Url Helper Service
   */
  constructor(
    private httpClient: HttpClient,
    private environmentService: EnvironmentService,
    private urlHelperService: UrlHelperService
  ) {
    this._endpointWidgetRequests = new EndpointService('requests');
    this._endpointWidgetRequests.items.get =
      '?limit=${limit}&offset=${offset}${action}${status}';

    this._endpointFlash = new EndpointService('information-flash');
    this._endpointFlash.item.get = '';

    this._endpointInformation = new EndpointService('informations');
    this._endpointInformation.item.get = '';
  }

  /**
   * Get Request for Widget
   * @param obj Request Object
   */
  getWidgetRequests(obj: Object = {}): Observable<any> {
    const params = {
      '${action}': obj['action']
        ? '&action=' + obj['action'].toString()
        : '&action=requests',
      '${limit}': obj['limit'] ? obj['limit'].toString() : 50,
      '${offset}': obj['offset'] ? obj['offset'].toString() : 0,
      '${status}': obj['status'] ? '&status=' + obj['status'].toString() : '',
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpointWidgetRequests.items.get,
      params
    );
    if (this.environmentService.options.mock.data.counter) {
      path = this._endpointWidgetRequests.toMock(path);
    }

    return this.httpClient.get(path);
  }

  /**
   * Get Information Flash
   */
  getInformationFlash(): Observable<any> {
    let path: string = this._endpointFlash.item.get;
    if (this.environmentService.options.mock.data.catalog) {
      path = this._endpointFlash.toMock(path);
    }
    return this.httpClient.get(path);
  }

  /**
   * Get Information Widget
   */
  getInformationWidget(): Observable<any> {
    let path: string = this._endpointInformation.item.get;
    if (this.environmentService.options.mock.data.catalog) {
      path = this._endpointFlash.toMock(path);
    }
    return this.httpClient.get(path);
  }
}
