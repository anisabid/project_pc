import { ICounter } from '@shared/models/counter';
import { Source } from '@shared/models/source';

export enum OPERATIONS {
  REQUESTS = 'requests',
  APPROVALS = 'approvals',
}
export class Operation {
  name: OPERATIONS;
  route: String;
  dataSource: Source;
  counter: ICounter;
  constructor(name: OPERATIONS, route: String, dataSource: Source) {
    this.name = name;
    this.route = route;
    this.dataSource = dataSource;
  }
}
