import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../dashboard.service';
import { Information } from './information.model';

@Component({
  selector: 'sfr-widget-information',
  templateUrl: './widget-information.component.html',
  styleUrls: ['./widget-information.component.scss'],
})
export class WidgetInformationComponent implements OnInit {
  information: Information;

  /**
   * Constructor
   * @param dashboardService Dashboard Service
   */
  constructor(private dashboardService: DashboardService) {}

  ngOnInit(): void {
    this.dashboardService.getInformationWidget().subscribe((result: any) => {
      this.information = new Information(result.informations);
    });
  }
}
