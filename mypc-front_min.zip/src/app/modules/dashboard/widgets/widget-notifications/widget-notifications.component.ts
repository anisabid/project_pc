import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sfr-widget-notifications',
  templateUrl: './widget-notifications.component.html',
  styleUrls: ['./widget-notifications.component.scss']
})
export class WidgetNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
