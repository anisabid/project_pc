import { Injectable } from '@angular/core';
import { UserSearchResult } from '@shared/models/user';
import { ApiService } from '@shared/services/api/v2/api.service';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AdvancedFilterService {
  public translateNode = 'i18n.module.requests.components.list.filter.';
  constructor(private apiService: ApiService) {}

  /**
   * Get Users
   * @param value Value
   * @param offset Offset
   * @param limit Limit
   */
  getUsers(
    value?: string,
    offset?: number,
    limit?: number
  ): Observable<UserSearchResult> {
    return this.apiService.users.getUsers(value, offset, limit);
  }
}
