import { Component, Input } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from '@app/modules/requests/i18n/fr';
import { MatLegacyDialog as MatDialog, MatLegacyDialogConfig as MatDialogConfig } from '@angular/material/legacy-dialog';
import { ModalComplaintComponent } from '../modal/modal-complaint/modal-complaint.component';
import { LifeCycleChange } from '@requestsModule/models/life-cycle.model';
import { ActionTypeService } from '@app/modules/requests/services/action-type.service';

@Component({
  selector: 'sfr-changes',
  templateUrl: './changes.component.html',
  styleUrls: ['./changes.component.scss'],
})
export class ChangesComponent {
  @Input() changes: LifeCycleChange[] = [];

  /**
   * Constructor
   * @param translationLoaderService Translation Loader Service
   * @param matDialog Material Dialog
   * @param store NgRx Store
   * @param actionTypeService Action-type Service
   */
  constructor(
    private translationLoaderService: TranslationLoaderService,
    private matDialog: MatDialog,
    private actionTypeService: ActionTypeService
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
  }

  /**
   * Check if the change is a complaint
   * @param complaint change to verify
   * @param isShowComplaint determine if to show/hide
   */
  isComplaint(complaint: boolean, isShowComplaint: boolean): boolean {
    return complaint && isShowComplaint;
  }

  /**
   * Insert Line Breaks to replace <br>
   * @param comment Comment to format
   */
  insertLineReturn(comment: string): string {
    return comment && comment !== ''
      ? comment.replace(/<\s*\/?br>/gi, '\r\n')
      : '';
  }

  /**
   * Get Arrow Position Icon
   * @param show determines show/hide mode
   */
  getArrowPosition(show: boolean): string {
    return show ? 'keyboard_arrow_up' : 'keyboard_arrow_down';
  }

  /**
   * Open a file new Complaint Dialog
   */
  public complaintAction(change: any): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.data = {
      change,
      actionType: this.actionTypeService.getActionType,
    };
    dialogConfig.autoFocus = false;
    this.matDialog.open(ModalComplaintComponent, dialogConfig);
  }
}
