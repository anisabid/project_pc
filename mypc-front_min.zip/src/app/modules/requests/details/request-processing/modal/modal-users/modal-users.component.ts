import {Component, Inject, OnInit, ViewEncapsulation} from '@angular/core';
import {MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA, MatLegacyDialogRef as MatDialogRef} from "@angular/material/legacy-dialog";

@Component({
  selector: 'sfr-modal-users',
  templateUrl: './modal-users.component.html',
  styleUrls: ['./modal-users.component.scss'],
    encapsulation: ViewEncapsulation.None,

})
export class ModalUsersComponent implements OnInit {
 users;
  constructor(
      @Inject(MAT_DIALOG_DATA) public data: any,
      public dialogRef: MatDialogRef<ModalUsersComponent>,
  ) { }

  ngOnInit(): void {
    this.users = this.data.users;
  }



}
