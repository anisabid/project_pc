import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import {
  FormGroup,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { DataType } from '@app/modules/requests/enums/dataType.enum';
import { RequestsService } from '@app/modules/requests/services/requests.service';
import { User } from '@shared/models/user';
import { ApiService } from '@shared/services/api/v2/api.service';
import { SessionService } from '@shared/services/session/session.service';
import { Observable, Subscription } from 'rxjs';
import {
  LifeCycle,
  LifeCycleActionItem,
  LifeCycleSummary,
} from '@app/modules/requests/models/life-cycle.model';
import {
  LifeCycleActionActions,
  LifeCycleCommentActions,
  lifeCycleSelectors,
} from '@app/modules/requests/store';
import { Store } from '@ngrx/store';

@Component({
  selector: 'sfr-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.scss'],
})
export class CommentComponent implements OnInit, OnDestroy {
  @Input() comments;
  @Input() currentStep;

  public vfile = undefined;
  isShowConversation: boolean = false;
  addComment: boolean = true;
  items = Array.from({ length: 100000 }).map((_, i) => `Item #${i}`);

  public user: User;
  public commentFG: UntypedFormGroup = new FormGroup({});
  private subscription: Subscription = new Subscription();
  private dataType: DataType;
  public showNoteButton: boolean = true;

  public isAnswer: boolean = false;
  public isComplement = false;
  public idAction: any;

  /**
   * Selected Life-cycle Observable
   */
  public selectedLifeCycle$: Observable<LifeCycle>;
  /**
   * Constructor
   * @param sessionService Session Service
   * @param apiService API Service
   * @param requestsService Requests Service
   * @param formBuilder Form Builder
   * @param store NgRx Store
   */
  constructor(
    private sessionService: SessionService,
    private apiService: ApiService,
    private requestsService: RequestsService,
    private formBuilder: UntypedFormBuilder,
    private store: Store
  ) {
    this.user = this.sessionService.user;
  }

  /**
   * Init Function
   */
  ngOnInit(): void {
    this.getLifeCycle();
    this.getAvatars();
    this.commentFG = this.commentFormInit();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle() {
    this.selectedLifeCycle$ = this.store.select(
      lifeCycleSelectors.selectSelectedRequest
    );

    this.subscription.add(
      this.selectedLifeCycle$.subscribe((lifeCycle: LifeCycle) => {
        if (lifeCycle) {
          this.checkIfComplement(lifeCycle.actions, lifeCycle.resume);
          this.checkIfAnswer(lifeCycle.actions, lifeCycle.resume);
        }
      })
    );
  }

  /**
   * Check if Complement
   * @param actions Actions
   */
  checkIfComplement(
    actions: LifeCycleActionItem[],
    resume: LifeCycleSummary
  ): void {
    const complementFound = actions?.find((action: LifeCycleActionItem) =>
      action?.libelle_btn.includes("Demander un complément d'information")
    );

    if (complementFound) {
      this.isComplement = true;
      this.idAction = {
        id: complementFound.id_action,
        dateUpdate: resume.lmd,
      };
    }
  }

  /**
   * Check if Answer
   * @param actions Actions
   */
  checkIfAnswer(
    actions: LifeCycleActionItem[],
    resume: LifeCycleSummary
  ): void {
    const answerFound = actions?.find((action: LifeCycleActionItem) =>
      action?.libelle_btn.includes("Répondre au complément d'information")
    );
    if (answerFound) {
      this.isAnswer = true;
      this.idAction = {
        id: answerFound.id_action,
        dateUpdate: resume.lmd,
      };
    }
  }

  /**
   * Check if it's a conversation start
   */
  isStartConversation(): void {
    this.dataType = DataType.NOTE;
    this.isShowConversation = true;
    this.showNoteButton = false;
    this.isAnswer = false;
    this.isComplement = false;
  }

  /**
   * Check if it's a Comment Answer
   */
  isShowAddCommentAnswer(): void {
    this.dataType = DataType.ACTION;
    this.isAnswer = false;
    this.isComplement = false;
    this.showNoteButton = false;
  }

  /**
   * Check if it's an Information Complement
   */
  isShowAddCommentComplement(): void {
    this.dataType = DataType.ACTION;
    this.isComplement = false;
    this.isAnswer = false;
    this.showNoteButton = false;
  }

  /**
   * Show Ask For More Information Button
   */
  public showAskForInformationButton(): boolean {
    return (
      this.isComplement &&
      !this.isShowConversation &&
      !this.comments &&
      this.currentStep
    );
  }

  /**
   * Respond to Followup Request Button
   */
  public showRespondToFollowUpRequestButton(): boolean {
    return (
      this.isAnswer &&
      !this.isShowConversation &&
      !this.comments &&
      this.currentStep
    );
  }

  /**
   * Show Add Comment Button
   */
  public showAddCommentButton(): boolean {
    return (
      !this.isShowConversation &&
      !this.comments &&
      this.currentStep &&
      this.showNoteButton
    );
  }

  /**
   * Show Add Comment Input Field
   */
  public showAddCommentInputField(): boolean {
    return (
      !(this.isAnswer || this.isComplement || this.showNoteButton) ||
      this.isShowConversation
    );
  }

  /**
   * Show Form Respond Form Buttons
   */
  public showFormRespondButtons(): boolean {
    return (
      (this.isAnswer || this.isComplement || this.showNoteButton) &&
      this.comments
    );
  }

  /**
   * Check if is current user
   * @param perId person ID
   */
  isCurrentUser(perId): boolean {
    return perId.includes(this.user.perId);
  }

  /**
   * Init Comment Form
   */
  commentFormInit(): UntypedFormGroup {
    return this.formBuilder.group({
      note: ['', Validators.required],
      vfile: [''],
    });
  }

  /**
   * Add Note
   */
  addNote(): void {
    const requestId = localStorage.getItem('idRequest');
    const formData = new FormData();
    formData.append('vfile', this.vfile);
    formData.append('note', this.commentFG.get('note').value);

    this.store.dispatch(
      LifeCycleCommentActions.AddComment({
        request_id: requestId,
        body: formData,
      })
    );
  }

  /**
   * Add Action
   */
  addAction(): void {
    const idDemande = localStorage.getItem('idRequest');
    const formData = new FormData();
    formData.append('vfile', this.vfile);
    formData.append('user_comment', this.commentFG.get('note').value);
    formData.append('wf_status', this.idAction.id);
    formData.append('lmd', this.idAction.dateUpdate);

    this.store.dispatch(
      LifeCycleActionActions.AddLifeCycleAction({
        request_id: idDemande,
        body: formData,
      })
    );
  }

  /**
   * Send Data
   */
  sendData(): void {
    if (this.dataType === DataType.ACTION) {
      if (this.idAction) {
        this.addAction();
      }
    } else {
      this.addNote();
    }
  }

  /**
   * On File Change
   * @param event Event
   */
  onFileChange(event): void {
    if (event.target.files && event.target.files.length) {
      this.vfile = event.target.files[0];
    }
  }

  /**
   * Get Users Avatars
   * TODO: Convert this function to use NgRx after adding Users store
   */
  getAvatars(): void {
    if (this.comments) {
      const uids = [...new Set(this.comments.map((item) => item.user_uperid))]; // table of unique uids for comments
      uids.forEach((user: string) => {
        // For each uid we recover the avatar with the api
        this.subscription.add(
          this.apiService.users
            .getAvatar({ uPerId: user })
            .subscribe((result: { avatar: string }) => {
              this.comments
                .filter((comment) => comment.user_uperid == user)
                .forEach((element) => {
                  element.avatarStyle = this.getStyleBackgroundImageAvatar(
                    result.avatar
                  );
                  element.avatar = !(element.avatarStyle == '');
                }); // For each comment, we attribute a style depending on the user
            })
        );
      });
    }
  }

  /**
   * Get Background Avatar
   * @param value value
   */
  getStyleBackgroundImageAvatar(value: string) {
    return value
      ? 'background-image: url("data:image/png;base64,' + value + '");'
      : '';
  }

  /**
   * Get File URL
   * @param filePath Relative file path
   */
  getFileURL(filePath: string): string {
    return filePath && filePath !== ''
      ? this.requestsService.getFullFileURL(filePath)
      : '';
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
