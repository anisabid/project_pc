import { Component, HostListener, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { BusIframe } from '@shared/models/bus-iframe';
import { Router } from '@angular/router';
import { ActionTypeService } from '@app/modules/requests/services/action-type.service';

@Component({
  selector: 'sfr-origin-form',
  templateUrl: './origin-form.component.html',
  styleUrls: ['./origin-form.component.scss'],
})
export class OriginFormComponent implements OnInit {
  public idRequest;
  public src: SafeResourceUrl;

  constructor(
    private urlHelperService: UrlHelperService,
    private domSanitizer: DomSanitizer,
    private router: Router,
    private actionTypeService: ActionTypeService
  ) {}

  @HostListener('window:message', ['$event'])
  onMessage(event) {
    if (event.data) {
      try {
        const jsonParse = JSON?.parse(event.data);
        const data: BusIframe = new BusIframe(jsonParse);
        if (data && data.actions) {
          if (data.hasAction('CLOSE_MATDIALOG')) {
            // traitement
            this.reloadCurrentRoute();
          }
        }
      } catch (ex) {
        // console.error(ex);
      }
    }
  }

  /**
   * Reload Current Route
   */
  reloadCurrentRoute(): void {
    this.actionTypeService.reloadCurrentRoute(this.router.url);
  }

  public ngOnInit(): void {
    this.processedDocument();
  }

  /**
   * Create IFrame link source
   */
  processedDocument(): void {
    let url = this.urlHelperService.transformParameters(
      'mypc/index.php?p=ps%2Fview_form&item_id=${id}',
      {
        '${id}': localStorage.getItem('idRequest'),
      }
    );
    this.src = this.domSanitizer.bypassSecurityTrustResourceUrl(
      this.urlHelperService.toBackOffice(url)
    );
  }
}
