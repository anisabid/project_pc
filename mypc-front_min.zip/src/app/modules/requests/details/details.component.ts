import {
  AfterViewChecked,
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatLegacyDialog as MatDialog, MatLegacyDialogConfig as MatDialogConfig } from '@angular/material/legacy-dialog';
import { ModalActionsComponent } from '@app/modules/requests/details/request-processing/modal/modal-actions/modal-actions.component';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { Observable, Subscription } from 'rxjs';
import { RequestQueryActions } from '../enums/request-query-actions.enum';
import {
  EnumRequestsRoutesPath,
  EnumRequestTypePath,
} from '../const/request.const.routes';
import { LifeCycle } from '../models/life-cycle.model';
import { Store } from '@ngrx/store';
import { lifeCycleSelectors } from '../store';
import { ActionTypeService } from '../services/action-type.service';

@Component({
  selector: 'sfr-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss'],
})
export class DetailsComponent implements OnInit, AfterViewChecked, OnDestroy {
  private subscription: Subscription = new Subscription();
  /**
   * Selected Life-cycle Observable
   */
  public selectedLifeCycle$: Observable<LifeCycle>;
  public idRequest: string;

  /**
   * Constructor
   * @param route Route
   * @param cdref CdRef
   * @param matDialog Material Dialog
   * @param store NgRx Store
   * @param actionTypeService Action Type Service
   */
  constructor(
    private route: ActivatedRoute,
    private cdRef: ChangeDetectorRef,
    private matDialog: MatDialog,
    private store: Store,
    private actionTypeService: ActionTypeService
  ) {}

  /**
   * On Init
   */
  ngOnInit(): void {
    this.getLifeCycle();
    this.getRequestId();
  }

  /**
   * After View Checked
   */
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle(): void {
    this.selectedLifeCycle$ = this.store.select(
      lifeCycleSelectors.selectSelectedRequest
    );
  }

  /**
   * Select Action
   * @param data Data
   */
  public selectAction(data): void {
    this.subscription.add(
      this.selectedLifeCycle$.subscribe((lifeCycle: LifeCycle) => {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.panelClass = 'sfr-dialog';
        dialogConfig.width = '30vw';
        dialogConfig.data = {
          action: data,
          idRequest: lifeCycle.resume.req_id,
          dateUpdate: lifeCycle.resume.lmd,
        };
        this.matDialog.open(ModalActionsComponent, dialogConfig);
      })
    );
  }

  /**
   * Get Return Route
   */
  get getReturnRoute(): string {
    let subRoute: string;
    switch (this.actionTypeService.getActionType) {
      case RequestQueryActions.REQUESTS:
        subRoute = `/${EnumRequestsRoutesPath.REQUESTS}`;
        break;
      case RequestQueryActions.REQUESTS_HISTORY:
        subRoute = `/${EnumRequestsRoutesPath.REQUESTS}/${EnumRequestTypePath.HISTORY}`;
        break;
      case RequestQueryActions.ACTIONS:
        subRoute = `/${EnumRequestsRoutesPath.APPROVALS}`;
        break;
      case RequestQueryActions.ACTIONS_HISTORY:
        subRoute = `/${EnumRequestsRoutesPath.APPROVALS}/${EnumRequestTypePath.HISTORY}`;
        break;
      default:
        subRoute = '';
    }
    return `/${ConstRoutesPath.REQUESTS}` + subRoute;
  }

  /**
   * Get Request ID
   */
  getRequestId(): void {
    this.idRequest = this.route.snapshot.paramMap.get('idRequest');
    window.localStorage.removeItem('idRequest');
    localStorage.setItem('idRequest', this.idRequest);
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
