// Add Comment Action

import { HttpErrorResponse } from '@angular/common/http';
import { createAction, props } from '@ngrx/store';
import { RequestQueryActions } from '../../enums/request-query-actions.enum';
import { CommentResponseBody } from '../../models/comment.model';

/**
 * Add Life-Cycle Action
 */
export const AddComment = createAction(
  '[Requests] Add Comment Action',
  props<{
    request_id: string;
    body: any;
    requestType?: RequestQueryActions;
  }>()
);

/**
 * Add Life-Cycle Action Success Action
 */
export const AddCommentSuccess = createAction(
  '[Requests] Add Comment Success',
  props<{ action: CommentResponseBody }>()
);

/**
 * Add Life-Cycle Action Fail Action
 */
export const AddCommentFail = createAction(
  '[Requests] Add Comment Fail',
  props<{ error?: HttpErrorResponse }>()
);
