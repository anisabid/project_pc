import { createSelector } from '@ngrx/store';
import * as fromFeature from '../reducers';
import * as fromLifeCycleReducers from '../reducers/life-cycle.reducer';
import * as fromRoot from '@app/store';
import { LifeCycle } from '../../models/life-cycle.model';
import { RouterStateUrl } from '@app/store';

/**
 * Select Life-Cycle State
 */
export const selectLifeCycleState = createSelector(
  fromFeature.selectRequestModuleState,
  (state: fromFeature.RequestModuleState) => state.lifeCycle
);

/**
 * Select Life-Cycle Entities
 */
export const selectLifeCycleEntities = createSelector(
  selectLifeCycleState,
  fromLifeCycleReducers.selectLifeCycleEntities
);

/**
 * Select Life-Cycle List
 */
export const selectLifeCycleList = createSelector(
  selectLifeCycleState,
  fromLifeCycleReducers.selectLifeCycle
);

/**
 * Select Life-Cycle Loaded
 */
export const selectIfLifeCycleListLoaded = createSelector(
  selectLifeCycleState,
  fromLifeCycleReducers.getLifeCyclesLoaded
);

/**
 * Select Life-Cycle Loaded
 */
export const selectIfLifeCycleListLoading = createSelector(
  selectLifeCycleState,
  fromLifeCycleReducers.getLifeCyclesLoading
);

/**
 * Select Selected Request
 */
export const selectSelectedRequest = createSelector(
  selectLifeCycleList,
  fromRoot.selectRouterState,
  (entities, router): LifeCycle => {
    const state: RouterStateUrl = (router as any).router.state;
    return (
      state &&
      entities.find((lifeCycle: LifeCycle) =>
        lifeCycle.resume.req_id.includes(state.params.idRequest)
      )
    );
  }
);

/**
 * Check if LifeCycle Exists Selector
 */
export const selectIfLifeCycleExists = (id: string) =>
  createSelector(
    selectLifeCycleList,
    (entities): boolean =>
      !!(
        entities &&
        entities.some((lifeCycle: LifeCycle) =>
          lifeCycle?.resume?.req_id?.includes(id)
        )
      )
  );
