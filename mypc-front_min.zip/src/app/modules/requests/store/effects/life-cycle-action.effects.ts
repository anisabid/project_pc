import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import * as fromRequestServices from '@requestsModule/services';
import * as fromRoot from '@app/store';
import { SnackBarMessageService } from '@app/shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@app/shared/services/errors/common-errors.service';
import { ActionTypeService } from '../../services/action-type.service';
import { Store } from '@ngrx/store';
import { LifeCycleActionActions } from '../actions';
import { catchError, first, map, switchMap } from 'rxjs/operators';
import { ActionResponseBody } from '../../models/action-response.model';
import { HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { RouterStateUrl } from '@app/store';
/**
 * Life-cycle Action Effects
 */
@Injectable()
export class LifeCycleActionEffects {
  /**
   * Constructor
   * @param actions$ action
   * @param requestService Requests Service
   * @param snackBarMessageService Material SnackBar Message Service
   * @param commonErrorsService Common Request Error Service
   */
  constructor(
    private actions$: Actions,
    private requestService: fromRequestServices.RequestsService,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService,
    private actionTypeService: ActionTypeService,
    private store: Store
  ) {}

  /**
   * Add Life-cycle Action
   */
  addAction$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleActionActions.AddLifeCycleAction),
      switchMap(({ request_id, body }) =>
        this.requestService.postActionLifeCycle(request_id, body).pipe(
          map((actionResponse: ActionResponseBody) => {
            if (actionResponse?.success === 'true') {
              return LifeCycleActionActions.AddLifeCycleActionSuccess({
                action: actionResponse,
              });
            }
            return LifeCycleActionActions.AddLifeCycleActionFail({});
          }),
          catchError((error: HttpErrorResponse) =>
            of(LifeCycleActionActions.AddLifeCycleActionFail({ error }))
          )
        )
      )
    );
  });

  /**
   * Add Life-cycle Action Success
   */
  addActionSuccess$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleActionActions.AddLifeCycleActionSuccess),
      switchMap(() => {
        this.snackBarMessageService.success({
          message: 'Votre commentaire a été envoyé avec succès !',
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      }),
      map((action) => {
        let currentUrl: string = '';

        this.store
          .select(fromRoot.selectRouterState)
          .pipe(first())
          .subscribe((routerState) => {
            const state: RouterStateUrl = (routerState as any).router.state;
            currentUrl = state.url;
          });

        this.actionTypeService.reloadCurrentRoute(currentUrl);

        return action;
      })
    );
  });

  /**
   * Life-cycle Action Error handler ...
   */
  addActionFail$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleActionActions.AddLifeCycleActionFail),
      switchMap(({ error }) => {
        const err = error
          ? this.commonErrorsService.getCommonRequestError(error)
          : "Echec d'envoi du commentaire";

        // ... you can check the payload here to show different messages
        // like if error.statusCode === 501 etc.
        this.snackBarMessageService.error({
          message: err,
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      }),
      map((action) => {
        let currentUrl: string = '';

        this.store
          .select(fromRoot.selectRouterState)
          .pipe(first())
          .subscribe((routerState) => {
            const state: RouterStateUrl = (routerState as any).router.state;
            currentUrl = state.url;
          });

        this.actionTypeService.reloadCurrentRoute(currentUrl);

        return action;
      })
    );
  });
}
