import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { createReducer, on } from '@ngrx/store';
import { LifeCycle } from '../../models/life-cycle.model';
import * as fromLifeCycleActions from '../actions/life-cycle.actions';

/**
 * Life-cycle State
 */
export interface LifeCycleStateEntity extends EntityState<LifeCycle> {
  /**
   * Data
   */
  data: LifeCycle[];
  /**
   * Loaded
   */
  loaded: boolean;
  /**
   * Loading
   */
  loading: boolean;
}

/**
 * Life-cycle Adapter
 */
export const lifeCycleAdapter: EntityAdapter<LifeCycle> =
  createEntityAdapter<LifeCycle>({
    selectId: (lifeCycle) => lifeCycle.resume.req_id,
    sortComparer: false,
  });

/**
 * Life-cycle initial State
 */
export const initialState: LifeCycleStateEntity =
  lifeCycleAdapter.getInitialState({
    data: [],
    loaded: false,
    loading: false,
  });

/**
 * Life-cycle Selectors
 *
 * LifeCycleAdapters created with @ngrx/entity generate
 * commonly used selector functions including
 * getting all ids in the record set, a dictionary
 * of the records by id, an array of records and
 * the total number of records. This reduces boilerplate
 * in selecting records from the entity state.
 */
export const {
  selectIds: selectLifeCycleIds,
  selectEntities: selectLifeCycleEntities,
  selectAll: selectLifeCycle,
  selectTotal: selectTotalLifeCycle,
} = lifeCycleAdapter.getSelectors();

/**
 * Life-cycle Reducer
 */
export const LifeCycleReducer = createReducer(
  initialState,

  on(
    fromLifeCycleActions.LoadLifeCycle,
    (state): LifeCycleStateEntity => ({
      ...state,
      loading: true,
    })
  ),

  on(fromLifeCycleActions.LoadLifeCycleSuccess, (state, { lifeCycle }) =>
    lifeCycleAdapter.setOne(lifeCycle, {
      ...state,
      loading: false,
      loaded: true,
    })
  ),

  on(
    fromLifeCycleActions.LoadLifeCycleFail,
    (state): LifeCycleStateEntity => ({
      ...state,
      loading: false,
      loaded: false,
    })
  )
);

/**
 * get Life-Cycle Entities
 * @param state Life-Cycle State
 */
export const getLifeCyclesEntities = (state: LifeCycleStateEntity) =>
  state.data;
/**
 * get Life-Cycle Loading
 * @param state Life-Cycle State
 */
export const getLifeCyclesLoading = (state: LifeCycleStateEntity) =>
  state.loading;
/**
 * get Life-Cycle Loaded
 * @param state Life-Cycle State
 */
export const getLifeCyclesLoaded = (state: LifeCycleStateEntity) =>
  state.loaded;
