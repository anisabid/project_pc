export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        requests: {
          global: {},
          request: 'Mes Demandes',
          approval: 'Mes Approbations',
          history: 'Mes Historiques',
          history_demande: 'Historique de Mes Demandes',
          history_actions: 'Historique de Mes Approbations',
          add_request: 'Faire une demande',
          add_comment: 'Ajouter une note',
          add_file: 'Joindre un fichier',
          add_complement: 'Demander des informations',
          respond_to_complement: 'Répondre au complément',
          back_to_my_requests: 'Retour à Mes Demandes',
          back_to_my_approbations: 'Retour à Mes Approbations',
          name: 'Mes Demandes',
          search: {
            placeholder: 'Recherchez par, id, type de demande, date, etc..',
          },
          components: {
            list: {
              table: {
                columns: {
                  actions: 'Actions',
                  beneficiary: 'Bénéficiaire',
                  date: 'Date',
                  number: 'N° de dossier',
                  status: 'Statut',
                  step: 'Étape',
                  summary: 'Résumé',
                  type: 'Type',
                  element: 'Elément',
                },
                header: {
                  actions:
                    '{{value1}} demande en attente d’action de votre part',
                  requests: '{{value1}} autres demandes actives',
                },
              },
              filter: {
                label: 'Filtres',
                history: 'Historique',
                current: 'courantes',
                date_begin: 'Date de début',
                date_end: 'Date de fin',
                resume: 'Résumé',
                element: 'Elément',
                status: 'Statut',
                step: 'Étape',
                req: 'Numéro de dossier',
                emet: 'Demandeur',
                benef: 'Bénéficiaire',
                grp: 'Groupe en charge',
                buttons: {
                  filter_list: 'Filtres',
                  cancel: 'Annuler',
                  delete: 'Supprimer',
                  confirm: 'Confimer',
                  reset: 'Réinitialiser',
                  rollBack: 'Restaurer dernière recherche',
                },
              },
            },
            item: {
              resume: {
                object: 'Sujet de la demande',
                deadlines: 'Délais avant échéance',
                beneficiary: 'Bénéficiaire',
                number: 'N° de dossier',
                applicant: 'Demandeur',
                created: 'Créé le',
                update: 'Modifié le',
                summary: 'Résumé',
              },
              folder: {
                number: 'Dossier n°',
                life_cycle: 'Cycle de vie',
                original_form: "Formulaire d'origine",
              },
            },
          },
        },
      },
    },
  },
};
