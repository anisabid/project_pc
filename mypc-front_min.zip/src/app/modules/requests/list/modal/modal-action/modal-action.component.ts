import {
  Component,
  ElementRef,
  Inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatLegacyDialogRef as MatDialogRef, MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA } from '@angular/material/legacy-dialog';
import { SafeResourceUrl } from '@angular/platform-browser';
import { RequestParam } from '@app/modules/requests/models/request-param.model';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';

@Component({
  selector: 'sfr-modal-action',
  templateUrl: './modal-action.component.html',
})
export class ModalActionComponent implements OnInit {
  @ViewChild('iframe') iframe: ElementRef;
  public action: RequestParam;
  public iFrameDisplay: boolean;
  public iFrameUrl: SafeResourceUrl;
  public title: string;
  public srcdoc: string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ModalActionComponent>,
    private urlHelperService: UrlHelperService,
    private environmentService: EnvironmentService
  ) {
    this.iFrameDisplay = false;
  }

  ngOnInit(): void {
    this.action = <RequestParam>this.data.action;
    this.title = this.data.title;
    this.urlHelperService.post(this.url).subscribe((result) => {
      this.srcdoc = result;
    });
  }

  get url(): string {
    return (
      this.environmentService.iframe.baseUrl +
      '?p=ps/view_form&origin=refonte&item_id=' +
      this.action.item_id
    );
  }
}
