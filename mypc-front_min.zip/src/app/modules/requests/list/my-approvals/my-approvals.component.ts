import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './../../i18n/fr';
import { LegacyPageEvent as PageEvent } from '@angular/material/legacy-paginator';
import { ActionsService } from '@shared/services/actions/actions.service';
import { ActionEvent } from '@shared/models/action-event';
import {
  EnumRequestsRoutesPath,
  EnumRequestTypePath,
} from '../../const/request.const.routes';
import { Router } from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import {
  FilterTypes,
  SearchFilter,
} from '../../advanced-filter/advanced-filter.model';
import { RequestsService } from '../../services/requests.service';
import { RequestQueryActions } from '../../enums/request-query-actions.enum';
import { Observable, Subscription } from 'rxjs';
import { requestListPagination } from '../../models/request-list.model';
import { ArrayTitle } from '@app/shared/models/array-title.model';
import { Store } from '@ngrx/store';
import { RequestActions, RequestSelectors } from '../../store';
import { Request } from '../../models/request.model';

@Component({
  selector: 'sfr-my-approvals',
  templateUrl: './my-approvals.component.html',
})

/**
 * Current/History Approvals List Component
 */
export class MyApprovalsComponent implements OnInit, OnDestroy {
  private isHistory: boolean;
  public action: RequestQueryActions;
  public itemsFilter: SearchFilter;
  private subscription: Subscription = new Subscription();

  private defaultPageSize = 10;
  public totalRows = 0;
  public pageSize = this.defaultPageSize;
  public currentPage = 0;
  public offsetPage = 0;
  public pageSizeOptions = [5, 10, 25, 100];

  /**
   * Filter List for Advanced Filter
   */
  public filterItemList: FilterTypes[] = [
    FilterTypes.REQUESTER,
    FilterTypes.RECIPIENT,
    FilterTypes.FOLDER_NUMBER,
    FilterTypes.GROUP,
    FilterTypes.STATUS,
    FilterTypes.ELEMENT,
    FilterTypes.RESUME,
    FilterTypes.START_DATE,
    FilterTypes.END_DATE,
  ];

  // Functions
  /**
   * Table Titles (Used for Table Skeleton)
   */
  public titles: ArrayTitle[] = [
    {
      column: 'status',
      description: 'i18n.module.requests.components.list.table.columns.status',
      size: 70,
      type: 'chips',
    },
    {
      column: 'number',
      description: 'i18n.module.requests.components.list.table.columns.number',
      size: 80,
    },
    {
      column: 'element',
      description: 'i18n.module.requests.components.list.table.columns.element',
      size: 100,
    },
    {
      column: 'summary',
      description: 'i18n.module.requests.components.list.table.columns.summary',
      size: 100,
    },
    {
      column: 'step',
      description: 'i18n.module.requests.components.list.table.columns.step',
      size: 60,
    },
    {
      column: 'type',
      description: 'i18n.module.requests.components.list.table.columns.type',
      size: 80,
    },
    {
      column: 'date',
      description: 'i18n.module.requests.components.list.table.columns.date',
      size: 100,
    },
    {
      column: 'beneficiary',
      description:
        'i18n.module.requests.components.list.table.columns.beneficiary',
      size: 100,
    },
  ];

  /**
   * Table Is Empty
   */
  tableIsEmpty = true;

  // Observables
  /**
   * Is Loading Observable
   */
  public isLoading$: Observable<boolean>;
  /**
   * Request List Observable
   */
  public requestList$: Observable<Request[]>;
  /**
   * Request list Pagination Observable
   */
  public requestListPagination$: Observable<requestListPagination>;

  /**
   * Constructor
   * @param translationLoaderService Translation Loader Service
   * @param requestsService Requests Service
   * @param actionsService Actions Service
   * @param router Router
   * @param store Store
   */
  constructor(
    private translationLoaderService: TranslationLoaderService,
    private requestsService: RequestsService,
    private actionsService: ActionsService,
    private router: Router,
    private store: Store
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
  }

  /**
   * On Init
   */
  ngOnInit(): void {
    this.isLoading$ = this.store.select(
      RequestSelectors.selectIfRequestListLoading
    );
    this.setIsHistory();
    this.setAction();
    this.setPageTitle();
    this.getApprovals();
  }

  /**
   * Get/Search Approvals
   * @param limit Limit
   * @param offset Offset
   * @param filter Filter
   */
  getApprovals(
    filter?: SearchFilter,
    limit: number = this.pageSize > 0 ? this.pageSize : this.defaultPageSize,
    offset: number = 0
  ): void {
    this.currentPage =
      JSON.stringify(filter) === JSON.stringify(this.itemsFilter)
        ? this.currentPage
        : 0;
    this.itemsFilter = filter ? filter : undefined;

    this.store.dispatch(
      RequestActions.LoadRequestList({
        action: this.action,
        limit,
        offset,
        filter: this.itemsFilter,
      })
    );
    this.requestList$ = this.store.select(RequestSelectors.selectRequestList);
    this.requestListPagination$ = this.store.select(
      RequestSelectors.selectRequestListPaginationParameters
    );

    this.subscription.add(
      this.requestList$.subscribe((requestList: Request[]) => {
        this.tableIsEmpty = requestList?.length === 0;
      })
    );

    this.subscription.add(
      this.requestListPagination$.subscribe(
        (pagination: requestListPagination) => {
          this.pageSize = pagination.limit;
          this.totalRows = pagination.total;
          this.offsetPage = pagination.offset;
        }
      )
    );
  }

  /**
   * On Page Changed Event
   * @param event Event
   */
  pageChanged(event: PageEvent): void {
    this.currentPage = this.pageSize !== event.pageSize ? 0 : event.pageIndex;
    this.pageSize = event.pageSize;
    const offset = this.currentPage * this.pageSize;
    this.getApprovals(this.itemsFilter, this.pageSize, offset);
  }

  /**
   * Apply Request Title
   * @param title Title
   */
  actionEvent(title: string): void {
    this.actionsService.onEvents.next(
      new ActionEvent({
        component: 'component.request.list',
        key: 'title',
        value: title,
      })
    );
  }

  /**
   * Navigate to Request Life cycle
   * @param requestId Request ID
   */
  navigate(requestId: string): string {
    return `/${ConstRoutesPath.REQUESTS}/${EnumRequestsRoutesPath.LIFECYCLE}/${requestId}`;
  }

  /**
   * Set Approvals Data Mode
   */
  setIsHistory(): void {
    this.isHistory = !!this.router.url.includes(EnumRequestTypePath.HISTORY);
  }

  /**
   * Set Action
   */
  setAction(): void {
    this.action = this.isHistory
      ? RequestQueryActions.ACTIONS_HISTORY
      : RequestQueryActions.ACTIONS;
  }

  /**
   * SetPageTitle
   */
  setPageTitle(): void {
    this.actionEvent(
      this.isHistory
        ? 'i18n.module.requests.history_actions'
        : 'i18n.module.requests.approval'
    );
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
