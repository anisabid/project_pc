import { ActionResponse } from '@requestsModule/models/action-response.model';
import { CommentResponse } from '@requestsModule/models/comment.model';
import { ComplaintResponse } from '@requestsModule/models/complaint.model';
import { LifeCycle } from '@requestsModule/models/life-cycle.model';
import { RequestList } from '@requestsModule/models/request-list.model';

/**
 * Request Result
 */
export interface RequestResult {
  requests: RequestResultData;
  actions: ActionResultData;
}

/**
 * Request Result Data Type
 */
export type RequestResultData =
  | RequestList
  | CommentResponse
  | LifeCycle
  | ActionResponse
  | ComplaintResponse;

/**
 * Action Result Data Type
 */
export type ActionResultData = undefined;
