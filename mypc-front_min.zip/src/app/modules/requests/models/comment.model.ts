/**
 * Comment Model
 */
export interface Comment {
  vfile?: any;
  note?: string;
}

/**
 * Comment Response Model
 */
export interface CommentResponse {
  note: CommentResponseBody;
}

export interface CommentResponseBody {
  msg: string;
  req_id: string;
  status_id: number;
  success: string;
}
