import { Request } from './request.model';

/**
 * Request List Model
 */
export interface RequestList {
  data: Request[];
  limit: number;
  offset: number;
  total: number;
  totalPage: number;
}

/**
 * Request List Pagination Model
 */
export type requestListPagination = Pick<
  RequestList,
  'limit' | 'offset' | 'total' | 'totalPage'
>;
