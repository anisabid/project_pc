/**
 * Action Response Model
 */
export interface ActionResponse {
  action: ActionResponseBody;
}

/**
 * Action Response Body Model
 */
export interface ActionResponseBody {
  close_form: number;
  insert_histo: string;
  lmd: string;
  msg: string;
  req_id: string;
  success: string;
  updategroup: string;
  workflowgroup: string;
}
