/**
 * Request Query Params
 */
export class RequestQueryParams {
  action: string;
  limit: number;
  offset: number;

  constructor(action: string = '', limit: number = 50, offset: number = 0) {
    this.action = action;
    this.limit = limit;
    this.offset = offset;
  }
}
