import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { RequestQueryActions } from '../enums/request-query-actions.enum';

@Injectable({
  providedIn: 'root',
})
export class ActionTypeService {
  private actionType: RequestQueryActions = RequestQueryActions.REQUESTS;

  /**
   * Constructor
   * @param router Router
   */
  constructor(private router: Router) {}

  /**
   * Reload Current Route
   */
  reloadCurrentRoute(currentUrl: string): void {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigateByUrl(currentUrl, {
        state: {
          actionType: this.getActionType,
        },
      });
    });
  }

  /**
   * Get Action Type
   */
  get getActionType(): RequestQueryActions {
    return this.actionType;
  }

  /**
   * Set Action Type
   */
  setActionType(actionType: RequestQueryActions): void {
    this.actionType = actionType;
  }
}
