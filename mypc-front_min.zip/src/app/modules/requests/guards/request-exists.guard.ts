import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter, switchMap, take, tap } from 'rxjs/operators';
import { RequestQueryActions } from '../enums/request-query-actions.enum';
import { ActionTypeService } from '../services/action-type.service';
import { LifeCycleActions, lifeCycleSelectors } from '../store';

@Injectable({
  providedIn: 'root',
})
export class RequestExistsGuard implements CanActivate {
  /**
   * Check if checkRequestExists() Has been Executed
   */
  executed = false;

  /**
   * Constructor
   * @param store NgRx Store
   * @param actionTypeService Action Type Service
   * @param router Router
   */
  constructor(
    private store: Store,
    private actionTypeService: ActionTypeService,
    public router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    this.setActionType();

    const id: string = route.params.idRequest;
    return this.checkStore(id).pipe(
      switchMap(() => {
        return this.checkRequestExists(id);
      })
    );
  }

  /**
   * check Store Function
   * @param requestId Request ID
   */
  checkStore(requestId: string): Observable<boolean> {
    this.store.dispatch(
      LifeCycleActions.LoadLifeCycle({
        action: RequestQueryActions.REQUESTS,
        requestId,
      })
    );
    return this.store
      .select(lifeCycleSelectors.selectIfLifeCycleListLoaded)
      .pipe(
        filter((loaded) => loaded),
        take(1)
      );
  }

  /**
   * Check if Request Exists in Store
   * @param leaveId Request ID
   */
  checkRequestExists(requestId: string): Observable<boolean> {
    return this.store
      .select(lifeCycleSelectors.selectIfLifeCycleExists(requestId))
      .pipe(
        tap((exists: boolean) => {
          if (!exists && !this.executed) {
            this.store.dispatch(
              LifeCycleActions.LoadLifeCycle({
                action: RequestQueryActions.REQUESTS,
                requestId,
              })
            );
            this.executed = true;
          }
        }),
        filter((exists) => exists),
        take(1)
      );
  }

  /**
   * Set Action Type
   */
  setActionType(): void {
    const actionType =
      this.router.getCurrentNavigation()?.extras?.state?.actionType;

    this.actionTypeService.setActionType(
      actionType ? actionType : RequestQueryActions.REQUESTS
    );
  }
}
