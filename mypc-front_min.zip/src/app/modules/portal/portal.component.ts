import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ContentService } from '@shared/modules/layout/components/content/content.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'sfr-portal',
  templateUrl: './portal.component.html',
  styleUrls: ['./portal.component.scss'],
})
export class PortalComponent implements OnInit, OnDestroy {
  @ViewChild('sfrParentIframe') sfrParentIframe: ElementRef;
  @ViewChild('sfrIframe') sfrIframe: ElementRef;
  public url: SafeResourceUrl;

  constructor(
    private translationLoaderService: TranslationLoaderService,
    private contentService: ContentService,
    private urlHelperService: UrlHelperService,
    private domSanitizer: DomSanitizer
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.contentService.onTogglePerfectScrollbarChanged.next(false);
  }

  ngOnInit(): void {
    this.url = this.domSanitizer.bypassSecurityTrustResourceUrl(
      this.urlHelperService.toBackOffice(
        '/mypc/index.php?p=ps%2Frsc_inventory&pannel=partenaires'
      )
    );
  }

  resizeIframe() {
    if (this.sfrIframe) {
      this.sfrIframe.nativeElement.style.height =
        this.sfrParentIframe.nativeElement.offsetHeight + 'px';
    }
  }

  ngOnDestroy(): void {
    this.contentService.onTogglePerfectScrollbarChanged.next(true);
  }
}
