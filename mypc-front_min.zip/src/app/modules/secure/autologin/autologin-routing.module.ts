import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AutologinComponent } from './autologin.component';

const routes: Routes = [{ path: '', component: AutologinComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AutologinRoutingModule {}
