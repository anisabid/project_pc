import { Component, OnInit } from '@angular/core';
import { JwtService } from '@app/core/services/jwt.service';
import { EnumAccess } from '@shared/consts/access.const';
import {
  ConstNavigationItemType,
  EnumNavigationItemType,
  NavigationItemType,
} from '@shared/consts/navigation.const';
import { EnumUrlTarget } from '@shared/consts/url-target.const';
import { NavigationItem } from '@shared/models/navigation';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';

@Component({
  selector: 'sfr-administration-dashboard',
  templateUrl: './administration-dashboard.component.html',
  styleUrls: ['./administration-dashboard.component.scss'],
})
export class AdministrationDashboardComponent implements OnInit {
  public menuDashboard: Array<Array<NavigationItem>>;
  public constNavigationItemType: NavigationItemType;
  constructor(
    private jwtService: JwtService,
    private urlHelperService: UrlHelperService
  ) {
    this.constNavigationItemType = ConstNavigationItemType;
    this.menuDashboard = [
      [
        {
          id: 'administration-socle',
          type: EnumNavigationItemType.GROUP,
          translate:
            'i18n.module.administration.items.administration-of-the-base',
          iconName: 'home',
          access: [EnumAccess.ADMIN, EnumAccess.ADMIN_SOCLE],
          children: [
            {
              id: 'administration-socle--service-catalog',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.service-catalog',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/admin_socle_new'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_FORM_EDITOR],
            },
            {
              id: 'administration-socle--workflow',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.workflow',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/adm_spe_workflow'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_SPE_WORKFLOW],
            },
            {
              id: 'administration-socle--form',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.form',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/adm_form_editor'
              ),
              url_target: EnumUrlTarget.BLANK,
            },
            {
              id: 'administration-socle--mapping',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.mapping',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/adm_mapping'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_MAPPING],
            },
          ],
        },
        {
          id: 'administration-cms',
          type: EnumNavigationItemType.GROUP,
          translate: 'i18n.module.administration.items.content-management',
          iconName: 'settings',
          access: [EnumAccess.ADMIN],
          children: [
            {
              id: 'administration-cms--communications-panel',
              type: EnumNavigationItemType.ITEM,
              translate:
                'i18n.module.administration.items.communications-panel',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/admin_socle_pan_com'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_COM_PANEL],
            },
            {
              id: 'administration-cms--flash-headband',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.flash-headband',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/admin_socle_bandeau_flash'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_SOCLE_FLASH_BANNER],
            },
            {
              id: 'administration-cms--maintenance-and-debug-mode',
              type: EnumNavigationItemType.ITEM,
              translate:
                'i18n.module.administration.items.maintenance-and-debug-mode',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/admin_socle_maintenance'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_SOCLE_MAINTENANCE],
            },
          ],
        },
      ],
      [
        {
          id: 'administration-grp',
          type: EnumNavigationItemType.GROUP,
          translate: 'i18n.module.administration.items.group-management',
          iconName: 'group',
          access: [EnumAccess.ADMIN, EnumAccess.ADMIN_SPE_GROUPS],
          children: [
            {
              id: 'administration-grp--groups',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.groups',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/adm_spe_groupes'
              ),
              url_target: EnumUrlTarget.BLANK,
            },
          ],
        },
        {
          id: 'administration-reporting',
          type: EnumNavigationItemType.GROUP,
          translate: 'i18n.module.administration.items.reporting',
          iconName: 'report',
          access: [EnumAccess.ADMIN],
          children: [
            {
              id: 'administration-reporting--reporting-kpi',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.reporting-kpi',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/CreateExcelFile'
              ),
              url_target: EnumUrlTarget.BLANK,
            },
            {
              id: 'administration-reporting--reporting-kpi-settings',
              type: EnumNavigationItemType.ITEM,
              translate:
                'i18n.module.administration.items.reporting-kpi-settings',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/adm_reporting'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_REPORTING],
            },
            {
              id: 'administration-reporting--export-users',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.export-users',
              url: this.urlHelperService.toBackOffice(
                'mypc/inc/extract_data_csv.php'
              ),
              url_target: EnumUrlTarget.BLANK,
            },
          ],
        },
        {
          id: 'administration-processing',
          type: EnumNavigationItemType.GROUP,
          translate: 'i18n.module.administration.items.batch-processing',
          iconName: 'batch_prediction',
          access: [EnumAccess.ADMIN, EnumAccess.ADMIN_PROCESSING],
          children: [
            {
              id: 'administration-processing--requests-or-changes',
              type: EnumNavigationItemType.ITEM,
              translate: 'i18n.module.administration.items.requests-or-changes',
              url: this.urlHelperService.toBackOffice(
                'mypc/index.php?p=ps/adm_massProcessing'
              ),
              url_target: EnumUrlTarget.BLANK,
              access: [EnumAccess.ADMIN_PROCESSING],
            },
          ],
        },
      ],
    ];
  }

  ngOnInit(): void {}
}
