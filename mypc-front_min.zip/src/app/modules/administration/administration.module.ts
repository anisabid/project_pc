import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdministrationComponent } from './administration.component';
import { AdministrationRoutingModule } from './administration-routing.module';
import { SharedModule } from '@shared/shared.module';
import { AdministrationSideComponent } from './administration-side/administration-side.component';
import { AdministrationDashboardComponent } from './administration-dashboard/administration-dashboard.component';

@NgModule({
  declarations: [AdministrationComponent, AdministrationSideComponent, AdministrationDashboardComponent],
  imports: [CommonModule, SharedModule, AdministrationRoutingModule],
})
export class AdministrationModule {}
