import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { EndpointService } from '@shared/services/api/v2/endpoint.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { Page } from '@shared/models/page';
import { UserSearch, UserSearchResult } from '@shared/models/user';
import { ApiService } from '@shared/services/api/v2/api.service';
import { SessionService } from '@shared/services/session/session.service';
import { BehaviorSubject } from 'rxjs';
import { Delegation, DelegationPathParams } from './delegation.model';

@Injectable({
  providedIn: 'root',
})
export class DelegationsService {
  public onDelegationsChanged: BehaviorSubject<Page<Delegation>>;
  public onDelegateChanged: BehaviorSubject<any>;
  private _delegations: Page<Delegation>;
  private _delegate: UserSearch;
  private _pathParams: DelegationPathParams;
  private _endpoint: EndpointService;

  /**
   * Constructor
   * @param apiService API Service
   * @param sessionService Session Service
   * @param httpClient HTTP Client
   * @param environmentService Environment Service
   * @param urlHelperService URL Helper Service
   */
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService,
    private httpClient: HttpClient,
    private environmentService: EnvironmentService,
    private urlHelperService: UrlHelperService
  ) {
    this._delegations = new Page();
    this._delegate = null;
    this.onDelegationsChanged = new BehaviorSubject(this._delegations);
    this.onDelegateChanged = new BehaviorSubject(this._delegate);

    this._endpoint = new EndpointService('delegations');
    this._endpoint.items.get = '${action}/${idDelegate}';
    this._endpoint.item.delete = '${idDelegation}';
    this._endpoint.item.put = '${idDelegation}';
  }

  /**
   * Resolve
   * @param activatedRouteSnapshot Activated Route Snapshot
   * @param state State
   */
  resolve(
    activatedRouteSnapshot: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<any> {
    this._pathParams = new DelegationPathParams();
    this._pathParams.idDelegate =
      activatedRouteSnapshot.parent.params.idDelegate ??
      this.sessionService.user.uPerId;
    this._pathParams.action = activatedRouteSnapshot.routeConfig.path;
    return new Promise((resolve, reject) => {
      this.getDelegate().then(() => {
        Promise.all([this.getDelegations()]).then(() => {
          resolve(true);
        }, reject);
      });
    });
  }

  /**
   * Get Delegations
   */
  public getDelegations(): Promise<Page<Delegation>> {
    const obj = this._pathParams.normalize();
    if (obj['idDelegate'] && this._delegate) {
      obj['idDelegate'] = this._delegate.id;
    }
    const params = {
      '${action}': obj['action'] ? obj['action'] : 'self',
      '${idDelegate}': obj['idDelegate'] ? obj['idDelegate'] : '0',
      limit: obj['limit'] ? obj['limit'] : '50',
      offset: obj['offset'] ? obj['offset'] : '0',
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpoint.items.get,
      params
    );
    if (this.environmentService.options.mock.data.delegations) {
      path = this._endpoint.toMock(path);
    }

    this._delegations = new Page();
    return new Promise((resolve, reject) => {
      this._pathParams.idDelegate = this.delegate.id;
      this.httpClient.get<any>(path).subscribe((result) => {
        this._delegations = new Page();
        if (result && result.delegations.data) {
          result.delegations.data.map((item: any) => {
            this._delegations.push(new Delegation(item));
          });
        }
        this.onDelegationsChanged.next(this._delegations);
        resolve(this._delegations);
      }, reject);
    });
  }

  /**
   * Post Delegation
   * @param obj Delegation Object
   */
  public postDelegation(obj: Object = {}): Promise<any> {
    let path: string = this.urlHelperService.transformParameters(
      this._endpoint.items.post
    );
    if (this.environmentService.options.mock.data.delegations) {
      path = this._endpoint.toMock(path);
    }

    return new Promise((resolve, reject) => {
      this.httpClient.post<any>(path, obj).subscribe((result) => {
        if (result) {
          this.getDelegations();
          resolve(true);
        }
      }, reject);
    });
  }

  /**
   * Put Delegation
   * @param idDelegation ID Delegation
   * @param obj Delegation Object
   */
  public putDelegation(idDelegation: string, obj: Object = {}): Promise<any> {
    const params = {
      '${idDelegation}': idDelegation,
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpoint.item.put,
      params
    );
    if (this.environmentService.options.mock.data.delegations) {
      path = this._endpoint.toMock(path);
    }

    return new Promise((resolve, reject) => {
      this.httpClient.put<any>(path, obj).subscribe((result) => {
        if (result) {
          this.getDelegations();
          resolve(true);
        }
      }, reject);
    });
  }

  /**
   * Get Delegate
   */
  public getDelegate(): Promise<unknown> {
    return new Promise((resolve, reject) => {
      this.apiService.users
        .getUsers(this._pathParams.idDelegate)
        .subscribe((result: UserSearchResult) => {
          const foundUser = result.users.data?.find(
            (user: UserSearch) => user.uperid === this._pathParams.idDelegate
          );
          this._delegate = foundUser ? foundUser : null;
          this.onDelegateChanged.next(this._delegate);
          resolve(this._delegate);
        }, reject);
    });
  }

  /**
   * Delete Delegation
   * @param idDelegation Delegation ID
   */
  public deleteDelegation(idDelegation: string): Promise<boolean> {
    const params = {
      '${idDelegation}': idDelegation,
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpoint.item.delete,
      params
    );
    if (this.environmentService.options.mock.data.delegations) {
      path = this._endpoint.toMock(path);
    }

    return new Promise((resolve, reject) => {
      this.httpClient.delete<any>(path).subscribe((result) => {
        if (result) {
          this.getDelegations();
          resolve(true);
        }
      }, reject);
    });
  }

  /**
   * Get if is The Connected Delegate
   */
  get isTheConnectedDelegate(): boolean {
    return this.delegate.id === this.sessionService.user.id;
  }

  /**
   * Get delegations
   */
  get delegations(): Page<Delegation> {
    return this._delegations;
  }

  /**
   * Get Delegate
   */
  get delegate(): UserSearch {
    return this._delegate;
  }

  /**
   * Get Path Params
   */
  get pathParams(): DelegationPathParams {
    return this._pathParams;
  }
}
