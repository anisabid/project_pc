import { DateHelper } from '@shared/helpers/date.helper';
import { UserSearch } from '@shared/models/user';

export class Delegation {
  active: string;
  dateBegin: Date;
  dateEnd: Date;
  id: string;
  user: DelegationUser;

  constructor(data?: any, fromApi: boolean = true) {
    if (data) {
      if (fromApi) {
        this.setFromApi(data);
      } else {
        this.setFromLocal(data);
      }
    }
  }

  public setFromApi?(data?: any) {
    this.active = !data?.active ? null : data.active;
    this.dateBegin = !data?.dateBegin
      ? null
      : DateHelper.normalizeDateFromBackToFront(data.dateBegin);
    this.dateEnd = !data?.dateEnd
      ? null
      : DateHelper.normalizeDateFromBackToFront(data.dateEnd);
    this.id = !data?.id ? null : data.id;
    this.user = new DelegationUser(data);
  }

  public setFromLocal?(data?: any) {
    this.active = data?.active;
    this.dateBegin = data?.dateBegin;
    this.dateEnd = data?.dateEnd;
    this.id = data?.id;
    this.user = data?.user;
  }

  public setUserFromApiSearchUsers?() {}

  public isCanBeStopped?(): boolean {
    return this.dateBegin < new Date() && this.dateEnd > new Date();
  }

  public isCanBeDeleted?(): boolean {
    return this.dateBegin < new Date();
  }

  public isCanBeEditing(): boolean {
    return this.dateEnd > new Date();
  }

  public toApiDTO?(idUserFrom: string): Object {
    return {
      dateBegin: DateHelper.normalizeDateFromFrontToBack(this.dateBegin),
      dateEnd: DateHelper.normalizeDateFromFrontToBack(this.dateEnd),
      userIdTo: this.user.id,
      userIdFrom: idUserFrom,
    };
  }
}

class DelegationUser {
  id: string;
  name: string;

  constructor(data?: any) {
    this.id = !data?.deleg_personne_id ? null : data.deleg_personne_id;
    this.name = !data?.deleg_personne_name ? null : data.deleg_personne_name;
  }
}

export interface RoutesPathDelegations {
  DEFAULT: string;
  GIVEN_TO_ME: string;
  I_GAVE: string;
}

export enum EnumRoutesPathDelegations {
  GIVEN_TO_ME = 'given-to-me',
  I_GAVE = 'i-gave',
}

export const ConstRoutesPathDelegations: RoutesPathDelegations = {
  DEFAULT: EnumRoutesPathDelegations.I_GAVE,
  GIVEN_TO_ME: EnumRoutesPathDelegations.GIVEN_TO_ME,
  I_GAVE: EnumRoutesPathDelegations.I_GAVE,
};

export enum EnumApiPathDelegations {
  SELF = 'self',
  OTHERS = 'others',
}

export class DelegationPathParams {
  private _userId: string;
  private _action: string;
  private _isIGive: boolean;
  private _isGivenToMe: boolean;

  constructor() {
    this._userId = '0';
    this._action = EnumApiPathDelegations.SELF;
  }

  public normalize(): any {
    return {
      action: this._action,
      idDelegate: this._userId,
    };
  }

  set idDelegate(value: string) {
    this._userId = value ? value : '0';
  }

  set action(value: string) {
    this._action =
      value === ConstRoutesPathDelegations.I_GAVE
        ? EnumApiPathDelegations.SELF
        : EnumApiPathDelegations.OTHERS;
    this._isIGive = value === ConstRoutesPathDelegations.I_GAVE;
    this._isGivenToMe = value === ConstRoutesPathDelegations.GIVEN_TO_ME;
  }

  get idDelegate(): string {
    return this._userId;
  }

  get action(): string {
    return this._action;
  }

  get isIGive(): boolean {
    return this._isIGive;
  }

  get isGivenToMe(): boolean {
    return this._isGivenToMe;
  }
}

export class DelegationDialogData {
  action: string;
  delegate: UserSearch;
  delegation?: Delegation;
}
