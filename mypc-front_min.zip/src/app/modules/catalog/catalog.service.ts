import { Injectable } from '@angular/core';
import {
  Catalog,
  CatalogAction,
  Catalogs,
  SearchResults,
} from '@shared/models/catalog';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { JsonHelperService } from '@shared/services/helper/json-helper.service';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { EndpointService } from '@shared/services/api/v2/endpoint.service';
import { HttpClient } from '@angular/common/http';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';

@Injectable({
  providedIn: 'root',
})
export class CatalogService {
  private _catalogs: Catalogs;
  private _localStorageCatalogsId: string;
  public onCatalogsChanged: BehaviorSubject<Catalogs>;
  private _endpoint: EndpointService;

  /**
   * Constructor
   * @param environmentService Environment Service
   * @param jsonHelperService json Helper Service
   * @param httpClient HTTP Client
   * @param urlHelperService URL Helper Service
   */
  constructor(
    private environmentService: EnvironmentService,
    private jsonHelperService: JsonHelperService,
    private httpClient: HttpClient,
    private urlHelperService: UrlHelperService
  ) {
    this._localStorageCatalogsId =
      this.environmentService.options.localStorage.catalogs;
    this._catalogs = null;
    this.onCatalogsChanged = new BehaviorSubject(this._catalogs);

    this._endpoint = new EndpointService('catalog');
    this._endpoint.items.get = '';
    this._endpoint.items.post = '';
    this._endpoint.items.delete = '';
    this._endpoint.item.get = '';
  }

  /**
   * Resolve
   */
  resolve(): Observable<any> | Promise<any> | any {
    return new Promise((resolve, reject) => {
      Promise.all([this.getCatalogs()]).then(() => {
        resolve(true);
      }, reject);
    });
  }

  /**
   * Get Catalogs
   */
  public getCatalogs(): Promise<any> {
    return new Promise((resolve, reject) => {
      if (this.getCatalogsLocalStorage()) {
        of(this._catalogs).subscribe((results: any) => {
          this.onCatalogsChanged.next(results);
          resolve(results);
        }, reject);
      } else {
        let path: string = this._endpoint.items.get;
        if (this.environmentService.options.mock.data.catalog) {
          path = this._endpoint.toMock(path);
        }

        this.httpClient.get<any>(path).subscribe((results: any) => {
          this._catalogs = new Catalogs(results);
          this.setCatalogsLocalStorage(this._catalogs);
          this.onCatalogsChanged.next(this._catalogs);
          resolve(this._catalogs);
        }, reject);
      }
    });
  }

  /**
   * Search Catalogs Service
   * @param term Search term
   * @returns SearchResults
   */
  public searchCatalogs(term: string): Promise<SearchResults> {
    const params = {
      '${term}': term,
      '${action}': 'all',
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpoint.items.get + '?term=${term}&action=${action}',
      params
    );
    if (this.environmentService.options.mock.data.catalog) {
      path = this._endpoint.toMock(path);
    }

    return new Promise((resolve, reject) => {
      this.httpClient
        .get<SearchResults>(path)
        .subscribe((results: SearchResults) => {
          resolve(results);
        });
    });
  }

  public getCatalogsLocalStorage(): Catalogs {
    this._catalogs = <Catalogs>(
      JSON.parse(
        localStorage.getItem(this._localStorageCatalogsId),
        this.jsonHelperService.reviver
      )
    );
    return !this._catalogs ? null : this._catalogs;
  }

  public setCatalogsLocalStorage(val?: Catalogs) {
    if (val) {
      localStorage.setItem(
        this._localStorageCatalogsId,
        JSON.stringify(val, this.jsonHelperService.replacer)
      );
    }
  }

  /**
   * getCatalogsBySteps
   *
   * @description Find Catalog by step
   * @param steps : Array of ids steps
   * @returns Array<Catalog>
   */
  public getCatalogsBySteps(steps: Array<string>): Array<Catalog> {
    let catalogsSelected: Array<Catalog> = [];
    for (let i = 0; i < steps.length; i++) {
      if (i === 0) {
        catalogsSelected.push(this._catalogs[steps[i]]);
      } else {
        catalogsSelected.push(catalogsSelected[i - 1].children.get(steps[i]));
      }
    }
    return catalogsSelected;
  }

  /**
   * getStepsByAction
   * @description Find Catalog by step
   * @param action : Action from which get list of id parent catalogs
   * @returns Array<string>
   */
  public getStepsByAction(action: CatalogAction): Array<string> {
    const steps: Array<string> = [action.parentId];
    const childrenCatalogs: Map<string, Catalog> = this.getChildrenCatalogs();
    this.getRecursiveStepsFromAction(
      childrenCatalogs.get(action.parentId),
      steps,
      childrenCatalogs
    );
    return steps;
  }

  public getRecursiveStepsFromAction(
    value: Catalog,
    steps: Array<string> = [],
    childrenCatalogs: Map<string, Catalog>
  ): Array<string> {
    steps.unshift(value.parentId);
    if (value.parentId && value.actions) {
      this.getRecursiveStepsFromAction(
        childrenCatalogs.get(value.parentId),
        steps,
        childrenCatalogs
      );
    }
    return steps;
  }

  /**
   * getChildrenCatalogs
   *
   * @description Get All Catalogs
   * @returns Map<string, Catalog>
   */
  public getChildrenCatalogs(): Map<string, Catalog> {
    const childrenCatalogs = new Map();
    Object.entries(this._catalogs).forEach(([key, catalog]) => {
      childrenCatalogs.set(key, catalog);
      this.getRecursiveChildrenCatalogs(
        (<Catalog>catalog).children,
        childrenCatalogs
      );
    });
    return childrenCatalogs;
  }

  private getRecursiveChildrenCatalogs(
    children: Map<string, Catalog>,
    catalogs: Map<string, Catalog> = new Map()
  ): Map<string, Catalog> {
    for (let [key, value] of children) {
      catalogs.set(key, value);
      if ((<Catalog>value).children.size) {
        this.getRecursiveChildrenCatalogs((<Catalog>value).children, catalogs);
      }
    }
    return catalogs;
  }

  /**
   * getCatalogByStep
   *
   * @description Find Catalog by step deep
   * @param steps : Array of ids steps
   * @param step : Deep or index of catalog to find
   * @returns Catalog | null
   */
  public getCatalogByStep(steps: Array<string>, step: number = 0): Catalog {
    let catalog: Catalog = null;
    // TODO If you try to access a step that does not exist
    if (step < steps.length) {
      for (let i = 0; i < step; i++) {
        if (i === 0) {
          catalog = this._catalogs[steps[i]];
        } else {
          catalog = catalog.children.get(steps[i]);
        }
      }
      return new Catalog(catalog);
    }
    return null;
  }

  /**
   * getCatalogsActions
   *
   * @description Find All Actions using getRecursiveActionsFromChildren
   * @returns Map<string, Array<CatalogAction>>
   */
  public getCatalogsActions(): Map<string, Array<CatalogAction>> {
    const catalogsActions = new Map();
    Object.entries(this._catalogs).forEach(([key, catalog]) => {
      catalogsActions.set(
        key,
        this.getRecursiveActionsFromChildren((<Catalog>catalog).children)
      );
    });
    return catalogsActions;
  }

  private getRecursiveActionsFromChildren(
    children: Map<string, Catalog>,
    actions: Array<CatalogAction> = []
  ): Array<CatalogAction> {
    for (let [key, value] of children) {
      Array.prototype.push.apply(actions, (<Catalog>value).actions);
      if ((<Catalog>value).children.size) {
        this.getRecursiveActionsFromChildren(
          (<Catalog>value).children,
          actions
        );
      }
    }
    return actions;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Catalogs
   *
   * @returns {Catalogs}
   */
  get catalogs(): Catalogs {
    return this._catalogs;
  }
}
