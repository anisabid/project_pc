import { createAction, props } from '@ngrx/store';
import { NavigationExtras } from '@angular/router';

/**
 * Go to Specific Route Action
 */
export const Go = createAction(
  '[Router] Go',
  props<{ path: any[]; query?: object; extras?: NavigationExtras }>()
);

/**
 * Back to previous Route Action
 */
export const Back = createAction('[Router] Back');

/**
 * Go Forward Action
 */
export const Forward = createAction('[Router] Forward');
