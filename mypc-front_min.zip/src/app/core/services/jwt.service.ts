import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import jwt_decode from 'jwt-decode';
import { EnvironmentService } from '@shared/services/environment/environment.service';

@Injectable({
  providedIn: 'root',
})
export class JwtService {
  private jwtLocalStorageKey: string;
  private jwtHelperService: JwtHelperService;

  constructor(private environmentService: EnvironmentService) {
    this.jwtHelperService = new JwtHelperService();
    this.jwtLocalStorageKey = !this.environmentService.options?.localStorage
      ?.jwt
      ? 'jwt'
      : this.environmentService.options.localStorage.jwt;
  }

  decodeJwt(): any {
    try {
      return this.jwtHelperService.decodeToken(this.getJwtFromLocalStorage());
    } catch (err) {
      console.error(
        'Probably the token is not in valid format or had been tempered disabled ! ',
        err
      );
    }
  }

  getTokenExpirationDate(): Date {
    try {
      return this.jwtHelperService.getTokenExpirationDate(
        this.getJwtFromLocalStorage()
      );
    } catch (err) {
      console.error(
        'Probably the token is not in valid format or had been tempered disabled ! ',
        err
      );
    }
  }

  isTokenExpired(): boolean {
    try {
      return this.jwtHelperService.isTokenExpired(
        this.getJwtFromLocalStorage()
      );
    } catch (err) {
      console.error(
        'Probably the token is not in valid format or had been tempered disabled ! ',
        err
      );
      return true;
    }
  }

  getJwtFromLocalStorage(): string {
    return localStorage.getItem(this.jwtLocalStorageKey);
  }

  getInfos(): any {
    return !this.getJwtFromLocalStorage()
      ? null
      : jwt_decode(this.getJwtFromLocalStorage());
  }

  isValidInfos(): boolean {
    if (
      this.getInfos()?.session &&
      this.getInfos()?.session?.user_displayname &&
      this.getInfos()?.session?.user_displayname !== undefined &&
      this.getInfos()?.session?.user_displayname.trim()
    ) {
      return true;
    }
    return false;
  }

  putJwtInLocalStorage(jwt: string): void {
    localStorage.setItem(this.jwtLocalStorageKey, jwt);
  }

  removeJwtFromLocalStorage(): void {
    localStorage.removeItem(this.jwtLocalStorageKey);
  }
}
