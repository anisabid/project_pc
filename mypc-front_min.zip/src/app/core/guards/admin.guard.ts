import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, Router, RouterStateSnapshot } from '@angular/router';
import { EnumAccess } from '@shared/consts/access.const';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { SessionService } from '@shared/services/session/session.service';

@Injectable({
  providedIn: 'root',
})
export class AdminGuard implements CanActivate, CanActivateChild {
  constructor(private sessionService: SessionService, private router: Router) {}

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.isLoggedIn();
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.isLoggedIn();
  }

  isLoggedIn(): boolean {
    const hasAccess = this.sessionService.session.access.hasAccessTo(
      [
        EnumAccess.ADMIN,
        EnumAccess.ADMIN_COM_PANEL,
        EnumAccess.ADMIN_SOCLE,
        EnumAccess.ADMIN_MAPPING,
        EnumAccess.ADMIN_SPE_WORKFLOW,
        EnumAccess.ADMIN_FORM_EDITOR,
        EnumAccess.ADMIN_SPE_GROUPS,
        EnumAccess.ADMIN_PROCESSING,
      ],
      false
    );
    if (!hasAccess) {
      this.router.navigateByUrl(ConstRoutesPath.DEFAULT);
    }
    return hasAccess;
  }
}
