import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, Router, RouterStateSnapshot } from '@angular/router';
import { ConstRoutesPath } from '@shared/consts/routes.const';
import { AuthenticationService } from '@core/services/authentication.service';

@Injectable({
  providedIn: 'root',
})
export class LoginGuard implements CanActivate, CanActivateChild {
  constructor(private authenticationService: AuthenticationService, private router: Router) {}

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.isNotLoggedIn();
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.isNotLoggedIn();
  }

  isNotLoggedIn(): boolean {
    if (this.authenticationService.isLoggedIn() && !this.authenticationService.isSessionExpired()) {
      this.router.navigateByUrl(ConstRoutesPath.DEFAULT);
      return false;
    }
    return true;
  }
}
