import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

/**
 * @todo check if this class used in project or removed him or update project to used
 */
@Injectable({
  providedIn: 'root',
})
export class RootClassService {
  private _rootClass: Array<string>;
  public onChanged: Subject<string | Array<string>>;

  constructor() {
    this._rootClass = [];
    this.onChanged = new Subject();
  }

  public add(data: string | Array<string>) {
    if (data) {
      if (Array.isArray(data)) {
        data.forEach((element) => {});
      } else {
        // hasAccess = this.read.indexOf(data.trim().toUpperCase()) !== -1;
      }
    }
  }

  public remove(data: string | Array<string>) {}
}
