export class Api {
  readonly schemes: string;
  readonly host: string;
  readonly basePath: string;
  readonly paths: Object;

  /**
   * Constructor
   *
   * @param api
   */
  constructor(api?) {
    api = api || {};
    this.schemes = api.schemes || "";
    this.host = api.host || "";
    this.basePath = api.basePath || "";
    this.paths = api.paths || {};
  }
}
