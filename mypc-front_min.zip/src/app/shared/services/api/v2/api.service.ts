import { Injectable } from '@angular/core';
import { UsersMicroServices } from '@shared/services/api/v2/microservices/users.micro.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { Api } from './api.model';
import { LoginMicroServices } from './microservices/login.micro.service';
import { LogoutMicroServices } from './microservices/logout.micro.service';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private _api: Api;
  private _login: LoginMicroServices;
  private _logout: LogoutMicroServices;
  private _users: UsersMicroServices;

  constructor(
    private environmentService: EnvironmentService,
    private loginMicroServices: LoginMicroServices,
    private logoutMicroServices: LogoutMicroServices,
    private usersMicroServices: UsersMicroServices
  ) {
    this._api = new Api(this.environmentService.api);
    this._login = this.loginMicroServices;
    this._logout = this.logoutMicroServices;
    this._users = this.usersMicroServices;
  }

  get api() {
    return this._api;
  }

  get login(): LoginMicroServices {
    return this._login;
  }

  get logout(): LogoutMicroServices {
    return this._logout;
  }

  get users(): UsersMicroServices {
    return this._users;
  }
}
