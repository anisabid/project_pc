import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserSearch, UserSearchResult } from '@shared/models/user';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EndpointService } from '../endpoint.service';

@Injectable({
  providedIn: 'root',
})
export class UsersMicroServices {
  private _endpointAvatar: EndpointService;
  private _endpointUsers: EndpointService;

  constructor(
    private httpClient: HttpClient,
    private urlHelperService: UrlHelperService
  ) {
    this._endpointAvatar = new EndpointService('avatar');
    this._endpointAvatar.items.get = '?user_uperid=${uPerId}';
    this._endpointUsers = new EndpointService('users');
    this._endpointUsers.items.get = '';
    this._endpointUsers.item.get = '?id=${id}';
  }

  getAvatar(obj: Object = {}): Observable<any> {
    const params = {
      '${uPerId}': obj['uPerId'] ? obj['uPerId'] : '',
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpointAvatar.items.get,
      params
    );

    return this.httpClient.get<any>(path);
  }

  /**
   * Get Users
   * @param value Value
   * @param offset Offset
   * @param limit Limit
   */
  getUsers(
    value: string = '',
    offset: number = 0,
    limit: number = 50
  ): Observable<UserSearchResult> {
    let path: string =
      this._endpointUsers.items.get +
      `?value=${value}&offset=${offset}&limit=${limit}`;

    return this.httpClient.get<any>(path).pipe(
      map((result) => {
        if (result?.users?.data) {
          result.users.data = result.users.data
            .map((user: any) => new UserSearch(user))
            ?.sort((a, b) => a.name.localeCompare(b.name));
        }
        return result;
      })
    );
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------

  get endpointAvatar(): EndpointService {
    return this._endpointAvatar;
  }

  get endpointUsers(): EndpointService {
    return this._endpointUsers;
  }
}
