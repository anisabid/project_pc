import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { Observable } from 'rxjs';
import { EndpointService } from '../endpoint.service';

@Injectable({
  providedIn: 'root',
})
export class LogoutMicroServices {
  private _endpointLogoutMyPc: EndpointService;
  constructor(
    private httpClient: HttpClient,
    private environmentService: EnvironmentService
  ) {
    this._endpointLogoutMyPc = new EndpointService('logout');

    this._endpointLogoutMyPc.item.post = '';
  }

  get endpoint(): EndpointService {
    return this._endpointLogoutMyPc;
  }

  postLogout(): Observable<any> {
    let path: string = this._endpointLogoutMyPc.item.post;
    if (this.environmentService.options.mock.data.logout) {
      path = this._endpointLogoutMyPc.toMock(path);
    }
    return this.httpClient.post(path, null, { observe: 'response' as 'body' });
  }
}
