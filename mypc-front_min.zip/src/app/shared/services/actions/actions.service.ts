import { Injectable } from '@angular/core';
import { ActionEvent } from '@shared/models/action-event';
import { Subject } from 'rxjs';

/**
 * @todo remove this class or move to  shared/services/subject folder
 */
@Injectable({
  providedIn: 'root',
})
export class ActionsService {
  public onEvents: Subject<ActionEvent>;

  constructor() {
    this.onEvents = new Subject();
  }
}
