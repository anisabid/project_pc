import { NgModule } from '@angular/core';
import { ButtonLoadingDirective } from './button-loading.directive';
import { HasAccessDirective } from './has-access.directive';
import { IfEnvDevDirective } from './if-env-dev.directive';
import { NgModelChangeDebouncedDirective } from './ngModel-change-debounced.directive';
import { ToggleMediaDirective } from './toggle-media.directive';
import { TogglePartnerDirective } from './toggle-partner.directive';
import { ToggleProfileDirective } from './toggle-profile.directive';

@NgModule({
  declarations: [
    ButtonLoadingDirective,
    HasAccessDirective,
    IfEnvDevDirective,
    NgModelChangeDebouncedDirective,
    ToggleMediaDirective,
    TogglePartnerDirective,
    ToggleProfileDirective,
  ],
  imports: [],
  exports: [
    ButtonLoadingDirective,
    HasAccessDirective,
    IfEnvDevDirective,
    NgModelChangeDebouncedDirective,
    ToggleMediaDirective,
    TogglePartnerDirective,
    ToggleProfileDirective,
  ],
})
export class DirectivesModule {}
