import { Directive, ElementRef, HostBinding, Input, TemplateRef } from '@angular/core';

@Directive({
  selector: '[buttonLoading]',
})
export class ButtonLoadingDirective {
  @Input() buttonLoading = false;
  @Input() hideText = false;

  @HostBinding('class.sfr-button-loading') get validButtonLoading(): boolean {
    return this.buttonLoading;
  }

  @HostBinding('class.hide-text') get validHideText(): boolean {
    return this.buttonLoading;
  }

  @HostBinding('disabled')
  get disabledButtonLoading(): boolean {
    return this.buttonLoading;
  }
}
