import {
  Directive,
  ElementRef,
  Input,
  OnInit,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import { SessionService } from '@shared/services/session/session.service';

interface HasAccessParams {
  all: boolean;
}

@Directive({
  selector: '[hasAccess]',
})
export class HasAccessDirective implements OnInit {
  private access: string | Array<string>;
  private accessAll: boolean;
  private isHidden: boolean;

  @Input('hasAccessParams') hasAccessParams: HasAccessParams;

  constructor(
    private element: ElementRef,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private sessionService: SessionService
  ) {
    this.isHidden = true;
    this.access = '';
  }

  ngOnInit() {
    if (this.sessionService.session.id) {
      this.updateView();
    }
  }

  @Input()
  set hasAccess(val: string | Array<string>) {
    this.access = val;
    this.updateView();
  }

  private updateView() {
    if (this.checkAccess()) {
      if (this.isHidden) {
        this.viewContainer.createEmbeddedView(this.templateRef);
        this.isHidden = false;
      }
    } else {
      this.isHidden = true;
      this.viewContainer.clear();
    }
  }

  private checkAccess(): boolean {
    return this.sessionService.session.access.hasAccessTo(
      this.access,
      this.hasAccessParams?.all
    );
  }
}
