import {
  Directive,
  ElementRef,
  Input,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import { SessionService } from '@shared/services/session/session.service';

@Directive({
  selector: '[togglePartner]',
})
export class TogglePartnerDirective {
  constructor(
    private element: ElementRef,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private sessionService: SessionService
  ) {}

  @Input()
  set togglePartner(val: boolean) {
    if (val !== undefined) {
      if (val) {
        this.updateView(this.sessionService.session.user.isPartner);
      } else {
        this.updateView(!this.sessionService.session.user.isPartner);
      }
    } else {
      this.updateView(true);
    }
  }

  private updateView(display: boolean) {
    if (display) {
      this.displayView();
    } else {
      this.hideView();
    }
  }

  private hideView() {
    this.viewContainer.clear();
  }

  private displayView() {
    this.viewContainer.createEmbeddedView(this.templateRef);
  }
}
