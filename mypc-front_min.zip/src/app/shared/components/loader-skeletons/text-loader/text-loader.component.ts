import { Component, Input } from '@angular/core';

@Component({
  selector: 'sfr-text-loader',
  templateUrl: './text-loader.component.html',
})
export class TextLoaderComponent {
  @Input()
  width = 300;
  @Input()
  height = 12;
  @Input()
  wUnite: 'px' | '%' = 'px';
  @Input()
  hUnite: 'px' | '%' = 'px';

  get getWidth(): string {
    return `${this.width}${this.wUnite}`;
  }
  get getHeight(): string {
    return `${this.height}${this.hUnite}`;
  }
}
