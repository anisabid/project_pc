import { Component, Input } from '@angular/core';

@Component({
  selector: 'sfr-circle-loader',
  templateUrl: './circle-loader.component.html',
})
export class CircleLoaderComponent {
  @Input()
  size = 44;

  constructor() {}

  get getSize(): string {
    return `${this.size}px`;
  }
}
