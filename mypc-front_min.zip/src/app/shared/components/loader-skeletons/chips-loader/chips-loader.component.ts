import { Component, Input } from '@angular/core';

@Component({
  selector: 'sfr-chips-loader',
  templateUrl: './chips-loader.component.html',
})
export class ChipsLoaderComponent {
  @Input()
  width = 60;
  @Input()
  height = 32;
  constructor() {}

  get getWidth(): string {
    return `${this.width}px`;
  }
  get getHeight(): string {
    return `${this.height}px`;
  }
}
