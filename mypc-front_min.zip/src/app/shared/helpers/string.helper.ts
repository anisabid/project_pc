export class StringHelper {
  constructor() {}

  static isEmpty(str: string): boolean {
    if (!str) {
      return true;
    }
    return typeof str === 'string' && str.trim().length == 0;
  }

  static isNotEmpty(str: string): boolean {
    return !this.isEmpty(str);
  }
}
