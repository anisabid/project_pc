export interface ArrayTitle {
  column: string;
  description: string;
  size: number;
  count?: number;
  type?: string;
}
