/**
 * Step
 */
export class Step {
  code: string;
  label?: string;
  name?: string;
  translate?: string;

  constructor(obj: Object = {}) {
    let params = {
      code: "",
      label: "",
      name: "",
      translate: "",
    };
    Object.assign(params, obj);

    this.code = params.code;
    this.label = params.label;
    this.name = params.name;
    this.translate = params.translate;
  }
}
