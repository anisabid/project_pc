export interface ICounter {
  inProgress: number;
  toDo: number;
  total: number;
}
export class CounterRequests implements ICounter {
  inProgress: number;
  toDo: number;
  total: number;

  constructor(data?) {
    this.inProgress = !data ? null : data.in_progress;
    this.toDo = !data ? null : data.toDo;
    this.total = !data ? false : data.total;
  }
}
export class CounterActions implements ICounter {
  inProgress: number;
  toDo: number;
  total: number;

  constructor(data?) {
    this.inProgress = !data ? null : data.in_waiting;
    this.toDo = !data ? null : data.toDo;
    this.total = !data ? false : data.total;
  }
}

export class Counter {
  requests: CounterRequests;
  actions: CounterActions;

  constructor(data?) {
    this.requests = !data ? null : new CounterRequests(data.counterDemands);
    this.actions = !data ? null : new CounterActions(data.counterActions);
  }
}
