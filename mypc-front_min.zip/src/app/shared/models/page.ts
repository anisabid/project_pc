export class Page<T> {
  _totalElements: number;
  _content: Array<T>;

  constructor() {
    this._content = [];
    this._totalElements = 0;
  }

  public push(value: T) {
    this._content.push(value);
    this._totalElements++;
  }

  set totalElements(value: number) {
    this._totalElements = value;
  }

  set content(value: Array<T>) {
    this._content = value;
  }

  get totalElements(): number {
    return this._totalElements;
  }

  get content(): Array<T> {
    return this._content;
  }

  get isEmpty(): boolean {
    return this._content.length === 0;
  }
}
