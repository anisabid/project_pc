import { EnumCRUD } from '../consts/crud.const';

export class Crud {
  private _action: string;

  constructor(value: string) {
    this._action = value.toLowerCase();
  }

  set action(value: string) {
    this._action = value.toLowerCase();
  }

  get action(): string {
    return this._action.toLowerCase();
  }

  get isCreate(): boolean {
    return this._action === EnumCRUD.CREATE;
  }

  get isRead(): boolean {
    return this._action === EnumCRUD.READ;
  }
  get isUpdate(): boolean {
    return this._action === EnumCRUD.UPDATE;
  }
  get isDelete(): boolean {
    return this._action === EnumCRUD.DELETE;
  }
}
