export class FilterItem {
  id: string;
  label: string;
  disabled: boolean;

  constructor(data) {
    this.id = !data ? null : data.id;
    this.label = !data ? null : data.label;
    this.disabled = !data ? false : data.disabled;
  }
}
