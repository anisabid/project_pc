import { NgModule } from '@angular/core';
import { MaterialModule } from '../material/material.module';
import { SnackBarMessageComponent } from './snack-bar-message.component';
import { SnackBarMessageService } from './snack-bar-message.service';

@NgModule({
  imports: [MaterialModule],
  entryComponents: [SnackBarMessageComponent],
  declarations: [SnackBarMessageComponent],
  exports: [SnackBarMessageComponent],
  providers: [SnackBarMessageService],
})
export class SnackBarMessageModule {}
