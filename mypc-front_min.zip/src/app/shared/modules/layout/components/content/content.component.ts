import { Component, ViewEncapsulation } from '@angular/core';
import { ContentService } from './content.service';

@Component({
  selector: 'content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ContentComponent {
  public wrappedByPerfectScrollbar: boolean;
  constructor(private contentService: ContentService) {
    this.contentService.onTogglePerfectScrollbarChanged.subscribe((value: boolean) => {
      this.wrappedByPerfectScrollbar = value;
    });
  }
}
