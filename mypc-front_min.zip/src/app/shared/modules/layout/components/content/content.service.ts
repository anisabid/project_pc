import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ContentService {
  private _perfectScrollbarToggle: boolean;
  public onTogglePerfectScrollbarChanged: BehaviorSubject<boolean>;

  /*
  private _disabledPerfectScrollbar: boolean;
  private _wrappedByPerfectScrollbar: boolean;
  public defaultDisabledPerfectScrollbar = false;
  public onTogglePerfectScrollbarChanged: BehaviorSubject<boolean>;
  public onDisablesPerfectScrollbarChanged: BehaviorSubject<boolean>;
  public onWrappedByPerfectScrollbarChanged: BehaviorSubject<boolean>;
  */

  constructor() {
    this._perfectScrollbarToggle = true;
    this.onTogglePerfectScrollbarChanged = new BehaviorSubject(this._perfectScrollbarToggle);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Set methods
  // -----------------------------------------------------------------------------------------------------

  set perfectScrollbarToggle(value: boolean) {
    this._perfectScrollbarToggle = value;
    this.onTogglePerfectScrollbarChanged.next(this._perfectScrollbarToggle);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------
  get perfectScrollbarToggle(): boolean {
    return this._perfectScrollbarToggle;
  }
}
