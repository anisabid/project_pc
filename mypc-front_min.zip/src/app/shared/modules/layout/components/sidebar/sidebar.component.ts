import { Clipboard } from '@angular/cdk/clipboard';
import { Component, Input, OnInit } from '@angular/core';
import { MatLegacySnackBar as MatSnackBar } from '@angular/material/legacy-snack-bar';
import {
  ConstNavigationItemType,
  NavigationItemType,
} from '@shared/consts/navigation.const';
import { EnumUrlTarget } from '@shared/consts/url-target.const';
import { NavigationItem, NavigationItems } from '@shared/models/navigation';
import { User } from '@shared/models/user';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { SessionService } from '@shared/services/session/session.service';
import { SidebarService } from './sidebar.service';

@Component({
  selector: 'sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
  public open: boolean;
  public user: User;
  public constNavigationItemType: NavigationItemType;
  private _styleBackgroundImageAvata: string;
  @Input() navigation: NavigationItems;
  constructor(
    private clipboard: Clipboard,
    private environmentService: EnvironmentService,
    private matSnackBar: MatSnackBar,
    private sessionService: SessionService,
    private sidebarService: SidebarService,
    private urlHelperService: UrlHelperService
  ) {
    this.open = this.sidebarService.toggle;
    this.user = this.sessionService.user;
    this.constNavigationItemType = ConstNavigationItemType;
  }

  ngOnInit(): void {
    this.sidebarService.getAvatar(this.user.uPerId).then((result: string) => {
      this.styleBackgroundImageAvata = result;
    });
  }

  public clickItem(id: string) {
    this.sidebarService.onItemClick.next(id);
  }

  /**
   * @todo Create directive for copyClipboard with template
   * @param value
   */
  public copyToClipboard(value: string): void {
    if (this.clipboard.copy(value)) {
      this.matSnackBar.open(value, null, {
        duration: this.environmentService.config.snackBarDuration,
        verticalPosition: 'top',
      });
    }
  }

  public toggle(val: boolean): void {
    this.open = val;
    this.sidebarService.toggle = val;
  }

  public getNavigationItemLabelForTranslate(item: NavigationItem): string {
    return item.translate ? item.translate : item.title;
  }

  public isBlankTarget(item: NavigationItem): boolean {
    return item.url_target === EnumUrlTarget.BLANK;
  }
  public isPopupTarget(item: NavigationItem): boolean {
    return item.url_target === EnumUrlTarget.POPUP;
  }

  public url_redirect(item: NavigationItem, parameters: any = {}): string {
    const url = this.urlHelperService.transformParameters(item.url, parameters);
    return this.urlHelperService.toBackOffice(url, item.url_config);
  }

  public openPopup(url: string): void {
    url = this.urlHelperService.transformParameters(url, {
      '${uperid}': this.user.uPerId,
    });
    window.open(url, 'popup', 'width=600,height=600');
  }

  public overrideNavigationItem(item: NavigationItem): NavigationItem {
    if (item.id === 'footer-blog') {
      return this.overrideNavigationBlog(item);
    }
    return item;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  private overrideNavigationBlog(item: NavigationItem): NavigationItem {
    if (this.user.isDefault) {
      item.url =
        this.environmentService.config.modules.layoutSidebar.navigation.blog.url.default;
      item.translate = 'i18n.navigation.blog.default';
      return item;
    } else {
      if (this.user.isMedia) {
        item.url =
          this.environmentService.config.modules.layoutSidebar.navigation.blog.url.media;
        item.translate = 'i18n.navigation.blog.media';
        return item;
      }
      if (this.user.isPartner) {
        item.url =
          this.environmentService.config.modules.layoutSidebar.navigation.blog.url.partner;
        item.translate = 'i18n.navigation.blog.partner';
        return item;
      }
    }
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Set methods
  // -----------------------------------------------------------------------------------------------------
  set styleBackgroundImageAvata(value: string) {
    this._styleBackgroundImageAvata = value
      ? 'background-image: url("data:image/png;base64,' + value + '");'
      : '';
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------
  get styleBackgroundImageAvata(): string {
    return this._styleBackgroundImageAvata;
  }
  get resetPasswordItem(): any {
    let item = this.navigation.footer.menu.find((item) => {
      return item.id === 'footer-reset-password';
    });
    item.url = this.urlHelperService.transformParameters(item.url, {
      '${uperid}': this.user.uPerId,
    });
    return item;
  }
}
