import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { NavigationIconComponent } from './navigation-icon.component';

@NgModule({
  declarations: [NavigationIconComponent],
  imports: [CommonModule, MatIconModule],
  exports: [NavigationIconComponent],
})
export class NavigationIconModule {}
