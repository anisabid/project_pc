import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatLegacyProgressSpinnerModule as MatProgressSpinnerModule } from '@angular/material/legacy-progress-spinner';
import { LoaderComponent } from './loader.component';
import { LoaderService } from './loader.service';
import { LoaderInterceptor } from './loader.interceptor';
import { LoaderDirective } from './loader.directive';
import { LoaderOverlayComponent } from './overlay/overlay.component';
import { SpinnerComponent } from './spinner/spinner.component';

@NgModule({
  declarations: [LoaderComponent, LoaderDirective, LoaderOverlayComponent, SpinnerComponent],
  imports: [CommonModule, MatProgressSpinnerModule],
  exports: [LoaderComponent, LoaderDirective, LoaderOverlayComponent, SpinnerComponent],
  providers: [LoaderService, { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }],
})
export class LoaderModule {}
