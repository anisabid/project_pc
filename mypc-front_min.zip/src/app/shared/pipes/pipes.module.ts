import { NgModule } from '@angular/core';
import { AccessPipe } from './access.pipe';
import { AcronymPipe } from './acronym.pipe';
import { IconPipe } from './icon.pipe';
import { StatusPipe } from './status.pipe';
import { StepPipe } from './step.pipe';
import { StringPipe } from './string.pipe';
import { ActionPipe } from './action.pipe';
import { SafeHtmlPipe } from './safe-html.pipe';

@NgModule({
  declarations: [AccessPipe, AcronymPipe, ActionPipe, IconPipe, StatusPipe, StepPipe, StringPipe, SafeHtmlPipe],
  imports: [],
  exports: [AccessPipe, AcronymPipe, ActionPipe, IconPipe, StatusPipe, StepPipe, StringPipe, SafeHtmlPipe],
  providers: [AccessPipe],
})
export class PipesModule {}
