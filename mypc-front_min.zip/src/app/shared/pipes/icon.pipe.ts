import {Pipe, PipeTransform} from "@angular/core";
import {Icons} from "@shared/models/icons";
import {ConstIcons} from "@shared/consts/icons.const";

@Pipe({
    name: "icon",
})
export class IconPipe implements PipeTransform {
    private icon: Icons;
    private response: any;

    /**
     * Transform
     *
     * @param value
     * @param {string} desc
     * @returns {any}
     */
    transform(value: string, desc: string): any {
        if (value.toUpperCase()) {
            switch (value.toUpperCase()) {
                case ConstIcons.TIMES.code.toUpperCase():
                    this.icon = ConstIcons.TIMES;
                    break;

                case ConstIcons.THUMBS_UP.code.toUpperCase():
                    this.icon = ConstIcons.THUMBS_UP;
                    break;
                case ConstIcons.ARCHIVE.code.toUpperCase():
                    this.icon = ConstIcons.ARCHIVE;
                    break;
                case ConstIcons.COMMENTS.code.toUpperCase():
                    this.icon = ConstIcons.COMMENTS;
                    break;
                case ConstIcons.BAN.code.toUpperCase():
                    this.icon = ConstIcons.BAN;
                    break;
                case ConstIcons.INBOX.code.toUpperCase():
                    this.icon = ConstIcons.INBOX;
                    break;

                case ConstIcons.CALENDAR.code.toUpperCase():
                    this.icon = ConstIcons.CALENDAR;
                    break;
                case ConstIcons.CHECK_SQUARE.code.toUpperCase():
                    this.icon = ConstIcons.CHECK_SQUARE;
                    break;
                case ConstIcons.FILE.code.toUpperCase():
                    this.icon = ConstIcons.FILE;
                    break;

                default:
                    this.icon = new Icons();
            }

            switch (desc.toLowerCase()) {
                case "code":
                    this.response = this.icon.code;
                    break;
                case "translate":
                    this.response = this.icon.translate;
                    break;
                default:
                    this.response = this.icon.code;
            }
            return this.response;
        }
        return null;
    }
}
