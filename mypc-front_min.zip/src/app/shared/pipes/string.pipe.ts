import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'string',
})
export class StringPipe implements PipeTransform {
  private response: string;
  /**
   * Transform
   *
   * @param value
   * @param {any} args
   * @returns {string}
   */
  transform(value: string, ...args: any[]): any {
    if (value) {
      switch (args[0].toLowerCase()) {
        case 'boldSubstr':
          if (args[1] !== '') {
            const strRegExp = new RegExp(args[1], 'gi');
            this.response = value.replace(strRegExp, '<b>' + args[1] + '</b>');
          }
          break;
        default:
          this.response = value;
      }
      return this.response;
    }
    return '';
  }
}
