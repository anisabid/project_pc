/**
 * @todo rename access in api php
 */
export interface Access {
  ADMIN_COM_PANEL: string;
  ADMIN_DELEGATIONS: string;
  ADMIN_FORM_EDITOR: string;
  ADMIN_FORM: string;
  ADMIN_MAPPING: string;
  ADMIN_MENU: string;
  ADMIN_NEW: string;
  ADMIN_PROCESSING: string;
  ADMIN_RDV: string;
  ADMIN_REPORTING: string;
  ADMIN_SOCLE_FLASH_BANNER: string;
  ADMIN_SOCLE_MAINTENANCE: string;
  ADMIN_SOCLE_NEWS: string;
  ADMIN_SOCLE: string;
  ADMIN_SPE_GROUPS: string;
  ADMIN_SPE_WORKFLOW: string;
  ADMIN_SUPER_MENU: string;
  ADMIN: string;
  COM_PANEL: string;
  CSL_ACTIONS: string;
  CSL_FOLLOW_UP: string;
  CSL_HOME: string;
  CSL_SEARCH: string;
  GRP_GEST: string;
  GRP_MEMBER: string;
  MEDIA: string;
  MY_DELEGATIONS: string;
  MY_REPORTS: string;
  RSC_CATALOG: string;
  RSC_INVENTORY: string;
  WIDGETS: string;
}
export enum EnumAccess {
  ADMIN = 'ADMIN', // Super-administration
  ADMIN_COM_PANEL = 'PS/ADMIN_SOCLE_PAN_COM', // Administration of the communication panel
  ADMIN_DELEGATIONS = 'SUBSTITUTE DELEGATION', // Admin Delegations
  ADMIN_FORM = 'PS/ADM_FORMULAIRE', // Forms administration (old version)
  ADMIN_FORM_EDITOR = 'PS/ADM_FORM_EDITOR', // 	Forms Administration
  ADMIN_MAPPING = 'PS/ADM_MAPPING', // Mapping administration
  ADMIN_MENU = 'ADMINMENU', // Menu Admin
  ADMIN_NEW = 'PS/ADM_NEW', // News administration
  ADMIN_NEWS = 'PS/ADM_NEWS', // News administration
  ADMIN_PROCESSING = 'PS/ADM_MASSPROCESSING', // Bulk processing
  ADMIN_RDV = 'PS/ADMIN_PRISE_RDV', // Appointment Administration
  ADMIN_REPORTING = 'PS/ADM_REPORTING', // Reporting administration
  ADMIN_SOCLE = 'PS/ADMIN_SOCLE', // Administration socle
  ADMIN_SOCLE_FLASH_BANNER = 'PS/ADMIN_SOCLE_BANDEAU_FLASH', // Administration of the flash banner
  ADMIN_SOCLE_MAINTENANCE = 'PS/ADMIN_SOCLE_MAINTENANCE', // Maintenance and debugging
  ADMIN_SOCLE_NEWS = 'PS/ADMIN_SOCLE_NEW', // New administration of the SOCLE
  ADMIN_SPE_GROUPS = 'PS/ADM_SPE_GROUPES', // Group administration
  ADMIN_SPE_WORKFLOW = 'PS/ADM_SPE_WORKFLOW', // Workflow administration
  ADMIN_SUPER_MENU = 'ADMIN_SUPER_MENU', // Menu super Admin
  COM_PANEL = 'PANNEAUCOM', // Communications panel
  CSL_ACTIONS = 'PS/CSL_ACTIONS', // My actions console
  CSL_FOLLOW_UP = 'PS/CSL_SUIVIS', // Follow up Console
  CSL_HOME = 'PS/CSL_ACCUEIL', // My Folders console
  CSL_SEARCH = 'PS/CSL_SEARCH', // E-support
  GRP_GEST = 'GEST_GRP',
  GRP_MEMBER = 'MEMBER_GRP',
  MEDIA = 'MEDIA',
  MY_DELEGATIONS = 'MES DELEGATIONS', // My Delegations
  MY_REPORTS = 'PS/CREATEEXCELFILE', // My reports
  RSC_CATALOG = 'PS/RSC_CATALOG', // 	Catalogue de service
  RSC_INVENTORY = 'PS/RSC_INVENTORY', // My Resources
  WIDGETS = 'WIDGETS', // Widgets
}

export const ConstAccess: Access = {
  ADMIN_COM_PANEL: EnumAccess.ADMIN_COM_PANEL,
  ADMIN_DELEGATIONS: EnumAccess.ADMIN_DELEGATIONS,
  ADMIN_FORM_EDITOR: EnumAccess.ADMIN_FORM_EDITOR,
  ADMIN_FORM: EnumAccess.ADMIN_FORM,
  ADMIN_MAPPING: EnumAccess.ADMIN_MAPPING,
  ADMIN_MENU: EnumAccess.ADMIN_MENU,
  ADMIN_NEW: EnumAccess.ADMIN_NEW,
  ADMIN_PROCESSING: EnumAccess.ADMIN_PROCESSING,
  ADMIN_RDV: EnumAccess.ADMIN_RDV,
  ADMIN_REPORTING: EnumAccess.ADMIN_REPORTING,
  ADMIN_SOCLE_FLASH_BANNER: EnumAccess.ADMIN_SOCLE_FLASH_BANNER,
  ADMIN_SOCLE_MAINTENANCE: EnumAccess.ADMIN_SOCLE_MAINTENANCE,
  ADMIN_SOCLE_NEWS: EnumAccess.ADMIN_SOCLE_NEWS,
  ADMIN_SOCLE: EnumAccess.ADMIN_SOCLE,
  ADMIN_SPE_GROUPS: EnumAccess.ADMIN_SPE_GROUPS,
  ADMIN_SPE_WORKFLOW: EnumAccess.ADMIN_SPE_WORKFLOW,
  ADMIN_SUPER_MENU: EnumAccess.ADMIN_SUPER_MENU,
  ADMIN: EnumAccess.ADMIN, // Super-administration
  COM_PANEL: EnumAccess.COM_PANEL,
  CSL_ACTIONS: EnumAccess.CSL_ACTIONS,
  CSL_FOLLOW_UP: EnumAccess.CSL_FOLLOW_UP,
  CSL_HOME: EnumAccess.CSL_HOME,
  CSL_SEARCH: EnumAccess.CSL_SEARCH,
  GRP_GEST: EnumAccess.GRP_GEST,
  GRP_MEMBER: EnumAccess.GRP_MEMBER,
  MEDIA: EnumAccess.MEDIA,
  MY_DELEGATIONS: EnumAccess.MY_DELEGATIONS,
  MY_REPORTS: EnumAccess.MY_REPORTS,
  RSC_CATALOG: EnumAccess.RSC_CATALOG,
  RSC_INVENTORY: EnumAccess.RSC_INVENTORY,
  WIDGETS: EnumAccess.WIDGETS,
};
