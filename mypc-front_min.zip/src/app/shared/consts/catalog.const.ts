export interface interfaceTypesCatalogs {
  CDS: string;
  ESUP: string;
}

export enum EnumCatalogs {
  CDS = 'cds',
  ESUP = 'esup',
}

export enum EnumCatalogSearch {
  CDS = 'searchESUP',
  ESUP = 'searchCDS',
}

export const ConstTypesCatalogs: interfaceTypesCatalogs = {
  CDS: EnumCatalogs.CDS,
  ESUP: EnumCatalogs.ESUP,
};

export const ConstCatalogSearch: interfaceTypesCatalogs = {
  CDS: EnumCatalogSearch.CDS,
  ESUP: EnumCatalogSearch.ESUP,
};
