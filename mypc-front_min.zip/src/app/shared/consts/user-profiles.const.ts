export interface UserProfile {
  MEDIA: string;
  PARTNER: string;
  DEFAULT: string;
}

export enum EnumUserProfile {
  MEDIA = 'media',
  PARTNER = 'partner',
  DEFAULT = 'default',
}

export const ConstUserProfile: UserProfile = {
  MEDIA: EnumUserProfile.MEDIA,
  PARTNER: EnumUserProfile.PARTNER,
  DEFAULT: EnumUserProfile.DEFAULT,
};
