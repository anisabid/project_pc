import { Action } from "@shared/models/action";

export interface action {
    REJECT: Action;
    COMPLEMENT: Action;
    CANCELED: Action;
    CANCELED_Folder: Action;
    DONE: Action;
    DONE_FINISHED: Action;
    SUBMIT: Action;
    CREATE: Action;
    SAVE: Action;
    SUBMIT_DEROGATION: Action;
    SUBMIT_VALIDATION_TECH: Action;
    SUBMIT_VALIDATION_TECH_PRE: Action;
    SUBMIT_VALIDATION_SUP: Action;
    SUBMIT_VALIDATION_SUP_PRE: Action;
    VALIDATE_TECH: Action;
    VALIDATE_FONCT: Action;
    TRAITE: Action;
    CLAIMED: Action;
    FROZEN: Action;
    PLANNED: Action;
    FINISHED: Action;
    RELAUNCH: Action;
    RELANCE_PRE: Action;
    RELANCE_REA: Action;
    RELANCE_REPRISE: Action;
    WAITING_CLOSE: Action;
    REJECT_PRIO: Action;
    ACCEPT_PRIO: Action;
    REJECTED_TRAITEMENT: Action;
    ASK_DEROGATION: Action;
    ASK_APPOINTMENT: Action;
    REJECT_TO_OPEN: Action;
    RECORD: Action;
    GO: Action;
    ESCALATION: Action;
    ECHEC: Action;
    VERIFY: Action;
    WAIT: Action;
    CONCEPTION: Action;
    PRIORITY: Action;
    SEND: Action;

}

/**
 * ConstActions Const
 */

export const ConstActions = {
    REJECT: new Action({
        code: 'Refuser',
        translate: 'i18n.action.reject',
    }),

    COMPLEMENT: new Action({
        code: 'Demander un complément d\'information',
        translate: 'i18n.action.complement',
    }),


    CANCELED_Folder: new Action({
        code: "Annuler mon dossier",
        translate: 'i18n.action.canceled_folder',

    }),

    CANCELED: new Action({
        code: "Annuler",
        translate: 'i18n.action.canceled',

    }),

    DONE: new Action({
        code: 'Valider',
        translate: 'i18n.action.done',

    }),

    SEND: new Action({
        code: 'envoyer',
        translate: 'i18n.action.done',

    }),

    DONE_FINISHED: new Action({
        code: 'Accepter le traitement',
        translate: 'i18n.action.done_finished',

    }),
    SUBMIT: new Action({
        code: 'Soumettre',
        translate: 'i18n.action.submit',

    }),
    CREATE: new Action({
        code: 'Création',
        translate: 'i18n.action.create',

    }),
    SAVE: new Action({
        code: 'Enregistrer puis soumettre',
        translate: 'i18n.action.save',

    }),

    SUBMIT_DEROGATION: new Action({
        code: 'Soumettre à dérogation SLA',
        translate: 'i18n.action.submit_derogation',

    }),
    SUBMIT_VALIDATION_SUP: new Action({
        code: 'Soumettre à validation supplémentaire',
        translate: 'i18n.action.submit_validation_sup',

    }),
    SUBMIT_VALIDATION_SUP_PRE: new Action({
        code: 'Soumettre à validation supplémentaire priorisée',
        translate: 'i18n.action.submit_validation_sup',

    }),
    SUBMIT_VALIDATION_TECH: new Action({
        code: 'Soumettre à validation technique',
        translate: 'i18n.action.submit_validation_tech',

    }),
    SUBMIT_VALIDATION_TECH_PRE: new Action({
        code: 'Soumettre à validation tech priorisé',
        translate: 'i18n.action.submit_validation_tech_pre',

    }),
    VALIDATE_FONCT: new Action({
        code: 'Valider fonctionnellement la prioritée',
        translate: 'i18n.action.validate_fonct',

    }),

    VALIDATE_TECH: new Action({
        code: 'Soumettre à validation tech priorisé',
        translate: 'i18n.action.validate_tech',

    }),

    TRAITE: new Action({
        code: 'Traiter',
        translate: 'i18n.action.traite',

    }),

    CLAIMED: new Action({
        code: 'En réclamation',
        translate: 'i18n.action.claimed',

    }),

    FROZEN: new Action({
        code: 'Geler',
        translate: 'i18n.action.frozen',

    }),

    PLANNED: new Action({
        code: 'Planifier',
        translate: 'i18n.action.planned',

    }),

    FINISHED: new Action({
        code: 'Finaliser',
        translate: 'i18n.action.finished',

    }),

    RELAUNCH: new Action({
        code: 'Relancer ma demande',
        translate: 'i18n.action.relaunch',

    }),

    RELANCE_REA: new Action({
        code: 'Lancer réalisation',
        translate: 'i18n.action.relance_rea',

    }),

    RELANCE_PRE: new Action({
        code: 'Lancer préparation',
        translate: 'i18n.action.relance_pre',

    }),
    RELANCE_REPRISE: new Action({
        code: 'Lancer reprise',
        translate: 'i18n.action.relance_reprise',

    }),
    WAITING_CLOSE: new Action({
        code: 'En attente de fermeture',
        translate: 'i18n.action.waiting_close',

    }),
    REJECT_PRIO: new Action({
        code: 'Refuser Prio',
        translate: 'i18n.action.reject_prio',

    }),
    ACCEPT_PRIO: new Action({
        code: 'Accepter Prio',
        translate: 'i18n.action.accept_prio',

    }),
    REJECTED_TRAITEMENT: new Action({
        code: 'Rejeter le traitement',
        translate: 'i18n.action.rejected_traitement',

    }),
    ASK_APPOINTMENT: new Action({
        code: 'Demande de Planification de RDV',
        translate: 'i18n.action.ask_appointment',

    }),
    ASK_DEROGATION: new Action({
        code: 'Demander dérogation',
        translate: 'i18n.action.ask_derogation',

    }),
    REJECT_TO_OPEN: new Action({
        code: 'Refuser réouverture',
        translate: 'i18n.action.reject_to_open',

    }),
    RECORD: new Action({
        code: 'Reprise manuelle',
        translate: 'i18n.action.record',

    }),
    RECORD_MANUALY: new Action({
        code: 'Reprendre manuellement',
        translate: 'i18n.action.record_manualy',

    }),
    GO: new Action({
        code: 'GO réalisation technique',
        translate: 'i18n.action.go',

    }),
    ESCALATION: new Action({
        code: 'Escalader suite à refus de traitement',
        translate: 'i18n.action.escalation',

    }),
    ECHEC: new Action({
        code: 'Marquer en échec réalisation',
        translate: 'i18n.action.echec',

    }),
    VERIFY: new Action({
        code: 'Marquer comme à vérifier',
        translate: 'i18n.action.verify',

    }),
    WAIT: new Action({
        code: 'Marquer en attente de réalisation',
        translate: 'i18n.action.wait',

    }),
    CONCEPTION: new Action({
        code: 'Aller en Phase de Conception',
        translate: 'i18n.action.conception',

    }),
    PRIORITY: new Action({
        code: 'Envoyer la demande de Priorisation (N+1)',
        translate: 'i18n.action.priority',

    }),

};
