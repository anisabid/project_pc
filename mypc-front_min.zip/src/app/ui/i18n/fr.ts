export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      ui: {
        name: 'UI components',
        navigation: {
          page: {
            header: 'Page Header',
          },
        },
        global: {},
      },
    },
  },
};
