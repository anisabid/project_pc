import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';
import { UiComponent } from './ui.component';
import { UiRoutingModule } from './ui-routing.module';
import { PageHeaderComponent } from './components/page-header/page-header.component';
import { HighlightModule } from 'ngx-highlightjs';
import {
  PerfectScrollbarModule,
  PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG,
} from 'ngx-perfect-scrollbar';

@NgModule({
  declarations: [UiComponent, PageHeaderComponent],
  imports: [
    CommonModule,
    SharedModule,
    UiRoutingModule,
    HighlightModule,
    PerfectScrollbarModule,
  ],
})
export class UiModule {}
