// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  integration: false,
  api: {
    schemes: '',
    host: '',
    basePath: 'api/v1/',
    paths: {},
  },
  backOffice: {
    baseUrl: 'https://su13540.phys.perf:8081/',
  },
  access: {
    lockApp: {
      enable: true,
      dateBegin: '2022/12/09',
      dateEnd: '2022/12/15',
    },
    mapEqual: 'origin',
    map: {
      intranet: '0',
      internet: '1',
      mobile: '2',
      default: '0', // Default id Environnement
      'http://localhost:4202': '0',
      'https://mypc-v2.pfv.private.sfr.com/': '0',
      'https://mypc-v2.private.sfr.com': '0',
      'https://mypc-v2.pfv.sfr.fr/': '1',
      'https://mypc-v2.sfr.fr': '1',
    },
    redirect: {
      partner: {
        enable: false,
        url: 'http://mypc.private.sfr.com/',
      },
    },
  },
  iframe: {
    baseUrl: '/mypc/index.php',
    baseUrlMyAssistance: '/myAssistance/',
  },
  config: {
    defaultNavigate: '/',
    snackBarDuration: 1000,
    modules: {
      layoutSidebar: {
        navigation: {
          blog: {
            url: {
              default:
                'https://intranetgroupe.private.sfr.com/xwiki/bin/view/Bureautique/',
              media:
                'https://intranetgroupe.private.sfr.com/xwiki/bin/view/Le%20blog%20Bureautique%20m%C3%A9dia/Offre%20service%20Bureautique%20M%C3%A9dia',
              partner: 'https://support-partenaires.private.sfr.com/',
            },
          },
        },
      },
      dashboard: {
        widgets: {
          faq: {
            active: false,
          },
          notifications: {
            active: false,
          },
          requests: {
            active: true,
          },
        },
        workflow: {
          genericIncident: {
            name: 'Incident générique',
            formId: '6516',
          },
        },
      },
      login: {
        disableLogout: false,
        mergeLogin: false,
        onlyAutoLogin: true,
        onlyManualLogin: false,
        urlAutoLogin:
          'http://mypc.private.sfr.com/mypc-backoffice/api/v1/login?auto=true',
        snackBarErrorDuration: 2000,
      },
      logout: {
        duration: 500,
        path: {
          myPc: 'mypc/index.php?p=deconnexion',
          myAssistance: 'myAssistance/?origin=refonte&action=logout',
        },
        autoRedirectToLogin: true,
      },
      requests: {
        myApprovals: {},
        myRequests: {},
        advancedFilter: {
          validation: {
            global: false,
            partial: true,
          },
          rollBack: true,
          reset: true,
        },
      },
    },
  },
  options: {
    localStorage: {
      jwt: 'jwt',
      sidebar: 'sidebar',
      catalogs: 'catalogs',
      requestsPreviousSearch: 'requestsPreviousSearch',
      clearAfterLogout: ['catalogs', 'jwt'],
      clearAfterUpdateAppVersion: [
        'sidebar',
        'requestsPreviousSearch',
        'idRequest',
      ],
    },
    localCookies: {
      clearAfterLogout: '*',
    },
    mock: {
      api: {
        schemes: '',
        host: '',
        basePath: 'mocks/',
        paths: {},
      },
      data: {
        catalog: false,
        counter: false,
        login: false,
        requests: false,
      },
    },
  },
};
