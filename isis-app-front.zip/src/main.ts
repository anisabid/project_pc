import { enableProdMode } from "@angular/core";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { APP_CONFIG } from "@app/app.config";

import { AppModule } from "./app/app.module";
import { environment } from "@env/environment";

// Load conf mounted during ci deployment stage of the pipeline (and take the default one for localhost)
// TECH NOTE: use XMLHttpRequest instead of fetch to allow preload in index.html
const xhr = new XMLHttpRequest();
xhr.onreadystatechange = () => {
  if (xhr.readyState === 4 && xhr.status === 200) {
    if (environment.production) {
      enableProdMode();
    }
    platformBrowserDynamic([{ provide: APP_CONFIG, useValue: xhr.response }])
      .bootstrapModule(AppModule)
      .catch((err) => console.error(err));
  }
};

xhr.responseType = "json";
xhr.open("GET", "/assets/config/isis_bootstrap_config.json", true);
xhr.responseType = "json";
xhr.send();
