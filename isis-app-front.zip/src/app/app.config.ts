import { InjectionToken } from "@angular/core";

export class AppConfig {
  ciEnvironment: string;
  isProduction: boolean;
  environmentName: string;
  socketUrl: string;
  isisSpringBackV2BaseApi: {
    schemes: string;
    host: string;
    basePath: string;
  };
  moteurClarifyBaseApi: {
    schemes: string;
    host: string;
    basePath: string;
  };
  apmRUM?: {
    serverUrl?: string;
  };
  config: {
    alarms__cron__timer_init: number;
    alarms__cron__timer_loop: number;
    alarms__lock__timer_loop: number;
    alarms__websocket__logs__disable: boolean;
  };
  keyCloakIsis: {
    url: string;
    realm: string;
    clientId: string;
  };
}
export const APP_CONFIG = new InjectionToken<AppConfig>("APP_CONFIG");
