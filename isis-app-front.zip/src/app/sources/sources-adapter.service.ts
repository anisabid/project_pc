import { Injectable } from "@angular/core";
import {
  HostSourceApiItem,
  HostSourceItem,
  SourceApiItem,
  SourceItem,
} from "./sources.model";

@Injectable({ providedIn: "root" })
export class SourcesAdapterService {
  private _evaluateIfNotInService(sourceApiItem: SourceApiItem): boolean {
    return !sourceApiItem.hosts;
  }

  convertToHostSourceItem(
    hostSourceApiItem: HostSourceApiItem,
    relativeSourceName: string
  ): HostSourceItem {
    return <HostSourceItem>{
      heartBeatId: hostSourceApiItem.heartBeatId,
      isOk: hostSourceApiItem.status === "OK",
      host:
        hostSourceApiItem.host === "UNKNOWN"
          ? "Instance par défaut"
          : hostSourceApiItem.host,
      lastOKTimestamp: hostSourceApiItem.timestamp,
      blackoutEventReference: hostSourceApiItem.blackoutEventReference,
      underMaintenance: hostSourceApiItem.underMaintenance,
      relativeSourceName: relativeSourceName,
    };
  }

  private _convertToHostSourceItems(
    hostSourceApiItems: HostSourceApiItem[],
    relativeSourceName: string
  ): HostSourceItem[] {
    if (!hostSourceApiItems || hostSourceApiItems.length === 0) {
      return null;
    }
    return hostSourceApiItems.map((hostSourceApiItem: HostSourceApiItem) => {
      return this.convertToHostSourceItem(
        hostSourceApiItem,
        relativeSourceName
      );
    });
  }

  convertToSourceItem(sourceApiItem: SourceApiItem): SourceItem {
    const isNotInService = this._evaluateIfNotInService(sourceApiItem);
    const sourceItem: SourceItem = {
      sourceName: sourceApiItem.source,
      consigneUrl: this._getSafeStringUrl(sourceApiItem.consigneUrl),
      hosts: isNotInService
        ? null
        : this._convertToHostSourceItems(
            sourceApiItem.hosts,
            sourceApiItem.source
          ),
      isNotInService: isNotInService,
    };
    return sourceItem;
  }

  // TECH NOTE: to avoid to have WARNING in browser related to unsafe URL value (wrong data from DB).
  private _getSafeStringUrl(consignUrl: string): string {
    if (!consignUrl) return undefined;
    try {
      const url = new URL(consignUrl);
      return (url.protocol === "https:" || url.protocol === "http:") &&
        !url.host.includes("...")
        ? consignUrl
        : undefined;
    } catch (error: unknown) {
      return undefined;
    }
  }
}
