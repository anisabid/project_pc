export interface HostSourceItem {
  heartBeatId: string;
  isOk: boolean;
  host: string;
  lastOKTimestamp: number;
  underMaintenance?: boolean;
  blackoutEventReference?: string;
  requesterUpperId?: string;
  relativeSourceName?: string;
}

export interface SourceItem {
  sourceName: string;
  hosts?: HostSourceItem[];
  consigneUrl?: string;
  isNotInService?: boolean;
}

export interface HostSourceInfo {
  heartBeatId: string;
  relativeSourceName: string;
}

export interface HostSourceApiItem {
  heartBeatId: string;
  host: string;
  status: "OK" | "KO";
  timestamp: number;
  underMaintenance?: boolean;
  blackoutEventReference?: string;
  requesterUpperId?: string;
}

export interface SourceApiItem {
  source: string;
  hosts: HostSourceApiItem[];
  consigneUrl?: string;
}
