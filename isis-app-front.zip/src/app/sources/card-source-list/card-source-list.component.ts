import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from "@angular/core";
import { IsisError } from "@app/shared/models/error";
import { SourceItem } from "../sources.model";

@Component({
  selector: "app-card-source-list",
  templateUrl: "./card-source-list.component.html",
  styleUrls: ["./card-source-list.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CardSourceListComponent {
  noResultlabel = "Aucune donnée disponible !";
  @Input()
  sourceItems: SourceItem[];

  @Input()
  isisError?: IsisError;

  @Output() openModalForSourceItemEmitter: EventEmitter<SourceItem> =
    new EventEmitter();

  openModal(sourceItem: SourceItem): void {
    this.openModalForSourceItemEmitter.emit(sourceItem);
  }
}
