import { HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { IsisError } from "@app/shared/models/error";
import {
  catchError,
  Observable,
  of,
  OperatorFunction,
  pipe,
  retry,
  shareReplay,
  switchMap,
  tap,
  throwError,
  timer,
  BehaviorSubject,
  merge,
  Subject,
} from "rxjs";
import { SourcesAdapterService } from "./sources-adapter.service";
import { SourcesApiService } from "./sources-api.service";
import {
  HostSourceInfo,
  HostSourceItem,
  SourceApiItem,
  SourceItem,
} from "./sources.model";

@Injectable({ providedIn: "root" })
export class SourcesService {
  currentSourceItems$: Observable<SourceItem[]>;
  atLeastOneSourceKO$: Observable<boolean>;
  sourcesIsisError$: Observable<IsisError>;
  private _currentUpdatedHostInfo: HostSourceInfo;

  errorMessages = {
    loading:
      "Erreur lors du chargement des données relatives à la disponibilité des sources",
    update: "Erreur lors la mise à jour de l'instance",
    refBlackoutExists: "Erreur: cette réference de blackout existe déjà !",
    delete: "Erreur lors du désengagement de l'instance",
  };

  private _sourcesIsisErrorBhSubject: BehaviorSubject<IsisError>;
  private _pollingPeriodInMs = 10000;

  private _sourceApiItemsAfterUpdateSubject: Subject<SourceApiItem[]>;
  private _sourceApiItemsAfterUpdates$: Observable<SourceApiItem[]>;
  private _sourceApiItemsFromPolling$: Observable<SourceApiItem[]>;

  constructor(
    private _sourcesApiService: SourcesApiService,
    private _sourcesAdapterService: SourcesAdapterService
  ) {
    this._sourcesIsisErrorBhSubject = new BehaviorSubject(null);
    this.sourcesIsisError$ = this._sourcesIsisErrorBhSubject.asObservable();

    this._sourceApiItemsFromPolling$ = this._getSourceApiItemsWithPolling(
      0,
      this._pollingPeriodInMs
    );
    this._sourceApiItemsAfterUpdateSubject = new Subject();
    this._sourceApiItemsAfterUpdates$ =
      this._sourceApiItemsAfterUpdateSubject.asObservable();

    this.currentSourceItems$ = merge(
      this._sourceApiItemsFromPolling$,
      this._sourceApiItemsAfterUpdates$
    ).pipe(
      this._convertToSourceItemsList(),
      this._sortSourceItemsList(),
      shareReplay(1)
    );

    this.atLeastOneSourceKO$ = this.currentSourceItems$.pipe(
      this._isOneSourceKo()
    );
  }

  private _sortSourceItemsList(): OperatorFunction<SourceItem[], SourceItem[]> {
    return pipe(
      switchMap((sourceItems: SourceItem[]) => {
        return of(sourceItems?.sort(this._sortBySourceName));
      })
    );
  }

  private _convertToSourceItemsList(): OperatorFunction<
    SourceApiItem[],
    SourceItem[]
  > {
    return pipe(
      switchMap((sourceApiItems: SourceApiItem[]) => {
        const sourceItems: SourceItem[] = sourceApiItems.map(
          (sourceApiItem: SourceApiItem) => {
            return this._sourcesAdapterService.convertToSourceItem(
              sourceApiItem
            );
          }
        );
        return of(sourceItems);
      })
    );
  }

  private _isOneSourceKo(): OperatorFunction<SourceItem[], boolean> {
    return pipe(
      switchMap((sourceItems: SourceItem[]) => {
        const isOneSourceKO = sourceItems.some((sourceItem: SourceItem) => {
          return sourceItem.hosts?.some((hostSourceItem: HostSourceItem) => {
            return !hostSourceItem.isOk && !hostSourceItem.underMaintenance;
          });
        });
        return of(isOneSourceKO);
      })
    );
  }

  private _getSourceApiItemsWithPolling(
    startPollingInMs: number,
    periodPollingInMs: number
  ): Observable<SourceApiItem[]> {
    return timer(startPollingInMs, periodPollingInMs).pipe(
      this._getAllSourceApiItemsAndManageError(),
      retry({ delay: periodPollingInMs }),
      shareReplay(1)
    );
  }

  private _getAllSourceApiItemsAndManageError(): OperatorFunction<
    unknown,
    SourceApiItem[]
  > {
    return pipe(
      switchMap(() => {
        return this._sourcesApiService.getSourceApiItems().pipe(
          tap(() => {
            this._sourcesIsisErrorBhSubject.next(null);
          })
        );
      }),
      catchError(() => {
        const isisError = this._notifyApiError(
          "ERROR_GET_SOURCES_API",
          this.errorMessages.loading
        );
        return throwError(() => isisError);
      })
    );
  }

  private _sortBySourceName = (sourceA: SourceItem, sourceB: SourceItem) => {
    return sourceA.sourceName.localeCompare(sourceB.sourceName);
  };

  private _notifyApiError(errorCode: string, errorMessage: string): IsisError {
    const isisError: IsisError = {
      isisCode: errorCode,
      isisMessage: errorMessage,
    };
    this._sourcesIsisErrorBhSubject.next(isisError);
    return isisError;
  }

  updateHostSourceItem(hostSourceItem: HostSourceItem): Observable<unknown> {
    return this._sourcesApiService.updateHostSourceItem(hostSourceItem).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 409) {
          this._notifyApiError(
            "ERROR_UPDATE_SOURCES_API",
            `${this.errorMessages.refBlackoutExists} : ${hostSourceItem.blackoutEventReference}`
          );
        } else {
          this._notifyApiError(
            "ERROR_UPDATE_SOURCES_API",
            this.errorMessages.update
          );
        }
        return of(hostSourceItem); // never throw error here
      }),
      tap(() => {
        this._currentUpdatedHostInfo = {
          heartBeatId: hostSourceItem.heartBeatId,
          relativeSourceName: hostSourceItem.relativeSourceName,
        };
      }),
      this._getAllSourceApiItemsAndManageError(),
      tap((sourceApiItems: SourceApiItem[]) => {
        this._sourceApiItemsAfterUpdateSubject.next(sourceApiItems);
      })
    );
  }

  deleteHostSourceItem(hostSourceInfo: HostSourceInfo): Observable<unknown> {
    return this._sourcesApiService
      .deleteHostSourceItem(hostSourceInfo.heartBeatId)
      .pipe(
        catchError(() => {
          this._notifyApiError(
            "ERROR_DELETE_SOURCES_API",
            this.errorMessages.delete
          );
          return of(hostSourceInfo); // never throw error here
        }),
        tap(() => {
          this._currentUpdatedHostInfo = {
            heartBeatId: null,
            relativeSourceName: hostSourceInfo.relativeSourceName,
          };
        }),
        this._getAllSourceApiItemsAndManageError(),
        tap((sourceApiItems: SourceApiItem[]) => {
          this._sourceApiItemsAfterUpdateSubject.next(sourceApiItems);
        })
      );
  }

  getCurrentUpdatedHostInfo(): HostSourceInfo {
    return this._currentUpdatedHostInfo;
  }

  clearCurrentUpdatedHostInfo(): void {
    this._currentUpdatedHostInfo = null;
  }
}
