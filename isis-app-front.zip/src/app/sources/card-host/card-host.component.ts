import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { HostSourceItem } from "../sources.model";

@Component({
  selector: "app-card-host",
  templateUrl: "./card-host.component.html",
  styleUrls: ["./card-host.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CardHostComponent {
  @Input() hostSourceItem: HostSourceItem;
  @Input() iconAtTheLeft = false;
}
