import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  EventEmitter,
  Output,
} from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";
import { SourceItem } from "../sources.model";

@Component({
  selector: "app-card-source",
  templateUrl: "./card-source.component.html",
  styleUrls: ["./card-source.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CardSourceComponent implements OnInit {
  @Input() sourceItem: SourceItem;

  @Output() openModalForSourceItemEmitter: EventEmitter<SourceItem> =
    new EventEmitter();

  labels = {
    tooltip: {
      actionsButton: "Actions",
    },
    disabled: {
      notInService: "En attente de mise en service",
    },
  };

  isAdminOrSupervisor = false;

  constructor(private _securityService: KeycloakSecurityService) {}

  ngOnInit(): void {
    this.isAdminOrSupervisor =
      this._securityService.hasRequiredRole(IsisRole.admin) ||
      this._securityService.hasRequiredRole(IsisRole.supervisor);
  }

  openSourceActionsModal(sourceItem: SourceItem): void {
    this.openModalForSourceItemEmitter.emit(sourceItem);
  }
}
