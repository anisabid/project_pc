import { Component, OnDestroy, OnInit } from "@angular/core";
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
} from "@angular/material/dialog";
import { IsisError } from "@app/shared/models/error";
import { ToastrService } from "ngx-toastr";
import { Observable, tap } from "rxjs";
import { ModalActionsSourceComponent } from "./modal-actions-source/modal-actions-source.component";
import { HostSourceInfo, HostSourceItem, SourceItem } from "./sources.model";
import { SourcesService } from "./sources.service";

@Component({
  selector: "app-sources-page",
  templateUrl: "./sources-page.component.html",
  styleUrls: ["./sources-page.component.scss"],
})
export class SourcesPageComponent implements OnInit, OnDestroy {
  sourceItems$: Observable<SourceItem[]>;
  sourceIsisError$: Observable<IsisError>;

  constructor(
    private _sourcesService: SourcesService,
    private _toastrService: ToastrService,
    private _matDialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.sourceIsisError$ = this._sourcesService.sourcesIsisError$.pipe(
      tap((isisError: IsisError) => {
        if (isisError?.isisMessage) {
          this._toastrService.error(isisError?.isisMessage);
        }
      })
    );

    this.sourceItems$ = this._sourcesService.currentSourceItems$.pipe(
      tap((sourceItems: SourceItem[]) => {
        const updatedHeartbeatInfo =
          this._sourcesService.getCurrentUpdatedHostInfo();
        this._updateActionsModalWithUpdatedHost(
          sourceItems,
          updatedHeartbeatInfo
        );
      })
    );
  }

  ngOnDestroy(): void {
    if (this._matDialog.openDialogs?.length > 0) {
      this._matDialog.openDialogs.forEach(
        (openDialog: MatDialogRef<ModalActionsSourceComponent>) => {
          openDialog.close();
        }
      );
    }
  }

  private _searchRelativeSourceItemInListById(
    sourceItems: SourceItem[],
    heartbeatId: string
  ): SourceItem {
    return sourceItems?.find((sourceItem: SourceItem) => {
      return !!sourceItem.hosts?.some((hostSourceItem: HostSourceItem) => {
        return hostSourceItem.heartBeatId === heartbeatId;
      });
    });
  }

  private _searchRelativeSourceItemInListBySourceName(
    sourceItems: SourceItem[],
    sourceName: string
  ): SourceItem {
    return sourceItems?.find((sourceItem: SourceItem) => {
      return sourceItem.sourceName === sourceName;
    });
  }

  private _updateActionsModalWithUpdatedHost(
    newListSourceItems: SourceItem[],
    currentUpdatedSourceInfo: HostSourceInfo
  ): void {
    if (currentUpdatedSourceInfo) {
      const currentHeartBeatId = currentUpdatedSourceInfo.heartBeatId;
      const currentHeartBeatRelativeSourceName =
        currentUpdatedSourceInfo.relativeSourceName;

      const sourceItem = currentHeartBeatId
        ? this._searchRelativeSourceItemInListById(
            newListSourceItems,
            currentHeartBeatId
          )
        : this._searchRelativeSourceItemInListBySourceName(
            newListSourceItems,
            currentHeartBeatRelativeSourceName
          );
      this._sourcesService.clearCurrentUpdatedHostInfo();

      if (sourceItem.hosts && sourceItem.hosts.length !== 0) {
        this.openSourceActionsModal(sourceItem, true);
      } else {
        this._closeCurrentModal();
      }
    } else {
      // do nothing
    }
  }

  // TECH NOTE: open modal from page component instead of sourceItem component to avoid closing modal during polling
  openSourceActionsModal(
    sourceItem: SourceItem,
    openWithUpdatedSource = false
  ): void {
    if (this._matDialog.openDialogs?.length > 0) {
      this._matDialog.openDialogs.forEach(
        (openDialog: MatDialogRef<ModalActionsSourceComponent>) => {
          if (openDialog.id !== sourceItem.sourceName) {
            openDialog.close();
            this._openModal(sourceItem);
          } else if (openWithUpdatedSource) {
            openDialog.componentInstance.data = {
              sourceItem,
            };
          } else {
            // do nothing (don't close the modal if it is the same)
          }
        }
      );
    } else {
      this._openModal(sourceItem);
    }
  }

  private _closeCurrentModal(): void {
    if (this._matDialog.openDialogs?.length > 0) {
      this._matDialog.openDialogs.forEach(
        (openDialog: MatDialogRef<ModalActionsSourceComponent>) => {
          openDialog.close();
        }
      );
    }
  }

  private _openModal(sourceItem: SourceItem): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = "modal-actions-source";
    dialogConfig.autoFocus = false;
    dialogConfig.hasBackdrop = false;
    dialogConfig.id = `${sourceItem.sourceName}`;
    dialogConfig.data = {
      sourceItem,
    };
    dialogConfig.closeOnNavigation = true;
    this._matDialog.open(ModalActionsSourceComponent, dialogConfig);
  }
}
