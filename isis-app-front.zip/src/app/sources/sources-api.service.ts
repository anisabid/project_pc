import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { Observable } from "rxjs";
import {
  HostSourceApiItem,
  HostSourceItem,
  SourceApiItem,
} from "./sources.model";

@Injectable({ providedIn: "root" })
export class SourcesApiService {
  private _heartBeatSourcesApiBaseUrl: string;
  private _headers: HttpHeaders;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService,
    private _securityService: KeycloakSecurityService
  ) {
    this._heartBeatSourcesApiBaseUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.heartbeatSourcesPath}`;
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
  }

  getSourceApiItems(): Observable<SourceApiItem[]> {
    const httpOptions = {
      headers: this._headers,
    };
    const url = `${this._heartBeatSourcesApiBaseUrl}/sources`;
    return this._httpClient.get<SourceApiItem[]>(url, httpOptions);
  }

  // TECH NOTE: This method returns nothing
  updateHostSourceItem(
    hostSourceItem: HostSourceItem
  ): Observable<HostSourceApiItem> {
    const httpOptions = {
      headers: this._headers,
      params: this._buildHttpParamsForUpdate(hostSourceItem),
    };
    const url = `${this._heartBeatSourcesApiBaseUrl}/${hostSourceItem.heartBeatId}`;
    return this._httpClient.put<HostSourceApiItem>(url, undefined, httpOptions);
  }

  private _buildHttpParamsForUpdate(
    hostSourceItem: HostSourceItem
  ): HttpParams {
    const expectedUnderMaintenance = hostSourceItem.underMaintenance;
    let parameters: HttpParams = new HttpParams().set(
      "underMaintenance",
      expectedUnderMaintenance
    );

    const refBlackoutToAdd = hostSourceItem.blackoutEventReference;
    if (expectedUnderMaintenance && refBlackoutToAdd?.length !== 0) {
      parameters = parameters.append(
        "blackoutEventReference",
        refBlackoutToAdd
      );
    }

    parameters = parameters.append(
      "requesterUpperId",
      `u${this._securityService.getUser().uperId}`
    );
    return parameters;
  }

  deleteHostSourceItem(id: string): Observable<HostSourceApiItem> {
    const httpOptions = {
      headers: this._headers,
    };
    const url = `${this._heartBeatSourcesApiBaseUrl}/${id}`;
    return this._httpClient.delete<HostSourceApiItem>(url, httpOptions);
  }
}
