import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SharedModule } from "@app/shared/shared.module";
import { CardHostComponent } from "./card-host/card-host.component";
import { CardSourceListComponent } from "./card-source-list/card-source-list.component";
import { CardSourceComponent } from "./card-source/card-source.component";
import { ActionsHostItemComponent } from "./modal-actions-source/actions-host-item/actions-host-item.component";
import { ModalActionsSourceComponent } from "./modal-actions-source/modal-actions-source.component";
import { SourcesPageComponent } from "./sources-page.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "home",
    pathMatch: "full",
  },
  {
    path: "home",
    component: SourcesPageComponent,
  },
  {
    path: "**",
    redirectTo: "home",
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes), SharedModule],
  declarations: [
    SourcesPageComponent,
    CardHostComponent,
    CardSourceComponent,
    CardSourceListComponent,
    ModalActionsSourceComponent,
    ActionsHostItemComponent,
  ],
})
export class SourcesModule {}
