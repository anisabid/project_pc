import {
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { HostSourceInfo, HostSourceItem } from "@app/sources/sources.model";
import { SourcesService } from "@app/sources/sources.service";
import { Subject, take, takeUntil } from "rxjs";

@Component({
  selector: "app-actions-host-item",
  templateUrl: "./actions-host-item.component.html",
  styleUrls: ["./actions-host-item.component.scss"],
})
export class ActionsHostItemComponent implements OnInit, OnChanges, OnDestroy {
  @Input() hostSourceItem: HostSourceItem;

  labels = {
    titles: { refBlackout: "REF Blackout" },
    confirm: {
      message: "Confirmez-vous la suppression ?",
      warning: "Blackout EN COURS",
      yes: "Oui",
      no: "Non",
    },
    tooltips: {
      activate: "Mettre à nouveau en service",
      maintenance: "Mettre en maintenance",
      delete: "Désengager",
    },
  };

  displayStateAtLeft = true;
  refBlackoutFormControl: FormControl<string>;
  showConfirmDelete = false;

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(private _sourcesService: SourcesService) {}

  ngOnInit(): void {
    this.refBlackoutFormControl = new FormControl<string>({
      value: this.hostSourceItem.blackoutEventReference,
      disabled: this.hostSourceItem.underMaintenance,
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    const currentHostItem: HostSourceItem =
      changes.hostSourceItem?.currentValue;
    if (this.refBlackoutFormControl && currentHostItem) {
      this.refBlackoutFormControl.patchValue(
        currentHostItem.blackoutEventReference
      );
      currentHostItem.underMaintenance
        ? this.refBlackoutFormControl.disable()
        : this.refBlackoutFormControl.enable();
    }
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  activateAgain(hostSourceItem: HostSourceItem): void {
    this._sourcesService
      .updateHostSourceItem({
        ...hostSourceItem,
        underMaintenance: false,
      })
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  desactivate(hostSourceItem: HostSourceItem): void {
    this._sourcesService
      .updateHostSourceItem({
        ...hostSourceItem,
        blackoutEventReference: this.refBlackoutFormControl.value,
        underMaintenance: true,
      })
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  delete(): void {
    this.showConfirmDelete = true;
  }

  cancelDelete(): void {
    this.showConfirmDelete = false;
  }

  confirmDelete(hostSourceItem: HostSourceItem): void {
    this.showConfirmDelete = false;
    this._sourcesService
      .deleteHostSourceItem(<HostSourceInfo>{
        heartBeatId: hostSourceItem.heartBeatId,
        relativeSourceName: hostSourceItem.relativeSourceName,
      })
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  removeFirstWhiteSpaces(event: Event): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.refBlackoutFormControl?.patchValue(value.trimStart());
    }
  }

  removeEndWhiteSpaces(event: Event): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.refBlackoutFormControl.patchValue(value.trimEnd());
    }
  }
}
