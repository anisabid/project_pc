import { Component, Inject, OnDestroy } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { SourceItem } from "../sources.model";

@Component({
  selector: "app-modal-actions-source",
  templateUrl: "./modal-actions-source.component.html",
  styleUrls: ["./modal-actions-source.component.scss"],
})
export class ModalActionsSourceComponent implements OnDestroy {
  labels = {
    tooltips: {
      closeModal: "Fermer la fenêtre",
    },
  };

  constructor(
    public dialogRef: MatDialogRef<ModalActionsSourceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { sourceItem: SourceItem }
  ) {}

  ngOnDestroy(): void {
    this.closeModal();
  }

  closeModal(): void {
    this.dialogRef.close();
  }
}
