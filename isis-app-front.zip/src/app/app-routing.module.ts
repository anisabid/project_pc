import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "./auth-helper/auth.guard";
import { StandardLayoutComponent } from "@app/shared/components/standard-layout/standard-layout.component";
import { ErrorPageComponent } from "./shared/components/errorPage/error-page.component";

const routes: Routes = [
  {
    path: "",
    component: StandardLayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: "",
        redirectTo: "alarms/si/all",
        pathMatch: "full",
      },
      {
        path: "administration",
        loadChildren: () =>
          import("./admin/admin.module").then((m) => m.AdminModule),
      },
      {
        path: "alarms",
        loadChildren: () =>
          import("./alarms/alarms.module").then((m) => m.AlarmsModule),
      },
      {
        path: "inhibitions",
        loadChildren: () =>
          import("./seker/seker.module").then((m) => m.SekerModule),
      },
      {
        path: "services",
        loadChildren: () =>
          import("./impacted-services/impacted-services.module").then(
            (m) => m.ImpactedServicesModule
          ),
      },
      {
        path: "sources",
        loadChildren: () =>
          import("./sources/sources.module").then((m) => m.SourcesModule),
      },
    ],
  },
  {
    path: "error/:code",
    component: ErrorPageComponent,
  },
  {
    path: "error",
    component: ErrorPageComponent,
  },
  { path: "**", redirectTo: "alarms/si/all" },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: "legacy" })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
