import { Component, EventEmitter, Input, Output } from "@angular/core";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";

@Component({
  selector: "app-simple-subheader",
  templateUrl: "./simple-subheader.component.html",
})
export class SimpleSubheaderComponent {
  @Input() breadcrumbItems: BreadcrumbItem[];
  @Input() quickSearchPlaceholder? = "Filtre par mot-clé";
  @Input() tooltipAddButtonLabel? = "Ajouter un item";
  @Input() tooltipDeleteSelectionButtonLabel? =
    "Supprimer le (ou les) item(s) sélectionné(s)";
  @Input() displayDeleteButton? = false;

  @Output() keywordFilterEmitter: EventEmitter<string> =
    new EventEmitter<string>();
  @Output() openEditModeEmitter: EventEmitter<boolean> =
    new EventEmitter<boolean>();
  @Output() deleteMultipleItemEmitter: EventEmitter<boolean> =
    new EventEmitter<boolean>();

  filterByKeyword(keyword?: string): void {
    this.keywordFilterEmitter.emit(keyword);
  }

  openEditMode(): void {
    this.openEditModeEmitter.emit(true);
  }

  deleteMultipleItem(): void {
    this.deleteMultipleItemEmitter.emit(true);
  }
}
