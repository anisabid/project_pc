import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import {
  forkJoin,
  from,
  MonoTypeOperatorFunction,
  Observable,
  of,
  Subject,
  throwError,
  catchError,
  map,
  switchMap,
  tap,
} from "rxjs";
import { AdminCrudApiService, CrudItem } from "./admin-crud-api.service";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import {
  AttributesForLog,
  LogMessage,
  PostLogService,
} from "@app/shared/services/api/v2/microservices/post-log.service";

@Injectable({
  providedIn: "root",
})
export class AdminCrudService<
  T extends CrudItem
> extends AdminCrudApiService<T> {
  protected _itemSubject: Subject<T[]> = new Subject();
  items$: Observable<T[]>;
  // to override when specific messages
  toasterMessages = {
    confirm: {
      delete: "L'item sera supprimé.",
      deleteMultiple: "Les items sélectionnés seront supprimés.",
      notDeleted: "L'item n'a pas été supprimé.",
      notDeletedMultiple: "Les items sélectionnés n'ont pas été supprimés.",
    },
    success: {
      add: "Item enregistré avec succès",
      update: "Item mis à jour avec succès",
      delete: "Item supprimé avec succès !",
      deleteMultiple: "Les items ont été supprimés avec succès !",
    },
    error: {
      all: "Erreur lors du chargement des items !",
      add: "Erreur lors de l'ajout !",
      update: "Erreur lors de la mise à jour de l'item !",
      delete: "Erreur lors de la suppression de l'item !",
      deleteMultiple: "Erreur lors de la suppression des items !",
    },
    log: {
      add: "ajout d'un nouvel item",
      update: "mise à jour d'un item",
      delete: "suppression d'un item",
    },
  };

  private _confirmDeleteLabel = "Etes-vous sûr ?";

  constructor(
    protected httpClient: HttpClient,
    protected apiService: ApiService,
    protected path: string,
    protected toastrService: ToastrService,
    protected isisService: IsisService,
    protected confirmDialogService: ConfirmDialogService,
    protected postLogService: PostLogService
  ) {
    super(httpClient, apiService, path);
    this.items$ = this._itemSubject.asObservable();
  }

  resolve(): Observable<T[]> {
    return this._getAllItems();
  }

  protected _getAllItems(): Observable<T[]> {
    return super.getAll().pipe(
      map((items: T[]) => {
        this._itemSubject.next(items);
        return items;
      }),
      catchError((error) => {
        this.toastrService.error(error, this.toasterMessages.error.all);
        return [];
      })
    );
  }

  private _addItem(
    itemToAdd: T,
    attributesForLog?: AttributesForLog
  ): Observable<T> {
    return super
      .createItem(itemToAdd)
      .pipe(this._doAfterCrudOperation("add", attributesForLog));
  }

  private _doAfterCrudOperation(
    type: "add" | "update" | "delete",
    attributesForLog?: AttributesForLog
  ): MonoTypeOperatorFunction<T> {
    return (item) =>
      item.pipe(
        switchMap((item: T) => {
          this.toastrService.success(this.toasterMessages.success[`${type}`]);
          return this._postLogSuccessCrudOperation(
            item,
            attributesForLog,
            type
          );
        }),
        catchError((error) => {
          this.toastrService.error(
            error,
            this.toasterMessages.error[`${type}`]
          );
          return throwError(() => error);
        })
      );
  }

  private _updateItem(
    itemToUpdate: T,
    attributesForLog?: AttributesForLog
  ): Observable<T> {
    return super
      .updateItem(itemToUpdate)
      .pipe(this._doAfterCrudOperation("update", attributesForLog));
  }

  private _deleteItem(
    itemToDelete: T,
    attributesForLog?: AttributesForLog
  ): Observable<T> {
    return from(
      this.confirmDialogService.confirm(
        this._confirmDeleteLabel,
        this.toasterMessages.confirm.delete
      )
    ).pipe(
      switchMap((confirmed: boolean) => {
        if (confirmed) {
          return super
            .deleteItem(itemToDelete.id) // this method returns null when success
            .pipe(
              switchMap(() => {
                return of(itemToDelete);
              }),
              this._doAfterCrudOperation("delete", attributesForLog)
            );
        } else {
          this.toastrService.error(this.toasterMessages.confirm.notDeleted);
          return of(itemToDelete);
        }
      }),
      catchError((error) => {
        return throwError(() => error);
      })
    );
  }

  private _deleteMultipleItems(
    itemToDeletes: T[],
    attributesForLog?: AttributesForLog
  ): Observable<T[]> {
    return from(
      this.confirmDialogService.confirm(
        this._confirmDeleteLabel,
        this.toasterMessages.confirm.deleteMultiple
      )
    ).pipe(
      switchMap((confirmed: boolean) => {
        if (confirmed) {
          const itemToDeletes$: Observable<T>[] = itemToDeletes.map(
            (itemToDelete: T) => {
              return super
                .deleteItem(itemToDelete.id) // tech note: this method returns null
                .pipe(
                  switchMap(() => {
                    return this._postLogSuccessCrudOperation(
                      itemToDelete,
                      attributesForLog,
                      "delete"
                    );
                  })
                );
            }
          );
          return forkJoin(itemToDeletes$).pipe(
            tap(() => {
              this.toastrService.success(
                this.toasterMessages.success.deleteMultiple
              );
            }),
            catchError((error) => {
              this.toastrService.error(
                this.toasterMessages.error.deleteMultiple
              );
              return throwError(() => error);
            })
          );
        } else {
          this.toastrService.error(
            this.toasterMessages.confirm.notDeletedMultiple
          );
          return of(itemToDeletes);
        }
      }),
      catchError((error) => {
        return throwError(() => error);
      })
    );
  }

  private _postLogSuccessCrudOperation(
    item: T,
    attributesForLogs: AttributesForLog,
    typeLog: "add" | "update" | "delete"
  ): Observable<T> {
    if (attributesForLogs) {
      const logSuccessCrudOperationAndReturnItem = this.postLogService
        .postLog(this._buildMessageToLog(item, attributesForLogs, typeLog))
        .pipe(
          switchMap(() => {
            return of(item);
          })
        );
      return logSuccessCrudOperationAndReturnItem;
    } else {
      return of(item);
    }
  }

  private _buildMessageToLog(
    item: T,
    attributesForLogs: AttributesForLog,
    typeLog: "add" | "update" | "delete"
  ): LogMessage {
    return {
      action: `${this.toasterMessages.log[`${typeLog}`]} : ${
        item[`${attributesForLogs.actionLog}`]
      }`,
      key: item[
        `${
          attributesForLogs.keyLog
            ? attributesForLogs.keyLog
            : attributesForLogs.actionLog
        }`
      ],
    };
  }

  protected addItemAndRefreshItems(
    itemToAdd: T,
    attributesForLog?: AttributesForLog
  ): Observable<T[]> {
    return this._addItem(itemToAdd, attributesForLog).pipe(
      switchMap(() => {
        return this._getAllItems();
      })
    );
  }

  protected updateItemAndRefresItems(
    itemToUpdate: T,
    attributesForLog?: AttributesForLog
  ): Observable<T[]> {
    return this._updateItem(itemToUpdate, attributesForLog).pipe(
      switchMap(() => {
        return this._getAllItems();
      })
    );
  }

  protected deleteItemAndRefreshItems(
    itemToDelete: T,
    attributesForLog?: AttributesForLog
  ): Observable<T[]> {
    return this._deleteItem(itemToDelete, attributesForLog).pipe(
      switchMap(() => {
        return this._getAllItems();
      })
    );
  }

  protected deleteMultipleItemsAndRefreshItems(
    items: T[],
    attributesForLog?: AttributesForLog
  ): Observable<T[]> {
    return this._deleteMultipleItems(items, attributesForLog).pipe(
      switchMap(() => {
        return this._getAllItems();
      })
    );
  }
}
