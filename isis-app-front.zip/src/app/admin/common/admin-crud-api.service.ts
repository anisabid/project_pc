import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { ApiService } from "@app/shared/services/api/v2/api.service";

export interface CrudItem {
  id?: string;
}

@Injectable({
  providedIn: "root",
})
export class AdminCrudApiService<T extends CrudItem> {
  protected _headers: HttpHeaders;
  protected _adminApiBaseUrl: string;

  constructor(
    protected _httpClient: HttpClient,
    protected apiService: ApiService,
    protected path: string
  ) {
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
    this._adminApiBaseUrl = `${this.apiService.isisSpringAppBackV2ApiConfig.basePath}${path}`;
  }

  getAll(): Observable<T[]> {
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient.get<T[]>(this._adminApiBaseUrl, httpOptions);
  }

  createItem(itemToCreate: T): Observable<T> {
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient.post<T>(
      this._adminApiBaseUrl,
      itemToCreate,
      httpOptions
    );
  }

  updateItem(itemToUpdate: T): Observable<T> {
    const httpOptions = {
      headers: this._headers,
    };
    const url = `${this._adminApiBaseUrl}/${itemToUpdate.id}`;
    return this._httpClient.put<T>(url, itemToUpdate, httpOptions);
  }

  deleteItem(itemId: string): Observable<T> {
    const httpOptions = {
      headers: this._headers,
    };
    const url = `${this._adminApiBaseUrl}/${itemId}`;
    return this._httpClient.delete<T>(url, httpOptions); // Tech note: this method returns null when success.
  }
}
