export const commonAdminLabels = {
  ALARMS: "Alarmes",
  TITLES: {
    actions: "Actions",
  },
  BUTTONS: {
    save: "Enregistrer",
    cancel: "Annuler et fermer",
  },
};
