import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: "app-quick-search-input",
  templateUrl: "./quick-search-input.component.html",
  styleUrls: ["./quick-search-input.component.scss"],
})
export class QuickSearchInputComponent {
  @Input() inputPlaceholder: string;
  @Output() keywordEmitter: EventEmitter<string> = new EventEmitter();

  emitKeyword(keyword: string): void {
    this.keywordEmitter.emit(keyword.trim().toLowerCase());
  }
}
