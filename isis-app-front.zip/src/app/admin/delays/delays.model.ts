import { FormControl, FormGroup } from "@angular/forms";
import {
  SirocoRefNameSubForm,
  SirocoRefNameSubFormValue,
} from "@app/shared/components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.component";
import { CrudItem } from "../common/admin-crud-api.service";

export interface DelayRule extends CrudItem {
  sfrSource?: string;
  sfrRefClarify?: string;
  sfrRefClarifyName?: string;
  host?: string;
  hostName?: string;
  message?: string;
  supervisedObject?: string;
  supervisionDomain?: string;
  delay: number;
}

export interface DelayRuleTableItem extends DelayRule {
  delayInMin?: number;
}

export interface DelayRuleFormValue {
  id?: string;
  sfrSource?: string;
  sfrRefClarify?: SirocoRefNameSubFormValue;
  host?: SirocoRefNameSubFormValue;
  message?: string;
  supervisedObject?: string;
  supervisionDomain?: string;
  delayInMin?: number;
}

export interface DelayRuleForm {
  id: FormControl<string>;
  sfrSource: FormControl<string>;
  sfrRefClarify?: FormGroup<SirocoRefNameSubForm>;
  host?: FormGroup<SirocoRefNameSubForm>;
  message: FormControl<string>;
  supervisedObject: FormControl<string>;
  supervisionDomain: FormControl<string>;
  delayInMin: FormControl<number>;
}
