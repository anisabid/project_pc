import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ValidationErrors,
  Validators,
} from "@angular/forms";
import { IsisUtilsService } from "@app/service/isis-utils.service";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { SirocoRefNameAutocompleteService } from "@app/shared/components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.service";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { PostLogService } from "@app/shared/services/api/v2/microservices/post-log.service";
import { ToastrService } from "ngx-toastr";
import { Observable } from "rxjs";
import { AdminCrudService } from "../common/admin-crud-service";
import {
  DelayRule,
  DelayRuleForm,
  DelayRuleFormValue,
  DelayRuleTableItem,
} from "./delays.model";

@Injectable({ providedIn: "root" })
export class DelaysService extends AdminCrudService<DelayRule> {
  delayRules$: Observable<DelayRule[]>;
  toasterMessages = {
    confirm: {
      delete: "La temporisation sera supprimée.",
      deleteMultiple: "Les temporisations sélectionnées seront supprimées.",
      notDeleted: "La temporisation n'a pas été supprimée.",
      notDeletedMultiple:
        "Les temporisations sélectionnées n'ont pas été supprimées.",
    },
    success: {
      add: "Temporisation enregistrée avec succès",
      update: "Temporisation mise à jour avec succès",
      delete: "Temporisation supprimée avec succès !",
      deleteMultiple: "Les temporisations ont été supprimées avec succès !",
    },
    error: {
      all: "Erreur lors du chargement des temporisations !",
      add: "Erreur lors de l'ajout !",
      update: "Erreur lors de la mise à jour de la temporisation !",
      delete: "Erreur lors de la suppression de la temporisation !",
      deleteMultiple: "Erreur lors de la suppression des temporisation !",
    },
    log: {
      add: "ajout d'une nouvelle temporisation",
      update: "mise à jour d'une temporisation",
      delete: "suppression d'une temporisation",
    },
  };
  keyControlNameFullfilledToChecks = [
    "sfrSource",
    "sfrRefClarify",
    "host",
    "message",
    "supervisionDomain",
    "supervisedObject",
  ];

  constructor(
    protected _httpClient: HttpClient,
    protected _apiService: ApiService,
    protected _toastrService: ToastrService,
    protected _isisService: IsisService,
    protected _confirmDialogService: ConfirmDialogService,
    private _isisUtilsService: IsisUtilsService,
    private _sirocoRefNameAutocompleteService: SirocoRefNameAutocompleteService,
    protected _postLogService: PostLogService
  ) {
    super(
      _httpClient,
      _apiService,
      "alarm-delay-rules",
      _toastrService,
      _isisService,
      _confirmDialogService,
      _postLogService
    );
    this.delayRules$ = this.items$;
  }

  private _getDelayRuleTableItemFromDelayRule(
    delayRule: DelayRule
  ): DelayRuleTableItem {
    const sfrRefClarifyValueOrEmpty =
      this._isisUtilsService.getStringValueOrEmpty(delayRule.sfrRefClarify);
    const hostValueOrEmpty = this._isisUtilsService.getStringValueOrEmpty(
      delayRule.host
    );
    return {
      id: delayRule.id,
      sfrSource: this._isisUtilsService.getStringValueOrEmpty(
        delayRule.sfrSource
      ),
      sfrRefClarify: sfrRefClarifyValueOrEmpty,
      sfrRefClarifyName: delayRule.sfrRefClarifyName?.length
        ? delayRule.sfrRefClarifyName
        : sfrRefClarifyValueOrEmpty,
      host: hostValueOrEmpty,
      hostName: delayRule.hostName?.length
        ? delayRule.hostName
        : hostValueOrEmpty,
      message: this._isisUtilsService.getStringValueOrEmpty(delayRule.message),
      supervisedObject: this._isisUtilsService.getStringValueOrEmpty(
        delayRule.supervisedObject
      ),
      supervisionDomain: this._isisUtilsService.getStringValueOrEmpty(
        delayRule.supervisionDomain
      ),
      delay: delayRule.delay ? delayRule.delay : undefined,
      delayInMin: this._getDelayTimeInMin(delayRule.delay),
    };
  }

  private _getDelayTimeInMin(delayInMillisec: number): number {
    return delayInMillisec ? Math.floor(delayInMillisec / 60000) : undefined;
  }

  getDelayRuleTableItemsFromDelayRules(
    delayRules: DelayRule[]
  ): DelayRuleTableItem[] {
    return delayRules.map((delayRule: DelayRule) => {
      return this._getDelayRuleTableItemFromDelayRule(delayRule);
    });
  }

  buildDelayRuleFormGroup(): FormGroup<DelayRuleForm> {
    return new FormGroup<DelayRuleForm>(
      {
        id: new FormControl(null),
        sfrSource: new FormControl(""),
        sfrRefClarify:
          this._sirocoRefNameAutocompleteService.buildSirocoRefNameFormGroup(
            true
          ),
        host: this._sirocoRefNameAutocompleteService.buildSirocoRefNameFormGroup(
          false
        ),
        message: new FormControl(""),
        supervisedObject: new FormControl(""),
        supervisionDomain: new FormControl(""),
        delayInMin: new FormControl(0, [
          Validators.required,
          Validators.min(1),
        ]),
      },
      { validators: [this._atLeastOneFieldFulfilled] }
    );
  }

  addDelayRuleAndRefreshRules(rule: DelayRule): Observable<DelayRule[]> {
    return this.addItemAndRefreshItems(rule, { actionLog: "delay" });
  }

  updateDelayRuleAndRefreshRules(rule: DelayRule): Observable<DelayRule[]> {
    return this.updateItemAndRefresItems(rule, { actionLog: "delay" });
  }

  deleteDelayRuleAndRefreshRules(rule: DelayRule): Observable<DelayRule[]> {
    this.toasterMessages.confirm.delete = `La temporisation de ${this._getDelayTimeInMin(
      rule.delay
    )} min sera supprimée.`;
    return this.deleteItemAndRefreshItems(rule, { actionLog: "delay" });
  }

  deleteMultipleDelayRulesAndRefreshRules(
    rules: DelayRule[]
  ): Observable<DelayRule[]> {
    return this.deleteMultipleItemsAndRefreshItems(rules, {
      actionLog: "delay",
    });
  }

  isRuleAlreadyExist(
    valueFromRuleFG: DelayRuleFormValue,
    allExistingRules: DelayRuleTableItem[]
  ): boolean {
    const isRuleExist = allExistingRules?.some((rule: DelayRuleTableItem) => {
      return (
        rule.id !== valueFromRuleFG.id &&
        rule.sfrSource === valueFromRuleFG.sfrSource &&
        rule.sfrRefClarify === valueFromRuleFG.sfrRefClarify.sirocoRef &&
        rule.host === valueFromRuleFG.host.sirocoRef &&
        rule.message === valueFromRuleFG.message &&
        rule.supervisedObject === valueFromRuleFG.supervisedObject &&
        rule.supervisionDomain === valueFromRuleFG.supervisionDomain
      );
    });
    if (isRuleExist) {
      this._toastrService.error("Cette temporisation existe déjà");
    }
    return isRuleExist;
  }

  getValueToPatchFromRuleTableItem(
    rule: DelayRuleTableItem
  ): DelayRuleFormValue {
    const sirocoAutocompleteSfrRefClarify =
      this._sirocoRefNameAutocompleteService.getAutocompleteInputValue(
        rule.sfrRefClarify,
        rule.sfrRefClarifyName
      );
    const sirocoAutocompleteHost =
      this._sirocoRefNameAutocompleteService.getAutocompleteInputValue(
        rule.host,
        rule.hostName
      );
    return {
      ...rule,
      sfrRefClarify: {
        sirocoRefNameAuto: sirocoAutocompleteSfrRefClarify,
        sirocoRef: sirocoAutocompleteSfrRefClarify?.id,
        sirocoName: sirocoAutocompleteSfrRefClarify?.name,
      },
      host: {
        sirocoRefNameAuto: sirocoAutocompleteHost,
        sirocoRef: sirocoAutocompleteHost?.id,
        sirocoName: sirocoAutocompleteHost?.name,
      },
    };
  }

  convertFormValueToDelayRuleBeforeSave(value: DelayRuleFormValue): DelayRule {
    return {
      id: value.id?.length ? value.id : null,
      sfrSource: this._isisUtilsService.getStringValueOrUndefined(
        value.sfrSource
      ),
      sfrRefClarify: value?.sfrRefClarify?.sirocoRef?.length
        ? value?.sfrRefClarify?.sirocoRef
        : undefined,
      sfrRefClarifyName: value?.sfrRefClarify?.sirocoName?.length
        ? value.sfrRefClarify.sirocoName
        : undefined,
      host: value?.host?.sirocoRef?.length ? value.host.sirocoRef : undefined,
      hostName: value?.host?.sirocoName?.length
        ? value?.host?.sirocoName
        : undefined,
      message: this._isisUtilsService.getStringValueOrUndefined(value.message),
      supervisedObject: this._isisUtilsService.getStringValueOrUndefined(
        value.supervisedObject
      ),
      supervisionDomain: this._isisUtilsService.getStringValueOrUndefined(
        value.supervisionDomain
      ),
      delay: value.delayInMin * 60000, // (in milliseconds)
    };
  }

  private _atLeastOneFieldFulfilled(
    control: AbstractControl
  ): ValidationErrors | null {
    const formGroup = control as FormGroup<DelayRuleForm>;
    const keyToChecks = [
      "sfrSource",
      "sfrRefClarify",
      "host",
      "message",
      "supervisedObject",
      "supervisionDomain",
    ];

    const autocompleteKeys = ["sfrRefClarify", "host"];
    const fulfilledFieldName = keyToChecks.find((keyControlName) => {
      const controlValue = formGroup.controls[keyControlName].value;
      if (autocompleteKeys.includes(keyControlName)) {
        return controlValue?.sirocoRef?.length;
      } else {
        return controlValue?.trim() !== "";
      }
    });
    // clear error 'requiredOneFieldFulfilled' of each formControl if at least one fulfilled
    if (fulfilledFieldName) {
      keyToChecks.map((keyControlName) => {
        const errors = formGroup.controls[keyControlName].errors;
        if (errors?.requiredOneFieldFulfilled) {
          formGroup.controls[keyControlName].setErrors(null);
          if (autocompleteKeys.includes(keyControlName)) {
            (formGroup.controls[`${keyControlName}`] as FormGroup).controls[
              "sirocoRefNameAuto"
            ].setErrors(null);
          }
        } else {
          // do nothing
        }
      });
      return null;
    } else {
      // set error 'requiredOneFieldFulfilled' on each formControl if no one fulfilled
      const error: ValidationErrors = {
        requiredOneFieldFulfilled: {
          value: true,
          message: constValidatorsErrorMessages.AT_LEAST_ONE_FIELD,
        },
      };
      keyToChecks.map((keyControlName) => {
        const formControl = formGroup.controls[keyControlName];
        formControl.setErrors(error);

        if (autocompleteKeys.includes(keyControlName)) {
          (formGroup.controls[`${keyControlName}`] as FormGroup).controls[
            "sirocoRefNameAuto"
          ].setErrors(error);
        }
      });
      return error;
    }
  }
}
