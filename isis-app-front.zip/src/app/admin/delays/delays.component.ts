import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { ActivatedRoute } from "@angular/router";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";
import { SirocoRefNameSubFormValue } from "@app/shared/components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.component";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import { of, startWith, Subject, switchMap, take, takeUntil, tap } from "rxjs";
import { commonAdminLabels } from "../common/common-admin-labels";
import { SimpleSelectionBaseComponent } from "@app/shared/components/simple-selection-base/simple-selection-base.component";
import {
  DelayRule,
  DelayRuleForm,
  DelayRuleFormValue,
  DelayRuleTableItem,
} from "./delays.model";
import { DelaysService } from "./delays.service";

@Component({
  selector: "app-delays",
  templateUrl: "./delays.component.html",
  styleUrls: ["../common/common-admin-style.scss", "./delays.component.scss"],
})
export class DelaysComponent
  extends SimpleSelectionBaseComponent<DelayRuleTableItem>
  implements OnInit, AfterViewInit, OnDestroy
{
  breadcrumbItems: BreadcrumbItem[];
  dataSource: MatTableDataSource<DelayRuleTableItem> =
    new MatTableDataSource<DelayRuleTableItem>([]);
  commonAdminLabels = commonAdminLabels;
  labels = {
    DELAY_RULES: "Temporisations",
    TITLES: {
      newRule: "Ajout d'une temporisation",
      updateRule: "Mise à jour d'une temporisation",
      sfrSource: "SFR source",
      sfrRefClarify: "Référence du bien",
      host: "host",
      message: "message",
      supervisedObject: "Objet supervisé",
      supervisionDomain: "Domaine supervision",
      delayInMin: "Délai (min)",
    },
    TOOLTIPS: {
      addDelayRule: "Ajouter une temporisation",
      editDelayRule: "Mettre à jour la temporisation",
      deleteDelayRule: "Supprimer la temporisation",
      deleteSelectedDelayRules:
        "Supprimer la (ou les) temporisation(s) sélectionnée(s)",
    },
    NO_RESULTS: "Aucune temporisation !",
  };
  isEditMode: boolean;
  editModeTitle: string;

  ruleFG: FormGroup<DelayRuleForm>;
  displayedColumns = [
    "select",
    "sfrSource",
    "sfrRefClarifyName",
    "hostName",
    "message",
    "supervisionDomain",
    "supervisedObject",
    "delayInMin",
    "actions",
  ];
  @ViewChild(MatSort) sort: MatSort;

  errorMessages = constValidatorsErrorMessages;
  sfrClarifyFormInputId = "sfrClarifyFormInputId";
  hostFormInputId = "hostFormInputId";

  private _emptyAutocompleteSubFormValue: SirocoRefNameSubFormValue = {
    sirocoRefNameAuto: "",
    sirocoRef: "",
    sirocoName: "",
  };
  private _emptySubformValue: DelayRuleFormValue = {
    sfrSource: "",
    sfrRefClarify: this._emptyAutocompleteSubFormValue,
    host: this._emptyAutocompleteSubFormValue,
    message: "",
    supervisedObject: "",
    supervisionDomain: "",
  };
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _delaysService: DelaysService,
    private _route: ActivatedRoute
  ) {
    super();
  }

  ngOnInit(): void {
    this.breadcrumbItems = [
      {
        link: "/alarms",
        label: commonAdminLabels.ALARMS,
      },
      {
        label: this.labels.DELAY_RULES,
        active: true,
      },
    ];
    this.ruleFG = this._delaysService.buildDelayRuleFormGroup();
    this._delaysService.delayRules$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        startWith(this._route.snapshot.data["delayRules"]),
        switchMap((delayRules: DelayRule[]) => {
          return of(
            this._delaysService.getDelayRuleTableItemsFromDelayRules(delayRules)
          );
        }),
        tap((delayRuleTableItems: DelayRuleTableItem[]) => {
          this.selection.clear();
          this.dataSource.data = delayRuleTableItems;
          this.closeEditMode();
        })
      )
      .subscribe();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  onAutocompleteTouched(): void {
    this._markSFullfilledToCheckFieldsAsTouched();
  }

  openEditMode(rule?: DelayRuleTableItem): void {
    this.ruleFG.reset();
    this.editModeTitle = this._getEditModeTitle(rule);
    this.ruleFG.patchValue(
      rule
        ? this._delaysService.getValueToPatchFromRuleTableItem(rule)
        : this._emptySubformValue
    );
    if (rule) {
      this.ruleFG.markAllAsTouched();
    }
    this.isEditMode = true;
  }

  closeEditMode(): void {
    this.isEditMode = false;
  }

  filterByKeyword(keyword?: string): void {
    this.dataSource.filter = keyword;
  }

  saveOrUpdateDelayRule(): void {
    const valueFromRuleFG: DelayRuleFormValue = this.ruleFG.getRawValue();

    if (
      this._delaysService.isRuleAlreadyExist(
        valueFromRuleFG,
        this.dataSource.data
      )
    ) {
      return;
    }

    const correspondingRule: DelayRule =
      this._delaysService.convertFormValueToDelayRuleBeforeSave(
        valueFromRuleFG
      );

    const isUpdate = !!correspondingRule?.id;

    if (isUpdate) {
      this._delaysService
        .updateDelayRuleAndRefreshRules(correspondingRule)
        .pipe(takeUntil(this._needUnsubscribe$), take(1))
        .subscribe();
    } else {
      this._delaysService
        .addDelayRuleAndRefreshRules(correspondingRule)
        .pipe(takeUntil(this._needUnsubscribe$), take(1))
        .subscribe();
    }
  }

  deleteDelayRule(rule: DelayRuleTableItem): void {
    this._delaysService
      .deleteDelayRuleAndRefreshRules(rule)
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  deleteMultipleDelayRules(): void {
    const delayRules: DelayRuleTableItem[] = [...this.selection.selected];
    this._delaysService
      .deleteMultipleDelayRulesAndRefreshRules(delayRules)
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  private _getEditModeTitle(rule?: DelayRuleTableItem): string {
    return rule ? this.labels.TITLES.updateRule : this.labels.TITLES.newRule;
  }

  removeFirstWhiteSpaces(event: Event, formControlName: string): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.ruleFG.controls[formControlName].patchValue(value.trimStart());
    }
  }

  removeEndWhiteSpaces(event: Event, formControlName: string): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.ruleFG.controls[formControlName].patchValue(value.trimEnd());
    }
    this._markSFullfilledToCheckFieldsAsTouched();
  }

  private _markSFullfilledToCheckFieldsAsTouched(): void {
    this._delaysService.keyControlNameFullfilledToChecks.forEach(
      (keyControlName) => {
        this.ruleFG.controls[`${keyControlName}`].markAllAsTouched();
      }
    );
  }
}
