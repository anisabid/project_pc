import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/shared.module";
import { TopBarService } from "@app/shared/components/top-bar/top-bar.service";
import { RolesComponent } from "./roles/roles.component";
import { ReglesComponent } from "./regles/regles.component";
import { RightsComponent } from "./rights/rights.component";
import { ReglesService } from "./regles/regles.service";
import { RolesService } from "./roles/roles.service";
import { RightsService } from "./rights/rights.service";
import { QuickSearchInputComponent } from "./common/quick-search-input/quick-search-input.component";
import { ServicesRulesComponent } from "./services-rules/services-rules.component";
import { SimpleSubheaderComponent } from "./common/simple-subheader/simple-subheader.component";
import { ServicesRulesService } from "./services-rules/services-rules.service";
import { DelaysComponent } from "./delays/delays.component";
import { DelaysService } from "./delays/delays.service";
import { RegleFormComponent } from "./regles/regle-form/regle-form.component";
import { CanActivateModuleAdmin } from "./admin-module.guard";

const routes: Routes = [
  {
    path: "roles",
    component: RolesComponent,
    canActivate: [CanActivateModuleAdmin],
    resolve: {
      topBar: TopBarService,
      roles: RolesService,
    },
  },
  {
    path: "regles",
    component: ReglesComponent,
    canActivate: [CanActivateModuleAdmin],
    resolve: {
      topBar: TopBarService,
      regroupingRules: ReglesService,
    },
  },
  {
    path: "rights",
    component: RightsComponent,
    canActivate: [CanActivateModuleAdmin],
    resolve: {
      topBar: TopBarService,
      rightsAndRolesFromApi: RightsService,
    },
  },
  {
    path: "services",
    component: ServicesRulesComponent,
    canActivate: [CanActivateModuleAdmin],
    resolve: {
      topBar: TopBarService,
      serviceRules: ServicesRulesService,
    },
  },
  {
    path: "delays",
    component: DelaysComponent,
    canActivate: [CanActivateModuleAdmin],
    resolve: {
      topBar: TopBarService,
      delayRules: DelaysService,
    },
  },
  {
    path: "**",
    redirectTo: "./alarms/si/all",
  },
];

@NgModule({
  declarations: [
    RolesComponent,
    ReglesComponent,
    RightsComponent,
    DelaysComponent,
    QuickSearchInputComponent,
    ServicesRulesComponent,
    SimpleSubheaderComponent,
    RegleFormComponent,
  ],
  imports: [RouterModule.forChild(routes), SharedModule],
})
export class AdminModule {}
