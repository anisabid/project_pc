import { Injectable } from "@angular/core";
import { CanActivate, Router, UrlTree } from "@angular/router";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";
import { ToastrService } from "ngx-toastr";

@Injectable({ providedIn: "root" })
export class CanActivateModuleAdmin implements CanActivate {
  constructor(
    private _securityService: KeycloakSecurityService,
    private _toastrService: ToastrService,
    private _router: Router
  ) {}

  canActivate(): boolean | UrlTree {
    const hasRole = this._securityService.hasRequiredRole(IsisRole.admin);
    if (!hasRole) {
      this._toastrService.error(this._securityService.accessErrorMessage);
      return this._router.parseUrl("alarms/si/all");
    }
    return hasRole;
  }
}
