import { FormControl } from "@angular/forms";
import { CrudItem } from "../common/admin-crud-api.service";

export interface ServiceRule extends CrudItem {
  sfrSource: string;
  objetSupervise: string;
  domaineSupervision: string;
  parametre: string;
}

export interface ServiceRuleForm {
  id?: FormControl<string>;
  sfrSource: FormControl<string>;
  objetSupervise: FormControl<string>;
  domaineSupervision: FormControl<string>;
  parametre: FormControl<string>;
}
