import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { PostLogService } from "@app/shared/services/api/v2/microservices/post-log.service";
import { ToastrService } from "ngx-toastr";
import { Observable } from "rxjs";
import { AdminCrudService } from "../common/admin-crud-service";
import { ServiceRule, ServiceRuleForm } from "./services-rules.model";

@Injectable({ providedIn: "root" })
export class ServicesRulesService extends AdminCrudService<ServiceRule> {
  rules$: Observable<ServiceRule[]>;
  toasterMessages = {
    confirm: {
      delete: "La règle sera supprimée.",
      deleteMultiple: "Les règles sélectionnées seront supprimées.",
      notDeleted: "La règle n'a pas été supprimée.",
      notDeletedMultiple: "Les règles sélectionnées n'ont pas été supprimées.",
    },
    success: {
      add: "Règle enregistrée avec succès",
      update: "Règle mise à jour avec succès",
      delete: "Règle supprimée avec succès !",
      deleteMultiple: "Les règles ont été supprimées avec succès !",
    },
    error: {
      all: "Erreur lors du chargement des règles de services !",
      add: "Erreur lors de l'ajout !",
      update: "Erreur lors de la mise à jour de la règle !",
      delete: "Erreur lors de la suppression de la règle !",
      deleteMultiple: "Erreur lors de la suppression des règles !",
    },
    log: {
      add: "ajout d'une nouvelle règle de service",
      update: "mise à jour d'une règle de service",
      delete: "suppression d'une règle de service",
    },
  };

  constructor(
    protected _httpClient: HttpClient,
    protected _apiService: ApiService,
    protected _toastrService: ToastrService,
    protected _isisService: IsisService,
    protected _confirmDialogService: ConfirmDialogService,
    protected _postLogService: PostLogService
  ) {
    super(
      _httpClient,
      _apiService,
      "service-map-rules",
      _toastrService,
      _isisService,
      _confirmDialogService,
      _postLogService
    );
    this.rules$ = this.items$;
  }

  buildRuleFormGroup(): FormGroup<ServiceRuleForm> {
    return new FormGroup<ServiceRuleForm>({
      id: new FormControl<string>(null),
      sfrSource: new FormControl("", Validators.required),
      objetSupervise: new FormControl(""),
      domaineSupervision: new FormControl(""),
      parametre: new FormControl(""),
    });
  }

  addServiceRuleAndRefreshRules(rule: ServiceRule): Observable<ServiceRule[]> {
    return this.addItemAndRefreshItems(rule, { actionLog: "sfrSource" });
  }

  updateServiceRuleAndRefreshRules(
    rule: ServiceRule
  ): Observable<ServiceRule[]> {
    return this.updateItemAndRefresItems(rule, { actionLog: "sfrSource" });
  }

  deleteServiceRuleAndRefreshRules(
    rule: ServiceRule
  ): Observable<ServiceRule[]> {
    this.toasterMessages.confirm.delete = `La règle relative à ${rule.sfrSource} sera supprimée.`;
    return this.deleteItemAndRefreshItems(rule, { actionLog: "sfrSource" });
  }

  deleteMultipleServiceRulesAndRefreshRules(
    rules: ServiceRule[]
  ): Observable<ServiceRule[]> {
    return this.deleteMultipleItemsAndRefreshItems(rules, {
      actionLog: "sfrSource",
    });
  }

  isRuleAlreadyExist(
    ruleToAddOrToUpdate: ServiceRule,
    allExistingRules: ServiceRule[]
  ): boolean {
    const isRuleExist = allExistingRules?.some((rule: ServiceRule) => {
      return (
        rule.sfrSource === ruleToAddOrToUpdate.sfrSource &&
        rule.objetSupervise === ruleToAddOrToUpdate.objetSupervise &&
        rule.domaineSupervision === ruleToAddOrToUpdate.domaineSupervision &&
        rule.parametre === ruleToAddOrToUpdate.parametre
      );
    });
    if (isRuleExist) {
      this._toastrService.error("Cette règle existe déjà !");
    }
    return isRuleExist;
  }
}
