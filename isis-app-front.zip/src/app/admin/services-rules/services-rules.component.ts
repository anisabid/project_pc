import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import { Subject, startWith, take, takeUntil, tap } from "rxjs";
import { MatSort } from "@angular/material/sort";
import { ServiceRule, ServiceRuleForm } from "./services-rules.model";
import { ServicesRulesService } from "./services-rules.service";
import { MatTableDataSource } from "@angular/material/table";
import { FormGroup } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";
import { SimpleSelectionBaseComponent } from "@app/shared/components/simple-selection-base/simple-selection-base.component";
import { commonAdminLabels } from "../common/common-admin-labels";

@Component({
  selector: "app-services-rules",
  templateUrl: "./services-rules.component.html",
  styleUrls: [
    "./services-rules.component.scss",
    "../common/common-admin-style.scss",
  ],
})
export class ServicesRulesComponent
  extends SimpleSelectionBaseComponent<ServiceRule>
  implements OnInit, AfterViewInit, OnDestroy
{
  commonAdminLabels = commonAdminLabels;
  labels = {
    SERVICES: "SERVICES",
    SERVICES_RULES: "Règles d'éligibilité des alarmes",
    TITLES: {
      newRule: "Nouvelle règle",
      updateRule: "Mise à jour de la règle",
      sfrSource: "SFR source",
      supervisedObject: "Objet supervisé",
      supervisionDomain: "Domaine supervision",
      parameter: "Paramètre",
    },
    TOOLTIPS: {
      addRule: "Ajouter une règle d'éligibilité",
      editRule: "Modifier la règle d'éligibilité",
      deleteRule: "Supprimer la règle d'éligibilité",
      deleteSelectedRules: "Supprimer la (les) règle(s) sélectionnée(s)",
    },
    NO_RESULTS: "Aucune règle d'éligibilité !",
  };
  isEditMode = false;
  editModeTitle = "";
  breadcrumbItems: BreadcrumbItem[];
  dataSource: MatTableDataSource<ServiceRule> =
    new MatTableDataSource<ServiceRule>([]);
  displayedColumns = [
    "select",
    "sfrSource",
    "domaineSupervision",
    "objetSupervise",
    "parametre",
    "actions",
  ];
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  errorMessages = constValidatorsErrorMessages;
  ruleFG: FormGroup<ServiceRuleForm>;

  private _constEmptyServiceRule: ServiceRule = {
    id: null,
    sfrSource: "",
    objetSupervise: "",
    domaineSupervision: "",
    parametre: "",
  };

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _servicesRulesService: ServicesRulesService,
    private _route: ActivatedRoute
  ) {
    super();
  }

  ngOnInit(): void {
    this.breadcrumbItems = [
      {
        link: "/services/home",
        label: this.labels.SERVICES,
      },
      {
        label: this.labels.SERVICES_RULES,
        active: true,
      },
    ];
    this.editModeTitle = this._getEditModeTitle();
    this.ruleFG = this._servicesRulesService.buildRuleFormGroup();
    this._servicesRulesService.rules$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        startWith(this._route.snapshot.data["serviceRules"]),
        tap((serviceRules: ServiceRule[]) => {
          this.selection.clear();
          this.dataSource.data = serviceRules;
          this.closeEditMode();
        })
      )
      .subscribe();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  openEditMode(rule?: ServiceRule): void {
    this.ruleFG.reset();
    this.editModeTitle = this._getEditModeTitle(rule);
    this.ruleFG.patchValue(rule ? rule : this._constEmptyServiceRule);
    this.isEditMode = true;
  }

  private _getEditModeTitle(rule?: ServiceRule): string {
    return rule ? this.labels.TITLES.updateRule : this.labels.TITLES.newRule;
  }

  closeEditMode(): void {
    this.isEditMode = false;
  }

  filterBySfrSource(keyword: string): void {
    this.dataSource.filter = keyword;
  }

  saveOrUpdateRule(): void {
    const serviceRule: ServiceRule = this.ruleFG.getRawValue();

    if (
      this._servicesRulesService.isRuleAlreadyExist(
        serviceRule,
        this.dataSource.data
      )
    ) {
      return;
    }

    const isUpdate = !!serviceRule?.id;
    if (isUpdate) {
      this._servicesRulesService
        .updateServiceRuleAndRefreshRules(serviceRule)
        .pipe(takeUntil(this._needUnsubscribe$), take(1))
        .subscribe();
    } else {
      this._servicesRulesService
        .addServiceRuleAndRefreshRules(serviceRule)
        .pipe(takeUntil(this._needUnsubscribe$), take(1))
        .subscribe();
    }
  }

  deleteRule(rule: ServiceRule): void {
    this._servicesRulesService
      .deleteServiceRuleAndRefreshRules(rule)
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  deleteMultipleRules(): void {
    const rules: ServiceRule[] = [...this.selection.selected];
    this._servicesRulesService
      .deleteMultipleServiceRulesAndRefreshRules(rules)
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  removeFirstWhiteSpaces(event: Event, formControlName: string): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.ruleFG.controls[formControlName].patchValue(value.trimStart());
    }
  }

  removeEndWhiteSpaces(event: Event, formControlName: string): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.ruleFG.controls[formControlName].patchValue(value.trimEnd());
    }
  }
}
