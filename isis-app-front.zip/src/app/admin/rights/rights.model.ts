import { Role } from "../roles/roles.model";

export interface Right {
  id: string;
  name: string;
  type: string;
  roles: Array<string>;
}

export interface RightsApiResponse {
  rightsRoles: Right[];
  roles: Role[];
}
