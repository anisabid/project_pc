import { Injectable } from "@angular/core";
import { Observable, of, Subject } from "rxjs";
import { RightsApiResponse } from "./rights.model";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { catchError, map, switchMap } from "rxjs";
import { ToastrService } from "ngx-toastr";
import { ApiService } from "@app/shared/services/api/v2/api.service";

export interface RightStatus {
  idRight: string;
  idRole: string;
  status: "off" | "on";
}

@Injectable({
  providedIn: "root",
})
export class RightsService {
  private _headers: HttpHeaders;
  private _rightsApiBaseUrl: string;

  private _rightsApiResponseSubject: Subject<RightsApiResponse> = new Subject();
  rightsApiResponse$: Observable<RightsApiResponse>;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService,
    private _toastrService: ToastrService
  ) {
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
    this._rightsApiBaseUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}rights/v2`;
    this.rightsApiResponse$ = this._rightsApiResponseSubject.asObservable();
  }

  resolve(): Observable<RightsApiResponse> {
    return this._getRightsApiResponse();
  }

  private _getRightsApiResponse(): Observable<RightsApiResponse> {
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient
      .get<RightsApiResponse>(this._rightsApiBaseUrl, httpOptions)
      .pipe(
        map((response: RightsApiResponse) => {
          this._rightsApiResponseSubject.next(response);
          return response;
        }),
        catchError(() => {
          this._toastrService.error("Erreur lors du chargement des droits !");
          return [];
        })
      );
  }

  private _updateRightStatus(
    rightStatus: RightStatus
  ): Observable<RightStatus> {
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient
      .put<RightStatus>(this._rightsApiBaseUrl, rightStatus, httpOptions)
      .pipe(
        catchError(() => {
          this._toastrService.error("Erreur lors de la mise à jour du droit !");
          return of(rightStatus);
        })
      );
  }

  updateRightStatusAndRefresh(
    rightStatus: RightStatus
  ): Observable<RightsApiResponse> {
    return this._updateRightStatus(rightStatus).pipe(
      switchMap(() => {
        return this._getRightsApiResponse();
      })
    );
  }
}
