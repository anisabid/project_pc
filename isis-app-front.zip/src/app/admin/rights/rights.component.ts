import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { Subject } from "rxjs";
import { RightsService } from "./rights.service";
import { startWith, takeUntil, tap } from "rxjs";
import { Right, RightsApiResponse } from "./rights.model";
import { ActivatedRoute } from "@angular/router";
import { Role } from "../roles/roles.model";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";
import { commonAdminLabels } from "../common/common-admin-labels";

@Component({
  selector: "app-rights",
  templateUrl: "./rights.component.html",
  styleUrls: ["./rights.component.scss"],
})
export class RightsComponent implements OnInit, OnDestroy {
  breadcrumbItems: BreadcrumbItem[];
  stickyTableHeader = false;
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Right>([]);
  roles: Role[];
  commonAdminLabels = commonAdminLabels;
  labels = {
    RIGHTS: "Droits",
    RIGHT: "Droit",
    FILTER: "Filtre par droit",
  };

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _rightsService: RightsService,
    private _route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.breadcrumbItems = [
      {
        link: "/alarms",
        label: commonAdminLabels.ALARMS,
      },
      {
        label: this.labels.RIGHTS,
        active: true,
      },
    ];
    this._rightsService.rightsApiResponse$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        startWith(this._route.snapshot.data["rightsAndRolesFromApi"]),
        tap((rightsApiResponse: RightsApiResponse) => {
          this.displayedColumns = ["right"].concat(
            rightsApiResponse.roles.map((role: Role) => {
              return role.id;
            })
          );
          this.roles = rightsApiResponse.roles;
          this.dataSource.data = rightsApiResponse.rightsRoles;
        })
      )
      .subscribe();
    window.addEventListener("scroll", this.scroll, true);
  }

  ngOnDestroy(): void {
    window.removeEventListener("scroll", this.scroll, true);
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  scroll = (): void => {
    this.stickyTableHeader =
      document.getElementById("rights-table").scrollTop > 70;
  };

  filterByRightName(keyword: string): void {
    this.dataSource.filter = keyword;
  }

  updateStatus(idRight: string, idRole: string, status: "off" | "on"): void {
    this._rightsService
      .updateRightStatusAndRefresh({
        idRight,
        idRole,
        status,
      })
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe();
  }
}
