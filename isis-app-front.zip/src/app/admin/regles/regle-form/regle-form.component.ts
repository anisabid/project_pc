import {
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import { UntypedFormGroup } from "@angular/forms";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { commonAdminLabels } from "@app/admin/common/common-admin-labels";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import { Subject, take, takeUntil, tap } from "rxjs";
import { Regle } from "../regles.model";
import { ReglesService } from "../regles.service";

@Component({
  selector: "app-regle-form",
  templateUrl: "./regle-form.component.html",
  styleUrls: [
    "../../common/common-admin-style.scss",
    "./regle-form.component.scss",
  ],
})
export class RegleFormComponent implements OnInit, OnChanges, OnDestroy {
  displayForm = false;
  @Input() rule: Regle;

  sources: string[];

  adminInputs: UntypedFormGroup;

  editRulesTitle: string;
  errorFormMessages = constValidatorsErrorMessages;
  commonAdminLabels = commonAdminLabels;
  labels = {
    TITLES: {
      alarmField: "Champ d'alarme",
      ruleName: "Nom de la règle",
      createRule: "Nouvelle règle :",
      updateRule: "Mise à jour de la règle :",
    },
    RULES: {
      open: "OPEN",
      ackWithTicket: "ACK avec ticket",
      ackWithoutTicket: "ACK sans ticket",
      ackWithRefMep: " ACK avec Ref Mep",
      close: "CLOSE",
    },
    INPUTS: {
      timeInterval: "Intervalle de temps (min)",
    },
  };

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(private _reglesService: ReglesService) {}

  ngOnInit(): void {
    this.sources = this._reglesService.sources;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.rule && !changes.rule.firstChange) {
      if (!this.adminInputs) {
        this.adminInputs = this._reglesService.buildFormGroup();
      }
      const ruleToUpdate = changes.rule?.currentValue;
      const isUpdate = !!ruleToUpdate?.id;

      this.editRulesTitle = isUpdate
        ? this.labels.TITLES.updateRule
        : this.labels.TITLES.createRule;

      this.adminInputs.reset();

      if (!isUpdate) {
        this._reglesService.sources.forEach((source: string) => {
          this._disableSourceCardControls(source);
        });
      }

      if (isUpdate) {
        this.adminInputs.patchValue(ruleToUpdate);
        this._reglesService.sources.forEach((source: string) => {
          if (!this.adminInputs.controls[source]?.value) {
            this._clearSourceCardControls(source);
          } else {
            this._enableSourceCardControls(source);
          }
        });
        this.adminInputs.markAllAsTouched();
      }
      this.displayForm = true;
    }
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  closeEditMode(): void {
    this.displayForm = false;
  }

  onSourceToggle(event: MatCheckboxChange, source: string): void {
    if (!event.checked) {
      this._clearSourceCardControls(source);
    }
    if (event.checked) {
      this._enableSourceCardControls(source);
      this._selectCheckboxesByDefault(source);
    }
  }

  getErrorCheckboxClass(formControlName: string): string {
    const formControl = this.adminInputs.controls[formControlName];
    return formControl?.touched && formControl?.invalid
      ? "checkbox-custom-invalid-standard"
      : "";
  }

  atLeastOneSourceTouched(): boolean {
    return this.sources.some((source: string) => {
      return this.adminInputs.controls[source].touched;
    });
  }

  getFormControlName(source: string, formName: string): string {
    return `${source}${formName}`;
  }

  removeFirstWhiteSpaces(event: Event, formControlName: string): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      const valueToPatch =
        formControlName === "ruleName"
          ? value.trimStart().replace(/[&/\\#,+()$~%.'":*?!<>{}]/g, "")
          : value.trimStart();
      this.adminInputs.controls[formControlName].patchValue(valueToPatch);
    }
  }

  removeEndWhiteSpaces(event: Event, formControlName: string): void {
    const value = (event.target as HTMLInputElement).value as string;
    if (value?.length) {
      this.adminInputs.controls[formControlName].patchValue(value.trimEnd());
    }
  }

  validate(): void {
    const formValue = this.adminInputs.getRawValue();
    const isUpdate = !!formValue?.id;
    if (!isUpdate) {
      this._reglesService
        .addRuleAndRefreshRules(formValue)
        .pipe(
          takeUntil(this._needUnsubscribe$),
          take(1),
          tap(() => {
            this.displayForm = false;
          })
        )
        .subscribe();
    } else {
      this._reglesService
        .updateRuleAndRefreshRules(formValue)
        .pipe(
          takeUntil(this._needUnsubscribe$),
          take(1),
          tap(() => {
            this.displayForm = false;
          })
        )
        .subscribe();
    }
  }

  private _disableSourceCardControls(source: string): void {
    this.adminInputs.controls[`${source}_open`].disable();
    this.adminInputs.controls[`${source}_ack_avec_ticket`].disable();
    this.adminInputs.controls[`${source}_ack_sans_ticket`].disable();
    this.adminInputs.controls[`${source}_ack_avec_ref_mep`].disable();
    this.adminInputs.controls[`${source}_closed`].disable();
    this.adminInputs.controls[`${source}_interval_temps`].disable();
  }

  private _clearSourceCardControls(source: string): void {
    this.adminInputs.controls[`${source}_open`].reset();
    this.adminInputs.controls[`${source}_open`].disable();
    this.adminInputs.controls[`${source}_ack_avec_ticket`].reset();
    this.adminInputs.controls[`${source}_ack_avec_ticket`].disable();
    this.adminInputs.controls[`${source}_ack_sans_ticket`].reset();
    this.adminInputs.controls[`${source}_ack_sans_ticket`].disable();
    this.adminInputs.controls[`${source}_ack_avec_ref_mep`].reset();
    this.adminInputs.controls[`${source}_ack_avec_ref_mep`].disable();
    this.adminInputs.controls[`${source}_closed`].reset();
    this.adminInputs.controls[`${source}_closed`].disable();
    this.adminInputs.controls[`${source}_interval_temps`].reset();
    this.adminInputs.controls[`${source}_interval_temps`].disable();
  }

  private _enableSourceCardControls(source: string): void {
    this.adminInputs.controls[`${source}_open`].enable();
    this.adminInputs.controls[`${source}_ack_avec_ticket`].enable();
    this.adminInputs.controls[`${source}_ack_sans_ticket`].enable();
    this.adminInputs.controls[`${source}_ack_avec_ref_mep`].enable();
    this.adminInputs.controls[`${source}_closed`].enable();
    this.adminInputs.controls[`${source}_interval_temps`].enable();
  }

  private _selectCheckboxesByDefault(source: string): void {
    this.adminInputs.controls[`${source}_open`].patchValue(true);
    this.adminInputs.controls[`${source}_ack_avec_ticket`].patchValue(true);
    this.adminInputs.controls[`${source}_ack_sans_ticket`].patchValue(true);
    this.adminInputs.controls[`${source}_ack_avec_ref_mep`].patchValue(true);
  }
}
