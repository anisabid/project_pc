export interface Regle {
  id?: string;
  field_alarm: string;
  ruleName?: string;
  backup?: boolean;
  diagflux?: boolean;
  diagmetier?: boolean;
  diagmq?: boolean;
  main_courante?: boolean;
  nnmi?: boolean;
  prometheus?: boolean;
  satis?: boolean;
  shinken?: boolean;
  soa?: boolean;
  sosi?: boolean;
  uipath?: boolean;
  vtom?: boolean;
  wazup?: boolean;
  witbe_si?: boolean;
  createdAt?: string;
  maxInterval?: number;
  /*  
  example at runtime for prometheus :
  prometheus_open: boolean;
  prometheus_ack_avec_ticket: boolean;
  prometheus_ack_sans_ticket: boolean;
  prometheus_ack_avec_ref_mep: boolean;
  prometheus_closed: boolean;
  prometheus_interval_temps: number; 
  */
}

export interface RegleTableItem extends Regle {
  sources?: string; //list of source names separated by comma.
}
