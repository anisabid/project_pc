import { Injectable } from "@angular/core";
import { Observable, tap } from "rxjs";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import {
  AbstractControl,
  FormControl,
  UntypedFormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from "@angular/forms";
import { DatePipe } from "@angular/common";
import { ToastrService } from "ngx-toastr";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { Regle } from "./regles.model";
import { HttpClient } from "@angular/common/http";
import { AdminCrudService } from "../common/admin-crud-service";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { PostLogService } from "@app/shared/services/api/v2/microservices/post-log.service";

@Injectable({
  providedIn: "root",
})
export class ReglesService extends AdminCrudService<Regle> {
  rules$: Observable<Regle[]>;
  sources: string[] = [
    "backup",
    "diagflux",
    "diagmq",
    "diagmetier",
    "main_courante",
    "nnmi",
    "prometheus",
    "satis",
    "shinken",
    "soa",
    "sosi",
    "uipath",
    "vtom",
    "wazup",
    "witbe_si",
  ];

  private _allRules: Regle[];

  toasterMessages = {
    confirm: {
      delete: "La règle sera supprimée.",
      deleteMultiple: "Les règles sélectionnées seront supprimées.",
      notDeleted: "La règle n'a pas été supprimée.",
      notDeletedMultiple: "Les règles sélectionnées n'ont pas été supprimées.",
    },
    success: {
      add: "Règle enregistrée avec succès",
      update: "Règle mise à jour avec succès",
      delete: "Règle supprimée avec succès !",
      deleteMultiple: "Les règles ont été supprimées avec succès !",
    },
    error: {
      all: "Erreur lors du chargement des règles !",
      add: "Erreur lors de l'ajout !",
      update: "Erreur lors de la mise à jour de la règle !",
      delete: "Erreur lors de la suppression de la règle !",
      deleteMultiple: "Erreur lors de la suppression des règles !",
    },
    log: {
      add: "ajout d'une nouvelle règle",
      update: "mise à jour d'une règle",
      delete: "suppression d'une règle",
    },
  };

  constructor(
    protected _httpClient: HttpClient,
    protected _apiService: ApiService,
    protected _toastrService: ToastrService,
    protected _isisService: IsisService,
    protected _confirmDialogService: ConfirmDialogService,
    protected _postLogService: PostLogService,
    private _datePipe: DatePipe
  ) {
    super(
      _httpClient,
      _apiService,
      "groupingRules",
      _toastrService,
      _isisService,
      _confirmDialogService,
      _postLogService
    );
    this.rules$ = this.items$;
  }

  buildFormGroup(): UntypedFormGroup {
    const formGroup: UntypedFormGroup = new UntypedFormGroup({
      id: new FormControl<string>(null),
      field_alarm: new FormControl("", Validators.required),
      ruleName: new FormControl("", [Validators.required]),
      createdAt: new FormControl(
        this._datePipe.transform(new Date(), "yyyy-MM-ddThh:mm:ss")
      ),
    });

    this.sources.forEach((source: string) => {
      formGroup.addControl(`${source}`, new FormControl<boolean>(false));
      formGroup.addControl(`${source}_open`, new FormControl<boolean>(false));
      formGroup.addControl(
        `${source}_ack_avec_ticket`,
        new FormControl<boolean>(false)
      );
      formGroup.addControl(
        `${source}_ack_sans_ticket`,
        new FormControl<boolean>(false)
      );
      formGroup.addControl(
        `${source}_ack_avec_ref_mep`,
        new FormControl<boolean>(false)
      );
      formGroup.addControl(`${source}_closed`, new FormControl<boolean>(false));
      formGroup.addControl(
        `${source}_interval_temps`,
        new FormControl("", Validators.required)
      );
      formGroup.addValidators([this._atLeastOneStatusCheckedBySource(source)]);
    });
    formGroup.addValidators([
      this._atLeastOneSourceChecked(this.sources),
      this._ruleNameAlreadyExists(
        this._allRules,
        this._getExistingRuleNamesBeforeValidation
      ),
      this._ruleAlreadyExists(
        this.sources,
        this._allRules,
        this._getOtherRulesBeforeValidation
      ),
    ]);
    return formGroup;
  }

  addRuleAndRefreshRules(rule: Regle): Observable<Regle[]> {
    return this.addItemAndRefreshItems(rule, { actionLog: "ruleName" });
  }

  updateRuleAndRefreshRules(rule: Regle): Observable<Regle[]> {
    return this.updateItemAndRefresItems(rule, { actionLog: "ruleName" });
  }

  deleteRuleAndRefreshRules(rule: Regle): Observable<Regle[]> {
    this.toasterMessages.confirm.delete = `La règle ${rule.ruleName} sera supprimée.`;
    return this.deleteItemAndRefreshItems(rule, { actionLog: "ruleName" });
  }

  deleteMultipleRulesAndRefreshRules(rules: Regle[]): Observable<Regle[]> {
    return this.deleteMultipleItemsAndRefreshItems(rules, {
      actionLog: "ruleName",
    });
  }

  private _getExistingRuleNamesBeforeValidation = (
    allRules: Regle[],
    idRule?: string
  ): string[] => {
    const isUpdate = !!idRule;

    const retrieveAllRuleNames = (rules: Regle[]): string[] => {
      return rules.map((regle: Regle) => {
        return regle.ruleName?.toLowerCase();
      });
    };

    if (isUpdate) {
      const inValidationRuleIndex = allRules.findIndex((rule: Regle) => {
        return rule.id === idRule;
      });
      const otherRules = [...allRules];
      otherRules.splice(inValidationRuleIndex, 1);
      return retrieveAllRuleNames(otherRules);
    } else {
      return retrieveAllRuleNames(allRules);
    }
  };

  private _getOtherRulesBeforeValidation = (
    allRules: Regle[],
    idRule?: string
  ): Regle[] => {
    const isUpdate = !!idRule;
    if (isUpdate) {
      const inValidationRuleIndex = allRules.findIndex((rule: Regle) => {
        return rule.id === idRule;
      });
      const otherRules = [...allRules];
      otherRules.splice(inValidationRuleIndex, 1);
      return otherRules;
    } else {
      return allRules;
    }
  };

  private _ruleNameAlreadyExists(
    existingRules: Regle[],
    existingRuleNamesFunction: (allRules: Regle[], idRule?: string) => string[]
  ): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control) return null;
      const formGroup = <UntypedFormGroup>control;
      const idRule = formGroup.controls["id"]?.value;
      const ruleNameControl = formGroup.controls["ruleName"];

      const existingRuleNames = existingRuleNamesFunction(
        existingRules,
        idRule
      );
      const alreadyExist = existingRuleNames.includes(
        ruleNameControl?.value?.toLowerCase()
      );
      if (alreadyExist) {
        const error: ValidationErrors = {
          ruleNameAlreadyExists: {
            value: true,
            message: "Ce nom existe déjà !",
          },
        };
        ruleNameControl.setErrors(error);
        return error;
      } else {
        if (ruleNameControl.hasError("ruleNameAlreadyExists")) {
          ruleNameControl.setErrors(null);
        }
        return null;
      }
    };
  }

  private _atLeastOneStatusCheckedBySource(source: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const formGroup = <UntypedFormGroup>control;

      const isSourceChecked = formGroup.controls[source]?.value;

      if (!isSourceChecked) {
        return null;
      } else {
        const statusSuffixs = [
          "_open",
          "_ack_avec_ticket",
          "_ack_sans_ticket",
          "_ack_avec_ref_mep",
          "_closed",
        ];

        const atLeastOneStatusChecked = statusSuffixs.some((suffix: string) => {
          return formGroup.controls[`${source}${suffix}`]?.value;
        });
        if (atLeastOneStatusChecked) {
          [""].concat(statusSuffixs).forEach((suffix: string) => {
            const existingNotCheckedError =
              formGroup.controls[`${source}${suffix}`]?.errors
                ?.statusNotChecked;
            if (existingNotCheckedError) {
              formGroup.controls[`${source}${suffix}`]?.setErrors(null);
            }
          });

          return null;
        } else {
          const statusNotChecked: ValidationErrors = {
            statusNotChecked: {
              value: true,
              message: `Merci de sélectionner au moins un statut d'alarme pour la source ${source}`,
            },
          };
          const atLeastOneMarkAsTouched = statusSuffixs.some(
            (suffix: string) => {
              return formGroup.controls[`${source}${suffix}`].touched;
            }
          );

          statusSuffixs.forEach((suffix: string) => {
            formGroup.controls[`${source}${suffix}`].setErrors(
              statusNotChecked
            );

            if (atLeastOneMarkAsTouched) {
              formGroup.controls[`${source}${suffix}`].markAsTouched();
            }
          });
          formGroup.controls[source].setErrors(statusNotChecked);
          return statusNotChecked;
        }
      }
    };
  }

  private _atLeastOneSourceChecked(sources: string[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control) return null;
      const formGroup = <UntypedFormGroup>control;
      const isOneSourceChecked = sources.some((source: string) => {
        return formGroup.controls[source]?.value;
      });

      if (isOneSourceChecked) {
        const existingError = formGroup.errors?.sourceRequired;
        if (existingError) {
          formGroup.setErrors(null);
        }
        return null;
      } else {
        const error: ValidationErrors = {
          sourceRequired: {
            value: true,
            message: "Merci de sélectionner au moins une source.",
          },
        };
        formGroup.setErrors(error);
        return error;
      }
    };
  }

  private _ruleAlreadyExists(
    sources: string[],
    existingRules: Regle[],
    getOtherExistingRules: (allRules: Regle[], idRule?: string) => Regle[]
  ): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const formGroup = <UntypedFormGroup>control;
      const fieldAlarmValue = formGroup.controls["field_alarm"]?.value;
      const idRule = formGroup.controls["id"]?.value;

      const ruleAlreadyExists = getOtherExistingRules(
        existingRules,
        idRule
      ).some((rule: Regle) => {
        const allPredicates: boolean[] = sources.map((source: string) => {
          return (
            Boolean(rule[`${source}`]) ===
            Boolean(formGroup.controls[`${source}`]?.value)
          );
        });
        const haveSameSources = !allPredicates.includes(false);

        const haveSameAlarmField =
          rule.field_alarm === (fieldAlarmValue?.length ? fieldAlarmValue : "");

        return haveSameAlarmField && haveSameSources;
      });

      if (ruleAlreadyExists) {
        const error: ValidationErrors = {
          ruleAlreadyExists: {
            value: true,
            message: "Cette règle existe déjà !",
          },
        };
        formGroup.setErrors(error);
        return error;
      } else {
        if (formGroup.hasError("ruleAlreadyExists")) {
          formGroup.setErrors(null);
        }
        return null;
      }
    };
  }

  // override getAllItems
  protected _getAllItems(): Observable<Regle[]> {
    return super._getAllItems().pipe(
      tap((regles: Regle[]) => {
        this._allRules = regles;
      })
    );
  }
}
