import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Subject } from "rxjs";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { ReglesService } from "./regles.service";
import { map, startWith, take, takeUntil, tap } from "rxjs";
import { Regle, RegleTableItem } from "./regles.model";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";
import { SimpleSelectionBaseComponent } from "@app/shared/components/simple-selection-base/simple-selection-base.component";
import { commonAdminLabels } from "../common/common-admin-labels";

@Component({
  selector: "app-regles",
  templateUrl: "./regles.component.html",
  styleUrls: ["../common/common-admin-style.scss", "./regles.component.scss"],
})
export class ReglesComponent
  extends SimpleSelectionBaseComponent<RegleTableItem>
  implements OnInit, OnDestroy
{
  breadcrumbItems: BreadcrumbItem[];
  ruleForForm: Regle;

  displayedColumns: string[] = [
    "field_alarm",
    "select",
    "ruleName",
    "sources",
    "action",
  ];
  dataSource = new MatTableDataSource<RegleTableItem>([]);
  @ViewChild(MatSort) sort: MatSort;

  commonAdminLabels = commonAdminLabels;
  labels = {
    REGROUPING_RULES: "Règles de regroupement",
    TITLES: {
      alarmField: "Champ d'alarme",
      ruleName: "Nom de la règle",
      sources: "Sources",
    },
    FILTER: "Filtre par champ d'alarme",
    TOOLTIPS: {
      addRule: "Ajouter une règle de regroupement",
      removeRules: "Supprimer la ou les règle(s)",
      editRule: "Mettre à jour la règle de regroupement",
      deleteRule: "Supprimer la règle de regroupement",
    },
    NO_RESULTS: "Aucune règle de regroupement !",
  };
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _reglesService: ReglesService,
    private _route: ActivatedRoute
  ) {
    super();
  }

  ngOnInit(): void {
    this.breadcrumbItems = [
      {
        link: "/alarms",
        label: commonAdminLabels.ALARMS,
      },
      {
        label: this.labels.REGROUPING_RULES,
        active: true,
      },
    ];

    this._reglesService.rules$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        startWith(this._route.snapshot.data["regroupingRules"]),
        map((rules: Regle[]) => {
          const ruleTableItems: RegleTableItem[] = rules.map((rule: Regle) => {
            return { ...rule, sources: this._getRuleSources(rule) };
          });
          const sortedRuleTableItems = ruleTableItems.sort(
            this._sortByFieldAlarm
          );
          this.dataSource = new MatTableDataSource<RegleTableItem>(
            sortedRuleTableItems
          );
          this.dataSource.sort = this.sort;
          return rules;
        })
      )
      .subscribe();
  }

  private _sortByFieldAlarm = (
    regleA: RegleTableItem,
    regleB: RegleTableItem
  ) => {
    return regleA.field_alarm.localeCompare(regleB.field_alarm);
  };

  private _getRuleSources(rule: Regle): string {
    return this._reglesService.sources
      .filter((sourceName: string) => {
        return rule[sourceName];
      })
      .join(", ");
  }

  displayAlarmField(indexRow: number): boolean {
    const isFirstHostRow =
      indexRow === this._getIndexOfFirstElementWithAlarmField("host");
    const isFirstClarifyRow =
      indexRow ===
      this._getIndexOfFirstElementWithAlarmField("sfr_ref_clarify");
    return isFirstHostRow || isFirstClarifyRow;
  }

  isLastRowForAFieldAlarm(indexRow: number): boolean {
    const isLastRow = indexRow + 1 === this.dataSource.filteredData?.length;
    const isLastHostRow =
      indexRow ===
      this._getIndexOfFirstElementWithAlarmField("sfr_ref_clarify") - 1;
    return isLastRow || isLastHostRow;
  }

  private _getIndexOfFirstElementWithAlarmField(alarmField: string): number {
    return this.dataSource.filteredData.findIndex(
      (sortedAndFilteredRule: RegleTableItem) => {
        return sortedAndFilteredRule.field_alarm === alarmField;
      }
    );
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  filterByKeyword(keyword: string): void {
    this.dataSource.filter = keyword;
  }

  openEditMode(regle?: Regle): void {
    this.ruleForForm = { ...regle };
  }

  deleteRule(rule: Regle): void {
    this._reglesService
      .deleteRuleAndRefreshRules(rule)
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  deleteMultipleRules(): void {
    const rules: Regle[] = [...this.selection.selected];
    this._reglesService
      .deleteMultipleRulesAndRefreshRules(rules)
      .pipe(
        takeUntil(this._needUnsubscribe$),
        take(1),
        tap(() => {
          this.selection.clear();
        })
      )
      .subscribe();
  }
}
