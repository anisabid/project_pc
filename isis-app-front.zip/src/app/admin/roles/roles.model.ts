import { FormControl } from "@angular/forms";

export interface Role {
  id?: string;
  identifiant: string;
  name: string;
  createdAt: string;
}

export interface RoleForm {
  id: FormControl<string>;
  name: FormControl<string>;
  identifiant: FormControl<string>;
  createdAt: FormControl<string>;
}
