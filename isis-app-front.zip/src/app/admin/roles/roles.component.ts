import { Component, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Subject } from "rxjs";
import { MatPaginator } from "@angular/material/paginator";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { ToastrService } from "ngx-toastr";
import { RolesService } from "./roles.service";
import { map, startWith, take, takeUntil, tap } from "rxjs";
import { Role, RoleForm } from "./roles.model";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";
import { SimpleSelectionBaseComponent } from "@app/shared/components/simple-selection-base/simple-selection-base.component";
import { commonAdminLabels } from "../common/common-admin-labels";

@Component({
  selector: "app-roles",
  templateUrl: "./roles.component.html",
  styleUrls: ["./roles.component.scss", "../common/common-admin-style.scss"],
})
export class RolesComponent
  extends SimpleSelectionBaseComponent<Role>
  implements OnInit, OnDestroy
{
  breadcrumbItems: BreadcrumbItem[];
  isEditMode = false;
  editModeTitle = "";
  adminInputs: FormGroup<RoleForm>;
  private _allRoles: Role[] = [];
  commonAdminLabels = commonAdminLabels;
  labels = {
    ALARMS: "Alarmes",
    ROLES: "Rôles",
    FILTER: "Filtre par rôle",
    form: {
      TITLE: {
        newRole: "Nouveau rôle",
        updateRole: "Mise à jour du rôle",
      },
      INPUT: "Nom du rôle",
    },
    TABLE: {
      name: "Name",
    },
    actions: {
      ADD: "Ajouter un rôle",
      REMOVE: "Supprimer le(s) rôle(s) sélectionnés",
    },
  };
  displayedColumns: string[] = ["select", "name", "action"];
  dataSource = new MatTableDataSource<Role>([]);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _toastrService: ToastrService,
    private datePipe: DatePipe,
    private _route: ActivatedRoute,
    private _rolesService: RolesService
  ) {
    super();
  }

  ngOnInit(): void {
    this.breadcrumbItems = [
      {
        link: "/alarms",
        label: commonAdminLabels.ALARMS,
      },
      {
        label: this.labels.ROLES,
        active: true,
      },
    ];
    this.editModeTitle = this._getEditModeTitle();
    this.adminInputs = new FormGroup<RoleForm>({
      id: new FormControl("", Validators.required),
      name: new FormControl("", Validators.required),
      identifiant: new FormControl("", Validators.required),
      createdAt: new FormControl(
        this.datePipe.transform(new Date(), "yyyy-MM-ddThh:mm:ss")
      ),
    });

    this._rolesService.roles$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        startWith(this._route.snapshot.data["roles"]),
        map((roles: Role[]) => {
          this._allRoles = roles;
          this.dataSource.data = roles;
          this.dataSource.sort = this.sort;
          return roles;
        })
      )
      .subscribe();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  filterByRoleName(keyword: string): void {
    this.dataSource.filter = keyword;
  }

  openEditMode(role?: Role): void {
    this.adminInputs.reset();
    this.editModeTitle = this._getEditModeTitle(role);
    this.adminInputs.patchValue(
      role
        ? role
        : {
            id: null,
            name: "",
            identifiant: "",
            createdAt: this.datePipe.transform(
              new Date(),
              "yyyy-MM-ddThh:mm:ss"
            ),
          }
    );
    this.isEditMode = true;
  }

  closeEditMode(): void {
    this.isEditMode = false;
  }

  private _checkIfRoleNameExists(newRoleName: string): Role[] {
    return this._allRoles.filter((role: Role) => role.name == newRoleName);
  }

  saveOrUpdateRole(): void {
    // if( this.adminInputs.dirty && this.adminInputs.valid ){

    if (this.adminInputs.controls["name"].value === "") {
      this._toastrService.error("Le champ Nom du rôle est requis !", "Erreur");
      return;
    }

    if (
      this._checkIfRoleNameExists(this.adminInputs.controls["name"].value)
        .length > 0
    ) {
      this._toastrService.error("Ce rôle existe déjà !");
      return;
    }

    const role: Role = this.adminInputs.getRawValue();
    const isUpdate = !!role?.id;
    if (isUpdate) {
      this._rolesService
        .updateRoleAndRefreshRoles(role)
        .pipe(
          takeUntil(this._needUnsubscribe$),
          take(1),
          tap(() => {
            this.closeEditMode();
          })
        )
        .subscribe();
    } else {
      this._rolesService
        .addRoleAndRefreshRoles(role)
        .pipe(
          takeUntil(this._needUnsubscribe$),
          take(1),
          tap(() => {
            this.closeEditMode();
          })
        )
        .subscribe();
    }
  }

  deleteRole(role: Role): void {
    this._rolesService
      .deleteRoleAndRefreshRoles(role)
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe();
  }

  deleteMultipleRoles(): void {
    const roles: Role[] = [...this.selection.selected];
    this._rolesService
      .deleteMultipleRolesAndRefreshRoles(roles)
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap(() => {
          this.selection.clear();
        })
      )
      .subscribe();
  }

  private _getEditModeTitle(role?: Role): string {
    return role
      ? this.labels.form.TITLE.updateRole
      : this.labels.form.TITLE.newRole;
  }
}
