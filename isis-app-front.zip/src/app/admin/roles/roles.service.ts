import { Injectable } from "@angular/core";
import { Role } from "./roles.model";
import { AdminCrudService } from "../common/admin-crud-service";
import { ToastrService } from "ngx-toastr";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { PostLogService } from "@app/shared/services/api/v2/microservices/post-log.service";

@Injectable({
  providedIn: "root",
})
export class RolesService extends AdminCrudService<Role> {
  roles$: Observable<Role[]>;
  toasterMessages = {
    confirm: {
      delete: "Le rôle sera supprimé.",
      deleteMultiple: "Les rôles sélectionnés seront supprimés.",
      notDeleted: "Le rôle n'a pas été supprimé.",
      notDeletedMultiple: "Les rôles sélectionnés n'ont pas été supprimés.",
    },
    success: {
      add: "Rôle enregistré avec succès",
      update: "Rôle mis à jour avec succès",
      delete: "Rôle supprimé avec succès !",
      deleteMultiple: "Les rôles ont été supprimés avec succès !",
    },
    error: {
      all: "Erreur lors du chargement des rôles !",
      add: "Erreur lors de l'ajout !",
      update: "Erreur lors de la mise à jour du rôle !",
      delete: "Erreur lors de la suppression du rôle !",
      deleteMultiple: "Erreur lors de la suppression des rôles !",
    },
    log: {
      add: "ajout d'un nouveau rôle",
      update: "mise à jour d'un rôle",
      delete: "suppression d'un rôle",
    },
  };

  constructor(
    protected _httpClient: HttpClient,
    protected _apiService: ApiService,
    protected _toastrService: ToastrService,
    protected _isisService: IsisService,
    protected _confirmDialogService: ConfirmDialogService,
    protected _postLogService: PostLogService
  ) {
    super(
      _httpClient,
      _apiService,
      "roles",
      _toastrService,
      _isisService,
      _confirmDialogService,
      _postLogService
    );
    this.roles$ = this.items$;
  }

  addRoleAndRefreshRoles(role: Role): Observable<Role[]> {
    return this.addItemAndRefreshItems(role, { actionLog: "name" });
  }

  updateRoleAndRefreshRoles(role: Role): Observable<Role[]> {
    return this.updateItemAndRefresItems(role, { actionLog: "name" });
  }

  deleteRoleAndRefreshRoles(role: Role): Observable<Role[]> {
    this.toasterMessages.confirm.delete = `Le rôle ${role.name} sera supprimé.`;
    return this.deleteItemAndRefreshItems(role, {
      actionLog: "name",
      keyLog: "identifiant",
    });
  }

  deleteMultipleRolesAndRefreshRoles(roles: Role[]): Observable<Role[]> {
    return this.deleteMultipleItemsAndRefreshItems(roles, {
      actionLog: "name",
      keyLog: "identifiant",
    });
  }
}
