import { Component, Inject } from "@angular/core";
import { LocalStorageService } from "@app/shared/services/localstorage/localstorage";
import { AppConfig, APP_CONFIG } from "./app.config";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {
  constructor(
    @Inject(APP_CONFIG) config: AppConfig,
    private localStorageService: LocalStorageService
  ) {
    console.log(config.ciEnvironment);
    this.localStorageService.check();
  }
}
