import { Injectable } from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { NotifyService } from "@app/service/notify/notify.service";
import { WebsocketService } from "@app/service/notify/websocket.service";
import { ConstColorStates } from "@app/shared/consts/color-alarms";
import {
  AlarmTableItem,
  Alarm,
  SfrServiceLevelEnum,
} from "@app/shared/models/alarm";
import { IsisRole } from "@app/shared/models/user";

@Injectable({ providedIn: "root" })
export class AlarmsUtilsService {
  constructor(
    private _websocketService: WebsocketService,
    private _securityService: KeycloakSecurityService,
    private _notifyService: NotifyService
  ) {}

  isAlarmInProcessFromNotifications(alarm: Alarm): boolean {
    let isInProcess = false;
    const notifiedAlarms = this._websocketService.notifiedAlarms;

    notifiedAlarms?.forEach((notifiedAlarm: Alarm) => {
      if (notifiedAlarm._id === alarm._id) {
        alarm._source.in_progress = notifiedAlarm._source.in_progress; // TODO make this immutable
        isInProcess = notifiedAlarm._source.in_progress;
      } else {
        isInProcess = false;
      }
    });
    return isInProcess;
  }

  hasAlarmActionRights(): boolean {
    return (
      this._securityService.hasRequiredRole(IsisRole.admin) ||
      this._securityService.hasRequiredRole(IsisRole.supervisor)
    );
  }

  isAlarmClosed(alarm: Alarm): boolean {
    return alarm?.state === ConstColorStates.CLOSED.code;
  }

  getSfrServiceLevelCode(alarm: Alarm): string {
    const sfrLevelServiceFromApi = alarm.app_sfr_niveau_service
      ? alarm.app_sfr_niveau_service
      : alarm.bdd_sfr_niveau_service
      ? alarm.bdd_sfr_niveau_service
      : alarm.srv_sfr_niveau_service
      ? alarm.srv_sfr_niveau_service
      : undefined;
    return this.getKnownSfrServiceLevelEnumKey(sfrLevelServiceFromApi);
  }

  getKnownSfrServiceLevelEnumKey(sfrServiceLevelFromApi: string): string {
    const allExistingServiceLevelKeys = Object.keys(SfrServiceLevelEnum);
    const allExistingServiceLevelValues = allExistingServiceLevelKeys.map(
      (key: string) => {
        return SfrServiceLevelEnum[key];
      }
    );

    return sfrServiceLevelFromApi &&
      allExistingServiceLevelValues.includes(sfrServiceLevelFromApi)
      ? allExistingServiceLevelKeys.filter((key: string) => {
          return SfrServiceLevelEnum[key] === sfrServiceLevelFromApi;
        })[0]
      : undefined;
  }

  getAlarmIdsListString(alarms: Alarm[]): string {
    return alarms
      .map((alarm: Alarm) => {
        return alarm._id;
      })
      .toString();
  }

  sendLockInfos(alarm: Alarm): void {
    const registeredUser = this._securityService.getUser();
    this._notifyService.sendAcknowledge({
      alarm: alarm,
      user: {
        username: registeredUser.username,
        uperId: registeredUser.uperId,
      },
    });
  }

  sendUnlockInfos(alarm: Alarm): void {
    const registeredUser = this._securityService.getUser();
    this._notifyService.sendEndAcknowledge({
      alarm: alarm,
      user: {
        username: registeredUser.username,
        uperId: registeredUser.uperId,
      },
    });
  }

  getAlarmFromAlarmTableItem(alarmTableItem: AlarmTableItem): Alarm {
    const { sfrServiceLevelCode, colorDescription, appName, ...rest } =
      alarmTableItem;
    return rest as Alarm;
  }
}
