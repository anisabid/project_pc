import { Component, OnInit, OnDestroy, AfterViewInit } from "@angular/core";
import {
  merge,
  Observable,
  of,
  Subject,
  catchError,
  switchMap,
  takeUntil,
  tap,
} from "rxjs";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { AlarmsService } from "./alarms.service";
import {
  AlarmListFromApi,
  AlarmSearchCriteria,
  AlarmTableItem,
  Alarm,
  DEFAULT_ALARM_REQUESTED_PAGE_META,
} from "@app/shared/models/alarm";
import { TopBarService } from "@app/shared/components/top-bar/top-bar.service";
import { AlarmListService } from "./alarm-list/alarm-list.service";
import {
  CustomTableColumn,
  CustomTableItem,
  CustomTablePage,
  CustomTableRequestedPageMeta,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { AlarmsActionsService } from "./alarms-actions.service";
import { AlarmApiService } from "@app/shared/services/api/v2/microservices/alarm-api.service";
import { AlarmsUtilsService } from "./alarms-utils.service";

@Component({
  selector: "app-alarms",
  templateUrl: "./alarms.component.html",
})
export class AlarmsComponent implements OnInit, OnDestroy, AfterViewInit {
  selectedAlarms: Alarm[];

  isAlarmTableSelectable: boolean;
  availableAlarmTableColumns: CustomTableColumn[];
  selectedColumnRefIds: string[];
  alarmTablePage$: Observable<CustomTablePage>;

  isLoadingResults = true;
  isRateLimitReached = false;

  isRegrouping = false;
  withoutActionsForm = false;

  private _requestedPageMeta: CustomTableRequestedPageMeta;

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    public _isisService: IsisService,
    private _alarmApiService: AlarmApiService,
    public _alarmsService: AlarmsService,
    private _topBarService: TopBarService,
    private _alarmsActionsService: AlarmsActionsService,
    private _alarmListService: AlarmListService,
    private _alarmsUtilsService: AlarmsUtilsService
  ) {}

  ngOnInit(): void {
    this._requestedPageMeta = { ...DEFAULT_ALARM_REQUESTED_PAGE_META };

    this._topBarService.currentUrl$
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((url: string) => {
        this.isRegrouping = url.includes("regroupings");
        this._requestedPageMeta.page = 0;
      });

    this.isAlarmTableSelectable =
      this._alarmsUtilsService.hasAlarmActionRights();

    this.availableAlarmTableColumns =
      this._alarmListService.buildAlarmTableColumns(
        this.isRegrouping,
        this.isAlarmTableSelectable
      );

    this._alarmsService.selectedAlarmColumns$
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((selectedColumns: string[]) => {
        this.selectedColumnRefIds = selectedColumns;
      });
  }

  ngAfterViewInit(): void {
    this.alarmTablePage$ = merge(
      this._topBarService.onSelectedRegroupingsChanged().pipe(
        tap(() => {
          this._requestedPageMeta.page = 0;
        })
      ),
      this._alarmsService.onFilterFGChanged.pipe(
        tap(() => {
          this._requestedPageMeta.page = 0;
        })
      ),
      this._alarmApiService.onUpdatedAlarm$.pipe(
        tap(() => {
          this._isisService.getGroups();
        })
      ),
      this._isisService.onAlarmsRefresh
    ).pipe(
      takeUntil(this._needUnsubscribe$),
      switchMap(() => {
        this.isLoadingResults = true;
        const commonFilterPageCriteria: AlarmSearchCriteria =
          this._buildCommonFilterPageCriteria();
        const defaultFilterPageCriteria: AlarmSearchCriteria =
          this._buildDefaultFilterPageCriteria(commonFilterPageCriteria);
        const regroupingFilterPageCriteria: AlarmSearchCriteria =
          this._buildRegroupingFilterPageCriteria(commonFilterPageCriteria);
        return this._alarmApiService.getAlarmListFromApi(
          this.isRegrouping
            ? regroupingFilterPageCriteria
            : defaultFilterPageCriteria
        );
      }),
      switchMap((data: AlarmListFromApi) => {
        const alarms: Array<Alarm> = data.items;
        return of(<CustomTablePage>{
          customTableItems: this._alarmListService.buildAlarmTableItems(alarms),
          page: this._requestedPageMeta.page,
          size: this._requestedPageMeta.size,
          numberOfElements: alarms.length,
          totalElements: data.count,
        });
      }),
      tap(() => {
        this.isLoadingResults = false;
        this.isRateLimitReached = false;
      }),
      catchError(() => {
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
        return of({
          customTableItems: [],
          page: 0,
          size: this._requestedPageMeta.size,
          numberOfElements: 0,
          totalElements: 0,
        });
      })
    );
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  onRefreshAlarmsRequested(
    partialPageMeta: Partial<CustomTableRequestedPageMeta>
  ): void {
    this._requestedPageMeta = Object.assign(
      this._requestedPageMeta,
      partialPageMeta
    );
    this._alarmsActionsService.refreshAlarmsAndGroups();
  }

  onAlarmsSelectedItems(event: CustomTableItem[]): void {
    const selectedAlarmTableItems = [...event];
    this.selectedAlarms = selectedAlarmTableItems.map(
      (alarmTableItem: AlarmTableItem) => {
        return this._alarmsUtilsService.getAlarmFromAlarmTableItem(
          alarmTableItem
        );
      }
    );
  }

  private _buildCommonFilterPageCriteria(): AlarmSearchCriteria {
    return {
      ...this._requestedPageMeta,
      sgroup: this._alarmsService.sgroup,
      advancedSearchValues: this._alarmsService.getAdvancedSearchValues(),
      severityValues: this._alarmsService.getFilterSeverityValues(),
      datesValue: this._alarmsService.getFilterDatesValue(),
    };
  }

  private _buildDefaultFilterPageCriteria(
    commonFilterPageCriteria: AlarmSearchCriteria
  ): AlarmSearchCriteria {
    return {
      ...commonFilterPageCriteria,
      stateValues:
        this._alarmsService.getFilterStateValuesWithUrlStateTakenIntoAccount(),
      blackoutId: this._alarmsService.getFilterBlackoutId(),
      alarmIds: this._alarmsService.getFilterAlarmIds(),
    };
  }

  private _buildRegroupingFilterPageCriteria(
    commonFilterPageCriteria: AlarmSearchCriteria
  ): AlarmSearchCriteria {
    return {
      ...commonFilterPageCriteria,
      stateValues: this._alarmsService.getFilterStatesValues(),
      requestedRegroupings: this._topBarService.selectedRegroupings.length
        ? this._topBarService.selectedRegroupings
        : this._topBarService.availableRegroupings,
      alarmIdForGrouping: this._topBarService.alarmIdForGrouping,
    };
  }
}
