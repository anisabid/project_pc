import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from "@angular/core";
import { FormControl, FormGroup, ValidationErrors } from "@angular/forms";
import { AlarmsActionsService } from "@app/alarms/alarms-actions.service";
import { AlarmsUtilsService } from "@app/alarms/alarms-utils.service";
import { Alarm } from "@app/shared/models/alarm";
import { ErrorUtilsService } from "@app/shared/services/error/error-utils.service";
import { Subject, takeUntil, tap } from "rxjs";
import { AlarmActionForm } from "./actions-form.model";

@Component({
  selector: "app-actions-form",
  templateUrl: "./actions-form.component.html",
  styleUrls: ["./actions-form.component.scss"],
})
export class ActionsFormComponent implements OnInit, OnDestroy {
  alarmFG: FormGroup<AlarmActionForm>;
  @Input() alarms: Alarm[];
  @Input() singleAlarmMode: boolean;

  @Output() updatedAlarmsEmitter: EventEmitter<Alarm[]> = new EventEmitter();
  @Output() needCloseModalEmitter: EventEmitter<boolean> = new EventEmitter();

  actionButtonsConfig: {
    displayAcknowledgeActions: boolean;
    displayCloseAction: boolean;
  };

  labels = {
    refIncident: "Ref incident",
    refMep: "Ref MEP/Blackout",
    alarmActionInfo: "Information sur l'alarme",
    errors: {
      refIncidentRequired: "Merci de saisir une Ref Incident",
      refMepRequired: "Merci de saisir une Ref MEP",
    },
    actions: {
      acknowledgeWithTicket: "Acquitter avec ticket",
      acknowledgeWithoutTicket: "Acquitter sans ticket",
      createNewTicket: "Créer nouveau ticket",
      acknowledgeWithMep: "Acquitter avec MEP",
      closeAlarm: "Fermer l'alarme",
    },
  };

  private _requiredFieldTimerId = {
    sfrRefMep: null,
    sfrRefIncident: null,
  };
  private _timerRequiredFieldDelayInMillisec = 5000;

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _alarmsUtilsService: AlarmsUtilsService,
    private _alarmsActionsService: AlarmsActionsService,
    private _errorUtilsService: ErrorUtilsService
  ) {}

  ngOnInit(): void {
    const isAdminOrSupervisor = this._alarmsUtilsService.hasAlarmActionRights();
    this.actionButtonsConfig = {
      displayAcknowledgeActions: isAdminOrSupervisor,
      displayCloseAction: isAdminOrSupervisor,
    };

    this.alarmFG = new FormGroup<AlarmActionForm>({
      sfrRefIncident: new FormControl(
        this.alarms.length === 1 ? this.alarms[0].sfr_ref_incident : ""
      ),
      sfrRefMep: new FormControl(
        this.alarms.length === 1 ? this.alarms[0].sfr_ref_mep : ""
      ),
      actionInformation: new FormControl(""),
    });

    this.alarmFG.markAllAsTouched();

    if (!this.actionButtonsConfig.displayAcknowledgeActions) {
      this.alarmFG.disable();
    }

    this.alarmFG
      .get(["sfrRefIncident"])
      .valueChanges.subscribe((result: string) => {
        if (result?.trim()) {
          this._clearErrorField("sfrRefIncident");
          this._clearFieldTimerId("sfrRefIncident");
        }
      });

    this.alarmFG.get(["sfrRefMep"]).valueChanges.subscribe((result: string) => {
      if (result?.trim()) {
        this._clearErrorField("sfrRefMep");
        this._clearFieldTimerId("sfrRefMep");
      }
    });
  }

  ngOnDestroy(): void {
    this._clearFieldTimerId("sfrRefIncident");
    this._clearFieldTimerId("sfrRefMep");
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  acknowledgeWithTicket(): void {
    const information = this.alarmFG.get(["actionInformation"]).value;
    const sfrRefIncident = this.alarmFG.get(["sfrRefIncident"]).value;
    this._clearBothErrorFieldAndTimeId("sfrRefMep");
    this._clearFieldTimerId("sfrRefIncident");

    if (!sfrRefIncident || sfrRefIncident.trim() === "") {
      this._setRefFieldError("sfrRefIncident");
      this._requiredFieldTimerId.sfrRefIncident =
        this._startRefFieldTimerId("sfrRefIncident");
    } else {
      this._clearErrorField("sfrRefIncident");
      this._alarmsActionsService
        .acknowledgeWithTicket(
          this.alarms,
          sfrRefIncident,
          information,
          this.singleAlarmMode
        )
        .pipe(
          takeUntil(this._needUnsubscribe$),
          tap((updatedAlarms: Alarm[]) => {
            this.updatedAlarmsEmitter.emit(updatedAlarms);
            this.needCloseModalEmitter.emit(true);
          })
        )
        .subscribe({
          next: () => {
            // do nothing
          },
          error: (error) => {
            this._errorUtilsService.manageThrowedError(error);
          },
          complete: () => {
            // do nothing
          },
        });
    }
  }

  acknowledgeWithoutTicket(): void {
    this._clearBothErrorFieldAndTimeId("sfrRefIncident");
    this._clearBothErrorFieldAndTimeId("sfrRefMep");
    const information = this.alarmFG.get(["actionInformation"]).value;

    this._alarmsActionsService
      .acknowledgeWithoutTicket(this.alarms, information, this.singleAlarmMode)
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap((updatedAlarms: Alarm[]) => {
          this.updatedAlarmsEmitter.emit(updatedAlarms);
          this.needCloseModalEmitter.emit(true);
        })
      )
      .subscribe({
        next: () => {
          // do nothing
        },
        error: (error) => {
          this._errorUtilsService.manageThrowedError(error);
        },
        complete: () => {
          // do nothing
        },
      });
  }

  createNewTicket(): void {
    this._clearBothErrorFieldAndTimeId("sfrRefIncident");
    this._clearBothErrorFieldAndTimeId("sfrRefMep");

    const information = this.alarmFG.get(["actionInformation"]).value;
    this._alarmsActionsService
      .createNewTicket(this.alarms, information, this.singleAlarmMode)
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap((updatedAlarms: Alarm[]) => {
          this.updatedAlarmsEmitter.emit(updatedAlarms);
          this.needCloseModalEmitter.emit(true);
        })
      )
      .subscribe({
        next: () => {
          // do nothing
        },
        error: (error) => {
          this._errorUtilsService.manageThrowedError(error);
        },
        complete: () => {
          // do nothing
        },
      });
  }

  acknowledgeWithMep(): void {
    this._clearFieldTimerId("sfrRefMep");
    this._clearBothErrorFieldAndTimeId("sfrRefIncident");
    const sfrRefMep = this.alarmFG.get(["sfrRefMep"]).value;
    const information = this.alarmFG.get(["actionInformation"]).value;

    if (!sfrRefMep || sfrRefMep.trim() === "") {
      this._setRefFieldError("sfrRefMep");
      this._requiredFieldTimerId.sfrRefMep =
        this._startRefFieldTimerId("sfrRefMep");
    } else {
      this._clearErrorField("sfrRefMep");
      this._alarmsActionsService
        .acknowledgeWithMep(
          this.alarms,
          sfrRefMep,
          information,
          this.singleAlarmMode
        )
        .pipe(
          takeUntil(this._needUnsubscribe$),
          tap((updatedAlarms: Alarm[]) => {
            this.updatedAlarmsEmitter.emit(updatedAlarms);
            this.needCloseModalEmitter.emit(true);
          })
        )
        .subscribe({
          next: () => {
            // do nothing
          },
          error: (error) => {
            this._errorUtilsService.manageThrowedError(error);
          },
          complete: () => {
            // do nothing
          },
        });
    }
  }

  closeAlarm(): void {
    this._clearBothErrorFieldAndTimeId("sfrRefIncident");
    this._clearBothErrorFieldAndTimeId("sfrRefMep");
    const information = this.alarmFG.get(["actionInformation"]).value;

    this._alarmsActionsService
      .closeLockedAlarms(this.alarms, information, this.singleAlarmMode)
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap((updatedAlarms: Alarm[]) => {
          this.updatedAlarmsEmitter.emit(updatedAlarms);
          this.needCloseModalEmitter.emit(true);
        })
      )
      .subscribe({
        next: () => {
          // do nothing
        },
        error: (error) => {
          this._errorUtilsService.manageThrowedError(error);
        },
        complete: () => {
          // do nothing
        },
      });
  }

  private _clearErrorField(fieldName: "sfrRefMep" | "sfrRefIncident"): void {
    this.alarmFG.get([`${fieldName}`]).setErrors(null);
  }

  private _clearFieldTimerId(fieldName: "sfrRefMep" | "sfrRefIncident"): void {
    if (
      this._requiredFieldTimerId &&
      this._requiredFieldTimerId[`${fieldName}`]
    ) {
      clearTimeout(this._requiredFieldTimerId[`${fieldName}`]);
    }
  }

  private _clearBothErrorFieldAndTimeId(
    fieldName: "sfrRefMep" | "sfrRefIncident"
  ): void {
    this._clearErrorField(fieldName);
    this._clearFieldTimerId(fieldName);
  }

  private _startRefFieldTimerId(
    fieldName: "sfrRefMep" | "sfrRefIncident"
  ): any {
    return setTimeout(() => {
      this.alarmFG.get([`${fieldName}`]).setErrors(null);
    }, this._timerRequiredFieldDelayInMillisec);
  }

  private _setRefFieldError(fieldName: "sfrRefMep" | "sfrRefIncident"): void {
    const error: ValidationErrors = {
      requiredField: {
        message:
          fieldName === "sfrRefMep"
            ? this.labels.errors.refMepRequired
            : this.labels.errors.refIncidentRequired,
      },
    };
    this.alarmFG.controls[`${fieldName}`].setErrors(error);
  }
}
