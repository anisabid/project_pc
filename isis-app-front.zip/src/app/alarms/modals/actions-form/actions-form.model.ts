import { FormControl } from "@angular/forms";

export interface AlarmActionForm {
  sfrRefIncident: FormControl<string>;
  sfrRefMep: FormControl<string>;
  actionInformation: FormControl<string>;
}
