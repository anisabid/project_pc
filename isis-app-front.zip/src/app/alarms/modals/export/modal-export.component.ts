import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { ExportService } from "@app/shared/services/export/export.service";

@Component({
  selector: "app-modal-export",
  templateUrl: "./modal-export.component.html",
  styleUrls: ["./modal-export.component.scss"],
})
export class ModalExportComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ModalExportComponent>,
    private _exportService: ExportService
  ) {}

  exportCSV(): void {
    this._exportService.downloadFile(this.data.selectedItems, "csv");
  }

  exportText(): void {
    this._exportService.downloadFile(this.data.selectedItems, "text");
  }
}
