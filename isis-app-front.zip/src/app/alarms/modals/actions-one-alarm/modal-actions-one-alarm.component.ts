import {
  AfterViewInit,
  Component,
  Inject,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { AlarmsActionsService } from "@app/alarms/alarms-actions.service";
import { AlarmsUtilsService } from "@app/alarms/alarms-utils.service";
import { AlarmsService } from "@app/alarms/alarms.service";
import { ConstColorPriorities } from "@app/shared/consts/color-alarms";
import { Alarm } from "@app/shared/models/alarm";
import { EnvironmentService } from "@app/shared/services/environment/environment.service";

@Component({
  selector: "app-modal-actions-one-alarm",
  templateUrl: "./modal-actions-one-alarm.component.html",
  styleUrls: ["./modal-actions-one-alarm.component.scss"],
})
export class ModalActionsOneAlarmComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  singleAlarmMode = true;
  defaultMaxOperations: number;
  showOperations: number;
  propertiesNames: string[];
  hasActionRights: boolean;
  alarmWhenModalOpen: Alarm;
  isAlarmAlreadyProcessing: boolean;
  isAlarmClosed: boolean;
  alarmProcessingMessage: string;
  isActionsEnabled: boolean;
  withoutActionsForm: boolean;
  sfrServiceLevelCode: string;
  constColorPriorities = ConstColorPriorities;
  labels = {
    grafanaDashboard: "Grafana dashboard",
    details: {
      title: "Détails de l'alarme",
    },
    actions: {
      title: "Acquittement",
    },
    closeModal: "Fermer la fenêtre",
    key: "key : ",
    message: "message : ",
    ticketMessage: "ticket_message : ",
    extraDefinitions: "extra_Definitions : ",
    sfrOperations: {
      title: "Historique d'opérations sur l'alarme",
      number: "#",
      timestamp: "Date et heure",
      refIncident: "REF incident",
      refMep: "REF MEP/Blackout",
      action: "Action",
      user: "User",
      message: "Message",
      displayMore: "Afficher plus d'opérations",
      displayLess: "Afficher moins d'opérations",
    },
  };
  updatedAlarm: Alarm;
  private _timerIdForClose = null;
  private _timeOutBeforeScroll = null;

  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { alarm: Alarm; withoutActionsForm: boolean },
    public dialogRef: MatDialogRef<ModalActionsOneAlarmComponent>,
    public alarmsService: AlarmsService,
    private _alarmsUtilsService: AlarmsUtilsService,
    private _alarmsActionsService: AlarmsActionsService,
    private _environmentService: EnvironmentService
  ) {}

  ngOnInit(): void {
    this.alarmWhenModalOpen = this.data.alarm;
    this.withoutActionsForm = this.data.withoutActionsForm;
    this.sfrServiceLevelCode = this._alarmsUtilsService.getSfrServiceLevelCode(
      this.alarmWhenModalOpen
    );
    this.isAlarmAlreadyProcessing =
      this._alarmsUtilsService.isAlarmInProcessFromNotifications(
        this.alarmWhenModalOpen
      ) || this.alarmWhenModalOpen._source?.in_progress;
    this.hasActionRights = this._alarmsUtilsService.hasAlarmActionRights();
    this.isAlarmClosed = this._alarmsUtilsService.isAlarmClosed(
      this.alarmWhenModalOpen
    );
    this.isActionsEnabled =
      !this.withoutActionsForm &&
      !this.isAlarmClosed &&
      this.hasActionRights &&
      !this.isAlarmAlreadyProcessing;
    this.updatedAlarm = this.alarmWhenModalOpen;

    if (this.isActionsEnabled) {
      this.alarmsService.timer = this.alarmsService.convertSecondsInMinutes(
        this._environmentService.config.alarms__lock__timer_loop
      );
    } else {
      //do nothing
    }

    this.defaultMaxOperations = 4;
    this.showOperations =
      this.alarmWhenModalOpen.sfr_operations.length > this.defaultMaxOperations
        ? this.defaultMaxOperations
        : this.alarmWhenModalOpen.sfr_operations.length;
    this.propertiesNames = this._getPropertiesNames();
  }

  ngAfterViewInit(): void {
    if (this.isActionsEnabled) {
      this.dialogRef.afterOpened().subscribe(() => {
        //Display timer
        this.alarmsService.startTimer();
        // End locking alarm and close modal after 5mn
        this._timerIdForClose = setTimeout(() => {
          this.closeModal();
        }, this._environmentService.config.alarms__lock__timer_loop * 1000);
      });
    } else {
      // do nothing
    }
  }

  ngOnDestroy(): void {
    if (this._timeOutBeforeScroll) {
      clearTimeout(this._timeOutBeforeScroll);
    }
    if (this.isActionsEnabled) {
      this.dialogRef.afterClosed().subscribe(() => {
        this._alarmsUtilsService.sendUnlockInfos(this.updatedAlarm);
      });
      if (this._timerIdForClose) {
        clearTimeout(this._timerIdForClose);
      }
      this.alarmsService.resetTimer();
    } else {
      // do nothing
    }
  }

  updateCurrentAlarm(updatedEmittedAlarms: Alarm[]): void {
    this.updatedAlarm = updatedEmittedAlarms[0];
  }

  closeModal(): void {
    this.dialogRef.close();
  }

  showMore(): void {
    this.showOperations = this.alarmWhenModalOpen.sfr_operations.length;
    this._scrollDown();
  }

  private _scrollDown(): void {
    if (this._timeOutBeforeScroll) {
      clearTimeout(this._timeOutBeforeScroll);
    }
    this._timeOutBeforeScroll = setTimeout(() => {
      const scrollingContainer = document.getElementById(
        "modal-actions-one-alarm__scrolling-container-id"
      );
      if (scrollingContainer) {
        scrollingContainer.scrollBy({
          top: scrollingContainer.scrollHeight,
          left: 0,
          behavior: "smooth",
        });
      }
    }, 0);
  }

  showLess(): void {
    this.showOperations = this.defaultMaxOperations;
  }

  navigateToRegrouping(
    sfrRegroupements: string[],
    alarmIdForGrouping: string
  ): void {
    this._alarmsActionsService.navigateToRegrouping(
      sfrRegroupements,
      alarmIdForGrouping
    );
    this.closeModal();
  }

  navigateToKnownErrors(alarmKey: string): void {
    this._alarmsActionsService.navigateToKnownErrors(alarmKey);
    this.closeModal();
  }

  private _getPropertiesNames(): string[] {
    const excludedColumnNames: string[] = [
      "message",
      "_id",
      "sfr_operations",
      "occurrences",
      "_source",
      "key",
      "extra_definitions",
      "ticket_message",
      "blackouts",
      "state",
      "severite",
      "sfr_url_consigne",
      "priority",
    ];
    return Object.getOwnPropertyNames(this.alarmWhenModalOpen).filter(
      (property: string) => {
        return !excludedColumnNames.includes(property);
      }
    );
  }

  getValueFromPropertyName(attribute: string): string {
    return this.alarmWhenModalOpen[attribute];
  }

  isTimeProperty(property: string): boolean {
    const timeProperties: string[] = [
      "origin_time",
      "last_arrival_time",
      "last_origin_time",
      "arrival_time",
      "expiration_time",
      "sfr_ack_date",
      "sfr_visu_date",
      "sfr_closed_date",
    ];
    return timeProperties.includes(property);
  }

  getAlarmProcessingMessage(alarmInProgress: Alarm): string {
    return !alarmInProgress._source.user?.username
      ? "Alarme en cours de traitement !"
      : `Alarme en cours de traitement par ${alarmInProgress._source.user.username}`;
  }
}
