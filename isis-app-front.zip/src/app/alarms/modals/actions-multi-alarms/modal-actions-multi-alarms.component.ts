import {
  AfterViewInit,
  Component,
  Inject,
  OnDestroy,
  OnInit,
} from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { AlarmsUtilsService } from "@app/alarms/alarms-utils.service";
import { AlarmsService } from "@app/alarms/alarms.service";
import { Alarm } from "@app/shared/models/alarm";
import { EnvironmentService } from "@app/shared/services/environment/environment.service";

@Component({
  selector: "app-modal-actions-multi-alarms",
  templateUrl: "./modal-actions-multi-alarms.component.html",
  styleUrls: ["./modal-actions-multi-alarms.component.scss"],
})
export class ModalActionsMultiAlarmsComponent
  implements OnInit, AfterViewInit, OnDestroy
{
  singleAlarmMode = false;
  selectedAlarms: Alarm[];
  updatedAlarms: Alarm[];

  labels = {
    title: "Actions",
    closeModal: "Fermer la fenêtre",
  };

  private _timerIdForClose = null;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { selectedItems: Alarm[] },
    public dialogRef: MatDialogRef<ModalActionsMultiAlarmsComponent>,
    public alarmsService: AlarmsService,
    private _environmentService: EnvironmentService,
    private _alarmsUtilsService: AlarmsUtilsService
  ) {}

  ngOnInit(): void {
    this.selectedAlarms = this.data.selectedItems;
    this.updatedAlarms = this.selectedAlarms;

    this.alarmsService.timer = this.alarmsService.convertSecondsInMinutes(
      this._environmentService.config.alarms__lock__timer_loop
    );
  }

  ngAfterViewInit(): void {
    this.dialogRef.afterOpened().subscribe(() => {
      //Display timer
      this.alarmsService.startTimer();
      // End locking alarm and close modal after 5mn
      this._timerIdForClose = setTimeout(() => {
        this.closeModal();
      }, this._environmentService.config.alarms__lock__timer_loop * 1000);
    });
  }

  ngOnDestroy(): void {
    this.dialogRef.afterClosed().subscribe(() => {
      this.updatedAlarms.forEach((updatedAlarm: Alarm) => {
        this._alarmsUtilsService.sendUnlockInfos(updatedAlarm);
      });
    });
    if (this._timerIdForClose) {
      clearTimeout(this._timerIdForClose);
    }
    this.alarmsService.resetTimer();
  }

  updateCurrentAlarms(updatedEmittedAlarms: Alarm[]): void {
    this.updatedAlarms = updatedEmittedAlarms;
  }

  closeModal(): void {
    this.dialogRef.close();
  }
}
