import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
} from "@angular/core";
import {
  CustomMultiSelectMenuConfig,
  CustomMultiSelectMenuTheme,
} from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import { CustomTableColumn } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { BreadcrumbItem } from "@app/shared/components/simple-breadcrumb/simple-breadcrumb.component";

@Component({
  selector: "app-alarm-known-errors-subheader",
  templateUrl: "./alarm-known-errors-subheader.component.html",
  styleUrls: ["./alarm-known-errors-subheader.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AlarmKnownErrorsSubheaderComponent implements OnInit {
  breadcrumbItems: BreadcrumbItem[];
  labels = {
    ALARMS: "Alarmes",
    KNOWN_ERRORS: "Erreurs connues",
  };
  columnMultiSelectMenuConfig: CustomMultiSelectMenuConfig;

  @Input() alarmKey: string;
  @Input() columnMultiSelectItems: CustomTableColumn[];
  @Output() requestedUpdateDisplayedColumnsEmitter: EventEmitter<string[]> =
    new EventEmitter();

  ngOnInit(): void {
    this._initBreadCrumbs();
    this._initColumnMultiSelectConfig();
  }

  onSelectedColumns(selectedColumns: string[]): void {
    this.requestedUpdateDisplayedColumnsEmitter.emit(selectedColumns);
  }

  private _initBreadCrumbs(): void {
    this.breadcrumbItems = [
      {
        link: "/alarms",
        label: this.labels.ALARMS,
      },
      {
        label: `${this.labels.KNOWN_ERRORS} : `,
        active: true,
      },
    ];
  }

  // to check it could be put in commons (customselectableBaseService par exempel)
  private _initColumnMultiSelectConfig(): void {
    this.columnMultiSelectMenuConfig = {
      isMenuTriggeredByIconButton: true,
      triggerButtonNameOrLabel: "view_column",
      triggerButtonTooltip: "Sélectionner les colonnes",
      withApplyButton: false,
      withSelectAllButton: false,
      theme: CustomMultiSelectMenuTheme.SMALL_BLACK,
    };
  }
}
