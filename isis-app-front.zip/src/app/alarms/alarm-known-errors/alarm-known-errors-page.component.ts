import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, ParamMap } from "@angular/router";
import { CustomMenuSelectItem } from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import {
  CustomTableColumn,
  CustomTablePage,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { CustomSelectableTableBaseService } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.service";
import { ToastrService } from "ngx-toastr";
import { catchError, map, Observable, of, switchMap, tap } from "rxjs";
import { AlarmListService } from "../alarm-list/alarm-list.service";
import { AlarmKnownErrorsService } from "./alarm-known-errors.service";

@Component({
  selector: "app-alarm-known-errors-page",
  templateUrl: "./alarm-known-errors-page.component.html",
})
export class AlarmKnownErrorsPageComponent implements OnInit {
  alarmKey$: Observable<string>;
  relatedAlarmTablePage$: Observable<CustomTablePage>;
  relatedAlarmTableColumns: CustomTableColumn[];
  selectedColumnRefIds: string[];
  columnMultiSelectItems: CustomMenuSelectItem[];
  isLoadingResults = true;
  isRateLimitReached = false;
  isRelatedAlarmTableSelectable = false;
  isRegrouping = false;
  withoutActionsForm = true;
  withoutPagination = false;
  withAutomaticPagination = true;
  withAutomaticSorting = true;

  constructor(
    private _route: ActivatedRoute,
    private _alarmKnownErrorsService: AlarmKnownErrorsService,
    private _alarmListService: AlarmListService,
    private _customSelectableTableBaseService: CustomSelectableTableBaseService,
    private _toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this._initAsyncData();
    this._initCommon();
    this._initList();
    this._initSubheader();
  }

  private _initAsyncData(): void {
    this.alarmKey$ = this._route.queryParamMap.pipe(
      map((params: ParamMap) => params.get("key"))
    );
    this.relatedAlarmTablePage$ = this.alarmKey$.pipe(
      switchMap((key: string) => {
        this.isLoadingResults = true;
        return this._alarmKnownErrorsService.getAlarmPageWithArchivesByKey(key);
      }),
      tap(() => {
        this.isLoadingResults = false;
      }),
      catchError(() => {
        this.isLoadingResults = false;
        this._toastrService.error("Une erreur est survenue !");
        return of({
          customTableItems: [],
        });
      })
    );
  }

  private _initCommon(): void {
    this.relatedAlarmTableColumns = this._alarmListService
      .buildMinimalAlarmTableColumns(false)
      .map((column: CustomTableColumn) => {
        return { ...column, isSortable: true };
      });
  }

  private _initSubheader(): void {
    this.columnMultiSelectItems =
      this._customSelectableTableBaseService.initAvailableColumnSelectItems(
        this.relatedAlarmTableColumns,
        "columns_alarms_known_errors"
      );
  }

  private _initList(): void {
    this.selectedColumnRefIds =
      this._customSelectableTableBaseService.getSelectedColumnsFromStorage(
        "columns_alarms_known_errors"
      );
  }

  updateDisplayedColumns(columnRefIdToDisplays: string[]): void {
    this.selectedColumnRefIds = columnRefIdToDisplays;
    this._customSelectableTableBaseService.updateSelectedColumnsIntoLocalStorage(
      columnRefIdToDisplays,
      "columns_alarms_known_errors"
    );
  }
}
