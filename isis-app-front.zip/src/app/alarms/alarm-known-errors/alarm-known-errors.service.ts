import { Injectable } from "@angular/core";
import { CustomTablePage } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { Alarm } from "@app/shared/models/alarm";
import { AlarmApiService } from "@app/shared/services/api/v2/microservices/alarm-api.service";
import { Observable, of, switchMap } from "rxjs";
import { AlarmListService } from "../alarm-list/alarm-list.service";

@Injectable({ providedIn: "root" })
export class AlarmKnownErrorsService {
  constructor(
    private _alarmApiService: AlarmApiService,
    private _alarmListService: AlarmListService
  ) {}

  getAlarmPageWithArchivesByKey(key: string): Observable<CustomTablePage> {
    return this._alarmApiService
      .getAlarmsByKeyIncludingArchivedAlarms(key)
      .pipe(
        switchMap((alarms: Alarm[]) => {
          return of(this.convertToAlarmPage(alarms));
        })
      );
  }

  convertToAlarmPage(alarms: Alarm[]): CustomTablePage {
    return <CustomTablePage>{
      customTableItems: this._alarmListService.buildAlarmTableItems(alarms),
    };
  }
}
