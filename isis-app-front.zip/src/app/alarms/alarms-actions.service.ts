import { Injectable } from "@angular/core";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import {
  ActionInfoLabelEnum,
  Alarm,
  AlarmActionInfo,
  AlarmActionParametersToUpdate,
  AlarmSfrOperation,
} from "@app/shared/models/alarm";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { ToastrService } from "ngx-toastr";
import { ModalExportComponent } from "./modals/export/modal-export.component";
import { ModalActionsMultiAlarmsComponent } from "./modals/actions-multi-alarms/modal-actions-multi-alarms.component";
import { ModalActionsOneAlarmComponent } from "./modals/actions-one-alarm/modal-actions-one-alarm.component";
import { Router } from "@angular/router";
import { from, Observable, of, throwError, catchError, switchMap } from "rxjs";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { ConstColorStates } from "@app/shared/consts/color-alarms";
import { IsisError } from "@app/shared/models/error";
import { AlarmsUtilsService } from "./alarms-utils.service";
import { AlarmApiService } from "@app/shared/services/api/v2/microservices/alarm-api.service";
import {
  ClarifyApiService,
  ClarifyPayload,
  ClarifyResponse,
} from "@app/shared/services/api/v2/microservices/clarify-api.service";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { PostLogService } from "@app/shared/services/api/v2/microservices/post-log.service";
import { WebsocketService } from "@app/service/notify/websocket.service";

interface ParametersToUpdate {
  state: string;
  sfr_ack_date?: number;
  sfr_ack_user?: string;
  sfr_ref_incident?: string;
  sfr_ref_mep?: string;
  sfr_closed_date?: number;
  sfr_closed_user?: string;
  sfr_operations?: AlarmSfrOperation[];
}

@Injectable({ providedIn: "root" })
export class AlarmsActionsService {
  constructor(
    private _isisService: IsisService,
    private _clarifyApiService: ClarifyApiService,
    private _matDialog: MatDialog,
    private _toastrService: ToastrService,
    private _websocketService: WebsocketService,
    private _alarmsUtilsService: AlarmsUtilsService,
    private _alarmApiService: AlarmApiService,
    private _router: Router,
    private _confirmDialogService: ConfirmDialogService,
    private _securityService: KeycloakSecurityService,
    private _postLogService: PostLogService
  ) {}

  refreshAlarmsAndGroups(): void {
    this._isisService.getGroups();
    this._isisService.onAlarmsRefresh.next(true);
  }

  refreshAlarms(): void {
    this._isisService.onAlarmsRefresh.next(true);
  }

  openAlarmDetailModal(alarm: Alarm, withoutActionsForm: boolean): void {
    const hasActionRights = this._alarmsUtilsService.hasAlarmActionRights();
    const isAlarmClosed = this._alarmsUtilsService.isAlarmClosed(alarm);

    if (hasActionRights && !isAlarmClosed && !withoutActionsForm) {
      this._isisService.checkAlarmInprogress(alarm._id).then((res) => {
        if (!res.anymatchlock) {
          this._alarmsUtilsService.sendLockInfos(alarm);
        }
        this._openAlarmDetailModal(alarm, withoutActionsForm);
      });
    } else {
      this._openAlarmDetailModal(alarm, withoutActionsForm);
    }
  }

  private _openAlarmDetailModal(
    alarm: Alarm,
    withoutActionsForm: boolean
  ): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = "modal-alarm-detail";
    dialogConfig.autoFocus = false;
    dialogConfig.data = {
      alarm,
      withoutActionsForm,
    };
    this._matDialog.open(ModalActionsOneAlarmComponent, dialogConfig);
  }

  openExportModal(selectedAlarms: Alarm[]): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = "modal-alarms-export";
    dialogConfig.data = {
      selectedItems: selectedAlarms,
    };
    this._matDialog.open(ModalExportComponent, dialogConfig);
  }

  openActionsForSelectedAlarmsModal(selectedAlarms: Alarm[]): void {
    const selectedAlarmsWhenModalOpen = [...selectedAlarms];
    const ids = this._alarmsUtilsService.getAlarmIdsListString(
      selectedAlarmsWhenModalOpen
    );
    this._isisService.checkAlarmInprogress(ids).then((res) => {
      if (res.anymatchlock) {
        this._toastrService.warning(
          "Au moins une des alarmes sélectionnées est déjà en cours de traitement !"
        );
      } else {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = {
          selectedItems: selectedAlarmsWhenModalOpen,
        };
        selectedAlarmsWhenModalOpen.forEach((selectedAlarm) => {
          this._alarmsUtilsService.sendLockInfos(selectedAlarm);
        });
        dialogConfig.autoFocus = false;
        this._matDialog.open(ModalActionsMultiAlarmsComponent, dialogConfig);
      }
    });
  }

  openLockInfos(alarm: Alarm): void {
    // check first in alarm self (case alarm's locked info comes from api rest)
    if (alarm._source?.in_progress && alarm._source?.user) {
      this._toastrService.warning(
        `Alarme en cours de traitement par ${alarm._source?.user?.username}`
      );
      return;
    }

    // if false check then in notifiedAlarms (case alarm's locked info comes from websocket)
    const notifiedAlarms = this._websocketService.notifiedAlarms;

    const lockedNotifiedAlarms = notifiedAlarms.filter(
      (lockedAlarm: Alarm) =>
        lockedAlarm?._id === alarm._id && lockedAlarm?._source?.in_progress
    ); // normally length 1

    const lockedAlarm =
      lockedNotifiedAlarms.length >= 2
        ? lockedNotifiedAlarms[lockedNotifiedAlarms.length - 1]
        : lockedNotifiedAlarms[0];

    this._toastrService.warning(
      `Alarme en cours de traitement par ${lockedAlarm._source?.user?.username}`
    );
  }

  navigateToRegrouping(
    sfrRegroupements: string[],
    alarmIdForGrouping: string
  ): void {
    if (sfrRegroupements?.length) {
      this._router.navigate(["/alarms/regroupings"], {
        queryParams: {
          sfr_regroupements: sfrRegroupements.toString(),
          relatedAlarmId: alarmIdForGrouping,
        },
      });
    }
  }

  navigateToKnownErrors(alarmKey: string): void {
    if (alarmKey) {
      this._router.navigate(["alarms/known-errors"], {
        queryParams: { key: alarmKey },
      });
    }
  }

  private _getUpdatedCurrentAlarms(
    alarms: Alarm[],
    parametersToUpdate: AlarmActionParametersToUpdate
  ): Alarm[] {
    return alarms.map((alarm: Alarm) => {
      return Object.assign(alarm, parametersToUpdate);
    });
  }

  private _getUpdatedAlarmSfrOperations(
    actionInfo: AlarmActionInfo,
    newAlarmState: string,
    alarmSfrOperations: AlarmSfrOperation[]
  ): AlarmSfrOperation[] {
    const operationInfo: AlarmSfrOperation = {
      timestamp: Date.now(),
      msg: actionInfo.information ?? "",
      user_uperid: this._securityService.getUser().uperId,
      etat: newAlarmState,
      action: actionInfo.action,
      sfr_ref_incident: actionInfo.sfr_ref_incident,
      sfr_ref_mep: actionInfo.sfr_ref_mep,
    };
    return alarmSfrOperations?.length
      ? [...alarmSfrOperations, operationInfo]
      : [operationInfo];
  }

  closeLockedAlarms(
    alarms: Alarm[],
    information: string,
    singleAlarmMode: boolean
  ): Observable<Alarm[]> {
    const newAlarmState = ConstColorStates.CLOSED.code;
    const actionInfo: AlarmActionInfo = {
      action: ActionInfoLabelEnum.CLOSE,
      information: information,
    };
    const minimalParametersToUpdate: ParametersToUpdate = {
      sfr_closed_date: Date.now(),
      sfr_closed_user: this._securityService.getUser().uperId,
      state: newAlarmState,
    };

    const parametersToUpdate = this._buildParametersForAlarmOperations(
      minimalParametersToUpdate,
      alarms,
      actionInfo,
      singleAlarmMode
    );

    const alarmsListIdString =
      this._alarmsUtilsService.getAlarmIdsListString(alarms);
    return this._alarmApiService
      .updateAlarms(alarmsListIdString, parametersToUpdate)
      .pipe(
        switchMap(() => {
          return this._postLogService.postLog({
            action:
              alarms.length === 1 && singleAlarmMode
                ? "Fermer une alarme"
                : "Fermer plusieurs alarmes",
            key: alarmsListIdString,
          });
        }),
        switchMap(() => {
          const successMessage =
            alarms.length === 1 && singleAlarmMode
              ? `Alarme ${alarmsListIdString} fermée.`
              : "Les alarmes ont été fermées.";
          this._toastrService.success(successMessage, "Success!");
          return of(this._getUpdatedCurrentAlarms(alarms, parametersToUpdate));
        })
      );
  }

  lockAlarmThenCloseAlarm(alarm: Alarm): Observable<Alarm> {
    if (alarm._source.in_progress) {
      this._toastrService.warning(
        `Alarme en cours de traitement par ${alarm._source.user.username}`
      );
    } else {
      this._alarmsUtilsService.sendLockInfos(alarm);
      return from(
        this._confirmDialogService.confirm(
          "Etes-vous sûr ?",
          "L'alarme sera fermée."
        )
      ).pipe(
        switchMap((choice: boolean) => {
          if (choice) {
            return this.closeLockedAlarms([alarm], "", true).pipe(
              switchMap((updatedCurrentAlarms: Alarm[]) => {
                this._alarmsUtilsService.sendUnlockInfos(
                  updatedCurrentAlarms[0]
                );
                return of(updatedCurrentAlarms[0]);
              }),
              catchError(() => {
                this._alarmsUtilsService.sendUnlockInfos(alarm);
                this._toastrService.error(
                  `L'alarme ${alarm._id} n'a pas été fermée.`
                );
                return [alarm];
              })
            );
          } else {
            this._alarmsUtilsService.sendUnlockInfos(alarm);
            this._toastrService.error(
              `L'alarme ${alarm._id} n'a pas été fermée.`
            );
            return [alarm];
          }
        })
      );
    }
  }

  acknowledgeWithTicket(
    alarms: Alarm[],
    sfrRefIncident: string,
    information: string,
    singleAlarmMode: boolean
  ): Observable<Alarm[]> {
    const clarifyPayload: ClarifyPayload = {
      uperid: this._securityService.getUser().uperId,
      id_alarm: alarms[0]._id, // We cannot send a list of ids.
      sfr_ref_incident: sfrRefIncident,
      message: information,
    };

    return this._clarifyApiService.addClarifyNote(clarifyPayload).pipe(
      switchMap((clarifyResponse: ClarifyResponse) => {
        if (clarifyResponse.retour === "OK") {
          const newAlarmState = ConstColorStates.ACQUITTED_WITH_TICKET.code;
          const actionInfo: AlarmActionInfo = {
            action: ActionInfoLabelEnum.ACQUITTED_WITH_TICKET,
            sfr_ref_incident: sfrRefIncident,
            information: information,
          };

          const minimalParametersToUpdate: ParametersToUpdate = {
            sfr_ack_date: Date.now(),
            sfr_ack_user: this._securityService.getUser().uperId,
            sfr_ref_incident: sfrRefIncident,
            state: newAlarmState,
          };

          const parametersToUpdate = this._buildParametersForAlarmOperations(
            minimalParametersToUpdate,
            alarms,
            actionInfo,
            singleAlarmMode
          );

          return this._alarmApiService
            .updateAlarms(
              this._alarmsUtilsService.getAlarmIdsListString(alarms),
              parametersToUpdate
            )
            .pipe(
              switchMap(() => {
                this._toastrService.success(
                  clarifyResponse.message,
                  "Success!"
                );
                return of(
                  this._getUpdatedCurrentAlarms(alarms, parametersToUpdate)
                );
              })
            );
        } else {
          const isisError: IsisError = {
            isisCode: "ERROR_CLARIFY_NOTES",
            isisMessage: `Erreur! (${clarifyResponse.code_erreur}) : ${clarifyResponse.message}`,
          };
          return throwError(() => isisError);
        }
      })
    );
  }

  acknowledgeWithoutTicket(
    alarms: Alarm[],
    information: string,
    singleAlarmMode: boolean
  ): Observable<Alarm[]> {
    const newAlarmState = ConstColorStates.ACQUITTED_WITHOUT_TICKET.code;
    const actionInfo: AlarmActionInfo = {
      action: ActionInfoLabelEnum.ACQUITTED_WITHOUT_TICKET,
      sfr_ref_incident: "",
      information: information,
    };

    const minimalParametersToUpdate: ParametersToUpdate = {
      sfr_ack_date: Date.now(),
      sfr_ack_user: this._securityService.getUser().uperId,
      sfr_ref_incident: "",
      state: newAlarmState,
    };

    const parametersToUpdate = this._buildParametersForAlarmOperations(
      minimalParametersToUpdate,
      alarms,
      actionInfo,
      singleAlarmMode
    );

    return this._alarmApiService
      .updateAlarms(
        this._alarmsUtilsService.getAlarmIdsListString(alarms),
        parametersToUpdate
      )
      .pipe(
        switchMap(() => {
          const successMessage =
            alarms.length === 1 && singleAlarmMode
              ? "L'alarme a été mise à jour avec succès."
              : "Les alarmes ont été mises à jour avec succès.";
          this._toastrService.success(successMessage, "Success!");
          return of(this._getUpdatedCurrentAlarms(alarms, parametersToUpdate));
        })
      );
  }

  acknowledgeWithMep(
    alarms: Alarm[],
    sfrRefMep: string,
    information: string,
    singleAlarmMode: boolean
  ): Observable<Alarm[]> {
    const newAlarmState = ConstColorStates.ACQUITTED_WITH_MEP.code;
    const actionInfo: AlarmActionInfo = {
      action: ActionInfoLabelEnum.ACQUITTED_WITH_MEP,
      sfr_ref_mep: sfrRefMep,
      information: information,
    };
    const minimalParametersToUpdate: ParametersToUpdate = {
      sfr_ack_date: Date.now(),
      sfr_ack_user: this._securityService.getUser().uperId,
      sfr_ref_mep: sfrRefMep,
      state: newAlarmState,
    };

    const parametersToUpdate = this._buildParametersForAlarmOperations(
      minimalParametersToUpdate,
      alarms,
      actionInfo,
      singleAlarmMode
    );

    return this._alarmApiService
      .updateAlarms(
        this._alarmsUtilsService.getAlarmIdsListString(alarms),
        parametersToUpdate
      )
      .pipe(
        switchMap(() => {
          const successMessage =
            alarms.length === 1 && singleAlarmMode
              ? `L'alarme a été mise à jour avec succès avec REF_MEP ${sfrRefMep}`
              : `Les alarmes ont été mises à jour avec succès avec REF_MEP ${sfrRefMep}`;
          this._toastrService.success(successMessage, "Success!");
          return of(this._getUpdatedCurrentAlarms(alarms, parametersToUpdate));
        })
      );
  }

  createNewTicket(
    alarms: Alarm[],
    information: string,
    singleAlarmMode: boolean
  ): Observable<Alarm[]> {
    const clarifyPayload: ClarifyPayload = {
      uperid: this._securityService.getUser().uperId,
      id_alarm: alarms[0]._id, // we can send only one alarm id
      message: information,
    };

    return this._clarifyApiService.createClarifyTicket(clarifyPayload).pipe(
      switchMap((clarifyResponse: ClarifyResponse) => {
        if (clarifyResponse.retour === "OK") {
          const newAlarmState = ConstColorStates.ACQUITTED_WITH_TICKET.code;
          const actionInfo: AlarmActionInfo = {
            action: ActionInfoLabelEnum.CREATE_TICKET,
            sfr_ref_incident: clarifyResponse.sfr_ref_incident,
            information: information,
          };
          const minimalParametersToUpdate: ParametersToUpdate = {
            sfr_ack_date: Date.now(),
            sfr_ack_user: this._securityService.getUser().uperId,
            sfr_ref_incident: clarifyResponse.sfr_ref_incident,
            state: newAlarmState,
          };

          const parametersToUpdate = this._buildParametersForAlarmOperations(
            minimalParametersToUpdate,
            alarms,
            actionInfo,
            singleAlarmMode
          );

          return this._alarmApiService
            .updateAlarms(
              this._alarmsUtilsService.getAlarmIdsListString(alarms),
              parametersToUpdate
            )
            .pipe(
              switchMap(() => {
                this._toastrService.success(
                  clarifyResponse.message,
                  "Success!"
                );
                return of(
                  this._getUpdatedCurrentAlarms(alarms, parametersToUpdate)
                );
              })
            );
        } else {
          const isisError: IsisError = {
            isisCode: "ERROR_CLARIFY_TICKETS",
            isisMessage: `Erreur : ${clarifyResponse.message}`,
          };
          return throwError(() => isisError);
        }
      })
    );
  }

  private _buildParametersForAlarmOperations(
    minimalParametersToUpdate: ParametersToUpdate,
    alarms: Alarm[],
    actionInfo: AlarmActionInfo,
    singleAlarmMode: boolean
  ): ParametersToUpdate {
    return alarms.length === 1 && singleAlarmMode
      ? {
          ...minimalParametersToUpdate,
          sfr_operations: this._getUpdatedAlarmSfrOperations(
            actionInfo,
            minimalParametersToUpdate.state,
            alarms[0].sfr_operations
          ),
        }
      : minimalParametersToUpdate;
  }
}
