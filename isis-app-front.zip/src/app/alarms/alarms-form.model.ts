import { FormControl, FormGroup } from "@angular/forms";

export interface SeverityFilterForm {
  OK: FormControl<boolean>;
  CRITICAL: FormControl<boolean>;
  MAJOR: FormControl<boolean>;
  WARNING: FormControl<boolean>;
  INFO: FormControl<boolean>;
  UNKNOWN: FormControl<boolean>;
}

export interface StateFilterForm {
  ACQUITTED_WITH_TICKET: FormControl<boolean>;
  ACQUITTED_WITHOUT_TICKET: FormControl<boolean>;
  ACQUITTED_WITH_MEP: FormControl<boolean>;
  BLACKOUT: FormControl<boolean>;
  CLOSED: FormControl<boolean>;
  OPEN: FormControl<boolean>;
}

export interface DateFilterForm {
  begin: FormControl<string>;
  end: FormControl<string>;
}

export interface AlarmFilterForm {
  severity: FormGroup<SeverityFilterForm>;
  states: FormGroup<StateFilterForm>;
  dates: FormGroup<DateFilterForm>;
  search: FormControl<string[]>;
}

export interface AlarmFilterStorage {
  severity?: {
    OK: boolean;
    CRITICAL: boolean;
    MAJOR: boolean;
    WARNING: boolean;
    INFO: boolean;
    UNKNOWN: boolean;
  };
  states?: {
    ACQUITTED_WITH_TICKET: boolean;
    ACQUITTED_WITHOUT_TICKET: boolean;
    ACQUITTED_WITH_MEP: boolean;
    BLACKOUT: boolean;
    CLOSED: boolean;
    OPEN: boolean;
  };
  search?: string[];
  dates?: {
    begin?: string;
    end?: string;
  };
}
