import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot } from "@angular/router";
import { BehaviorSubject, Observable, Subject, timer } from "rxjs";
import { FormControl, FormGroup } from "@angular/forms";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { EnvironmentService } from "@app/shared/services/environment/environment.service";
import {
  AlarmStateEnum,
  ConstColorSeverity,
} from "@app/shared/consts/color-alarms";
import { CustomFilterChipItem } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list.model";
import { CustomMenuSelectItem } from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import { Groups } from "@app/shared/models/group";
import { CustomTableColumn } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { CustomSelectableTableBaseService } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.service";
import {
  AlarmFilterForm,
  AlarmFilterStorage,
  DateFilterForm,
  SeverityFilterForm,
  StateFilterForm,
} from "./alarms-form.model";
import { AlarmAvancedSearchPrefix } from "@app/shared/models/alarm";

@Injectable({
  providedIn: "root",
})
export class AlarmsService {
  private _filterFG: FormGroup<AlarmFilterForm>;
  onFilterFGChanged: Subject<boolean> = new Subject();
  private _group = "isis";
  private _sgroup: string;
  private _state: string;
  timer: string;
  private _time: number;
  private _localStorageFilterFG: AlarmFilterStorage;
  cron: Observable<number>;
  private _stopwatch: any;

  selectedAlarmColumns$: Observable<string[]>;
  private _selectedAlarmColumnsBehaviorSubject: BehaviorSubject<string[]>;

  constructor(
    private isisService: IsisService,
    private environmentService: EnvironmentService,
    private _customSelectableTableBaseService: CustomSelectableTableBaseService
  ) {
    this._time = this.environmentService.config.alarms__lock__timer_loop;

    this._selectedAlarmColumnsBehaviorSubject = new BehaviorSubject(
      this._customSelectableTableBaseService.getSelectedColumnsFromStorage(
        "columns_alarms"
      )
    );
    this.selectedAlarmColumns$ =
      this._selectedAlarmColumnsBehaviorSubject.asObservable();

    this.cron = timer(
      this.environmentService.config.alarms__cron__timer_init,
      this.environmentService.config.alarms__cron__timer_loop
    );
  }

  resolve(route: ActivatedRouteSnapshot): Promise<boolean> {
    this._sgroup = route.params.sgroup;
    this._state = route.params.state;
    return new Promise((resolve, reject) => {
      Promise.all([this.isisService.getGroups()]).then(() => {
        resolve(true);
      }, reject);
      resolve(true);
    });
  }

  creatFilterFG(): FormGroup<AlarmFilterForm> {
    this._filterFG = new FormGroup<AlarmFilterForm>({
      severity: new FormGroup<SeverityFilterForm>({
        CRITICAL: new FormControl<boolean>(false),
        INFO: new FormControl<boolean>(false),
        MAJOR: new FormControl<boolean>(false),
        OK: new FormControl<boolean>(false),
        UNKNOWN: new FormControl<boolean>(false),
        WARNING: new FormControl<boolean>(false),
      }),
      states: new FormGroup<StateFilterForm>({
        ACQUITTED_WITH_TICKET: new FormControl<boolean>(false),
        ACQUITTED_WITHOUT_TICKET: new FormControl<boolean>(false),
        ACQUITTED_WITH_MEP: new FormControl<boolean>(false),
        BLACKOUT: new FormControl<boolean>(false),
        CLOSED: new FormControl<boolean>(false),
        OPEN: new FormControl<boolean>(false),
      }),
      dates: new FormGroup<DateFilterForm>({
        begin: new FormControl(""),
        end: new FormControl(""),
      }),
      search: new FormControl<string[]>([]),
    });

    // Set Value from local storage
    if (this._getLocalStorageFilterFG()) {
      this._filterFG.patchValue(this._localStorageFilterFG);
    }

    // Set value of form local storage
    this._filterFG.valueChanges.subscribe(() => {
      this._setLocalStorageFilterFG();
    });

    return this._filterFG;
  }

  getFilterBlackoutId(): string {
    const blackoutIdFromStorage = localStorage.getItem("blackout_id");
    return blackoutIdFromStorage ? JSON.parse(blackoutIdFromStorage) : "";
  }

  getFilterAlarmIds(): string {
    const alarmIdsFromStorage = localStorage.getItem("alarm_ids");
    return alarmIdsFromStorage ? JSON.parse(alarmIdsFromStorage) : "";
  }

  getFilterSeverityValues(): string[] {
    const severityFGItems: {
      CRITICAL: boolean;
      INFO: boolean;
      MAJOR: boolean;
      OK: boolean;
      UNKNOWN: boolean;
      WARNING: boolean;
    } = this._filterFG.get(["severity"]).value;

    return severityFGItems
      ? Object.keys(severityFGItems).filter((key: string) => {
          return severityFGItems[key];
        })
      : [];
  }

  getFilterStateValuesWithUrlStateTakenIntoAccount(): string[] {
    const stateFromUrl = this.state;
    return stateFromUrl?.toLowerCase() === "all"
      ? this.getFilterStatesValues()
      : stateFromUrl
      ? [stateFromUrl.toUpperCase()]
      : [];
  }

  getFilterStatesValues(): string[] {
    const stateFGItems: {
      ACQUITTED_WITHOUT_TICKET: boolean;
      ACQUITTED_WITH_MEP: boolean;
      ACQUITTED_WITH_TICKET: boolean;
      BLACKOUT: boolean;
      CLOSED: boolean;
      OPEN: boolean;
    } = this._filterFG.get(["states"]).value;

    return stateFGItems
      ? Object.keys(stateFGItems).filter((key: string) => {
          return stateFGItems[key];
        })
      : [];
  }

  getAdvancedSearchValues(): string[] {
    const searchFGItems: string[] = this._filterFG.get(["search"]).value;

    const searchItemsForRequestWithoutPreSelectedField = searchFGItems?.length
      ? searchFGItems.filter((item: string) => {
          return (
            !item.includes(AlarmAvancedSearchPrefix.REF_BLACKOUT) &&
            !item.includes(AlarmAvancedSearchPrefix.REF_SERVICE)
          );
        })
      : [];

    return searchItemsForRequestWithoutPreSelectedField;
  }

  getFilterDatesValue(): {
    begin: string;
    end: string;
  } {
    return this._filterFG.get(["dates"]).value;
  }

  private _getLocalStorageFilterFG(): AlarmFilterStorage {
    const filterFromLocalStorage = localStorage.getItem("filter_fg");
    this._localStorageFilterFG = filterFromLocalStorage
      ? JSON.parse(filterFromLocalStorage)
      : null;
    return this._localStorageFilterFG;
  }

  private _setLocalStorageFilterFG(): void {
    localStorage.setItem(
      "filter_fg",
      JSON.stringify(this._filterFG.getRawValue())
    );
  }

  updateSelectedColumms(selectedColumnRefIds: string[]): void {
    this._selectedAlarmColumnsBehaviorSubject.next(selectedColumnRefIds);
    this._customSelectableTableBaseService.updateSelectedColumnsIntoLocalStorage(
      selectedColumnRefIds,
      "columns_alarms"
    );
  }

  private _getStatePluralLabel(alarmState: AlarmStateEnum): string {
    let pluralLabel: string;
    switch (alarmState) {
      case AlarmStateEnum.ACQUITTED_WITHOUT_TICKET: {
        pluralLabel = "Acquittés sans ticket";
        break;
      }
      case AlarmStateEnum.ACQUITTED_WITH_MEP: {
        pluralLabel = "Acquittés avec MEP";
        break;
      }
      case AlarmStateEnum.ACQUITTED_WITH_TICKET: {
        pluralLabel = "Acquittés avec ticket";
        break;
      }
      case AlarmStateEnum.BLACKOUT: {
        pluralLabel = "Blackouts";
        break;
      }
      case AlarmStateEnum.OPEN: {
        pluralLabel = "Ouverts";
        break;
      }
      case AlarmStateEnum.CLOSED: {
        pluralLabel = "Clos";
        break;
      }
    }
    return pluralLabel;
  }

  private _getStateLabelForMultiSelectMenu(
    keyState: string,
    currentGroups?: Groups,
    currentSgroup?: string
  ): string {
    if (currentGroups && currentSgroup) {
      return `${this._getStatePluralLabel(AlarmStateEnum[keyState])} (${
        currentGroups[currentSgroup][AlarmStateEnum[keyState].toLowerCase()]
      })`;
    } else {
      return this._getStatePluralLabel(AlarmStateEnum[keyState]);
    }
  }

  initAvailableStateSelectItems(
    currentGroups?: Groups,
    currentSgroup?: string
  ): CustomMenuSelectItem[] {
    const selectedItems = Object.keys(AlarmStateEnum).map((key: string) => {
      const selectedStateValuesFromFG = this._filterFG.get(["states"]).value;

      const customMenuSelectItem: CustomMenuSelectItem = {
        label: this._getStateLabelForMultiSelectMenu(
          key,
          currentGroups,
          currentSgroup
        ),
        value: AlarmStateEnum[key],
        selectedOnInit: selectedStateValuesFromFG[key],
      };
      return customMenuSelectItem;
    });
    return selectedItems;
  }

  initAvailableColumnSelectItems(
    availableColumns: CustomTableColumn[]
  ): CustomMenuSelectItem[] {
    return this._customSelectableTableBaseService.initAvailableColumnSelectItems(
      availableColumns,
      "columns_alarms"
    );
  }

  initAvailableSeverityChipItems(): CustomFilterChipItem[] {
    return Object.keys(ConstColorSeverity).map((severityKey: string) => {
      const colorSeverity = ConstColorSeverity[severityKey];
      const selectedSeverityValuesFromFG = this._filterFG.get([
        "severity",
      ]).value;
      const severityFilterChipItem: CustomFilterChipItem = {
        label: colorSeverity.label,
        value: colorSeverity.code,
        selectedOnInit: Boolean(selectedSeverityValuesFromFG[severityKey]),
        colorDescription: colorSeverity,
      };
      return severityFilterChipItem;
    });
  }

  updateFormGroupItemsFilterOnSelect(
    selectedValues: string[],
    formControlName: string[],
    alwaysSelectedValues?: string[]
  ): void {
    const updatedSelectItems: Record<string, boolean> = {};
    Object.keys(this._filterFG.get(formControlName).value).forEach(
      (key: string) => {
        if (alwaysSelectedValues?.includes(key)) {
          updatedSelectItems[`${key}`] = true;
        } else {
          updatedSelectItems[`${key}`] =
            selectedValues.findIndex((value: string) => value === key) !== -1;
        }
      }
    );
    this._filterFG.get(formControlName).patchValue(updatedSelectItems);
    this.onFilterFGChanged.next(true);
  }

  /**
   * Getter et Setter
   */
  get filterFG(): FormGroup<AlarmFilterForm> {
    return this._filterFG;
  }

  get group(): string {
    return this._group;
  }

  set group(value: string) {
    this._group = value;
  }

  get sgroup(): string {
    return this._sgroup;
  }

  set sgroup(value: string) {
    this._sgroup = value;
  }

  get state(): string {
    return this._state;
  }

  set state(value: string) {
    this._state = value;
  }

  startTimer(): void {
    this._stopwatch = setInterval(() => {
      this.timer = this.convertSecondsInMinutes(this._time);
      this._time--;
    }, 1000);
  }

  convertSecondsInMinutes(time: number): string {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes} min ${seconds} `;
  }

  resetTimer(): void {
    clearInterval(this._stopwatch);
    this._time = this.environmentService.config.alarms__lock__timer_loop;
  }
}
