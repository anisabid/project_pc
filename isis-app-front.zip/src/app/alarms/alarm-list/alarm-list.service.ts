import { Injectable } from "@angular/core";
import {
  ColumnTypeEnum,
  CustomTableColumn,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { AlarmTableItem, Alarm } from "@app/shared/models/alarm";
import { AlarmsUtilsService } from "../alarms-utils.service";
import { BlackoutTypeEnum } from "@app/shared/models/blackout";

@Injectable({ providedIn: "root" })
export class AlarmListService {
  constructor(private _alarmsUtilsService: AlarmsUtilsService) {}

  buildMinimalAlarmTableColumns(withCheckbox: boolean): CustomTableColumn[] {
    return [
      {
        referenceId: "th",
        label: "",
        width: withCheckbox ? "40px" : "48px",
        type: ColumnTypeEnum.CUSTOM,
        isSelectable: false,
      },
      {
        referenceId: "priority",
        label: "",
        width: "40px",
        type: ColumnTypeEnum.CUSTOM,
        isSelectable: false,
      },
      {
        referenceId: "sfrServiceLevel",
        label: "",
        width: "70px",
        type: ColumnTypeEnum.CUSTOM,
        isSelectable: false,
      },
      {
        referenceId: "origin_time",
        label: "Origin time",
        width: "110px",
        type: ColumnTypeEnum.DATE_TIME,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "sfr_ref_mep",
        label: "REF Blackout",
        width: "200px",
        type: ColumnTypeEnum.CUSTOM,
        isSelectable: true,
        selectedByDefault: false,
      },
      {
        referenceId: "sfr_ref_incident",
        label: "REF Incident",
        width: "100px",
        type: ColumnTypeEnum.CUSTOM,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "appName",
        label: "App Name",
        width: "130px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: false,
      },
      {
        referenceId: "sfr_ref_clarify",
        label: "Siroco",
        width: "80px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "host",
        label: "Host",
        width: "140px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "message",
        label: "Message",
        width: "180px",
        type: ColumnTypeEnum.LONG_TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "sfr_source",
        label: "Sfr source",
        width: "100px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "sfr_vsr",
        label: "Sfr vsr",
        width: "67px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
      },
      {
        referenceId: "parametre",
        label: "Paramètre",
        width: "90px",
        type: ColumnTypeEnum.LONG_TEXT_SIZE_FIXED,
        isSelectable: true,
        selectedByDefault: false,
        isSortable: true,
      },
      {
        referenceId: "objet_supervise",
        label: "Objet supervisé",
        width: "100px",
        type: ColumnTypeEnum.LONG_TEXT,
        isSelectable: true,
        selectedByDefault: false,
        isSortable: true,
      },
      {
        referenceId: "domaine_supervision",
        label: "Domaine supervision",
        width: "100px",
        type: ColumnTypeEnum.LONG_TEXT,
        isSelectable: true,
        selectedByDefault: false,
        isSortable: true,
      },
      {
        referenceId: "sfr_repeat_count",
        label: "RC",
        width: "40px",
        type: ColumnTypeEnum.NUMBER,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
    ];
  }

  buildAlarmTableColumns(
    isRegrouping: boolean,
    withCheckbox: boolean
  ): CustomTableColumn[] {
    return [
      ...this.buildMinimalAlarmTableColumns(withCheckbox),
      {
        referenceId: "actions",
        label: "Actions",
        width: this._getColumnActionsWidth(isRegrouping),
        type: ColumnTypeEnum.CUSTOM,
        isSelectable: true,
        selectedByDefault: true,
      },
    ];
  }

  buildAlarmTableItems(alarms: Alarm[]): AlarmTableItem[] {
    return alarms.map((alarm: Alarm) => {
      const referenceBlackout = this._getRefBlackoutFromLinkedBlackouts(
        alarm.blackouts
      );
      return <AlarmTableItem>{
        ...alarm,
        sfrServiceLevelCode:
          this._alarmsUtilsService.getSfrServiceLevelCode(alarm),
        sfr_ref_mep: this._getDisplayedSfrRefMep(referenceBlackout, alarm),
        appName: this._getDisplayedAppName(alarm),
        linkedBlackoutId: referenceBlackout ? referenceBlackout._id : undefined,
      };
    });
  }

  private _getDisplayedAppName(alarm: Alarm): string {
    return alarm.sfr_ref_clarify.startsWith("BDD")
      ? alarm.bdd_application_proprietaire
      : alarm.app_sfr_nom;
  }

  private _getDisplayedSfrRefMep(
    referenceBlackout: {
      eventReference: string;
      terminated: boolean;
      type: BlackoutTypeEnum | string;
      _id: string;
    },
    alarm: Alarm
  ): string {
    return referenceBlackout
      ? referenceBlackout.eventReference
      : alarm?.sfr_ref_mep;
  }

  private _getColumnActionsWidth(isRegrouping: boolean): string {
    const withCloseButton = this._alarmsUtilsService.hasAlarmActionRights();

    let buttonCount = 1; // at least consigne button
    buttonCount = withCloseButton ? buttonCount + 1 : buttonCount;
    buttonCount = isRegrouping ? buttonCount : buttonCount + 1;
    return `${buttonCount * 48 + 16}px`;
  }

  private _getRefBlackoutFromLinkedBlackouts(
    blackouts: {
      eventReference: string;
      terminated: boolean;
      type: BlackoutTypeEnum | string;
      _id: string;
    }[]
  ): {
    eventReference: string;
    terminated: boolean;
    type: BlackoutTypeEnum | string;
    _id: string;
  } {
    if (!blackouts || !blackouts.length) {
      return undefined;
    }

    if (blackouts.length === 1) {
      return blackouts[0];
    }

    if (blackouts.length > 1) {
      const availableTypeEnums = Object.values(BlackoutTypeEnum);
      const filterByBlackoutType = (
        blackoutsToFilters: {
          eventReference: string;
          terminated: boolean;
          type: BlackoutTypeEnum | string;
          _id: string;
        }[],
        blackoutTypeEnum: BlackoutTypeEnum,
        availableTypeEnums: BlackoutTypeEnum[]
      ) => {
        const indexOfType = availableTypeEnums.findIndex((typeEnum) => {
          return typeEnum === blackoutTypeEnum;
        });
        const filteredBlackouts = blackoutsToFilters.filter(
          (blackout: {
            eventReference: string;
            terminated: boolean;
            type: BlackoutTypeEnum;
            _id: string;
          }) => {
            return blackoutTypeEnum === blackout.type;
          }
        );

        return Boolean(filteredBlackouts) && Boolean(filteredBlackouts.length)
          ? filteredBlackouts[0]
          : indexOfType > availableTypeEnums.length - 1
          ? undefined
          : filterByBlackoutType(
              blackoutsToFilters,
              availableTypeEnums[indexOfType + 1],
              availableTypeEnums
            );
      };
      const chosenRefBlackout = filterByBlackoutType(
        blackouts,
        availableTypeEnums[0],
        availableTypeEnums
      );

      return chosenRefBlackout;
    }
  }
}
