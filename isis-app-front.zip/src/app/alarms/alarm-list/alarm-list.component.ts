import { Component, Input } from "@angular/core";
import { WebsocketService } from "@app/service/notify/websocket.service";
import { CustomSelectableTableBaseComponent } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.component";
import {
  ConstColorPriorities,
  ConstColorSeverity,
  ConstColorStates,
} from "@app/shared/consts/color-alarms";
import { Alarm, AlarmTableItem } from "@app/shared/models/alarm";
import { takeUntil } from "rxjs";
import { AlarmsActionsService } from "../alarms-actions.service";
import { AlarmsUtilsService } from "../alarms-utils.service";

@Component({
  selector: "app-alarm-list",
  templateUrl: "./alarm-list.component.html",
  styleUrls: ["./alarm-list.component.scss"],
})
export class AlarmListComponent extends CustomSelectableTableBaseComponent {
  private _constTenMinutes = 10;
  private _constTenMinutesInMilliSec = this._constTenMinutes * 60 * 1000;

  constColorPriorities = ConstColorPriorities;
  constColorStates = ConstColorStates;
  constColorSeverity = ConstColorSeverity;

  tooltipLabel = {
    closeAlarmButton: "Fermer l'alarme",
    seeBlackoutLink: "Voir les détails du blackout",
    needToTreatAlarm: `Attention, alarme non traitée depuis ${this._constTenMinutes} min !`,
    alarmBeingProcessed: "Alarme en cours de traitement",
  };
  loadingLabel = {
    error: " API V1 rate limit has been reached. Please refresh the page!",
    noResults: "Aucune alarme !",
  };

  @Input() isRateLimitReached: boolean;
  @Input() isRegrouping: boolean;
  @Input() withoutActionsForm: boolean;

  constructor(
    protected _websocketService: WebsocketService,
    protected _alarmsActionsService: AlarmsActionsService,
    protected _alarmsUtilsService: AlarmsUtilsService
  ) {
    super();
  }

  openAlarmDetailModal(alarmTableItem: AlarmTableItem): void {
    this._alarmsActionsService.openAlarmDetailModal(
      this._alarmsUtilsService.getAlarmFromAlarmTableItem(alarmTableItem),
      this.withoutActionsForm
    );
  }

  openLockInfos(alarmTableItem: AlarmTableItem): void {
    this._alarmsActionsService.openLockInfos(
      this._alarmsUtilsService.getAlarmFromAlarmTableItem(alarmTableItem)
    );
  }

  closeAlarm(alarmTableItem: AlarmTableItem): void {
    this._alarmsActionsService
      .lockAlarmThenCloseAlarm(
        this._alarmsUtilsService.getAlarmFromAlarmTableItem(alarmTableItem)
      )
      .pipe(takeUntil(this.needUnsubscribe$))
      .subscribe();
  }

  navigateToRegrouping(
    sfrRegroupements: string[],
    alarmIdForGrouping: string
  ): void {
    this._alarmsActionsService.navigateToRegrouping(
      sfrRegroupements,
      alarmIdForGrouping
    );
  }

  isAlarmInProcessFromNotif(alarmTableItem: AlarmTableItem): boolean {
    let isInProcess = false;
    const notifiedAlarms = this._websocketService.notifiedAlarms;
    notifiedAlarms?.forEach((notifiedAlarm: Alarm) => {
      if (notifiedAlarm._id === alarmTableItem._id) {
        alarmTableItem._source.in_progress = notifiedAlarm._source.in_progress; // TODO make this immutable
        isInProcess = notifiedAlarm._source.in_progress;
      } else {
        isInProcess = false;
      }
    });
    return isInProcess;
  }

  hasAlarmActionRights(): boolean {
    return this._alarmsUtilsService.hasAlarmActionRights();
  }

  getTooltipMessageWithStateAndSeverity(
    alarmTableItem: AlarmTableItem
  ): string {
    const colorStateLabel = this.constColorStates[alarmTableItem.state]
      ? this.constColorStates[alarmTableItem.state].label
      : "";
    const colorSeverityLabel = this.constColorSeverity[alarmTableItem.severite]
      ? this.constColorSeverity[alarmTableItem.severite].label
      : "";
    return `${colorStateLabel} & ${colorSeverityLabel}`;
  }

  needUrgentTreatment(alarmTableItem: AlarmTableItem): boolean {
    const isOpen = alarmTableItem.state === this.constColorStates.OPEN.code;
    return (
      isOpen &&
      this._isHighLevelService(alarmTableItem.sfrServiceLevelCode) &&
      this._isNotTreatedSinceXMinutes(
        alarmTableItem.sfr_visu_date,
        this._constTenMinutesInMilliSec
      )
    );
  }

  private _isHighLevelService(sfrServiceLevelCode: string): boolean {
    return (
      sfrServiceLevelCode &&
      (sfrServiceLevelCode === "PLATINUM" ||
        sfrServiceLevelCode === "GOLD" ||
        sfrServiceLevelCode === "SILVER")
    );
  }

  private _isNotTreatedSinceXMinutes(
    sfrVisuDate: number,
    XminutesInMilliSec: number
  ): boolean {
    return sfrVisuDate + XminutesInMilliSec < Date.now();
  }

  trackRowByAlarmId(index: number, alarmTableItem: AlarmTableItem): string {
    return alarmTableItem._id;
  }
}
