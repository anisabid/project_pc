import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "@app/shared/shared.module";
import { AlarmsService } from "./alarms.service";
import { AlarmsComponent } from "./alarms.component";
import { ModalExportComponent } from "./modals/export/modal-export.component";
import { RegroupingService } from "@app/alarms/regrouping.service";
import { AlarmSubheaderComponent } from "./alarm-subheader/alarm-subheader.component";
import { AlarmListComponent } from "./alarm-list/alarm-list.component";
import { ActionsFormComponent } from "./modals/actions-form/actions-form.component";
import { ModalActionsMultiAlarmsComponent } from "./modals/actions-multi-alarms/modal-actions-multi-alarms.component";
import { ModalActionsOneAlarmComponent } from "./modals/actions-one-alarm/modal-actions-one-alarm.component";
import { AlarmsActionsService } from "./alarms-actions.service";
import { AlarmKnownErrorsPageComponent } from "./alarm-known-errors/alarm-known-errors-page.component";
import { AlarmKnownErrorsSubheaderComponent } from "./alarm-known-errors/alarm-known-errors-subheader/alarm-known-errors-subheader.component";

const routes: Routes = [
  {
    path: "regroupings",
    component: AlarmsComponent,
    resolve: {
      data: RegroupingService,
    },
  },
  {
    path: "known-errors",
    component: AlarmKnownErrorsPageComponent,
  },
  {
    path: ":sgroup/:state",
    component: AlarmsComponent,
    resolve: {
      data: AlarmsService,
    },
  },
  {
    path: ":sgroup",
    redirectTo: ":sgroup/all",
  },
  {
    path: "**",
    redirectTo: "si/all",
  },
];

@NgModule({
  declarations: [
    AlarmsComponent,
    AlarmSubheaderComponent,
    AlarmListComponent,
    ActionsFormComponent,
    ModalActionsOneAlarmComponent,
    ModalExportComponent,
    ModalActionsMultiAlarmsComponent,
    AlarmKnownErrorsPageComponent,
    AlarmKnownErrorsSubheaderComponent,
  ],
  providers: [AlarmsActionsService],
  imports: [RouterModule.forChild(routes), SharedModule],
  exports: [
    AlarmsComponent,
    AlarmSubheaderComponent,
    AlarmListComponent,
    ActionsFormComponent,
    ModalActionsOneAlarmComponent,
    ModalExportComponent,
    ModalActionsMultiAlarmsComponent,
  ],
})
export class AlarmsModule {}
