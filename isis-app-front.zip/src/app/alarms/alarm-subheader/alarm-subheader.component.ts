import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { CustomFilterChipItem } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list.model";
import {
  CustomMenuSelectItem,
  CustomMultiSelectMenuConfig,
  CustomMultiSelectMenuTheme,
} from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import { TopBarService } from "@app/shared/components/top-bar/top-bar.service";
import { Groups } from "@app/shared/models/group";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { takeUntil, Subject } from "rxjs";
import { AlarmsService } from "../alarms.service";
import { DatePipe, Location } from "@angular/common";
import { ConstColorStates } from "@app/shared/consts/color-alarms";
import { Alarm, AlarmAvancedSearchPrefix } from "@app/shared/models/alarm";
import { CustomTableColumn } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { AlarmsActionsService } from "../alarms-actions.service";
import { AdvancedSearchValue } from "@app/shared/components/custom-advanced-search/custom-advanced-search.component";
import { CustomDateTimeRange } from "@app/shared/components/date-time-range-select/date-time-range-select.component";
import { AlarmFilterForm } from "../alarms-form.model";
import { AlarmsUtilsService } from "../alarms-utils.service";

@Component({
  selector: "app-alarm-subheader",
  templateUrl: "./alarm-subheader.component.html",
  styleUrls: ["./alarm-subheader.component.scss"],
})
export class AlarmSubheaderComponent implements OnInit, OnDestroy {
  private _needUnsubscribe$ = new Subject<boolean>();
  isRegrouping = false;
  alarmFilterFormGroup: FormGroup<AlarmFilterForm>;

  groups: Groups;
  sgroup: string;
  state: string;

  stateMultiSelectMenuConfig: CustomMultiSelectMenuConfig;
  availableStateSelectItems: CustomMenuSelectItem[];
  beginDateFilter: string | Date;
  endDateFilter: string | Date;
  displayDateTimeRangeSelect = false;
  displayAdvancedSearchInput = false;
  availableSeverityFilterChipItems: CustomFilterChipItem[];
  advancedSearchItems: string[];
  columnMultiSelectMenuConfig: CustomMultiSelectMenuConfig;
  availableColumnSelectItems: CustomMenuSelectItem[];

  constColorStates = ConstColorStates;
  constColorStateKeys = Object.keys(this.constColorStates);

  hasAlarmActionRights = false;

  labels = {
    links: {
      isis: "ISIS",
      regrouping: "REGROUPEMENT",
    },
    buttons: {
      SI: "SI",
      VABFO: "VABFO",
    },
    states: {
      ALL: "TOUS",
      OPEN: "Ouverts",
      ACK_WITH_TICKET: "Acquittés avec ticket",
      ACK_WITH_MEP: "Acquittés avec MEP",
      ACK_WITHOUT_TICKET: "Acquittés sans ticket",
      BLACKOUTS: "Blackouts",
      CLOSED: "Clos",
    },
    tooltip: {
      helpButton:
        "Aide sur la recherche avancée: &#13; &#13; -Filtre par mot &#13; -Taper ENTER pour une recherche multiple par puce &#13; -La recherche se fait sur toutes les colonnes &#13;&#13; [ref_siroco | host | message | sfr_vsr ] ",
      actionsButton: "Actions",
      exportButton: "Exporter",
      openDateTimeButton: "Période des alarmes",
      refreshButton: "Rafraîchir les données",
      openSearchButton: "Recherche avancée",
    },
  };

  @Input() selectedAlarms: Alarm[];
  @Input() availableAlarmTableColumns: CustomTableColumn[];

  constructor(
    private _topBarService: TopBarService,
    private _alarmsService: AlarmsService,
    private _isisService: IsisService,
    public route: ActivatedRoute,
    private _location: Location,
    private _alarmsActionsService: AlarmsActionsService,
    private _alarmsUtilsService: AlarmsUtilsService,
    private _datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    this._topBarService.currentUrl$
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((url: string) => {
        this.isRegrouping = url.includes("regroupings");
      });
    this.hasAlarmActionRights = this._alarmsUtilsService.hasAlarmActionRights();
    this._topBarService.clearSelectedRegroupings();
    this._alarmsService.creatFilterFG();

    this.alarmFilterFormGroup = this._alarmsService.filterFG;
    this.sgroup = this._alarmsService.sgroup;
    this.state = this._alarmsService.state;
    this.groups = this._isisService.groups;

    this._isisService.onGroupsChanged
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((groups) => {
        this.groups = groups;
        this._setStateMultiSelectMenuProps(this.isRegrouping);
      });

    this.route.params.subscribe((params) => {
      this.state = params.state;
      this.sgroup = params.sgroup;
      this.refreshAlarms();
      this._setStateMultiSelectMenuProps(this.isRegrouping);
    });

    this._initMenuConfigsAndFilters();

    this._alarmsService.cron
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe(() => {
        this.refreshAlarmsAndGroups();
      });
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  refreshAlarmsAndGroups(): void {
    this._alarmsActionsService.refreshAlarmsAndGroups();
  }

  refreshAlarms(): void {
    this._alarmsActionsService.refreshAlarms();
  }

  back(): void {
    this._location.back();
  }

  openActionsForSelectedAlarmsModal(): void {
    const alarms: Alarm[] = [...this.selectedAlarms];
    this._alarmsActionsService.openActionsForSelectedAlarmsModal(alarms);
  }

  openExportModal(): void {
    const alarms: Alarm[] = [...this.selectedAlarms];
    this._alarmsActionsService.openExportModal(alarms);
  }

  toggleAdvancedSearch(event: boolean): void {
    this.displayAdvancedSearchInput = event;
  }

  toggleDateTimeRangeSelect(event: boolean): void {
    this.displayDateTimeRangeSelect = event;
  }

  onClosedStateMultiSelectMenu(): void {
    this._setStateMultiSelectMenuProps(this.isRegrouping);
  }

  onSelectedAlarmStates(selectedStates: string[]): void {
    this._alarmsService.updateFormGroupItemsFilterOnSelect(selectedStates, [
      "states",
    ]);
  }

  onSelectedSeverityFilter(selectedSeverities: string[]): void {
    this._alarmsService.updateFormGroupItemsFilterOnSelect(selectedSeverities, [
      "severity",
    ]);
  }

  onSelectedColumns(selectedColumns: string[]): void {
    this._alarmsService.updateSelectedColumms(selectedColumns);
  }

  onSelectedAdvancedSearch(advancedSearchEvent: AdvancedSearchValue): void {
    this.advancedSearchItems = advancedSearchEvent.items;
    if (
      advancedSearchEvent?.justRemovedItem?.includes(
        AlarmAvancedSearchPrefix.REF_BLACKOUT
      )
    ) {
      localStorage.removeItem("blackout_id");
    }
    if (
      advancedSearchEvent?.justRemovedItem?.includes(
        AlarmAvancedSearchPrefix.REF_SERVICE
      )
    ) {
      localStorage.removeItem("alarm_ids");
    }
    this._alarmsService.filterFG
      .get(["search"])
      .patchValue(advancedSearchEvent.items);
    this._alarmsService.onFilterFGChanged.next(true);
  }

  onSelectedDateTimeRange(dateTimeRange: CustomDateTimeRange): void {
    this.beginDateFilter = dateTimeRange.beginDateTime;
    this.endDateFilter = dateTimeRange.endDateTime;
    this._setDates(this.beginDateFilter, this.endDateFilter);
  }

  getRouterLinkForMenu(sgroup: string, stateKey: string): string[] {
    return [`/alarms/${sgroup}/${stateKey.toLocaleLowerCase()}`];
  }

  getCountForMenu(groups: string, sgroup: string, stateKey: string): number {
    return groups[sgroup][stateKey.toLocaleLowerCase()];
  }

  private _setDates(beginDate: Date | string, endDate: Date | string) {
    this._alarmsService.filterFG
      .get(["dates", "begin"])
      .setValue(this._datePipe.transform(beginDate, "yyyy-MM-dd HH:mm")); // format date for server side
    this._alarmsService.filterFG
      .get(["dates", "end"])
      .setValue(this._datePipe.transform(endDate, "yyyy-MM-dd HH:mm"));
    this._alarmsService.onFilterFGChanged.next(true);
  }

  private _setStateMultiSelectMenuProps(isRegroupingCase: boolean): void {
    if (!isRegroupingCase) {
      const allStatesButtonLabel =
        this.groups && this.groups[this.sgroup]
          ? `TOUS (${this.groups[this.sgroup]["all"]})`
          : "TOUS";
      this.stateMultiSelectMenuConfig = {
        isMenuTriggeredByIconButton: false,
        triggerButtonNameOrLabel: allStatesButtonLabel,
        triggerButtonTooltip: "Sélectionner le(s) statut(s) des alarmes",
        withApplyButton: true,
        withSelectAllButton: true,
        selectAllButtonLabel: allStatesButtonLabel,
        theme: CustomMultiSelectMenuTheme.STANDARD,
      };
      this.availableStateSelectItems =
        this._alarmsService.initAvailableStateSelectItems(
          this.groups,
          this.sgroup
        );
    } else {
      this.stateMultiSelectMenuConfig = {
        isMenuTriggeredByIconButton: false,
        triggerButtonNameOrLabel: "TOUS",
        triggerButtonTooltip: "Sélectionner le(s) statut(s) des alarmes",
        withApplyButton: true,
        withSelectAllButton: true,
        selectAllButtonLabel: "TOUS",
        theme: CustomMultiSelectMenuTheme.STANDARD,
      };
      this.availableStateSelectItems =
        this._alarmsService.initAvailableStateSelectItems();
    }
  }

  private _initMenuConfigsAndFilters(): void {
    this._initDateTimeRangeSelectProps();
    this._initSeverityFilterProps();
    this._initAdvancedSearchProps();
    this._initColumnMultiSelectMenuProps();
    this._setStateMultiSelectMenuProps(this.isRegrouping);
  }

  private _initDateTimeRangeSelectProps(): void {
    this.displayDateTimeRangeSelect = false;
    this.beginDateFilter = this._alarmsService.filterFG.get([
      "dates",
      "begin",
    ]).value;
    this.endDateFilter = this._alarmsService.filterFG.get([
      "dates",
      "end",
    ]).value;
  }

  private _initAdvancedSearchProps(): void {
    this.advancedSearchItems = this._alarmsService.filterFG.get([
      "search",
    ]).value;
  }

  private _initSeverityFilterProps(): void {
    this.availableSeverityFilterChipItems =
      this._alarmsService.initAvailableSeverityChipItems();
  }

  private _initColumnMultiSelectMenuProps(): void {
    this.columnMultiSelectMenuConfig = {
      isMenuTriggeredByIconButton: true,
      triggerButtonNameOrLabel: "view_column",
      triggerButtonTooltip: "Sélectionner les colonnes",
      withApplyButton: false,
      withSelectAllButton: false,
      theme: CustomMultiSelectMenuTheme.SMALL_BLACK,
    };
    this.availableColumnSelectItems =
      this._alarmsService.initAvailableColumnSelectItems(
        this.availableAlarmTableColumns
      );
  }
}
