import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot } from "@angular/router";
import { TopBarService } from "@app/shared/components/top-bar/top-bar.service";

import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class RegroupingService {
  constructor(private _topBarService: TopBarService) {}

  /**
   * Resolver
   *
   * @param {ActivatedRouteSnapshot} route
   * @returns {Observable<any> | Promise<any> | any}
   */
  resolve(route: ActivatedRouteSnapshot): Observable<any> | Promise<any> | any {
    const sfrRegroupementQueryParam = route.queryParams.sfr_regroupements;
    const alarmIdForGrouping = route.queryParams.relatedAlarmId;
    this._topBarService.availableRegroupings = sfrRegroupementQueryParam
      ? sfrRegroupementQueryParam.split(",")
      : [];

    this._topBarService.alarmIdForGrouping = alarmIdForGrouping;
    return new Promise((resolve, reject) => {
      Promise.all([]).then(() => {
        resolve(true);
      }, reject);
    });
  }
}
