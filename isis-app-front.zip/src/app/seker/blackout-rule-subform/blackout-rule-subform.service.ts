import { Injectable } from "@angular/core";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ValidationErrors,
  Validators,
} from "@angular/forms";
import { IsisUtilsService } from "@app/service/isis-utils.service";
import { SirocoRefNameAutocompleteService } from "@app/shared/components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.service";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import { BlackoutRule } from "@app/shared/models/blackout";
import {
  BlackoutRuleForm,
  SubformBlackoutRule,
} from "../blackout-details/blackout-details.model";

@Injectable({ providedIn: "root" })
export class BlackoutRuleSubFormService {
  constructor(
    private _sirocoRefNameAutocompleteService: SirocoRefNameAutocompleteService,
    private _isisUtilsService: IsisUtilsService
  ) {}

  initBlackoutRuleFormGroup(): FormGroup<BlackoutRuleForm> {
    return new FormGroup<BlackoutRuleForm>(
      {
        sfrRefClarify:
          this._sirocoRefNameAutocompleteService.buildSirocoRefNameFormGroup(
            true
          ),
        host: this._sirocoRefNameAutocompleteService.buildSirocoRefNameFormGroup(
          false
        ),
        sfrSource: new FormControl("", [Validators.minLength(3)]),
        parameter: new FormControl("", [Validators.minLength(2)]),
        supervisedObject: new FormControl("", [Validators.minLength(2)]),
        supervisionDomain: new FormControl("", [Validators.minLength(2)]),
      },
      {
        validators: [this._atLeastOneFieldFulfilled],
      }
    );
  }

  getValueToPatchFromBlackoutRule(
    blackoutRule: BlackoutRule
  ): SubformBlackoutRule {
    const sirocoAutocompleteSfrRefClarify =
      this._sirocoRefNameAutocompleteService.getAutocompleteInputValue(
        blackoutRule.sfrRefClarify,
        blackoutRule.sfrRefClarifyName
      );
    const sirocoAutocompleteHost =
      this._sirocoRefNameAutocompleteService.getAutocompleteInputValue(
        blackoutRule.host,
        blackoutRule.hostName
      );
    return {
      sfrRefClarify: {
        sirocoRefNameAuto: sirocoAutocompleteSfrRefClarify,
        sirocoRef: sirocoAutocompleteSfrRefClarify?.id,
        sirocoName: sirocoAutocompleteSfrRefClarify?.name,
      },
      host: {
        sirocoRefNameAuto: sirocoAutocompleteHost,
        sirocoRef: sirocoAutocompleteHost?.id,
        sirocoName: sirocoAutocompleteHost?.name,
      },
      sfrSource: this._isisUtilsService.getStringValueOrEmpty(
        blackoutRule.sfrSource
      ),
      parameter: this._isisUtilsService.getStringValueOrEmpty(
        blackoutRule.parameter
      ),
      supervisedObject: this._isisUtilsService.getStringValueOrEmpty(
        blackoutRule.supervisedObject
      ),
      supervisionDomain: this._isisUtilsService.getStringValueOrEmpty(
        blackoutRule.supervisionDomain
      ),
    };
  }

  getBlackoutRuleFromSubFormBlackoutRule(
    subformBlackoutRule: SubformBlackoutRule
  ): BlackoutRule {
    const { sfrRefClarify, host, ...restRule } = subformBlackoutRule;
    return {
      sfrRefClarify: sfrRefClarify?.sirocoRef?.length
        ? sfrRefClarify?.sirocoRef
        : undefined,
      sfrRefClarifyName: sfrRefClarify?.sirocoName?.length
        ? sfrRefClarify.sirocoName
        : undefined,
      host: host?.sirocoRef?.length ? host?.sirocoRef : undefined,
      hostName: host?.sirocoName?.length ? host.sirocoName : undefined,
      sfrSource: restRule?.sfrSource
        ? this._isisUtilsService.getStringValueOrUndefined(restRule.sfrSource)
        : undefined,
      parameter: restRule?.parameter
        ? this._isisUtilsService.getStringValueOrUndefined(restRule.parameter)
        : undefined,
      supervisedObject: restRule?.supervisedObject
        ? this._isisUtilsService.getStringValueOrUndefined(
            restRule.supervisedObject
          )
        : undefined,
      supervisionDomain: restRule?.supervisionDomain
        ? this._isisUtilsService.getStringValueOrUndefined(
            restRule.supervisionDomain
          )
        : undefined,
    };
  }

  private _atLeastOneFieldFulfilled(
    control: AbstractControl
  ): ValidationErrors | null {
    const formGroup = control as FormGroup<BlackoutRuleForm>;

    const autocompleteKeys = ["sfrRefClarify", "host"];

    const fieldFulfilled = Object.keys(formGroup.controls).find(
      (keyControlName) => {
        const controlValue = formGroup.controls[keyControlName].value;
        if (autocompleteKeys.includes(keyControlName)) {
          return controlValue?.sirocoRef?.length;
        } else {
          return controlValue?.trim() !== "";
        }
      }
    );
    // clear error 'requiredOneFieldFulfilled' of each formControl if at least one fulfilled
    if (fieldFulfilled) {
      Object.keys(formGroup.controls).map((keyControlName) => {
        const errors = formGroup.controls[keyControlName].errors;
        if (errors?.requiredOneFieldFulfilled) {
          formGroup.controls[keyControlName].setErrors(null);
          if (autocompleteKeys.includes(keyControlName)) {
            (formGroup.controls[`${keyControlName}`] as FormGroup).controls[
              "sirocoRefNameAuto"
            ].setErrors(null);
          }
        } else {
          // do nothing
        }
      });
      return null;
    } else {
      // set error 'requiredOneFieldFulfilled' on each formControl if no one fulfilled
      const error: ValidationErrors = {
        requiredOneFieldFulfilled: {
          value: true,
          message: constValidatorsErrorMessages.AT_LEAST_ONE_FIELD,
        },
      };
      Object.keys(formGroup.controls).map((keyControlName) => {
        const formControl = formGroup.controls[keyControlName];
        formControl.setErrors(error);
        if (autocompleteKeys.includes(keyControlName)) {
          (formGroup.controls[`${keyControlName}`] as FormGroup).controls[
            "sirocoRefNameAuto"
          ].setErrors(error);
        }
      });
      return error;
    }
  }
}
