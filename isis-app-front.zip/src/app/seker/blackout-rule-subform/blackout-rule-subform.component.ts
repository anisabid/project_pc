import {
  Component,
  forwardRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import {
  AbstractControl,
  ControlValueAccessor,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  Validator,
  FormGroup,
} from "@angular/forms";
import { Subject, map, takeUntil } from "rxjs";
import { BlackoutRuleSubFormService } from "./blackout-rule-subform.service";
import { ValidationErrors } from "@angular/forms";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import {
  BlackoutRuleForm,
  SubformBlackoutRule,
} from "../blackout-details/blackout-details.model";

@Component({
  selector: "app-blackout-rule-subform",
  templateUrl: "./blackout-rule-subform.component.html",
  styleUrls: ["./blackout-rule-subform.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => BlackoutRuleSubformComponent),
      multi: true,
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => BlackoutRuleSubformComponent),
      multi: true,
    },
  ],
})
export class BlackoutRuleSubformComponent
  implements OnInit, OnChanges, OnDestroy, ControlValueAccessor, Validator
{
  ruleLabels = {
    REF_ITEM: "REF_Item",
    HOST: "Host",
    SFR_SOURCE: "SFR source",
    PARAMETER: "Paramètre",
    SUPERVISED_OBJECT: "Objet supervisé",
    SUPERVISION_DOMAIN: "Domaine supervision",
  };
  errorMessages = constValidatorsErrorMessages;
  blackoutRuleFormGroup: FormGroup<BlackoutRuleForm>;
  private _needUnsubscribe$ = new Subject<boolean>();

  sfrRefClarifyAutocompleteId = "sfrRefClarifyAutocompleteId";
  hostAutocompleteId = "hostAutocompleteId";

  @Input() ruleLineNumber = 0;

  constructor(
    private _blackoutRuleSubformService: BlackoutRuleSubFormService
  ) {}

  ngOnInit(): void {
    this.blackoutRuleFormGroup =
      this._blackoutRuleSubformService.initBlackoutRuleFormGroup();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes?.ruleLineNumber?.currentValue + 1) {
      this.sfrRefClarifyAutocompleteId = `sfrRefClarifyAutocompleteId-${changes.ruleLineNumber.currentValue}`;
      this.hostAutocompleteId = `hostAutocompleteId-${changes.ruleLineNumber.currentValue}`;
    }
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  onAutocompleteTouched(): void {
    this.blackoutRuleFormGroup.markAllAsTouched();
  }

  onBlurRuleInputs(event: Event, formControlName: string): void {
    const formControl: AbstractControl =
      this.blackoutRuleFormGroup.controls[formControlName];
    if (formControl.value?.length) {
      this.blackoutRuleFormGroup.controls[formControlName].patchValue(
        ((event.target as HTMLInputElement).value as string).trimEnd()
      );
    }
    this.blackoutRuleFormGroup.markAllAsTouched();
  }

  removeFirstWhiteSpaces(event: Event, formControlName: string): void {
    const formControl: AbstractControl =
      this.blackoutRuleFormGroup.controls[formControlName];
    if (formControl.value?.length) {
      this.blackoutRuleFormGroup.controls[formControlName].patchValue(
        ((event.target as HTMLInputElement).value as string).trimStart()
      );
    }
  }

  // for interface ControlValueAccessor
  private _onTouched: () => void = () => {
    // do nothing
  };
  private _onChange: () => void = () => {
    // do nothing
  };

  // eslint-disable-next-line
  registerOnChange(fn: any): void {
    this.blackoutRuleFormGroup.valueChanges
      .pipe(
        takeUntil(this._needUnsubscribe$),
        map((res) => {
          return res;
        })
      )
      .subscribe(fn);
  }

  // Note: This method is used to init the values of the formGroup.
  writeValue(value: SubformBlackoutRule): void {
    if (value) {
      this.blackoutRuleFormGroup.patchValue(value);
      // to allow display error message on init if the form is initialized with existing data.
      this.blackoutRuleFormGroup.markAllAsTouched();
    }
  }

  // eslint-disable-next-line
  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    isDisabled
      ? this.blackoutRuleFormGroup.disable()
      : this.blackoutRuleFormGroup.enable();
  }

  // for interface Validator
  validate(): ValidationErrors | null {
    // Note: This method could be used also to return a specific error
    // message to a parent form.
    return this.blackoutRuleFormGroup.valid
      ? null
      : ({
          ruleSubFormInError: true,
        } as ValidationErrors);
  }

  registerOnValidatorChange(fn: () => void): void {
    this._onChange = fn;
  }
}
