import { Component, OnDestroy, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import {
  CustomTableColumn,
  CustomTableItem,
  CustomTablePage,
  CustomTableRequestedPageMeta,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { BlackoutTableItem } from "../blackout-list/blackout-list.model";
import { BlackoutTypeEnum } from "@app/shared/models/blackout";
import { Observable, Subject, takeUntil } from "rxjs";
import { SekerHomeService } from "./seker-home.service";
import { take } from "rxjs";
import { SekerUtilsService } from "../seker.utils.service";

@Component({
  selector: "app-seker-home",
  templateUrl: "./seker-home.component.html",
  styleUrls: ["./seker-home.component.scss"],
})
export class SekerHomeComponent implements OnInit, OnDestroy {
  selectedBlackoutItems = [];

  isBlackoutListSelectable: boolean;
  availableBlackoutTableColumns: CustomTableColumn[];
  selectedColumnRefIds: string[];
  blackoutTablePage$: Observable<CustomTablePage>;

  isLoadingResults = true;

  hasItemsSelected = false;

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _router: Router,
    private _sekerHomeService: SekerHomeService,
    private _sekerUtilsService: SekerUtilsService
  ) {}

  ngOnInit(): void {
    this.isBlackoutListSelectable =
      this._sekerUtilsService.hasRightsToEditBlackout();
    this.availableBlackoutTableColumns =
      this._sekerHomeService.buildBlackoutTableColumns(
        this.isBlackoutListSelectable
      );
    this.selectedColumnRefIds =
      this._sekerHomeService.getSelectedColumnsFromStorage();
    this.blackoutTablePage$ = this._sekerHomeService.blackoutTablePage$;
    this._sekerHomeService.onRefreshProcessing$
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((isProcessing: boolean) => {
        this.isLoadingResults = isProcessing;
      });
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  exportBlackoutList(): void {
    this._sekerHomeService.exportBlackoutListItems(this.selectedBlackoutItems);
  }

  deleteBlackoutList(): void {
    this._sekerHomeService
      .deleteBlackoutListItems(this.selectedBlackoutItems)
      .pipe(takeUntil(this._needUnsubscribe$), take(1))
      .subscribe();
  }

  refreshBlackoutList(event?: Partial<CustomTableRequestedPageMeta>): void {
    const newCriteriaForBlackoutSearch = event;
    newCriteriaForBlackoutSearch
      ? this._sekerHomeService.refreshBlackoutListItems(
          newCriteriaForBlackoutSearch
        )
      : this._sekerHomeService.refreshBlackoutListItems();
  }

  navigateToBlackoutDetails(idBlackout: string): void {
    this._router.navigate(["inhibitions/blackout", idBlackout]);
  }

  updateDisplayedColumns(columnRefIds: string[]): void {
    this.selectedColumnRefIds = columnRefIds;
    this._sekerHomeService.updateLocalStorageSekerColumns(
      this.selectedColumnRefIds
    );
  }

  onBlackoutSelectedItems(event: CustomTableItem[]): void {
    const selectedItemList = [...event];
    this.selectedBlackoutItems = selectedItemList.map(
      (item: BlackoutTableItem) => {
        return {
          _id: item._id,
          status: item.status,
          type: item.typeLabel,
          startDateTime:
            item.type === BlackoutTypeEnum.REPETITIVE
              ? item.startDateTime
              : this._getFormattedDateTime(item.startDateTime),
          endDateTime:
            item.type === BlackoutTypeEnum.REPETITIVE
              ? item.endDateTime
              : this._getFormattedDateTime(item.endDateTime),
          startRealDateTime: this._getFormattedDateTime(item.startRealDateTime),
          endRealDateTime: this._getFormattedDateTime(item.endRealDateTime),
          requesterUpperId: item.requesterUpperId,
          lastUpdatedRequesterUpperId: item.lastUpdatedRequesterUpperId?.length
            ? item.lastUpdatedRequesterUpperId
            : "",
          actor: item.actor?.length ? item.actor : "",
          phoneActor: item.phoneActor?.length ? item.phoneActor : "",
          eventReference: item.eventReference,
          description: item.description,
          comment: item.comment?.length ? item.comment : "",
          rules: item.requestedRules,
        };
      }
    );
    this.hasItemsSelected = Boolean(
      this.selectedBlackoutItems && this.selectedBlackoutItems.length
    );
  }

  private _getFormattedDateTime(dateTime?: number) {
    return dateTime
      ? this._sekerUtilsService.formatDateWithoutSeconds(dateTime)
      : "";
  }
}
