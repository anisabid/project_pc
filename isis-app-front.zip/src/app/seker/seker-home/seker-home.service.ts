import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import {
  ColumnTypeEnum,
  CustomTableColumn,
  CustomTablePage,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { CustomSelectableTableBaseService } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.service";
import { SirocoRefNameAutocompleteService } from "@app/shared/components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.service";
import { AlarmAvancedSearchPrefix } from "@app/shared/models/alarm";
import {
  Blackout,
  BlackoutPage,
  BlackoutRule,
  BlackoutSearchCriteria,
  BlackoutStatusEnum,
  BlackoutTypeEnum,
  DEFAULT_BLACKOUT_SEARCH_CRITERIA,
} from "@app/shared/models/blackout";
import { SirocoRefName } from "@app/shared/models/siroco-ref-name";
import { BlackoutApiService } from "@app/shared/services/api/v2/microservices/blackout-api.service";
import { ExportService } from "@app/shared/services/export/export.service";
import { ToastrService } from "ngx-toastr";
import {
  BehaviorSubject,
  Observable,
  of,
  catchError,
  map,
  switchMap,
  tap,
  throwError,
  forkJoin,
  from,
} from "rxjs";
import {
  ActionTableItem,
  BlackoutTableItem,
  ConstColorBlackoutStatus,
  constEmptyBlackoutTablePage,
} from "../blackout-list/blackout-list.model";
import { SekerUtilsService } from "../seker.utils.service";

@Injectable({ providedIn: "root" })
export class SekerHomeService {
  private _onRequestedRefreshBehaviorSubject: BehaviorSubject<BlackoutSearchCriteria>;

  private _onRefreshProcessingBehaviorSubject: BehaviorSubject<boolean> =
    new BehaviorSubject(false);
  onRefreshProcessing$: Observable<boolean>;

  blackoutTablePage$: Observable<CustomTablePage>;
  private _currentSearchCriteria: BlackoutSearchCriteria;
  private _confirmDeleteLabel =
    "Etes-vous sûr de vouloir supprimer ces inhibitions ?";
  private _irreversibleActionLabel = "(Cette action est irréversible.)";

  constructor(
    private _blackoutApiService: BlackoutApiService,
    private _toastrService: ToastrService,
    private _exportService: ExportService,
    private _sekerUtilsService: SekerUtilsService,
    private _router: Router,
    private _customSelectableTableBaseService: CustomSelectableTableBaseService,
    private _confirmDialogService: ConfirmDialogService,
    private _sirocoRefNameAutocompleteService: SirocoRefNameAutocompleteService
  ) {
    this._currentSearchCriteria = this.getSearchCriteriaForInit();
    this._onRequestedRefreshBehaviorSubject = new BehaviorSubject(
      this._currentSearchCriteria
    );
    this.onRefreshProcessing$ =
      this._onRefreshProcessingBehaviorSubject.asObservable();
    this.blackoutTablePage$ = this._onRequestedRefreshBehaviorSubject.pipe(
      switchMap((criteria: BlackoutSearchCriteria) => {
        return this._getBlackoutTablePage(criteria);
      })
    );
  }

  private _getBlackoutTablePage(
    criteria?: BlackoutSearchCriteria
  ): Observable<CustomTablePage> {
    this._onRefreshProcessingBehaviorSubject.next(true);
    const blackoutPages$: Observable<BlackoutPage> =
      this._blackoutApiService.getBlackoutPageByCriteria(criteria);
    return blackoutPages$.pipe(
      map((blackoutPage: BlackoutPage) => {
        return {
          page: blackoutPage.number,
          numberOfElements: blackoutPage.numberOfElements,
          size: blackoutPage.size,
          totalPages: blackoutPage.totalPages,
          totalElements: blackoutPage.totalElements,
          customTableItems: this._buildBlackoutTableItems(
            blackoutPage.content as Blackout[]
          ),
        };
      }),
      tap(() => {
        this._onRefreshProcessingBehaviorSubject.next(false);
      }),
      catchError(() => {
        this._toastrService.error("Une erreur est survenue !");
        this._onRefreshProcessingBehaviorSubject.next(false);
        return of(constEmptyBlackoutTablePage);
      })
    );
  }

  getSearchCriteriaForInit(): BlackoutSearchCriteria {
    const searchCriteriaFromLocalStorage = localStorage.getItem("filter_seker")
      ? JSON.parse(localStorage.getItem("filter_seker"))
      : null;
    return searchCriteriaFromLocalStorage
      ? Object.assign(
          { ...DEFAULT_BLACKOUT_SEARCH_CRITERIA },
          searchCriteriaFromLocalStorage
        )
      : DEFAULT_BLACKOUT_SEARCH_CRITERIA;
  }

  getSelectedColumnsFromStorage(): string[] {
    return this._customSelectableTableBaseService.getSelectedColumnsFromStorage(
      "columns_seker"
    );
  }

  refreshBlackoutListItems(newCriteria?: BlackoutSearchCriteria): void {
    this._currentSearchCriteria = this._buildCurrentSearchCriteria(newCriteria);
    this._updateLocalStorageFilterSeker(this._currentSearchCriteria);
    this._onRequestedRefreshBehaviorSubject.next(this._currentSearchCriteria);
  }

  buildBlackoutTableColumns(withSelectColumn: boolean): CustomTableColumn[] {
    // TECH NOTE: referenceId should have the same name as the attribute to allow sorting
    return [
      {
        referenceId: "status",
        label: "Statut",
        width: withSelectColumn ? "60px" : "66px",
        type: ColumnTypeEnum.BADGE,
        isSelectable: false,
        isSortable: true,
      },
      {
        referenceId: "lastUpperId",
        label: "Uid",
        tooltip: "Upperid",
        width: "75px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "startDateTime",
        label: "Début prévu le",
        tooltip: "Date et/ou heure de début prévues",
        width: "110px",
        type: ColumnTypeEnum.DATE_TIME,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "endDateTime",
        label: "Fin prévue le",
        tooltip: "Date et/ou heure de fin prévues",
        width: "110px",
        type: ColumnTypeEnum.DATE_TIME,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "startRealDateTime",
        label: "Déclenché le",
        tooltip: "Date et heure de déclenchement",
        width: "110px",
        type: ColumnTypeEnum.DATE_TIME,
        isSelectable: true,
        selectedByDefault: false,
        isSortable: true,
      },
      {
        referenceId: "endRealDateTime",
        label: "Clos/Annulé le",
        tooltip: "Date et heure de clôture ou d'annulation",
        width: "110px",
        type: ColumnTypeEnum.DATE_TIME,
        isSelectable: true,
        selectedByDefault: false,
        isSortable: true,
      },
      {
        referenceId: "description",
        label: "Description",
        width: "150px",
        type: ColumnTypeEnum.LONG_TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "comment",
        label: "Commentaires",
        width: "150px",
        type: ColumnTypeEnum.LONG_TEXT,
        isSelectable: true,
        selectedByDefault: false,
        isSortable: true,
      },
      {
        referenceId: "eventReference",
        label: "REF blackout",
        tooltip: "Référence de l'évènement déclencheur",
        width: "200px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "actor",
        label: "Demandeur",
        width: "120px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "requestedRules",
        label: "Inhibitions demandées",
        width: "150px",
        type: ColumnTypeEnum.LONG_TEXT,
        isSelectable: true,
        selectedByDefault: true,
      },
      {
        referenceId: "typeLabel",
        label: "Type",
        width: "100px",
        type: ColumnTypeEnum.TEXT,
        isSelectable: true,
        selectedByDefault: true,
        isSortable: true,
      },
      {
        referenceId: "actionTableItems",
        label: "Alarmes",
        width: "80px",
        type: ColumnTypeEnum.ACTIONS,
        isSelectable: true,
        selectedByDefault: false,
      },
    ];
  }

  private _buildSortFieldNameCriteria(sortField: string): string {
    let sortFieldName: string;
    switch (sortField) {
      case "lastUpperId": {
        sortFieldName = "requesterUpperId";
        break;
      }
      case "typeLabel": {
        sortFieldName = "type";
        break;
      }
      case "requestedRules": {
        sortFieldName = "rules";
        break;
      }
      default: {
        sortFieldName = sortField;
        break;
      }
    }
    return sortFieldName;
  }

  exportBlackoutListItems(blackoutTableItems: BlackoutTableItem[]): void {
    this._onRefreshProcessingBehaviorSubject.next(true);
    this._exportService.downloadFile(blackoutTableItems, "csv", "blackouts");
    this._onRefreshProcessingBehaviorSubject.next(false);
  }

  deleteBlackoutListItems(
    blackoutTableItems: BlackoutTableItem[]
  ): Observable<Blackout[] | BlackoutTableItem[]> {
    return from(
      this._confirmDialogService.confirm(
        this._confirmDeleteLabel,
        this._irreversibleActionLabel
      )
    ).pipe(
      switchMap((confirmed: boolean) => {
        if (confirmed) {
          this._onRefreshProcessingBehaviorSubject.next(true);
          // Tech note: this method returns null when success.
          const blackoutToDeletes$: Observable<Blackout>[] =
            blackoutTableItems.map(
              (blackoutTableItemToDelete: BlackoutTableItem) => {
                return this._blackoutApiService.deleteBlackout(
                  blackoutTableItemToDelete._id
                );
              }
            );
          return forkJoin(blackoutToDeletes$).pipe(
            tap(() => {
              this._toastrService.success(
                "Les inhibitions ont été supprimées avec succès !"
              );
              this.refreshBlackoutListItems();
              this._onRefreshProcessingBehaviorSubject.next(false);
            }),
            catchError((error) => {
              this._toastrService.error(
                error.isisCode
                  ? error.isisMessage
                  : "Erreur lors de la suppression des inhibitions !"
              );
              this._onRefreshProcessingBehaviorSubject.next(false);
              return throwError(() => error);
            })
          );
        } else {
          this._toastrService.error(
            "Les inhibitions n'ont pas été supprimées."
          );
          return of(blackoutTableItems);
        }
      }),
      catchError((error) => {
        return throwError(() => error);
      })
    );
  }

  updateLocalStorageSekerColumns(selectedColumns: string[]): void {
    this._customSelectableTableBaseService.updateSelectedColumnsIntoLocalStorage(
      selectedColumns,
      "columns_seker"
    );
  }

  private _updateLocalStorageFilterSeker(filter: BlackoutSearchCriteria): void {
    const { page, ...searchCriteriaWithoutPage } = filter;
    localStorage.setItem(
      "filter_seker",
      JSON.stringify(searchCriteriaWithoutPage)
    );
  }

  private _buildBlackoutTableItems(blackouts: Blackout[]): BlackoutTableItem[] {
    const items: BlackoutTableItem[] = blackouts.map((blackout: Blackout) => {
      const blackoutStatus = blackout.status;
      return <BlackoutTableItem>{
        ...blackout,
        startDateTime:
          blackout.type === BlackoutTypeEnum.REPETITIVE
            ? this._sekerUtilsService.formatTimeForTimeInput(
                blackout.repetitions[0].startHour
              )
            : blackout.startDateTime,
        endDateTime:
          blackout.type === BlackoutTypeEnum.REPETITIVE
            ? this._sekerUtilsService.formatTimeForTimeInput(
                blackout.repetitions[0].endHour
              )
            : blackout.endDateTime,
        startRealDateTime:
          !blackout.startRealDateTime || blackout.startRealDateTime === 0
            ? undefined
            : blackout.startRealDateTime,
        endRealDateTime:
          !blackout.endRealDateTime || blackout.endRealDateTime === 0
            ? undefined
            : blackout.endRealDateTime,
        typeLabel: this._sekerUtilsService.getBlackoutTypeLabel(blackout.type),
        lastUpperId: blackout.lastUpdatedRequesterUpperId
          ? blackout.lastUpdatedRequesterUpperId
          : blackout.requesterUpperId,
        requestedRules: blackout.rules.length
          ? this._getRequestedRules(blackout.rules)
          : "",
        colorDescription: ConstColorBlackoutStatus[blackoutStatus]
          ? ConstColorBlackoutStatus[blackoutStatus]
          : ConstColorBlackoutStatus.CANCELLED,
        actionTableItems: this._buildActionTableItems(blackout),
      };
    });
    return items;
  }

  private _getSfrRefClarifyOrHostToDisplayInTable(
    rule: BlackoutRule,
    attributeName: string
  ): string {
    const sirocoRefName: SirocoRefName =
      this._sirocoRefNameAutocompleteService.getAutocompleteInputValue(
        rule[`${attributeName}`],
        rule[`${attributeName}Name`]
      );

    return sirocoRefName?.id?.length && sirocoRefName?.name?.length
      ? `${sirocoRefName.name} (${sirocoRefName.id})`
      : sirocoRefName?.id?.length
      ? sirocoRefName.id
      : undefined;
  }

  private _getRequestedRules(blackoutRules: BlackoutRule[]): string {
    if (!blackoutRules.length) return "";
    const ruleInLines = blackoutRules.map((rule: BlackoutRule) => {
      let ruleInline = "";
      Object.keys(rule).map((attributeName: string) => {
        const attributeValue = rule[`${attributeName}`];

        const isSfrRefClarifyOrHost =
          attributeName === "sfrRefClarify" || attributeName === "host";

        const isAttributeToDisplay =
          attributeName !== "sfrRefClarifyName" &&
          attributeName !== "hostName" &&
          attributeValue?.length;

        const ruleInlineElement = isSfrRefClarifyOrHost
          ? this._getSfrRefClarifyOrHostToDisplayInTable(rule, attributeName)
          : isAttributeToDisplay
          ? attributeValue
          : undefined;

        if (ruleInlineElement) {
          ruleInline =
            ruleInline !== ""
              ? ruleInline.concat(`, ${ruleInlineElement}`)
              : ruleInline.concat(ruleInlineElement);
        }
        return ruleInline;
      });
      return `[${ruleInline}]`;
    });

    return ruleInLines.join("  ");
  }

  private _buildCurrentSearchCriteria(
    newCriteria: BlackoutSearchCriteria
  ): BlackoutSearchCriteria {
    const updatedCriteria = Object.assign(
      { ...this._currentSearchCriteria },
      newCriteria
    );

    return newCriteria && newCriteria.sortField
      ? {
          ...updatedCriteria,
          sortField: this._buildSortFieldNameCriteria(newCriteria.sortField),
        }
      : updatedCriteria;
  }

  private _buildActionTableItems(blackout: Blackout): ActionTableItem[] {
    const actionTableItems = [];
    if (blackout.status === BlackoutStatusEnum.IN_PROGRESS) {
      actionTableItems.push({
        iconButtonName: "notifications",
        iconButtonTooltip:
          blackout.alarmCount === 0
            ? "Aucune alarme associée"
            : "Voir les alarmes associées",
        customClass: "see-alarms-button",
        badgeValue: blackout.alarmCount,
        isButtonDisabled: blackout.alarmCount === 0,
        onClickFunction: this._storeIdAndGoToAlarms,
        argumentsOnClick: {
          eventRef: blackout.eventReference,
          blackoutId: blackout._id,
        },
      });
    }
    return actionTableItems;
  }

  private _storeIdAndGoToAlarms = (args: Record<string, string>) => {
    const eventReference = args["eventRef"];
    const blackoutId = args["blackoutId"];

    if (eventReference && blackoutId) {
      const localStorageFG = localStorage.getItem("filter_fg")
        ? JSON.parse(localStorage.getItem("filter_fg"))
        : null;

      const newSearchItems = [
        `${AlarmAvancedSearchPrefix.REF_BLACKOUT} ${eventReference}`,
      ];
      const updatedLocalStorageFg = localStorageFG
        ? {
            ...localStorageFG,
            search: newSearchItems,
            dates: {
              begin: null,
              end: null,
            },
            severity: {
              CRITICAL: false,
              INFO: false,
              MAJOR: false,
              OK: false,
              UNKNOWN: false,
              WARNING: false,
            },
            states: {
              ACQUITTED_WITHOUT_TICKET: false,
              ACQUITTED_WITH_MEP: false,
              ACQUITTED_WITH_TICKET: false,
              BLACKOUT: false,
              CLOSED: false,
              OPEN: false,
            },
          }
        : { search: newSearchItems };

      localStorage.setItem("filter_fg", JSON.stringify(updatedLocalStorageFg));
      localStorage.setItem("blackout_id", JSON.stringify(blackoutId));
      localStorage.removeItem("alarm_ids");
      this._router.navigate(["alarms/si/all"]);
    } else {
      //do nothing.
    }
  };
}
