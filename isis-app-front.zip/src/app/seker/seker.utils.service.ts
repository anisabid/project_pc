import { DatePipe } from "@angular/common";
import { Injectable } from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { BlackoutTypeEnum } from "@app/shared/models/blackout";
import { IsisRole } from "@app/shared/models/user";

@Injectable({ providedIn: "root" })
export class SekerUtilsService {
  constructor(
    private _datePipe: DatePipe,
    private _securityService: KeycloakSecurityService
  ) {}

  getBlackoutTypeLabel(blackoutType: BlackoutTypeEnum | string): string {
    if (blackoutType === BlackoutTypeEnum.INCIDENT) {
      return "Incident";
    }
    if (blackoutType === BlackoutTypeEnum.MEP) {
      return "MEP";
    }
    if (blackoutType === BlackoutTypeEnum.ORDONNANCEUR) {
      return "Ordonnanceur";
    }
    if (blackoutType === BlackoutTypeEnum.REPETITIVE) {
      return "Répétitif";
    }
  }

  toStringListSeparatedByComma(stringArray: string[]): string {
    return stringArray && stringArray.length
      ? stringArray.reduce((previousValue: string, currentValue: string) => {
          return `${previousValue},${currentValue}`;
        })
      : undefined;
  }

  formatTimeForTimeInput(timeInMs: number): string {
    const timeInHours = timeInMs / 3600000;
    const hoursPart = Math.floor(timeInHours);
    const minutesPart = Math.floor((timeInMs * 60) / 3600000 - hoursPart * 60); // keep this calculus to avoid bad rounded values.
    const formattedHours = hoursPart < 10 ? `0${hoursPart}` : `${hoursPart}`;
    const formattedMinutes =
      minutesPart < 10 ? `0${minutesPart}` : `${minutesPart}`;
    return `${formattedHours}:${formattedMinutes}`;
  }

  formatTimeStringInMs(timeString: string): number {
    const timeArray = timeString.split(":");
    return (Number(timeArray[0]) * 3600 + Number(timeArray[1]) * 60) * 1000;
  }

  isValidDate(date: Date): boolean {
    return date instanceof Date && !isNaN(Number(date));
  }

  isValidStringDate(date: string): boolean {
    return this.isValidDate(new Date(date));
  }

  formatDateWithoutSeconds(dateValue: string | number | Date): string {
    return this._datePipe.transform(dateValue, "yyyy-MM-dd HH:mm");
  }

  hasRightsToEditBlackout(): boolean {
    return (
      this._securityService.hasRequiredRole(IsisRole.admin) ||
      this._securityService.hasRequiredRole(IsisRole.supervisor) ||
      this._securityService.hasRequiredRole(IsisRole.isis_blackout)
    );
  }
}
