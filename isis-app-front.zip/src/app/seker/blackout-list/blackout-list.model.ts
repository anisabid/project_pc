import {
  CustomTableItem,
  CustomTablePage,
  CUSTOM_TABLE_PAGE_SIZE_OPTIONS,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import {
  ColorBaseType,
  ColorDescription,
} from "@app/shared/consts/color-alarms";
import { Blackout } from "@app/shared/models/blackout";

export interface ActionTableItem {
  iconButtonName?: string;
  iconButtonTooltip?: string;
  badgeValue?: number;
  onClickFunction?: (args: Record<string, string>) => void;
  argumentsOnClick?: Record<string, string>;
}

export interface BlackoutTableItem extends Blackout, CustomTableItem {
  typeLabel: string;
  lastUpperId: string;
  requestedRules: string;
  colorDescription: ColorDescription;
  actionTableItems?: ActionTableItem[];
}

export const constEmptyBlackoutTablePage: CustomTablePage = {
  customTableItems: [],
  page: 0,
  size: CUSTOM_TABLE_PAGE_SIZE_OPTIONS[1],
  numberOfElements: 0,
  totalPages: 0,
  totalElements: 0,
};

export interface ColorBlackoutStatus extends ColorBaseType {
  PREPARED: ColorDescription;
  IN_PROGRESS: ColorDescription;
  CLOSED: ColorDescription;
  CANCELLED: ColorDescription;
}

export const ConstColorBlackoutStatus: ColorBlackoutStatus = {
  PREPARED: new ColorDescription({
    label: "Préparé",
    color: "#4CAF50",
    icon: "check_circle",
    background: "#f8fff9",
    text_color: "#fff",
  }),
  IN_PROGRESS: new ColorDescription({
    label: "En cours",
    color: "#2979FF",
    icon: "error_outline",
    background: "#eff5fb",
    text_color: "#fff",
  }),
  CLOSED: new ColorDescription({
    label: "Clos",
    color: "#ff1744",
    icon: "highlight_off",
    background: "#fff3f2",
    text_color: "#fff",
  }),
  CANCELLED: new ColorDescription({
    label: "Annulé",
    color: "#ffd218",
    icon: "not_interested",
    background: "#fffef3",
    text_color: "#fff",
  }),
};
