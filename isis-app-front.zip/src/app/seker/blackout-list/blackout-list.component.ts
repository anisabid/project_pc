import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { CustomSelectableTableBaseComponent } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.component";
import { BlackoutTableItem } from "./blackout-list.model";

@Component({
  selector: "app-blackout-list",
  templateUrl: "./blackout-list.component.html",
  styleUrls: ["./blackout-list.component.scss"],
})
export class BlackoutListComponent extends CustomSelectableTableBaseComponent {
  loadingLabel = {
    noResults: "Aucune inhibition !",
  };

  constructor(private _router: Router) {
    super();
  }

  navigateToBlackoutDetails(blackoutTableItem: BlackoutTableItem): void {
    this._router.navigate(["inhibitions/blackout", blackoutTableItem._id]);
  }
}
