import { Injectable } from "@angular/core";
import { CanActivate, Router, UrlTree } from "@angular/router";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";
import { ToastrService } from "ngx-toastr";

@Injectable({ providedIn: "root" })
export class CanActivateCreateBlackout implements CanActivate {
  constructor(
    private _toastrService: ToastrService,
    private _securityService: KeycloakSecurityService,
    private _router: Router
  ) {}

  canActivate(): boolean | UrlTree {
    const hasRole =
      this._securityService.hasRequiredRole(IsisRole.admin) ||
      this._securityService.hasRequiredRole(IsisRole.supervisor) ||
      this._securityService.hasRequiredRole(IsisRole.isis_blackout);
    if (!hasRole) {
      this._toastrService.error(this._securityService.accessErrorMessage);
      return this._router.parseUrl("inhibitions/home");
    }
    return hasRole;
  }
}
