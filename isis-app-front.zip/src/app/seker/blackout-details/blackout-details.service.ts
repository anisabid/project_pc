import { Injectable } from "@angular/core";
import { FormArray, FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import {
  Blackout,
  BlackoutRepetitiveDayEnum,
  BlackoutRule,
  BlackoutStatusEnum,
  BlackoutTypeEnum,
} from "@app/shared/models/blackout";
import { ToastrService } from "ngx-toastr";
import { Observable, of, catchError } from "rxjs";
import { BlackoutRuleSubFormService } from "../blackout-rule-subform/blackout-rule-subform.service";
import { SekerUtilsService } from "../seker.utils.service";
import {
  BlackoutDetailsForm,
  ERROR_MESSAGE_ON_SUBMIT,
  SubformBlackoutMainInfo,
  SubformBlackoutRule,
} from "./blackout-details.model";
import { BlackoutSubmitActionService } from "./blackout-submit-action/blackout-submit-action.service";
import { SubformBlackoutTypeAndDays } from "./blackout-type-subform/blackout-type-subform.model";

@Injectable({ providedIn: "root" })
export class BlackoutDetailsService {
  savedBlackout$: Observable<Blackout>;
  constructor(
    private _router: Router,
    private _toastrService: ToastrService,
    private _securityService: KeycloakSecurityService,
    private _blackoutSubmitActionService: BlackoutSubmitActionService,
    private _sekerUtilsService: SekerUtilsService,
    private _blackoutRuleSubformService: BlackoutRuleSubFormService
  ) {
    this.savedBlackout$ = this._blackoutSubmitActionService.savedBlackout$;
  }

  initOrUpdateFormGroup(
    formGroup: FormGroup<BlackoutDetailsForm>,
    blackout: Blackout
  ): FormGroup<BlackoutDetailsForm> {
    const needUpdate = !!formGroup;
    return needUpdate
      ? this._updateFormGroup(formGroup, blackout)
      : this._initBlackoutFormGroup(blackout);
  }

  private _initBlackoutFormGroup(
    blackout: Blackout
  ): FormGroup<BlackoutDetailsForm> {
    const blackoutRules =
      blackout && blackout.rules && blackout.rules.length ? blackout.rules : [];
    const formGroup = new FormGroup<BlackoutDetailsForm>({
      blackoutTypeAndDays: this._initTypeAndDaysFormControl(blackout),
      blackoutMainInfo: this._initMainInfoFormControl(blackout),
      blackoutRules: this._initBlackoutRulesFormArray(blackoutRules),
    });
    if (blackout) {
      formGroup.markAllAsTouched();
      if (!this.isFormEditable(blackout)) {
        formGroup.disable();
      }
    }
    return formGroup;
  }

  private _updateFormGroup(
    formGroup: FormGroup<BlackoutDetailsForm>,
    blackout: Blackout
  ): FormGroup<BlackoutDetailsForm> {
    const isDisabledBeforeUpdate = formGroup.disabled;
    const needToBeEnabled = this.isFormEditable(blackout);
    if (blackout) {
      formGroup.markAllAsTouched();
    }
    if (isDisabledBeforeUpdate && needToBeEnabled) {
      formGroup.enable();
    }

    formGroup.setControl(
      "blackoutTypeAndDays",
      this._initTypeAndDaysFormControl(blackout)
    );

    formGroup.setControl(
      "blackoutMainInfo",
      this._initMainInfoFormControl(blackout)
    );
    const blackoutRules = blackout?.rules?.length ? blackout.rules : [];
    formGroup.setControl(
      "blackoutRules",
      this._initBlackoutRulesFormArray(blackoutRules)
    );

    if (!needToBeEnabled) {
      formGroup.disable();
    }
    return formGroup;
  }

  private _initMainInfoFormControl(
    blackout: Blackout
  ): FormControl<SubformBlackoutMainInfo> {
    const mainInfoFormControl = new FormControl<SubformBlackoutMainInfo>(null);
    if (blackout) {
      const valueToSet = this._getSubformBlackoutMainInfoFromBlackout(blackout);
      mainInfoFormControl.patchValue(valueToSet);
    }
    return mainInfoFormControl;
  }

  private _initTypeAndDaysFormControl(
    blackout: Blackout
  ): FormControl<SubformBlackoutTypeAndDays> {
    const typeAndDaysFormControl = new FormControl<SubformBlackoutTypeAndDays>(
      null
    );
    if (blackout) {
      const valueToSet: SubformBlackoutTypeAndDays = {
        selectedType: blackout.type
          ? BlackoutTypeEnum[blackout.type]
          : BlackoutTypeEnum.MEP,
        daysCheckedStatus: this._getRepetitionDaysStatusFromSelectedDays(
          blackout.repetitions ? blackout.repetitions : []
        ),
      };
      typeAndDaysFormControl.patchValue(valueToSet);
    }
    return typeAndDaysFormControl;
  }

  private _getSubformBlackoutMainInfoFromBlackout(
    blackout: Blackout
  ): SubformBlackoutMainInfo {
    const subformBlackoutMainInfo: SubformBlackoutMainInfo = {
      startDateTime:
        !blackout.startDateTime || blackout.startDateTime === 0
          ? undefined
          : new Date(blackout.startDateTime),
      endDateTime:
        !blackout.endDateTime || blackout.endDateTime === 0
          ? undefined
          : new Date(blackout.endDateTime),
      startTime:
        blackout.type === BlackoutTypeEnum.REPETITIVE
          ? this._sekerUtilsService.formatTimeForTimeInput(
              blackout.repetitions[0].startHour
            )
          : undefined,
      endTime:
        blackout.type === BlackoutTypeEnum.REPETITIVE
          ? this._sekerUtilsService.formatTimeForTimeInput(
              blackout.repetitions[0].endHour
            )
          : undefined,
      actor: blackout.actor?.length ? blackout.actor : "",
      phoneActor: blackout.phoneActor?.length ? blackout.phoneActor : "",
      eventReference: blackout.eventReference?.length
        ? blackout.eventReference
        : "",
      description: blackout.description?.length ? blackout.description : "",
      comment: blackout.comment?.length ? blackout.comment : "",
    };
    return subformBlackoutMainInfo;
  }

  private _getRepetitionDaysStatusFromSelectedDays(
    selectedDays: { day: number; startHour?: number; endHour?: number }[]
  ): boolean[] {
    const daysSelectedStatus: boolean[] = Object.keys(
      BlackoutRepetitiveDayEnum
    ).map((key) => {
      if (selectedDays && selectedDays.length) {
        return (
          selectedDays.findIndex(
            (selectedDay) =>
              selectedDay.day === Number(BlackoutRepetitiveDayEnum[key])
          ) !== -1
        );
      } else {
        return false;
      }
    });
    return daysSelectedStatus;
  }

  getBlackoutById(id: string): Observable<Blackout> {
    return this._blackoutSubmitActionService
      .getBlackoutByIdWithProcessingState(id)
      .pipe(
        catchError((error) => {
          if (error?.value?.code === "NO_EXISTING_BLACKOUT") {
            this._router.navigate(["inhibitions/blackout"]);
          }
          return of(null);
        })
      );
  }

  hasRightsToEdit(): boolean {
    return this._sekerUtilsService.hasRightsToEditBlackout();
  }

  isFormEditable(blackout: Blackout): boolean {
    const isCreation = !blackout;
    const isPreparedOrCopiedBlackout =
      blackout &&
      (blackout.status === BlackoutStatusEnum.PREPARED || !blackout._id);
    return this.hasRightsToEdit() && (isCreation || isPreparedOrCopiedBlackout);
  }

  isLaunchedOrCancelledOrClosedBlackout(blackout: Blackout): boolean {
    return (
      Boolean(blackout) &&
      (Boolean(blackout.startRealDateTime) || Boolean(blackout.endRealDateTime))
    );
  }

  initRuleFormControl(
    blackoutRule: BlackoutRule
  ): FormControl<SubformBlackoutRule> {
    const ruleFormControl = new FormControl<SubformBlackoutRule>(
      null,
      Validators.required
    );
    if (blackoutRule) {
      ruleFormControl.patchValue(
        this._blackoutRuleSubformService.getValueToPatchFromBlackoutRule(
          blackoutRule
        )
      );
    }
    return ruleFormControl;
  }

  private _initBlackoutRulesFormArray(
    blackoutRules: BlackoutRule[]
  ): FormArray<FormControl<SubformBlackoutRule>> {
    const formArray = new FormArray<FormControl<SubformBlackoutRule>>([]);
    if (blackoutRules.length) {
      blackoutRules.forEach((blackoutRule: BlackoutRule) => {
        formArray.push(this.initRuleFormControl(blackoutRule));
      });
    } else {
      formArray.push(this.initRuleFormControl(null));
    }
    return formArray;
  }

  buildBlackoutFromFormGroup(
    formGroup: FormGroup<BlackoutDetailsForm>,
    blackoutOnInit?: Blackout
  ): Blackout {
    const blackoutMainInfo = formGroup.controls["blackoutMainInfo"].value;
    const typeAndDays = formGroup.controls["blackoutTypeAndDays"].value;
    const type: BlackoutTypeEnum = typeAndDays?.selectedType
      ? typeAndDays.selectedType
      : BlackoutTypeEnum.MEP;
    const isRepetitive = type === BlackoutTypeEnum.REPETITIVE;
    const ruleControls = formGroup.controls["blackoutRules"].controls;

    const blackoutRules: BlackoutRule[] = ruleControls.map(
      (ruleControl: FormControl<SubformBlackoutRule>) => {
        const subformBlackoutRule = ruleControl.value;
        return this._blackoutRuleSubformService.getBlackoutRuleFromSubFormBlackoutRule(
          subformBlackoutRule
        );
      }
    );

    const blackoutToCreateOrUpdate: Blackout = {
      _id: blackoutOnInit?._id ? blackoutOnInit._id : undefined,
      status: blackoutOnInit?.status ? blackoutOnInit.status : undefined,
      type: type,
      repetitions: this._buildRepetitionDaysFromDaysCheckedStatus(
        isRepetitive,
        typeAndDays?.daysCheckedStatus,
        isRepetitive && blackoutMainInfo.startTime
          ? this._sekerUtilsService.formatTimeStringInMs(
              blackoutMainInfo.startTime
            )
          : null,
        isRepetitive && blackoutMainInfo.endTime
          ? this._sekerUtilsService.formatTimeStringInMs(
              blackoutMainInfo.endTime
            )
          : null
      ),
      startDateTime: isRepetitive
        ? 0
        : this._buildDateTime(blackoutMainInfo.startDateTime),
      endDateTime: isRepetitive
        ? 0
        : this._buildDateTime(blackoutMainInfo.endDateTime),
      requesterUpperId: this._buildRequestedUpperId(blackoutOnInit),
      lastUpdatedRequesterUpperId:
        this._buildLastUpdatedRequestedUpperId(blackoutOnInit),
      actor: blackoutMainInfo.actor?.length
        ? blackoutMainInfo.actor
        : undefined,
      phoneActor: blackoutMainInfo.phoneActor?.length
        ? blackoutMainInfo.phoneActor
        : undefined,
      eventReference: blackoutMainInfo.eventReference,
      description: blackoutMainInfo.description,
      comment: blackoutMainInfo.comment?.length
        ? blackoutMainInfo.comment
        : undefined,
      rules: blackoutRules,
    };
    return blackoutToCreateOrUpdate;
  }

  private _buildRepetitionDaysFromDaysCheckedStatus(
    isRepetitive: boolean,
    daysCheckedStatus: boolean[],
    startTime?: number,
    endTime?: number
  ): { day: number }[] {
    const repetitions: {
      day: number;
      startHour?: number;
      endHour?: number;
    }[] = [];
    if (isRepetitive) {
      daysCheckedStatus.forEach((dayCheckedStatus: boolean, index: number) => {
        if (dayCheckedStatus) {
          repetitions.push({
            day: index,
            startHour: startTime,
            endHour: endTime,
          });
        }
      });
    }
    return repetitions;
  }

  private _buildDateTime(dateTime: Date | string): number {
    if (dateTime instanceof Date) {
      return dateTime ? dateTime.getTime() : undefined;
    } else {
      return dateTime ? new Date(dateTime).getTime() : undefined;
    }
  }

  private _buildRequestedUpperId(blackoutOnInit?: Blackout): string {
    return blackoutOnInit && blackoutOnInit.requesterUpperId
      ? blackoutOnInit.requesterUpperId
      : `u${this._securityService.getUser().uperId}`;
  }

  private _buildLastUpdatedRequestedUpperId(blackoutOnInit?: Blackout): string {
    return blackoutOnInit && blackoutOnInit.requesterUpperId
      ? `u${this._securityService.getUser().uperId}`
      : undefined;
  }

  getActionNameWithCheckDatesNotInPast(
    noCheckSinceRepetitive: boolean,
    actionName: string,
    startDateTime: number,
    endDateTime: number
  ): string {
    const datesInPastForSaveOrUpdate =
      !noCheckSinceRepetitive &&
      (actionName === "save" || actionName === "update") &&
      !this._checkDatesNotInPast(startDateTime, endDateTime);
    if (datesInPastForSaveOrUpdate) {
      this._toastrService.error(ERROR_MESSAGE_ON_SUBMIT);
      return "";
    } else {
      return actionName;
    }
  }

  private _checkDatesNotInPast(
    startDateTime: number,
    endDateTime: number
  ): boolean {
    const dateNowInMillisec = new Date().getTime();
    const startDateNotInPast =
      new Date(startDateTime).getTime() >= dateNowInMillisec;
    const endDateNotInPast =
      new Date(endDateTime).getTime() >= dateNowInMillisec;
    return startDateNotInPast && endDateNotInPast;
  }

  clearSavedBlackout(): void {
    this._blackoutSubmitActionService.clearSavedBlackout();
  }

  getCopiedBlackout(): Blackout {
    return this._blackoutSubmitActionService.getCopiedBlackout();
  }

  clearCopiedBlackout(): void {
    this._blackoutSubmitActionService.clearCopiedBlackout();
  }
}
