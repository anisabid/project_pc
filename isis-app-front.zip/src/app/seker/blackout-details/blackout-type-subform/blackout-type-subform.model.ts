import { FormArray, FormControl } from "@angular/forms";
import { BlackoutTypeEnum } from "@app/shared/models/blackout";

export interface SubformBlackoutTypeAndDays {
  selectedType: BlackoutTypeEnum;
  daysCheckedStatus: boolean[];
}

export interface BlackoutTypeAndDaysForm {
  selectedType: FormControl<BlackoutTypeEnum>;
  daysCheckedStatus: FormArray<FormControl<boolean>>;
}
