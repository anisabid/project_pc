import {
  Component,
  EventEmitter,
  forwardRef,
  OnDestroy,
  OnInit,
  Output,
} from "@angular/core";
import {
  AbstractControl,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  FormGroup,
  FormControl,
  FormArray,
} from "@angular/forms";
import { CustomFilterChipItem } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list.model";
import {
  BlackoutRepetitiveDayEnum,
  BlackoutTypeEnum,
} from "@app/shared/models/blackout";
import { Subject, map, takeUntil } from "rxjs";
import {
  blackoutValidatorsErrorMessages,
  ConstColorBlackoutTypes,
} from "../blackout-main-info-subform/blackout-main-info-subform.model";
import {
  BlackoutTypeAndDaysForm,
  SubformBlackoutTypeAndDays,
} from "./blackout-type-subform.model";

@Component({
  selector: "app-blackout-type-subform",
  templateUrl: "./blackout-type-subform.component.html",
  styleUrls: ["./blackout-type-subform.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => BlackoutTypeSubformComponent),
      multi: true,
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => BlackoutTypeSubformComponent),
      multi: true,
    },
  ],
})
export class BlackoutTypeSubformComponent implements OnInit, OnDestroy {
  typeSubformLabels = {
    DAYS: ["L", "M", "M", "J", "V", "S", "D"],
  };
  availableTypeFilterChipItems: CustomFilterChipItem[];
  subFormGroup: FormGroup<BlackoutTypeAndDaysForm>;
  daysFormArray: FormArray<FormControl<boolean>>;
  private _needUnsubscribe$ = new Subject<boolean>();

  @Output() isRepetitiveBlackoutEmitter: EventEmitter<boolean> =
    new EventEmitter();

  ngOnInit(): void {
    this._setAvailableBlackoutTypes();
    this.subFormGroup = this._initTypeSubformGroup();
    this.daysFormArray = this.subFormGroup.controls["daysCheckedStatus"];
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  isRepetitive(): boolean {
    return (
      this.subFormGroup.controls["selectedType"].value ===
      BlackoutTypeEnum.REPETITIVE
    );
  }

  getErrorHighlightedCheckboxClass(): string {
    const needErrorHighlighted =
      this.daysFormArray.touched && this.daysFormArray.invalid;
    return needErrorHighlighted ? "checkbox-custom-invalid" : "";
  }

  onSelectedType(event: Event): void {
    const currentSelectedType = event[0];
    this.isRepetitiveBlackoutEmitter.emit(
      Boolean(currentSelectedType) &&
        currentSelectedType === BlackoutTypeEnum.REPETITIVE
    );
    this.subFormGroup.controls["selectedType"].patchValue(event[0]);
  }

  private _setAvailableBlackoutTypes(selectedType = BlackoutTypeEnum.MEP) {
    const availableBlackoutTypeKeys = Object.keys(BlackoutTypeEnum)
      .filter((typeKey: string) => {
        return (
          typeKey !== BlackoutTypeEnum.ORDONNANCEUR ||
          selectedType === BlackoutTypeEnum.ORDONNANCEUR
        );
      })
      .map((typeKey: string) => {
        return typeKey;
      });
    this.availableTypeFilterChipItems = availableBlackoutTypeKeys.map(
      (key: string) => {
        const customFilterChipItem: CustomFilterChipItem = {
          label: ConstColorBlackoutTypes[key].label,
          value: BlackoutTypeEnum[key],
          colorDescription: ConstColorBlackoutTypes[key],
          selectedOnInit: selectedType === key,
        };
        return customFilterChipItem;
      }
    );
  }

  private _initTypeSubformGroup(): FormGroup<BlackoutTypeAndDaysForm> {
    const formGroup = new FormGroup<BlackoutTypeAndDaysForm>(
      {
        selectedType: new FormControl(BlackoutTypeEnum.MEP),
        daysCheckedStatus: this._initDaysStatusFormArray(),
      },
      {
        validators: [this._atLeastOneDaySelectedIfRepetitive],
      }
    );
    return formGroup;
  }

  private _initDaysStatusFormArray(): FormArray<FormControl<boolean>> {
    const dayFormControls = Object.keys(BlackoutRepetitiveDayEnum).map(
      () => new FormControl<boolean>(false)
    );
    return new FormArray<FormControl<boolean>>(dayFormControls);
  }

  private _atLeastOneDaySelectedIfRepetitive(
    control: AbstractControl
  ): ValidationErrors | null {
    const formGroup = <FormGroup<BlackoutTypeAndDaysForm>>control;
    const isRepetitive =
      formGroup.controls["selectedType"].value === BlackoutTypeEnum.REPETITIVE;
    const daysControls = formGroup.controls["daysCheckedStatus"].controls;

    const atLeastOneDaySelected =
      formGroup.controls["daysCheckedStatus"].value.findIndex(
        (checkStatus: boolean) => checkStatus
      ) !== -1;

    if (isRepetitive && !atLeastOneDaySelected) {
      const error: ValidationErrors = {
        atLeastOneDaySelected: {
          value: true,
          message: blackoutValidatorsErrorMessages.ONE_DAY_SELECTED_REQUIRED,
        },
      };
      // Propagate error to checkboxes.
      daysControls.forEach((dayControl: FormControl<boolean>) => {
        dayControl.setErrors(error);
      });
      return error;
    } else {
      daysControls.forEach((dayControl: FormControl<boolean>) => {
        dayControl.setErrors(null);
      });
      return null;
    }
  }

  // for interface ControlValueAccessor
  private _onTouched: () => void = () => {
    // do nothing
  };
  private _onChange: () => void = () => {
    // do nothing
  };

  // eslint-disable-next-line
  registerOnChange(fn: any): void {
    this.subFormGroup.valueChanges
      .pipe(
        takeUntil(this._needUnsubscribe$),
        map((res) => {
          return res;
        })
      )
      .subscribe(fn);
  }

  // Note: This method is used to init the values of the formGroup.
  writeValue(value: SubformBlackoutTypeAndDays): void {
    if (value) {
      const currentSelectedType = value.selectedType;
      this._setAvailableBlackoutTypes(currentSelectedType);
      this.isRepetitiveBlackoutEmitter.emit(
        Boolean(currentSelectedType) &&
          currentSelectedType === BlackoutTypeEnum.REPETITIVE
      );
      this.subFormGroup.patchValue(value);
      // to allow display error message on init if the form is initialized with existing data.
      this.subFormGroup.markAllAsTouched();
    } else {
      this.isRepetitiveBlackoutEmitter.emit(false);
    }
  }

  // eslint-disable-next-line
  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    isDisabled ? this.subFormGroup.disable() : this.subFormGroup.enable();
  }

  // for interface Validator
  validate(): ValidationErrors | null {
    // Note: This method could be used also to return a specific error
    // message to a parent form.
    return this.subFormGroup.valid
      ? null
      : ({
          typeSubformInError: true,
        } as ValidationErrors);
  }

  registerOnValidatorChange(fn: () => void): void {
    this._onChange = fn;
  }
}
