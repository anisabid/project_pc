import { Injectable } from "@angular/core";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from "@angular/forms";
import { SekerUtilsService } from "@app/seker/seker.utils.service";
import {
  BlackoutMainInfoForm,
  blackoutValidatorsErrorMessages,
} from "./blackout-main-info-subform.model";

@Injectable({ providedIn: "root" })
export class BlackoutMainInfoSubformService {
  constructor(private _sekerUtilsService: SekerUtilsService) {}

  initMainInfoSubFormGroup(
    isRepetitiveOnInit: boolean
  ): FormGroup<BlackoutMainInfoForm> {
    const formGroup = new FormGroup<BlackoutMainInfoForm>({
      startDateTime: new FormControl(""),
      endDateTime: new FormControl(""),
      startTime: new FormControl(""),
      endTime: new FormControl(""),
      actor: new FormControl(""),
      phoneActor: new FormControl("", [
        Validators.minLength(10),
        Validators.pattern("^[0-9*+]+$"),
      ]),
      eventReference: new FormControl("", [
        Validators.required,
        Validators.minLength(3),
      ]),
      description: new FormControl("", [
        Validators.required,
        Validators.minLength(4),
      ]),
      comment: new FormControl(""),
    });
    this.updateValidators(formGroup, isRepetitiveOnInit);

    return formGroup;
  }

  updateValidators(
    formGroup: FormGroup<BlackoutMainInfoForm>,
    isRepetitiveType?: boolean
  ): void {
    const formControlNameStart = isRepetitiveType
      ? "startTime"
      : "startDateTime";
    const formControlNameEnd = isRepetitiveType ? "endTime" : "endDateTime";
    formGroup.setValidators([
      this._dateTimeRequired(formControlNameStart, isRepetitiveType),
      this._dateTimeRequired(formControlNameEnd, isRepetitiveType),
      this._startDateTimeBeforeOrEqualEndDateTime(
        formControlNameStart,
        formControlNameEnd,
        isRepetitiveType
      ),
      this._conditionalActorFieldRequired,
    ]);
    this._clearControl(
      formGroup,
      isRepetitiveType ? "startDateTime" : "startTime"
    );
    this._clearControl(formGroup, isRepetitiveType ? "endDateTime" : "endTime");
    formGroup.updateValueAndValidity();
  }

  private _clearControl(
    formGroup: FormGroup<BlackoutMainInfoForm>,
    formControlName: string
  ): void {
    formGroup.controls[`${formControlName}`].setErrors(null);
    formGroup.controls[`${formControlName}`].patchValue(null);
  }

  getValidationErrorMessage(
    validationErrors: ValidationErrors,
    formControlName?: string
  ): string | null {
    if (!validationErrors) return "";

    if (validationErrors.required) {
      return formControlName === "eventReference"
        ? blackoutValidatorsErrorMessages.EVENT_REFERENCE_REQUIRED
        : blackoutValidatorsErrorMessages.REQUIRED;
    }

    if (validationErrors.pattern) {
      return formControlName === "phoneActor"
        ? blackoutValidatorsErrorMessages.TELEPHONE_FORMAT_EXPECTED
        : blackoutValidatorsErrorMessages.PATTERN;
    }

    if (validationErrors.conditionalActorFieldRequired) {
      return blackoutValidatorsErrorMessages.CONDITIONAL_ACTOR_FIELD_REQUIRED;
    }

    if (validationErrors.minlength) {
      return formControlName === "phoneActor"
        ? blackoutValidatorsErrorMessages.TELEPHONE_FORMAT_EXPECTED
        : blackoutValidatorsErrorMessages.MIN_LENGTH_REQUIRED;
    }

    return null;
  }

  private _dateTimeRequired(
    controlName: string,
    timeOnly: boolean
  ): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const formGroup = <FormGroup<BlackoutMainInfoForm>>control;
      const dateTimeControl = formGroup.controls[`${controlName}`];
      const dateTime = dateTimeControl.value;
      const noDate =
        dateTime === undefined || dateTime === null || dateTime === "";
      const invalidDate = timeOnly
        ? !timeOnly
        : !this._sekerUtilsService.isValidStringDate(dateTime);
      if (noDate || invalidDate) {
        const dateError: ValidationErrors = {
          required: true,
        };
        dateTimeControl.setErrors(dateError);
        return dateError;
      } else {
        dateTimeControl.setErrors(null);
        return null;
      }
    };
  }

  private _startDateTimeBeforeOrEqualEndDateTime(
    controlNameStart: string | number,
    controlNameEnd: string | number,
    isTimeOnly: boolean
  ): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const formGroup = <FormGroup<BlackoutMainInfoForm>>control;
      const startDateTimeControl = formGroup.controls[`${controlNameStart}`];
      const endDateTimeControl = formGroup.controls[`${controlNameEnd}`];
      const startDateTime = startDateTimeControl.value;
      const endDateTime = endDateTimeControl.value;
      const noStartDateTime =
        startDateTime === undefined ||
        startDateTime === null ||
        startDateTime === "";
      const noEndDateTime =
        endDateTime === undefined || endDateTime === null || endDateTime === "";
      const noDateTimes = noStartDateTime || noEndDateTime;
      const invalidDates = isTimeOnly
        ? !isTimeOnly
        : !this._sekerUtilsService.isValidDate(startDateTime) ||
          !this._sekerUtilsService.isValidDate(endDateTime);

      const isValid =
        noDateTimes ||
        invalidDates ||
        (isTimeOnly
          ? this._sekerUtilsService.formatTimeStringInMs(startDateTime) <
            this._sekerUtilsService.formatTimeStringInMs(endDateTime)
          : new Date(
              this._sekerUtilsService.formatDateWithoutSeconds(startDateTime)
            ).getTime() <
            new Date(
              this._sekerUtilsService.formatDateWithoutSeconds(endDateTime)
            ).getTime());

      if (isValid) {
        const existingDateTimeError =
          startDateTimeControl.errors || endDateTimeControl.errors;
        if (
          existingDateTimeError &&
          existingDateTimeError.startDateTimeBeforeOrEqualEndDateTime
        ) {
          startDateTimeControl.setErrors(null);
          endDateTimeControl.setErrors(null);
        }
        return null;
      } else {
        const dateError: ValidationErrors = {
          startDateTimeBeforeOrEqualEndDateTime: {
            value: true,
            message: isTimeOnly
              ? blackoutValidatorsErrorMessages.START_HOUR_BEFORE_END_HOUR
              : blackoutValidatorsErrorMessages.START_DATE_BEFORE_END_DATE,
          },
        };
        startDateTimeControl.setErrors(dateError);
        endDateTimeControl.setErrors(dateError);
        return dateError;
      }
    };
  }

  private _conditionalActorFieldRequired(
    control: AbstractControl
  ): ValidationErrors | null {
    if (!control) return null;
    const formGroup = <FormGroup<BlackoutMainInfoForm>>control;
    const actorControl = formGroup.controls["actor"];
    const phoneActorControl = formGroup.controls["phoneActor"];
    const actor = actorControl.value;
    const phoneActor = phoneActorControl.value;
    if (phoneActor && !actor) {
      const error: ValidationErrors = {
        conditionalActorFieldRequired: {
          value: !actor ? "actor" : "phoneActor",
          message:
            blackoutValidatorsErrorMessages.CONDITIONAL_ACTOR_FIELD_REQUIRED,
        },
      };
      actorControl.setErrors(error);
      return error;
    } else {
      actorControl.setErrors(null);
      return null;
    }
  }
}
