import {
  Component,
  forwardRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import {
  AbstractControl,
  ControlValueAccessor,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  Validator,
  FormGroup,
} from "@angular/forms";
import { Subject, map, takeUntil } from "rxjs";
import { SubformBlackoutMainInfo } from "../blackout-details.model";
import { BlackoutMainInfoForm } from "./blackout-main-info-subform.model";
import { BlackoutMainInfoSubformService } from "./blackout-main-info-subform.service";

@Component({
  selector: "app-blackout-main-info-subform",
  templateUrl: "./blackout-main-info-subform.component.html",
  styleUrls: ["./blackout-main-info-subform.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => BlackoutMainInfoSubformComponent),
      multi: true,
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => BlackoutMainInfoSubformComponent),
      multi: true,
    },
  ],
})
export class BlackoutMainInfoSubformComponent
  implements OnInit, OnChanges, ControlValueAccessor, Validator, OnDestroy
{
  subFormLabels = {
    START_DATE_TIME: "Date et heure de début",
    START_HOUR: "Heure de début",
    END_DATE_TIME: "Date et heure de fin",
    END_HOUR: "Heure de fin",
    ACTOR: "Demandeur",
    PHONE_ACTOR: "Téléphone",
    EVENT_REFERENCE: "REF Blackout",
    DESCRIPTION: "Description",
    COMMENT: "Commentaires",
  };

  subFormGroup: FormGroup<BlackoutMainInfoForm>;
  private _needUnsubscribe$ = new Subject<boolean>();

  @Input() isRepetitiveType: boolean;

  constructor(
    private _blackoutMainInfoSubformService: BlackoutMainInfoSubformService
  ) {}

  ngOnInit(): void {
    this.subFormGroup =
      this._blackoutMainInfoSubformService.initMainInfoSubFormGroup(
        this.isRepetitiveType
      );
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.subFormGroup) {
      this._blackoutMainInfoSubformService.updateValidators(
        this.subFormGroup,
        changes.isRepetitiveType.currentValue
      );
    }
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  onCloseDateTimePicker(formControlName: string): void {
    this.subFormGroup.controls[formControlName].markAsTouched();
    this.subFormGroup.controls[formControlName].markAsDirty();
  }

  markActorAsTouchedIfRequired(): void {
    const actorFormControlErrors = this.subFormGroup.controls["actor"].errors;
    if (
      actorFormControlErrors &&
      actorFormControlErrors["conditionalActorFieldRequired"]
    ) {
      this.subFormGroup.controls["actor"].markAsTouched();
    }
  }

  removeFirstWhiteSpaces(event: Event, formControlName: string): void {
    const formControl: AbstractControl =
      this.subFormGroup.controls[formControlName];
    if (formControl.value?.length) {
      this.subFormGroup.controls[formControlName].patchValue(
        ((event.target as HTMLInputElement).value as string).trimStart()
      );
    }
  }

  private _removeEndWhiteSpaces(event: Event, formControlName: string): void {
    const formControl: AbstractControl =
      this.subFormGroup.controls[formControlName];
    if (formControl.value?.length) {
      this.subFormGroup.controls[formControlName].patchValue(
        ((event.target as HTMLInputElement).value as string).trimEnd()
      );
    }
  }

  onBlurMainInfoInputs(event: Event, formControlName: string): void {
    this._removeEndWhiteSpaces(event, formControlName);
    if (formControlName === "phoneActor") {
      this.markActorAsTouchedIfRequired();
    }
  }

  getErrorMessage(
    validationErrors: ValidationErrors,
    formControlName?: string
  ): string {
    return this._blackoutMainInfoSubformService.getValidationErrorMessage(
      validationErrors,
      formControlName
    );
  }

  // for interface ControlValueAccessor
  private _onTouched: () => void = () => {
    // do nothing
  };
  private _onChange: () => void = () => {
    // do nothing
  };

  // eslint-disable-next-line
  registerOnChange(fn: any): void {
    this.subFormGroup.valueChanges
      .pipe(
        takeUntil(this._needUnsubscribe$),
        map((res) => {
          return res;
        })
      )
      .subscribe(fn);
  }

  // Note: This method is used to init the values of the formGroup.
  writeValue(value: SubformBlackoutMainInfo): void {
    if (value) {
      this.subFormGroup.patchValue(value);
      // to allow display error message on init if the form is initialized with existing data.
      this.subFormGroup.markAllAsTouched();
    }
  }

  // eslint-disable-next-line
  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    isDisabled ? this.subFormGroup.disable() : this.subFormGroup.enable();
  }

  // for interface Validator
  validate(): ValidationErrors | null {
    // Note: This method could be used also to return a specific error
    // message to a parent form.
    return this.subFormGroup.valid
      ? null
      : ({
          mainInfoSubFormInError: true,
        } as ValidationErrors);
  }

  registerOnValidatorChange(fn: () => void): void {
    this._onChange = fn;
  }
}
