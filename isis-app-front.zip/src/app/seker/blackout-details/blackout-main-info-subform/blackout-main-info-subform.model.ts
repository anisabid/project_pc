import { FormControl } from "@angular/forms";
import { ColorDescription } from "@app/shared/consts/color-alarms";
import {
  ValidatorsErrorMessages,
  constValidatorsErrorMessages,
} from "@app/shared/consts/validators-error-messages";

interface BlackoutValidatorsErrorMessages extends ValidatorsErrorMessages {
  CONDITIONAL_ACTOR_FIELD_REQUIRED: string;
  ONE_DAY_SELECTED_REQUIRED: string;
  TELEPHONE_FORMAT_EXPECTED: string;
  EVENT_REFERENCE_REQUIRED: string;
}

export const blackoutValidatorsErrorMessages: BlackoutValidatorsErrorMessages =
  {
    ...constValidatorsErrorMessages,
    CONDITIONAL_ACTOR_FIELD_REQUIRED: "Merci de renseigner ce champ.",
    ONE_DAY_SELECTED_REQUIRED:
      "Merci de sélectionner au moins un jour de la semaine.",
    TELEPHONE_FORMAT_EXPECTED:
      "Le numéro doit être compris entre 10 et 13 chiffres.",
    EVENT_REFERENCE_REQUIRED:
      "Merci de renseigner ce champ. (MEP, Incident,...)",
  };

export interface ColorBlackoutType {
  MEP: ColorDescription;
  INCIDENT: ColorDescription;
  ORDONNANCEUR: ColorDescription;
  REPETITIVE: ColorDescription;
}

export const ConstColorBlackoutTypes: ColorBlackoutType = {
  MEP: new ColorDescription({
    label: "MEP",
    color: "#4CAF50",
    text_color: "#fff",
  }),
  INCIDENT: new ColorDescription({
    label: "Incident",
    color: "#ff1744",
    text_color: "#fff",
  }),
  ORDONNANCEUR: new ColorDescription({
    label: "Ordonnanceur",
    color: "#ffd218",
    text_color: "#fff",
  }),
  REPETITIVE: new ColorDescription({
    label: "Répétitif",
    color: "#2979FF",
    text_color: "#fff",
  }),
};

export interface BlackoutMainInfoForm {
  startDateTime: FormControl<Date | string>;
  endDateTime: FormControl<Date | string>;
  startTime: FormControl<string>;
  endTime: FormControl<string>;
  actor: FormControl<string>;
  phoneActor: FormControl<string>;
  eventReference: FormControl<string>;
  description: FormControl<string>;
  comment: FormControl<string>;
}
