import { FormArray, FormControl, FormGroup } from "@angular/forms";
import {
  SirocoRefNameSubForm,
  SirocoRefNameSubFormValue,
} from "@app/shared/components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.component";
import { SubformBlackoutTypeAndDays } from "./blackout-type-subform/blackout-type-subform.model";

export interface SubformBlackoutMainInfo {
  startDateTime?: Date | string;
  endDateTime?: Date | string;
  startTime?: string;
  endTime?: string;
  actor: string;
  phoneActor: string;
  eventReference: string;
  description: string;
  comment: string;
}

export const ERROR_MESSAGE_ON_SUBMIT =
  "Dans le cadre d'une nouvelle programmation ou d'une modification de blackout, les dates et heures prévues ne peuvent être dans le passé.";

export interface SirocoSearchMetaData {
  inputId: string;
  isProcessing: boolean;
  message?: string;
}

export interface BlackoutDetailsForm {
  blackoutTypeAndDays: FormControl<SubformBlackoutTypeAndDays>;
  blackoutMainInfo: FormControl<SubformBlackoutMainInfo>;
  blackoutRules: FormArray<FormControl<SubformBlackoutRule>>;
}

export interface BlackoutRuleForm {
  sfrRefClarify?: FormGroup<SirocoRefNameSubForm>;
  host?: FormGroup<SirocoRefNameSubForm>;
  sfrSource: FormControl<string>;
  parameter: FormControl<string>;
  supervisedObject: FormControl<string>;
  supervisionDomain: FormControl<string>;
}

export interface SubformBlackoutRule {
  sfrRefClarify?: SirocoRefNameSubFormValue;
  host?: SirocoRefNameSubFormValue;
  sfrSource?: string;
  parameter?: string;
  supervisedObject?: string;
  supervisionDomain?: string;
}
