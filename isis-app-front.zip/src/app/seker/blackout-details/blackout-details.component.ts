import { Component, OnDestroy, OnInit } from "@angular/core";
import { FormArray, FormControl, FormGroup } from "@angular/forms";
import { ActivatedRoute, ParamMap, Router } from "@angular/router";
import { constDefaultDateOnlyFormat } from "@app/shared/consts/date-formats";
import {
  Blackout,
  BlackoutStatusEnum,
  BlackoutTypeEnum,
} from "@app/shared/models/blackout";
import { merge, Observable, of, map, switchMap } from "rxjs";
import {
  BlackoutDetailsForm,
  SubformBlackoutRule,
} from "./blackout-details.model";
import { BlackoutDetailsService } from "./blackout-details.service";

@Component({
  selector: "app-blackout-details",
  templateUrl: "./blackout-details.component.html",
  styleUrls: ["./blackout-details.component.scss"],
})
export class BlackoutDetailsComponent implements OnInit, OnDestroy {
  title: string;
  blackoutFormGroup$: Observable<FormGroup<BlackoutDetailsForm>>;
  private _blackoutForm: FormGroup<BlackoutDetailsForm>;
  private _timeOutBeforeScroll = null;

  labels = {
    LAUNCHED: "Déclenché",
    CLOSED: "Clos",
    CANCELLED: "Annulé",
    INHIBITIONS_REFERENCE: "Références des inhibitions",
    INHIBITIONS_REFERENCE_ADD: "Ajouter une liste d'inhibitions",
    ISIS_LINK: "ISIS",
    INHIBITIONS_LINK: "INHIBITIONS",
    buttonTooltip: {
      SAVE_BLACKOUT: "Enregistrer",
      LAUNCH_BLACKOUT: "Déclencher",
      CANCEL_BLACKOUT: "Annuler",
      CLOSE_BLACKOUT: "Clôturer",
      COPY_BLACKOUT: "Copier",
    },
    inhibitions: {
      REF_ITEM: "REF_Item",
      HOST: "Host",
      SFR_SOURCE: "SFR source",
      PARAMETER: "Paramètre",
      SUPERVISED_OBJECT: "Objet supervisé",
      SUPERVISION_DOMAIN: "Domaine supervision",
    },
    tooltips: {
      ADD_INHIBITIONS: "Ajouter des inhibitions",
      REMOVE_INHIBITIONS: "Supprimer ces inhibitions",
      HELP_REF_ITEM: "Nom et référence Siroco du bien : NOM (REF)",
    },
  };
  format = {
    defaultDateOnly: constDefaultDateOnlyFormat,
  };
  isFormEditable = true;
  rulesFormArray: FormArray<FormControl<SubformBlackoutRule>>;
  requestedActionName = "";
  blackoutOnInit: Blackout;
  blackoutForAction: Blackout;
  formReady: boolean;
  displayStatus = false;
  blackoutStatusEnum = BlackoutStatusEnum;
  showInhibitions = false;
  isRepetitiveSelected: boolean;
  hasRightsToEdit: boolean;

  constructor(
    private _route: ActivatedRoute,
    private _blackoutDetailsService: BlackoutDetailsService,
    private _router: Router
  ) {}

  ngOnInit(): void {
    this.hasRightsToEdit = this._blackoutDetailsService.hasRightsToEdit();
    const blackoutFromId$: Observable<Blackout> = this._route.paramMap.pipe(
      switchMap((params: ParamMap) => of(params.get("idBlackout"))),
      switchMap((id) => {
        this.formReady = false;
        const isCreation = !id;
        if (isCreation) {
          this._blackoutDetailsService.clearSavedBlackout();
          return of(this._blackoutDetailsService.getCopiedBlackout());
        } else {
          return this._blackoutDetailsService.getBlackoutById(id);
        }
      })
    );

    const blackoutJustSaved$: Observable<Blackout> =
      this._blackoutDetailsService.savedBlackout$.pipe(
        map((savedBlackout: Blackout) => {
          this._onBlackoutSaved(savedBlackout);
          return savedBlackout;
        })
      );

    this.blackoutFormGroup$ = merge(blackoutFromId$, blackoutJustSaved$).pipe(
      map((blackout: Blackout) => {
        this.showInhibitions = Boolean(blackout);
        this._blackoutDetailsService.clearCopiedBlackout();
        this.title = this._formatTitle(blackout);
        this.isFormEditable =
          this._blackoutDetailsService.isFormEditable(blackout);
        this.blackoutOnInit = blackout;
        this.blackoutForAction = blackout;
        this.displayStatus =
          this._blackoutDetailsService.isLaunchedOrCancelledOrClosedBlackout(
            blackout
          );
        const formGroup = this._blackoutDetailsService.initOrUpdateFormGroup(
          this._blackoutForm,
          blackout
        );
        this.rulesFormArray = formGroup.controls["blackoutRules"];
        this._blackoutForm = formGroup;
        this.formReady = true;
        return formGroup;
      })
    );
  }

  ngOnDestroy(): void {
    if (this._timeOutBeforeScroll) {
      clearTimeout(this._timeOutBeforeScroll);
    }
  }

  private _scrollDown(): void {
    if (this._timeOutBeforeScroll) {
      clearTimeout(this._timeOutBeforeScroll);
    }
    this._timeOutBeforeScroll = setTimeout(() => {
      const scrollingContainer = document.getElementById(
        "blackout-details__main-content-container-id"
      );
      if (scrollingContainer) {
        scrollingContainer.scrollBy({
          top: scrollingContainer.scrollHeight,
          left: 0,
          behavior: "smooth",
        });
      }
    }, 0);
  }

  addRule(): void {
    this.rulesFormArray.push(
      this._blackoutDetailsService.initRuleFormControl(null)
    );
    this._scrollDown();
  }

  removeRule(index: number): void {
    this.rulesFormArray.removeAt(index);
  }

  onSubmit(event): void {
    this.blackoutForAction =
      this._blackoutDetailsService.buildBlackoutFromFormGroup(
        this._blackoutForm,
        this.blackoutOnInit
      );
    const actionName = event.submitter.name;
    this.requestedActionName =
      this._blackoutDetailsService.getActionNameWithCheckDatesNotInPast(
        this.blackoutForAction.type === BlackoutTypeEnum.REPETITIVE,
        actionName,
        this.blackoutForAction.startDateTime,
        this.blackoutForAction.endDateTime
      );
  }

  onSavingProcessErrorOrCancelAction(): void {
    this.requestedActionName = "";
  }

  getClassForStatus(blackout: Blackout): string {
    if (!blackout) return "";
    if (
      blackout.status === BlackoutStatusEnum.CLOSED ||
      blackout.status === BlackoutStatusEnum.CANCELLED
    ) {
      return "blackout-details__status__content--closed-or-cancelled";
    }
    if (blackout.status === BlackoutStatusEnum.IN_PROGRESS) {
      return "blackout-details__status__content--launched";
    }
    return "";
  }

  isBlackoutRepetitiveSelection(event: boolean): void {
    this.isRepetitiveSelected = event;
  }

  private _formatTitle(blackout: Blackout): string {
    return blackout && blackout._id
      ? `Demande N°${blackout._id}`
      : "Nouvelle demande BLACKOUT";
  }

  private _onBlackoutSaved(blackout: Blackout): void {
    this.requestedActionName = "";
    if (
      blackout &&
      blackout._id &&
      this._router.routerState.snapshot.url === "/inhibitions/blackout"
    ) {
      this._router.navigate(["inhibitions/blackout", blackout._id]);
    }
  }
}
