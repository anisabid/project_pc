import {
  OnDestroy,
  OnInit,
  Component,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  EventEmitter,
} from "@angular/core";
import { Router } from "@angular/router";
import { SekerUtilsService } from "@app/seker/seker.utils.service";
import { ConfirmDialogService } from "@app/shared/components/confirm-dialog/confirm-dialog.service";
import { Blackout, BlackoutStatusEnum } from "@app/shared/models/blackout";
import { ToastrService } from "ngx-toastr";
import {
  from,
  Observable,
  Observer,
  of,
  Subject,
  switchMap,
  takeUntil,
} from "rxjs";
import { BlackoutSubmitActionService } from "./blackout-submit-action.service";

@Component({
  selector: "app-blackout-submit-action",
  templateUrl: "./blackout-submit-action.component.html",
  styleUrls: ["./blackout-submit-action.component.scss"],
})
export class BlackoutSubmitActionComponent
  implements OnChanges, OnInit, OnDestroy
{
  @Input() blackout: Blackout;
  @Input() actionsDisabled: boolean;
  @Input() requestedActionName: string;

  @Output() startedSavingProcessErrorOrCancelAction: EventEmitter<
    "error" | "cancelAction"
  > = new EventEmitter<"error" | "cancelAction">();

  blackoutStatusEnum = BlackoutStatusEnum;
  buttonLabels = {
    SAVE_BLACKOUT: "Enregistrer",
    LAUNCH_BLACKOUT: "Déclencher",
    CANCEL_BLACKOUT: "Annuler",
    CLOSE_BLACKOUT: "Clôturer",
    COPY_BLACKOUT: "Copier",
  };
  isActionsDisabled: boolean;
  isSaveProcessing$: Observable<boolean>;
  hasRightsToEdit: boolean;

  private _confirmCancelLabel =
    "Etes-vous sûr de vouloir annuler cette inhibition ?";
  private _irreversibleActionLabel = "(Cette action est irréversible.)";
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _router: Router,
    private _blackoutSubmitActionService: BlackoutSubmitActionService,
    private _confirmDialogService: ConfirmDialogService,
    private _toastrService: ToastrService,
    private _sekerUtilsService: SekerUtilsService
  ) {}

  ngOnInit(): void {
    this.isSaveProcessing$ =
      this._blackoutSubmitActionService.isSaveProcessing$;
    this.hasRightsToEdit = this._sekerUtilsService.hasRightsToEditBlackout();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.actionsDisabled) {
      this.isActionsDisabled = changes.actionsDisabled.currentValue;
    }

    if (changes.requestedActionName) {
      this._doAction(changes.requestedActionName.currentValue, this.blackout);
    }
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  private _doAction(actionName: string, blackout: Blackout): void {
    const successMessage = "Succès !";
    switch (actionName) {
      case "save": {
        this._doActionCaseSave(blackout, successMessage);
        break;
      }
      case "update": {
        this._doActionCaseUpdate(blackout, successMessage);
        break;
      }
      case "launch": {
        this._doActionCaseLaunch(blackout, successMessage);
        break;
      }
      case "cancel": {
        this._doActionCaseCancel(blackout, successMessage);
        break;
      }
      case "close": {
        this._doActionCaseClose(blackout, successMessage);
        break;
      }
      case "copy": {
        this._doActionCaseCopy(blackout);
        break;
      }
      default:
        // do nothing
        break;
    }
  }

  private _doActionObserver: Partial<Observer<Blackout>> = {
    next: () => {
      // do nothing
    },
    error: () => {
      this.startedSavingProcessErrorOrCancelAction.emit("error");
    },
    complete: () => {
      // do nothing
    },
  };

  private _doActionCaseSave(blackout: Blackout, successMessage: string): void {
    const blackoutToSave = {
      ...blackout,
      status: BlackoutStatusEnum.PREPARED,
    };
    this._blackoutSubmitActionService
      .saveOrUpdateBlackout(blackoutToSave, successMessage)
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe(this._doActionObserver);
  }

  private _doActionCaseUpdate(
    blackout: Blackout,
    successMessage: string
  ): void {
    this._blackoutSubmitActionService
      .saveOrUpdateBlackout(blackout, successMessage)
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe(this._doActionObserver);
  }

  private _doActionCaseLaunch(
    blackout: Blackout,
    successMessage: string
  ): void {
    const blackoutToLaunch = {
      ...blackout,
      status: BlackoutStatusEnum.IN_PROGRESS,
    };
    this._blackoutSubmitActionService
      .saveOrUpdateBlackout(blackoutToLaunch, successMessage)
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe(this._doActionObserver);
  }

  private _doActionCaseCancel(
    blackout: Blackout,
    successMessage: string
  ): void {
    from(
      this._confirmDialogService.confirm(
        this._confirmCancelLabel,
        this._irreversibleActionLabel
      )
    )
      .pipe(
        takeUntil(this._needUnsubscribe$),
        switchMap((confirmed: boolean) => {
          if (confirmed) {
            const blackoutToCancel = {
              ...blackout,
              status: BlackoutStatusEnum.CANCELLED,
            };
            return this._blackoutSubmitActionService.saveOrUpdateBlackout(
              blackoutToCancel,
              successMessage
            );
          } else {
            this._toastrService.error("L'inhibition n'a pas été annulée.");
            this.startedSavingProcessErrorOrCancelAction.emit("cancelAction");
            return of(blackout);
          }
        })
      )
      .subscribe(this._doActionObserver);
  }

  private _doActionCaseClose(blackout: Blackout, successMessage: string): void {
    const blackoutToClose = {
      ...blackout,
      status: BlackoutStatusEnum.CLOSED,
    };
    this._blackoutSubmitActionService
      .saveOrUpdateBlackout(blackoutToClose, successMessage)
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe(this._doActionObserver);
  }

  private _doActionCaseCopy(blackout: Blackout): void {
    this._blackoutSubmitActionService.copyBlackout(blackout);
    this._router.navigate(["inhibitions/blackout"]);
  }
}
