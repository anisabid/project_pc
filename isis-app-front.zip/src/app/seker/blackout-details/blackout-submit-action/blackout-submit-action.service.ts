import { Injectable } from "@angular/core";
import { BlackoutApiService } from "@app/shared/services/api/v2/microservices/blackout-api.service";
import { Blackout, BlackoutTypeEnum } from "@app/shared/models/blackout";
import { ToastrService } from "ngx-toastr";
import {
  BehaviorSubject,
  Observable,
  Subject,
  throwError,
  catchError,
  map,
  take,
} from "rxjs";

@Injectable({ providedIn: "root" })
export class BlackoutSubmitActionService {
  private _isProcessingBehaviorSubject: BehaviorSubject<boolean> =
    new BehaviorSubject(false);
  isSaveProcessing$: Observable<boolean>;

  private _savedBlackoutSubject: Subject<Blackout> = new Subject();
  savedBlackout$: Observable<Blackout>;

  private _copiedBlackout: Blackout;

  constructor(
    private _blackoutApiService: BlackoutApiService,
    private _toastrService: ToastrService
  ) {
    this.isSaveProcessing$ = this._isProcessingBehaviorSubject.asObservable();
    this.savedBlackout$ = this._savedBlackoutSubject.asObservable();
  }

  getBlackoutByIdWithProcessingState(id: string): Observable<Blackout> {
    this._isProcessingBehaviorSubject.next(true);
    return this._blackoutApiService.getBlackoutById(id).pipe(
      map((blackout: Blackout) => {
        this._isProcessingBehaviorSubject.next(false);
        return blackout;
      }),
      catchError((errorResponse) => {
        return this._manageErrorCatching(errorResponse);
      })
    );
  }

  saveOrUpdateBlackout(
    blackoutToSave: Blackout,
    successMessage: string
  ): Observable<Blackout> {
    this._isProcessingBehaviorSubject.next(true);

    const isCreation = !blackoutToSave._id;
    const saveOrUpdate$: Observable<Blackout> = isCreation
      ? this._blackoutApiService.createBlackout(blackoutToSave)
      : this._blackoutApiService.updateAndReturnBlackout(blackoutToSave);

    return saveOrUpdate$.pipe(
      take(1),
      map((blackout: Blackout) => {
        this._toastrService.success(successMessage);
        this._savedBlackoutSubject.next(blackout);
        this._isProcessingBehaviorSubject.next(false);
        return blackout;
      }),
      catchError((errorResponse) => {
        return this._manageErrorCatching(errorResponse);
      })
    );
  }

  private _manageErrorCatching(errorResponse): Observable<never> {
    const errorMessage: string = errorResponse?.value?.message
      ? errorResponse.value.message
      : errorResponse?.error && errorResponse?.statusText !== "Unknown Error"
      ? JSON.stringify(errorResponse.error)
      : errorResponse?.isisMessage
      ? errorResponse.isisMessage
      : "Une erreur est survenue !";
    this._toastrService.error(errorMessage);
    this._isProcessingBehaviorSubject.next(false);
    return throwError(() => errorResponse);
  }

  clearSavedBlackout(): void {
    this._savedBlackoutSubject.next(null);
  }

  getCopiedBlackout(): Blackout {
    return this._copiedBlackout;
  }

  copyBlackout(blackout: Blackout): void {
    this._copiedBlackout = {
      ...blackout,
      _id: undefined,
      type: BlackoutTypeEnum.MEP,
      repetitions: [],
      status: undefined,
      startDateTime: undefined,
      endDateTime: undefined,
      startRealDateTime: undefined,
      endRealDateTime: undefined,
      requesterUpperId: undefined,
      lastUpdatedRequesterUpperId: undefined,
      actor: undefined,
      phoneActor: undefined,
      eventReference: undefined,
      description: undefined,
      comment: undefined,
      rules: blackout.rules,
    };
  }

  clearCopiedBlackout(): void {
    this._copiedBlackout = null;
  }
}
