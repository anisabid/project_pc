import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { Router } from "@angular/router";
import {
  CustomMenuSelectItem,
  CustomMultiSelectMenuConfig,
  CustomMultiSelectMenuTheme,
} from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import { BlackoutSearchCriteria } from "@app/shared/models/blackout";
import { CustomFilterChipItem } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list.model";
import { BlackoutSubheaderService } from "./blackout-subheader.service";
import { CustomTableColumn } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { AdvancedSearchValue } from "@app/shared/components/custom-advanced-search/custom-advanced-search.component";
import { CustomDateTimeRange } from "@app/shared/components/date-time-range-select/date-time-range-select.component";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";
import { SekerUtilsService } from "../seker.utils.service";

@Component({
  selector: "app-blackout-subheader",
  templateUrl: "./blackout-subheader.component.html",
  styleUrls: ["./blackout-subheader.component.scss"],
})
export class BlackoutSubheaderComponent implements OnInit {
  @Input() displayExportButton: boolean;
  @Input() availableColumns: CustomTableColumn[];

  @Output()
  requestedRefreshBlackoutListEmitter: EventEmitter<BlackoutSearchCriteria> = new EventEmitter();

  @Output() requestedExportBlackoutListEmitter: EventEmitter<boolean> =
    new EventEmitter();

  @Output() requestedDeleteBlackoutListEmitter: EventEmitter<boolean> =
    new EventEmitter();

  @Output() requestedUpdateDisplayedColumnsEmitter: EventEmitter<string[]> =
    new EventEmitter(true);

  labels = {
    openDateTimeButtonTooltip: "Période de blackouts",
    openSearchButtonTooltip: "Recherche avancée",
    exportButtonTooltip: "Exporter",
    refreshButtonTooltip: "Rafraîchir la liste",
    helpButtonTooltip:
      "Aide sur la recherche avancée: -Filtre par mot; -Taper ENTER pour une recherche multiple",
    deleteButtonTooltip: "Supprimer l'(les) inhibition(s) sélectionnée(s)",
    isisRouteLabel: "ISIS",
    inhibitionsRouteLabel: "INHIBITIONS",
  };

  hasRightsToEdit = false;
  isAdmin = false;

  beginDateFilter: Date | string;
  endDateFilter: Date | string;
  displayDateTimeRangeSelect = false;
  availableStatusFilterChipItems: CustomFilterChipItem[];

  typeMultiSelectMenuConfig: CustomMultiSelectMenuConfig;
  availableTypeSelectItems: CustomMenuSelectItem[];

  columnMultiSelectMenuConfig: CustomMultiSelectMenuConfig;
  availableColumnSelectItems: CustomMenuSelectItem[];

  displayAdvancedSearchInput = false;
  advancedSearchItems: string[];

  constructor(
    private _router: Router,
    private _securityService: KeycloakSecurityService,
    private _blackoutSubheaderService: BlackoutSubheaderService,
    private _sekerUtilsService: SekerUtilsService
  ) {}

  ngOnInit(): void {
    this.hasRightsToEdit = this._sekerUtilsService.hasRightsToEditBlackout();
    this.isAdmin = this._securityService.hasRequiredRole(IsisRole.admin);
    this._initMultiSelectConfigs();
    this._initFilterValues(
      this._blackoutSubheaderService.getSearchCriteriaForInit()
    );
  }

  navigateToCreateBlackout(): void {
    this._router.navigate(["inhibitions/blackout"]);
  }

  refreshBlackoutList(newSearchCriteria?: BlackoutSearchCriteria): void {
    this.requestedRefreshBlackoutListEmitter.emit(newSearchCriteria);
  }

  exportBlackoutList(): void {
    this.requestedExportBlackoutListEmitter.emit(true);
  }

  deleteMultipleBlackouts(): void {
    this.requestedDeleteBlackoutListEmitter.emit(true);
  }

  toggleDateTimeRangeSelect(event: boolean): void {
    this.displayDateTimeRangeSelect = event;
  }

  toggleAdvancedSearch(event: boolean): void {
    this.displayAdvancedSearchInput = event;
  }

  onSelectedDateTimeRange(dateTimeRange: CustomDateTimeRange): void {
    this.beginDateFilter = dateTimeRange.beginDateTime;
    this.endDateFilter = dateTimeRange.endDateTime;
    this.refreshBlackoutList(
      this._blackoutSubheaderService.buildDateCriteria(
        this.beginDateFilter,
        this.endDateFilter
      )
    );
  }

  onSelectedBlackoutStatus(selectedBlackoutStatus: string[]): void {
    this.refreshBlackoutList(
      this._blackoutSubheaderService.buildStatusCriteria(selectedBlackoutStatus)
    );
  }

  onSelectedBlackoutTypes(selectedBlackoutTypes: string[]): void {
    this.refreshBlackoutList(
      this._blackoutSubheaderService.buildTypeCriteria(selectedBlackoutTypes)
    );
  }

  onSelectedColumns(selectedColumns: string[]): void {
    this.requestedUpdateDisplayedColumnsEmitter.emit(selectedColumns);
  }

  onSelectedAdvancedSearch(advancedSearchEvent: AdvancedSearchValue): void {
    this.advancedSearchItems = advancedSearchEvent.items;
    this.refreshBlackoutList(
      this._blackoutSubheaderService.buildAdvancedSearchCriteria(
        advancedSearchEvent.items
      )
    );
  }

  onClosedTypeMultiSelectMenu(): void {
    this.availableTypeSelectItems =
      this._blackoutSubheaderService.initAvailableBlackoutTypeSelectItems(
        this._blackoutSubheaderService.getSearchCriteriaForInit().type
      );
  }

  private _initFilterValues(
    searchCriteriaOnInit: BlackoutSearchCriteria
  ): void {
    this.availableColumnSelectItems =
      this._blackoutSubheaderService.initAvailableBlackoutColumnSelectItems(
        this.availableColumns
      );
    this.beginDateFilter = searchCriteriaOnInit.beginDate;
    this.endDateFilter = searchCriteriaOnInit.endDate;
    this.availableStatusFilterChipItems =
      this._blackoutSubheaderService.initAvailableBlackoutStatusChipItems(
        searchCriteriaOnInit.status
      );
    this.availableTypeSelectItems =
      this._blackoutSubheaderService.initAvailableBlackoutTypeSelectItems(
        searchCriteriaOnInit.type
      );
    this.advancedSearchItems = searchCriteriaOnInit.fields
      ? searchCriteriaOnInit.fields.split(",")
      : [];
  }

  private _initMultiSelectConfigs(): void {
    this.typeMultiSelectMenuConfig = {
      isMenuTriggeredByIconButton: false,
      triggerButtonNameOrLabel: "TOUS",
      triggerButtonTooltip: "Sélectionner le(s) type(s) de demandes",
      withApplyButton: true,
      withSelectAllButton: true,
      selectAllButtonLabel: "TOUS",
      theme: CustomMultiSelectMenuTheme.BLUE,
    };
    this.columnMultiSelectMenuConfig = {
      isMenuTriggeredByIconButton: true,
      triggerButtonNameOrLabel: "view_column",
      triggerButtonTooltip: "Sélectionner les colonnes",
      withApplyButton: false,
      withSelectAllButton: false,
      theme: CustomMultiSelectMenuTheme.SMALL_BLACK,
    };
  }
}
