import { Injectable } from "@angular/core";
import { CustomMenuSelectItem } from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import {
  BlackoutSearchCriteria,
  BlackoutTypeEnum,
} from "@app/shared/models/blackout";
import { SekerHomeService } from "../seker-home/seker-home.service";
import { CustomFilterChipItem } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list.model";
import { BlackoutStatusEnum } from "@app/shared/models/blackout";
import { ConstColorBlackoutStatus } from "../blackout-list/blackout-list.model";
import { SekerUtilsService } from "../seker.utils.service";
import { CustomTableColumn } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { CustomSelectableTableBaseService } from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.service";
import { CustomFilterChipListUtilsService } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list-utils.service";

@Injectable({ providedIn: "root" })
export class BlackoutSubheaderService {
  constructor(
    private _sekerHomeService: SekerHomeService,
    private _sekerUtilsService: SekerUtilsService,
    private _customSelectableTableBaseService: CustomSelectableTableBaseService,
    private _customFilterChipListUtilsService: CustomFilterChipListUtilsService
  ) {}

  getSearchCriteriaForInit(): BlackoutSearchCriteria {
    return this._sekerHomeService.getSearchCriteriaForInit();
  }

  initAvailableBlackoutColumnSelectItems(
    availableColumns: CustomTableColumn[]
  ): CustomMenuSelectItem[] {
    return this._customSelectableTableBaseService.initAvailableColumnSelectItems(
      availableColumns,
      "columns_seker"
    );
  }

  initAvailableBlackoutStatusChipItems(
    statusListString: string
  ): CustomFilterChipItem[] {
    return this._customFilterChipListUtilsService.initCustomFilterChipList(
      Object.keys(BlackoutStatusEnum),
      ConstColorBlackoutStatus,
      statusListString
    );
  }

  initAvailableBlackoutTypeSelectItems(
    typeListString: string
  ): CustomMenuSelectItem[] {
    const isTypeFilterExistWhenInit = Boolean(
      typeListString && typeListString.trim() !== ""
    );

    const selectedTypeItemsForInit: string[] = isTypeFilterExistWhenInit
      ? typeListString.split(",")
      : [];

    const typeFilterChipItems: CustomMenuSelectItem[] = Object.keys(
      BlackoutTypeEnum
    ).map((key) => {
      const customMenuSelectItem: CustomMenuSelectItem = {
        label: this._sekerUtilsService.getBlackoutTypeLabel(
          BlackoutTypeEnum[key]
        ),
        value: BlackoutTypeEnum[key],
        selectedOnInit: selectedTypeItemsForInit.includes(key),
      };
      return customMenuSelectItem;
    });
    return typeFilterChipItems;
  }

  buildDateCriteria(
    beginDateTime: string | Date,
    endDateTime: string | Date
  ): BlackoutSearchCriteria {
    const dateCriteria: BlackoutSearchCriteria = {
      page: 0,
      beginDate:
        beginDateTime && beginDateTime !== ""
          ? this._sekerUtilsService.formatDateWithoutSeconds(beginDateTime)
          : undefined,
      endDate:
        endDateTime && endDateTime !== ""
          ? this._sekerUtilsService.formatDateWithoutSeconds(endDateTime)
          : undefined,
    };
    return dateCriteria;
  }

  buildTypeCriteria(selectedItems: string[]): BlackoutSearchCriteria {
    return {
      page: 0,
      type: this._sekerUtilsService.toStringListSeparatedByComma(selectedItems),
    };
  }

  buildStatusCriteria(selectedItems: string[]): BlackoutSearchCriteria {
    return {
      page: 0,
      status:
        this._sekerUtilsService.toStringListSeparatedByComma(selectedItems),
    };
  }

  buildAdvancedSearchCriteria(
    advancedSearchByKeywordItems: string[]
  ): BlackoutSearchCriteria {
    return {
      page: 0,
      fields: this._sekerUtilsService.toStringListSeparatedByComma(
        advancedSearchByKeywordItems
      ),
    };
  }
}
