import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SharedModule } from "@app/shared/shared.module";
import { BlackoutDetailsComponent } from "./blackout-details/blackout-details.component";
import { BlackoutListComponent } from "./blackout-list/blackout-list.component";
import { BlackoutSubheaderComponent } from "./blackout-subheader/blackout-subheader.component";
import { BlackoutRuleSubformComponent } from "./blackout-rule-subform/blackout-rule-subform.component";
import { BlackoutMainInfoSubformComponent } from "./blackout-details/blackout-main-info-subform/blackout-main-info-subform.component";
import { BlackoutSubmitActionComponent } from "./blackout-details/blackout-submit-action/blackout-submit-action.component";
import { SekerHomeComponent } from "./seker-home/seker-home.component";
import { BlackoutTypeSubformComponent } from "./blackout-details/blackout-type-subform/blackout-type-subform.component";
import { CanActivateCreateBlackout } from "./blackout-details/create-blackout.guard";

const routes: Routes = [
  {
    path: "",
    redirectTo: "home",
    pathMatch: "full",
  },
  {
    path: "blackout",
    canActivate: [CanActivateCreateBlackout],
    component: BlackoutDetailsComponent,
  },
  {
    path: "blackout/:idBlackout",
    component: BlackoutDetailsComponent,
  },
  {
    path: "home",
    component: SekerHomeComponent,
  },
  {
    path: "**",
    redirectTo: "home",
  },
];

@NgModule({
  declarations: [
    SekerHomeComponent,
    BlackoutDetailsComponent,
    BlackoutMainInfoSubformComponent,
    BlackoutRuleSubformComponent,
    BlackoutTypeSubformComponent,
    BlackoutListComponent,
    BlackoutSubheaderComponent,
    BlackoutSubmitActionComponent,
  ],
  imports: [RouterModule.forChild(routes), SharedModule],
})
export class SekerModule {}
