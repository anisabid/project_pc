import { animate, style, transition, trigger } from "@angular/animations";
import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { ServiceItem } from "@app/impacted-services/impacted-services.model";

@Component({
  selector: "app-services-list",
  templateUrl: "./services-list.component.html",
  styleUrls: ["./services-list.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger("animateInOut", [
      transition(":enter", [
        style({ opacity: 0 }),
        animate("500ms", style({ opacity: 1 })),
      ]),
      transition(":leave", [animate("500ms", style({ opacity: 0 }))]),
    ]),
  ],
})
export class ServicesListComponent {
  @Input() serviceItems: ServiceItem[];

  labels = {
    NO_RESULTS: "Aucun service indisponible !",
  };

  trackByUniqueKeyFn = (
    indexService: number,
    serviceItem: ServiceItem
  ): string => {
    return this.getUniqueKeyCard(indexService, serviceItem);
  };

  getUniqueKeyCard(indexService: number, serviceItem: ServiceItem): string {
    return `${serviceItem.sirocoReference}-${serviceItem.linkedAlarmsCount.critical}-${serviceItem.linkedAlarmsCount.major}-${serviceItem.linkedAlarmsCount.warning}-${indexService}`;
  }
}
