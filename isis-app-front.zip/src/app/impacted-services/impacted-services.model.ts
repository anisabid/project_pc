import { SfrServiceLevelEnum } from "@app/shared/models/alarm";

/**
 * Service impacté = applicatif impacté
 * - directement = il ya des remontées d'alarmes de cet applicatif
 *         => la référence siroco de l'applicatif (APPXXX) est celle de l'alarme
 * - indirectement = il ya des remontées d'alarmes pour les BDD ou les SRV impactant cet applicatif
 *         => la référence siroco de l'applicatif (APPXXX) n'est pas celle de l'alarme MAIS correspond à
 * un des srv_liens_REF_APP (cas d'un serveur) ou à un des bdd_ref_application_proprietaire (cas d'une BDD)
 *
 *
 * Les alarmes éligibles ne peuvent avoir qu' un 'state'= 'OPEN' OU 'ACK_WITH_TICKET' OU 'ACK_WITHOUT_TICKET' OU 'ACK_WITH_MEP'
 *
 * Les alarmes éligibles possèdent une 'severity' = 'CRITICAL' ou 'MAJOR' ou 'WARNING.
 *
 * Les alarmes éligibles peuvent être recherchées par ligne de service("app_ligne_service") (Tous, un ou plusieurs).
 */

export interface ServiceItem {
  /**
   * 'reference' correspond à :
   * si l'alarme éligible concerne un APP (ex: APP2495) : sfr_ref_clarify (string) de l' alarme
   * si l'alarme éligible concerne un SRV (ex: SRV48368) : un des srv_liens_REF_APP (array of string) de l'alarme
   * si alarme éligible concerne une BDD (ex: BDD12134) : un des bdd_ref_application_proprietaire de l'alarme (array of string aussi ????)
   *
   **/
  sirocoReference: string;
  /**
   * name: correspond au nom associé à la référence.
   * si l'alarme éligible concerne un APP : app_sfr_nom de l'alarme
   * si l'alarme éligible concerne un SRV: Besoin d'enrichir MongoDB pour avoir le nom associé à un élément de srv_liens_REF_APP!!!
   * si l'alarme éligible concerne une BDD : bdd_application_proprietaire de l'alarme
   */
  sirocoName: string;

  /**
   * app_sfr_service_level
   */
  serviceLevel?: SfrServiceLevelEnum;
  /**
   * Ligne de service Métier = ('LS') (ex: Vente),
   * correspond à 'app_ligne_service' d'une alarme éligible.
   * Unique for an alarm of app.
   */
  serviceLine: string;
  /**
   * Nombre d'alarmes associées directement ou indirectement à la référence du service impacté
   *  en fonction de la sévérité.
   * (avec un 'state'= 'OPEN' OU 'ACK_WITH_TICKET' OU 'ACK_WITHOUT_TICKET')
   */
  linkedAlarmsCount: {
    critical: number; // nombre d'alarmes avec 'severity'="CRITICAL"
    major: number; // nombre d'alarmes avec 'severity'="MAJOR"
    warning: number; // nombre d'alarmes avec 'severity'="WARNING"
    total: number; // somme des 3 autres (quelque soit la profondeur de vue sélectionnée ?)
  };
}

export interface ServiceApiItem {
  _id: string;
  critical: number;
  major: number;
  warning: number;
  total: number;
  name: string;
  niveau_de_service: string;
  ligne_de_service: string;
}

export interface FilterByKeywords {
  keywordsList: string;
  isKeywordsExcluded: boolean;
}

export interface ServiceSearchCriteria {
  filterByKeywords: FilterByKeywords;
  filterByAlarmSeverities: string;
}

export const DEFAULT_SERVICE_SEARCH_CRITERIA: ServiceSearchCriteria = {
  filterByKeywords: { keywordsList: "", isKeywordsExcluded: false },
  filterByAlarmSeverities: "",
};
