import { Component, OnInit } from "@angular/core";
import { ServiceItem } from "@app/impacted-services/impacted-services.model";
import { Observable } from "rxjs";
import { ImpactedServicesService } from "../impacted-services.service";

@Component({
  selector: "app-services-home-page",
  templateUrl: "./services-home-page.component.html",
  styleUrls: ["./services-home-page.component.scss"],
})
export class ServicesHomePageComponent implements OnInit {
  isLoadingDataFromApi$: Observable<boolean>;
  displayedServiceItems$: Observable<ServiceItem[]>;

  labels = {
    DATA_LOADING: "Nous procédons au chargement des données...",
  };

  constructor(private _impactedServicesService: ImpactedServicesService) {}

  ngOnInit(): void {
    this.isLoadingDataFromApi$ =
      this._impactedServicesService.isLoadingDataFromApi$;
    this.displayedServiceItems$ =
      this._impactedServicesService.sortedAndFilteredServiceItems$;
  }
}
