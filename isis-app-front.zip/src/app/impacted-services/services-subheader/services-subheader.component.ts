import { Component, OnInit } from "@angular/core";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { AdvancedSearchValue } from "@app/shared/components/custom-advanced-search/custom-advanced-search.component";
import { CustomFilterChipListUtilsService } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list-utils.service";
import { CustomFilterChipItem } from "@app/shared/components/custom-filter-chip-list/custom-filter-chip-list.model";

import {
  CustomMenuSelectItem,
  CustomMultiSelectMenuConfig,
  CustomMultiSelectMenuTheme,
} from "@app/shared/components/custom-multi-select-menu/custom-multi-select-menu.model";
import { ConstColorSeverity } from "@app/shared/consts/color-alarms";
import { Observable, map } from "rxjs";
import { ServiceSearchCriteria } from "../impacted-services.model";
import {
  constSortedByField,
  ImpactedServicesService,
} from "../impacted-services.service";

// has to be same as AlarmSeverityEnum
export enum MinimalAlarmSeverityEnum {
  CRITICAL = "CRITICAL",
  MAJOR = "MAJOR",
  WARNING = "WARNING",
}

@Component({
  selector: "app-services-subheader",
  templateUrl: "./services-subheader.component.html",
  styleUrls: ["./services-subheader.component.scss"],
})
export class ServicesSubheaderComponent implements OnInit {
  serviceLineMultiSelectConfig: CustomMultiSelectMenuConfig;
  availableServiceLineSelectItems: CustomMenuSelectItem[];
  availableSeverityFilterChipItems: CustomFilterChipItem[];
  advancedSearchItems: string[];
  displayAdvancedSearchInput = false;
  isExcludeKeywordsChecked = false;

  allServiceLines$: Observable<string[]>;
  sortByField$: Observable<string>;
  constSortedByFieldChoice = constSortedByField;
  private _storedSelectedValues: string[];

  labels = {
    isisRoute: "ISIS",
    servicesRoute: "SERVICES",
    serviceLines: "LIGNE(S) DE SERVICE :",
    serviceLineButton: "TOUTES",
    noServiceLine: "AUCUNE",
    advancedSearchExclude: "Exclure",
    tooltip: {
      refreshButton: "Rafraîchir les données",
      sortByServiceLineButton: "Trier par ligne de service",
      openSearchButton: "Recherche avancée",
    },
  };

  constructor(
    private _impactedServicesService: ImpactedServicesService,
    private _customFilterChipListUtilsService: CustomFilterChipListUtilsService
  ) {}

  ngOnInit(): void {
    this._initFilters();
    this.sortByField$ = this._impactedServicesService.sortByField$;
    this.allServiceLines$ = this._impactedServicesService.allServiceLines$.pipe(
      map((serviceLines: string[]) => {
        this.availableServiceLineSelectItems =
          this._initOrUpdateAvailableServiceLineSelectItems(serviceLines);
        return serviceLines;
      })
    );
  }

  onClosedServiceLineMultiSelect(currentServiceLines: string[]): void {
    this.availableServiceLineSelectItems =
      this._initOrUpdateAvailableServiceLineSelectItems(
        currentServiceLines,
        this._storedSelectedValues
      );
  }

  onSelectedServiceLines(serviceLines: string[]): void {
    this.storeSelectedValues(serviceLines);
    this._impactedServicesService.updateFilterServiceLines(serviceLines);
  }

  toggleSortedByButton(event: MatCheckboxChange): void {
    this._impactedServicesService.updateSortedByServiceLine(event.checked);
  }

  refreshServices(): void {
    this._impactedServicesService.refreshServices();
  }

  storeSelectedValues(selectedValuesWhenMenuOpen: string[]): void {
    this._storedSelectedValues = selectedValuesWhenMenuOpen;
  }

  toggleAdvancedSearch(event: boolean): void {
    this.displayAdvancedSearchInput = event;
  }

  onSelectedAdvancedSearch(advancedSearchEvent: AdvancedSearchValue): void {
    this.advancedSearchItems = advancedSearchEvent.items;
    this.isExcludeKeywordsChecked = advancedSearchEvent.isCheckboxChecked;
    this._impactedServicesService.refreshWithFilterByKeywords(
      this.advancedSearchItems,
      this.isExcludeKeywordsChecked
    );
  }

  onSelectedSeverity(selectedSeverities: string[]): void {
    this._impactedServicesService.refreshWithFilterBySeverities(
      selectedSeverities?.length ? selectedSeverities.toString() : ""
    );
  }

  private _initOrUpdateAvailableServiceLineSelectItems(
    currentServiceLines: string[],
    selectedValues?: string[]
  ): CustomMenuSelectItem[] {
    return currentServiceLines.map((serviceLine: string) => {
      return <CustomMenuSelectItem>{
        label: serviceLine,
        value: serviceLine,
        selectedOnInit: selectedValues
          ? selectedValues.includes(serviceLine)
          : true,
      };
    });
  }

  private _initMultiSelectConfig(): CustomMultiSelectMenuConfig {
    return {
      isMenuTriggeredByIconButton: false,
      triggerButtonNameOrLabel: this.labels.serviceLineButton,
      withApplyButton: true,
      withSelectAllButton: true,
      withScrollBar: true,
      selectAllButtonLabel: this.labels.serviceLineButton,
      theme: CustomMultiSelectMenuTheme.STANDARD,
    };
  }

  private _initAdvancedSearchFilter(
    currentServiceSearchCriteria?: ServiceSearchCriteria
  ): void {
    const filterByKeywords = currentServiceSearchCriteria?.filterByKeywords;
    const keywordsListOnInit = filterByKeywords?.keywordsList;

    if (keywordsListOnInit?.length) {
      this.advancedSearchItems = keywordsListOnInit.split(",");
      this.isExcludeKeywordsChecked = filterByKeywords.isKeywordsExcluded;
    } else {
      this.advancedSearchItems = [];
      this.isExcludeKeywordsChecked = false;
    }
  }

  private _initFilters(): void {
    this.serviceLineMultiSelectConfig = this._initMultiSelectConfig();
    const serviceSearchCriteriaOnInit =
      this._impactedServicesService.currentServiceSearchCriteria;
    this._initAdvancedSearchFilter(serviceSearchCriteriaOnInit);
    this.availableSeverityFilterChipItems =
      this._customFilterChipListUtilsService.initCustomFilterChipList(
        Object.keys(MinimalAlarmSeverityEnum),
        ConstColorSeverity,
        serviceSearchCriteriaOnInit?.filterByAlarmSeverities
      );
  }
}
