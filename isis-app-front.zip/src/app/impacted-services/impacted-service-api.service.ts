import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AlarmsUtilsService } from "@app/alarms/alarms-utils.service";
import { Alarm, SfrServiceLevelEnum } from "@app/shared/models/alarm";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { Observable, of, switchMap } from "rxjs";
import {
  ServiceApiItem,
  ServiceItem,
  ServiceSearchCriteria,
} from "./impacted-services.model";

@Injectable({ providedIn: "root" })
export class ImpactedServiceApiService {
  private _impactedServicesBaseUrl: string;
  private _headers: HttpHeaders;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService,
    private _alarmsUtilsService: AlarmsUtilsService
  ) {
    this._impactedServicesBaseUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.servicesPath}`;
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
  }

  getImpactedServices(
    serviceSearchCriteria?: ServiceSearchCriteria
  ): Observable<ServiceItem[]> {
    return this._httpClient
      .get<ServiceApiItem[]>(
        this._impactedServicesBaseUrl,
        this._buildHttpOptionsWithParameters(serviceSearchCriteria)
      )
      .pipe(
        switchMap((serviceApiItems: ServiceApiItem[]) => {
          return of(this._getServiceItemsFromServiceApiItems(serviceApiItems));
        })
      );
  }

  private _buildHttpOptionsWithParameters(
    serviceSearchCriteria?: ServiceSearchCriteria
  ): { headers: HttpHeaders; params?: HttpParams } {
    const filterByKeyWords = serviceSearchCriteria?.filterByKeywords;
    const keywordsList = filterByKeyWords?.keywordsList;
    const filterByAlarmSeverities =
      serviceSearchCriteria?.filterByAlarmSeverities;

    if (keywordsList?.length || filterByAlarmSeverities?.length) {
      let parameters: HttpParams = new HttpParams();

      if (keywordsList?.length) {
        parameters = parameters.append("keywords", keywordsList);
        parameters = parameters.append(
          "isKeywordsExcluded",
          filterByKeyWords.isKeywordsExcluded
        );
      }

      if (filterByAlarmSeverities?.length) {
        parameters = parameters.append("severities", filterByAlarmSeverities);
      }

      return {
        headers: this._headers,
        params: parameters,
      };
    } else {
      return {
        headers: this._headers,
      };
    }
  }

  getRelatedAlarms(sirocoReference: string): Observable<Alarm[]> {
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient.get<Alarm[]>(
      `${this._impactedServicesBaseUrl}/${sirocoReference}/alarms`,
      httpOptions
    );
  }

  private _getServiceItemFromServiceApiItem(
    serviceApiItem: ServiceApiItem
  ): ServiceItem {
    return {
      sirocoReference: serviceApiItem._id,
      sirocoName: serviceApiItem.name,
      serviceLevel: serviceApiItem.niveau_de_service
        ? SfrServiceLevelEnum[
            `${this._alarmsUtilsService.getKnownSfrServiceLevelEnumKey(
              serviceApiItem.niveau_de_service
            )}`
          ]
        : null,
      serviceLine: serviceApiItem.ligne_de_service,
      linkedAlarmsCount: {
        critical: serviceApiItem.critical,
        major: serviceApiItem.major,
        warning: serviceApiItem.warning,
        total: serviceApiItem.total,
      },
    };
  }

  private _getServiceItemsFromServiceApiItems(
    serviceApiItems: ServiceApiItem[]
  ): ServiceItem[] {
    return serviceApiItems.map((serviceApiItem: ServiceApiItem) => {
      return this._getServiceItemFromServiceApiItem(serviceApiItem);
    });
  }
}
