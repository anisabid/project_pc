import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import Chart from "chart.js/auto";

@Component({
  selector: "app-custom-doughnut-chart",
  templateUrl: "./custom-doughnut-chart.component.html",
  styleUrls: ["./custom-doughnut-chart.component.scss"],
})
export class CustomDoughnutChartComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy
{
  @Input() doughnutChartId: string;
  @Input() doughnutTitle: string;
  @Input() doughnutLabels: string[];
  @Input() doughnutFillColors: string[];
  @Input() doughnutData: number[];

  data: any;
  config: any;

  private _chart: Chart;

  ngOnInit(): void {
    this.data = {
      labels: this.doughnutLabels,
      datasets: [
        {
          backgroundColor: this.doughnutFillColors,
          data: this.doughnutData,
          hoverOffset: 2,
        },
      ],
    };

    this.config = {
      type: "doughnut",
      data: this.data,
      options: {
        cutout: "60%",
        plugins: {
          legend: {
            display: false,
          },
        },
      },
    };
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this._chart) return;

    const isChangeDoughnutInfo =
      changes.doughnutData ||
      changes.doughnutTitle ||
      changes.doughnutLabels ||
      changes.doughnutFillColors;

    if (isChangeDoughnutInfo) {
      this.data = {
        labels: changes.doughnutLabels
          ? changes.doughnutLabels.currentValue
          : this.doughnutLabels,
        datasets: [
          {
            backgroundColor: changes.doughnutFillColors
              ? changes.doughnutFillColors.currentValue
              : this.doughnutFillColors,
            data: changes.doughnutData
              ? changes.doughnutData.currentValue
              : this.doughnutData,
            hoverOffset: 2,
          },
        ],
      };

      this.config.data = this.data;
      Object.assign(this._chart.config.data, this.config.data);
      this._chart.update();
    }
  }

  ngAfterViewInit(): void {
    this._chart = new Chart(
      (document.getElementById(this.doughnutChartId) as any).getContext("2d"),
      this.config
    );
  }

  ngOnDestroy(): void {
    this._chart.destroy();
  }
}
