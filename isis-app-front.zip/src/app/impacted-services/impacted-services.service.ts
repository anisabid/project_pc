import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import {
  DEFAULT_SERVICE_SEARCH_CRITERIA,
  FilterByKeywords,
  ServiceItem,
  ServiceSearchCriteria,
} from "@app/impacted-services/impacted-services.model";
import {
  Alarm,
  AlarmAvancedSearchPrefix,
  SfrServiceLevelSortOrder,
} from "@app/shared/models/alarm";
import { ToastrService } from "ngx-toastr";
import {
  BehaviorSubject,
  combineLatest,
  Observable,
  Subject,
  map,
  switchMap,
  tap,
  catchError,
  of,
} from "rxjs";
import { ImpactedServiceApiService } from "./impacted-service-api.service";

export interface SortedByField {
  serviceLevel: string;
  serviceLine: string;
}

export const constSortedByField: SortedByField = {
  serviceLevel: "ServiceLevel",
  serviceLine: "ServiceLine",
};

@Injectable({ providedIn: "root" })
export class ImpactedServicesService {
  currentServiceSearchCriteria: ServiceSearchCriteria;

  private _needRefreshBSubj: BehaviorSubject<boolean> = new BehaviorSubject(
    true
  );
  private _filterByKeywordsBSubj: BehaviorSubject<FilterByKeywords>;
  private _filterByAlarmSeveritiesBSubj: BehaviorSubject<string>;

  private _allServiceLinesBSubj: BehaviorSubject<string[]> =
    new BehaviorSubject([]);
  private _sortedByFieldBSubj: BehaviorSubject<string> = new BehaviorSubject(
    constSortedByField.serviceLevel
  );
  private _filterByServiceLinesBSubj: BehaviorSubject<string[]> =
    new BehaviorSubject(["TOUTES"]);

  private _isLoadingDataFromApiBsubj: Subject<boolean> = new BehaviorSubject(
    true
  );

  private _errorLoadingMessage = "Erreur lors du chargement des données !";

  isLoadingDataFromApi$: Observable<boolean>;

  needRefresh$: Observable<boolean>;
  private _serviceItemsFromApi$: Observable<ServiceItem[]>;

  // sort and filter on the frontend side
  private _filterByServiceLines$: Observable<string[]>;
  sortByField$: Observable<string>;

  // filters by keywords and by alarm severities on the backend side
  filterByKeywords$: Observable<FilterByKeywords>;
  filterByAlarmSeverities$: Observable<string>;

  sortedAndFilteredServiceItems$: Observable<ServiceItem[]>;
  allServiceLines$: Observable<string[]>;

  constructor(
    private _impactedServiceApiService: ImpactedServiceApiService,
    private _toastrService: ToastrService,
    private _router: Router
  ) {
    this._initBackendFiltering();
    this._initFrontEndFiltering();
    this._serviceItemsFromApi$ = this._searchServiceItemsFromApiWithFilters();
    this.sortedAndFilteredServiceItems$ =
      this._sortAndFrontFilterServiceItems();
  }

  refreshServices(): void {
    this._needRefreshBSubj.next(true);
  }

  refreshWithFilterByKeywords(
    keywords: string[],
    isKeywordsExcluded: boolean
  ): void {
    const withKeywordsFilter = Boolean(keywords?.length);
    const filterByKeywords: FilterByKeywords = {
      keywordsList: withKeywordsFilter ? keywords.toString() : "",
      isKeywordsExcluded: withKeywordsFilter ? isKeywordsExcluded : false,
    };
    this._filterByKeywordsBSubj.next(filterByKeywords);
  }

  refreshWithFilterBySeverities(filterByAlarmSeverities: string): void {
    this._filterByAlarmSeveritiesBSubj.next(filterByAlarmSeverities);
  }

  updateFilterServiceLines(serviceLines: string[]): void {
    this._filterByServiceLinesBSubj.next(serviceLines);
  }

  updateSortedByServiceLine(checked: boolean): void {
    const sortedByFieldValue = checked
      ? constSortedByField.serviceLine
      : constSortedByField.serviceLevel;
    this._sortedByFieldBSubj.next(sortedByFieldValue);
  }

  getRelatedAlarmIds(sirocoReference: string): Observable<string[]> {
    this._isLoadingDataFromApiBsubj.next(true);
    return this._impactedServiceApiService
      .getRelatedAlarms(sirocoReference)
      .pipe(
        switchMap((alarms: Alarm[]) => {
          return of(
            alarms.map((alarm: Alarm) => {
              return alarm._id;
            })
          );
        }),
        tap(() => {
          this._isLoadingDataFromApiBsubj.next(false);
        }),
        catchError(() => {
          this._doIfErrorWhenLoadingData();
          return [];
        })
      );
  }

  private _getImpactedServiceItemsFromApi(
    serviceSearchCriteria?: ServiceSearchCriteria
  ): Observable<ServiceItem[]> {
    return this._impactedServiceApiService
      .getImpactedServices(serviceSearchCriteria)
      .pipe(
        catchError(() => {
          this._doIfErrorWhenLoadingData();
          return [];
        })
      );
  }

  private _doIfErrorWhenLoadingData(): void {
    this._isLoadingDataFromApiBsubj.next(false);
    this._toastrService.error(this._errorLoadingMessage);
  }

  private _searchServiceItemsFromApiWithFilters(): Observable<ServiceItem[]> {
    return combineLatest([
      this.filterByKeywords$,
      this.filterByAlarmSeverities$,
      this.needRefresh$,
    ]).pipe(
      switchMap(
        ([filterByKeywords, filterByAlarmSeverities, needRefresh]: [
          FilterByKeywords,
          string,
          boolean
        ]) => {
          this._isLoadingDataFromApiBsubj.next(true);

          localStorage.setItem(
            "filter_services",
            JSON.stringify({
              filterByKeywords,
              filterByAlarmSeverities,
            })
          );
          this.currentServiceSearchCriteria = {
            filterByKeywords,
            filterByAlarmSeverities,
          };

          return this._getImpactedServiceItemsFromApi({
            filterByKeywords,
            filterByAlarmSeverities,
          });
        }
      ),
      tap((serviceItemsFromApi: ServiceItem[]) => {
        const allSortedServiceLines =
          this._getAllSortedServiceLines(serviceItemsFromApi);
        this._allServiceLinesBSubj.next(allSortedServiceLines);
        this.updateFilterServiceLines(allSortedServiceLines);
        this._isLoadingDataFromApiBsubj.next(false);
      })
    );
  }

  private _sortAndFrontFilterServiceItems(): Observable<ServiceItem[]> {
    return combineLatest([
      this._serviceItemsFromApi$,
      this.sortByField$,
      this._filterByServiceLines$,
    ]).pipe(
      map(
        ([services, sortByField, filterByServiceLines]: [
          ServiceItem[],
          string,
          string[]
        ]) => {
          const sortedBySfrServiceLevel: ServiceItem[] = [...services].sort(
            this._sortBySfrServiceLevel
          );

          const sortedByField =
            sortByField === constSortedByField.serviceLine
              ? [...sortedBySfrServiceLevel].sort(this._sortByServiceLine)
              : sortedBySfrServiceLevel;

          const filteredByServiceLines = filterByServiceLines.includes("TOUTES")
            ? sortedByField
            : sortedByField.filter((service: ServiceItem) => {
                return filterByServiceLines.includes(service.serviceLine);
              });

          return filteredByServiceLines;
        }
      )
    );
  }

  private _getAllSortedServiceLines(
    serviceItemsFromApi: ServiceItem[]
  ): string[] {
    const serviceLinesFromServices = serviceItemsFromApi.map(
      (serviceItem: ServiceItem) => {
        return serviceItem.serviceLine;
      }
    );

    const sortedDistinctServiceLines = [
      ...new Set(
        [...serviceLinesFromServices].sort(
          (serviceLineA: string, serviceLineB: string) => {
            return serviceLineA.localeCompare(serviceLineB);
          }
        )
      ),
    ];
    return sortedDistinctServiceLines;
  }

  private _initBackendFiltering(): void {
    const currentStorage = localStorage.getItem("filter_services");
    this.currentServiceSearchCriteria = currentStorage
      ? (JSON.parse(currentStorage) as ServiceSearchCriteria)
      : DEFAULT_SERVICE_SEARCH_CRITERIA;

    this._filterByKeywordsBSubj = new BehaviorSubject(
      this.currentServiceSearchCriteria.filterByKeywords
    );

    this._filterByAlarmSeveritiesBSubj = new BehaviorSubject(
      this.currentServiceSearchCriteria.filterByAlarmSeverities
    );

    this.needRefresh$ = this._needRefreshBSubj.asObservable();
    this.filterByKeywords$ = this._filterByKeywordsBSubj.asObservable();
    this.filterByAlarmSeverities$ =
      this._filterByAlarmSeveritiesBSubj.asObservable();
    this.isLoadingDataFromApi$ = this._isLoadingDataFromApiBsubj.asObservable();
  }

  private _initFrontEndFiltering(): void {
    this.allServiceLines$ = this._allServiceLinesBSubj.asObservable();
    this.sortByField$ = this._sortedByFieldBSubj.asObservable();
    this._filterByServiceLines$ =
      this._filterByServiceLinesBSubj.asObservable();
  }

  private _sortByServiceLine = (
    serviceA: ServiceItem,
    serviceB: ServiceItem
  ) => {
    return serviceA.serviceLine.localeCompare(serviceB.serviceLine);
  };

  private _sortBySfrServiceLevel = (
    serviceA: ServiceItem,
    serviceB: ServiceItem
  ) => {
    if (serviceA.serviceLevel === serviceB.serviceLevel) return 0;
    if (!serviceA.serviceLevel) return 1;

    return SfrServiceLevelSortOrder[serviceA.serviceLevel] >
      SfrServiceLevelSortOrder[serviceB.serviceLevel]
      ? 1
      : -1;
  };

  storeAlarmIdsAndGoToAlarms(sirocoRefName: string, alarmIds: string[]): void {
    if (alarmIds?.length && sirocoRefName) {
      const localStorageFG = localStorage.getItem("filter_fg")
        ? JSON.parse(localStorage.getItem("filter_fg"))
        : null;
      const newSearchItems = [
        `${AlarmAvancedSearchPrefix.REF_SERVICE} ${sirocoRefName}`,
      ];
      const updatedLocalStorageFg = localStorageFG
        ? {
            ...localStorageFG,
            search: newSearchItems,
            dates: {
              begin: null,
              end: null,
            },
            severity: {
              CRITICAL: false,
              INFO: false,
              MAJOR: false,
              OK: false,
              UNKNOWN: false,
              WARNING: false,
            },
            states: {
              ACQUITTED_WITHOUT_TICKET: false,
              ACQUITTED_WITH_MEP: false,
              ACQUITTED_WITH_TICKET: false,
              BLACKOUT: false,
              CLOSED: false,
              OPEN: false,
            },
          }
        : { search: newSearchItems };

      localStorage.setItem("filter_fg", JSON.stringify(updatedLocalStorageFg));
      localStorage.setItem("alarm_ids", JSON.stringify(alarmIds.join(",")));
      localStorage.removeItem("blackout_id");
      this._router.navigate(["alarms/si/all"]);
    } else {
      // do nothing
    }
  }
}
