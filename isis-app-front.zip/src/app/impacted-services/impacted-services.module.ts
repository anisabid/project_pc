import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SharedModule } from "@app/shared/shared.module";
import { CustomDoughnutChartComponent } from "./custom-doughnut-chart/custom-doughnut-chart.component";
import { ServiceCardComponent } from "./service-card/service-card.component";
import { ServicesHomePageComponent } from "./services-home-page/services-home-page.component";
import { ServicesListComponent } from "./services-list/services-list.component";
import { ServicesSubheaderComponent } from "./services-subheader/services-subheader.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "home",
    pathMatch: "full",
  },
  {
    path: "home",
    component: ServicesHomePageComponent,
  },
  {
    path: "**",
    redirectTo: "home",
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes), SharedModule],
  declarations: [
    ServicesHomePageComponent,
    ServiceCardComponent,
    ServicesSubheaderComponent,
    ServicesListComponent,
    CustomDoughnutChartComponent,
  ],
})
export class ImpactedServicesModule {}
