import {
  Component,
  Input,
  OnChanges,
  OnDestroy,
  SimpleChanges,
} from "@angular/core";
import { ServiceItem } from "@app/impacted-services/impacted-services.model";
import { ConstColorSeverity } from "@app/shared/consts/color-alarms";
import { SfrServiceLevelCodeRecord } from "@app/shared/models/alarm";
import { Subject, take, takeUntil, tap } from "rxjs";
import { ImpactedServicesService } from "../impacted-services.service";

@Component({
  selector: "app-service-card",
  templateUrl: "./service-card.component.html",
  styleUrls: ["./service-card.component.scss"],
})
export class ServiceCardComponent implements OnChanges, OnDestroy {
  @Input() serviceItem: ServiceItem;
  @Input() uniqueKeyCard: string;

  SfrServiceLevelCode = SfrServiceLevelCodeRecord;

  labels = {
    alarms: "Alarmes",
    alarm: "Alarme",
    severity: "Sévérité",
  };
  severityDoughnutLabels = [
    ConstColorSeverity.CRITICAL.code,
    ConstColorSeverity.MAJOR.code,
    ConstColorSeverity.WARNING.code,
  ];
  severityDoughnutFillColors = [
    ConstColorSeverity.CRITICAL.color,
    ConstColorSeverity.MAJOR.color,
    ConstColorSeverity.WARNING.color,
  ];

  severityDoughnutData: number[];

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(private _impactedServicesService: ImpactedServicesService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.serviceItem?.currentValue) {
      const linkedAlarmsCount =
        changes.serviceItem.currentValue.linkedAlarmsCount;
      this.severityDoughnutData = [
        linkedAlarmsCount.critical ?? 0,
        linkedAlarmsCount.major ?? 0,
        linkedAlarmsCount.warning ?? 0,
      ];
    }
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  seeLinkedAlarms(sirocoReference: string): void {
    this._impactedServicesService
      .getRelatedAlarmIds(sirocoReference)
      .pipe(
        takeUntil(this._needUnsubscribe$),
        take(1),
        tap((alarmIds: string[]) => {
          this._impactedServicesService.storeAlarmIdsAndGoToAlarms(
            sirocoReference,
            alarmIds
          );
        })
      )
      .subscribe();
  }
}
