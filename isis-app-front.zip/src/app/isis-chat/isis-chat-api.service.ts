import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { Observable } from "rxjs";
import { IsisChatMessage, IsisChatUnreadInfo } from "./isis-chat.model";

@Injectable({ providedIn: "root" })
export class IsisChatApiService {
  private _chatMessagesUrl: string;
  private _headers: HttpHeaders;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService
  ) {
    this._chatMessagesUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.chatMessagesPath}`;
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
  }

  getAllChatMessages(): Observable<IsisChatMessage[]> {
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient.get<IsisChatMessage[]>(
      this._chatMessagesUrl,
      httpOptions
    );
  }

  getUnreadMessagesInfo(uperId: string): Observable<IsisChatUnreadInfo> {
    const httpOptions = {
      headers: this._headers,
      params: new HttpParams().set("uperId", uperId),
    };
    const url = `${this._chatMessagesUrl}/unreadMessages`;
    return this._httpClient.get<IsisChatUnreadInfo>(url, httpOptions);
  }

  notifyReadMessageByUser(
    uperId: string,
    messageCounter: number
  ): Observable<void> {
    let parameters: HttpParams = new HttpParams().set("uperId", uperId);
    parameters = parameters.append("chatMessageCounter", messageCounter);
    const httpOptions = {
      headers: this._headers,
      params: parameters,
    };
    const url = `${this._chatMessagesUrl}/userMessagesCounter`;
    return this._httpClient.put<void>(url, {}, httpOptions);
  }
}
