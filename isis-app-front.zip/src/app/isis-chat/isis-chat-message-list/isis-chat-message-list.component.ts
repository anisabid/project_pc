import {
  Component,
  OnInit,
  OnDestroy,
  Input,
  Output,
  EventEmitter,
} from "@angular/core";
import { IsisChatMessage } from "../isis-chat.model";
import {
  Observable,
  Subject,
  takeUntil,
  take,
  map,
  throwError,
  catchError,
} from "rxjs";
import { IsisChatService } from "../isis-chat.service";
import { HttpErrorResponse } from "@angular/common/http";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-isis-chat-message-list",
  templateUrl: "./isis-chat-message-list.component.html",
  styleUrls: ["./isis-chat-message-list.component.scss"],
})
export class IsisChatMessageListComponent implements OnInit, OnDestroy {
  @Input() boxMessagesContainerId: string;
  @Output() chatMessageListUpdatedEmitter: EventEmitter<boolean> =
    new EventEmitter();

  isMessagesLoading = true;
  labels = {
    loadingMessage: "Chargement des messages...",
    noResults: "Aucun message",
  };

  isisChatMessages$: Observable<IsisChatMessage[]>;

  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _isisChatService: IsisChatService,
    private _toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.isMessagesLoading = true;
    this.isisChatMessages$ = this._isisChatService.chatMessages$;

    this._isisChatService
      .getAllMessages()
      .pipe(
        takeUntil(this._needUnsubscribe$),
        take(1),
        map(() => {
          this.chatMessageListUpdatedEmitter.emit(true);
          this.isMessagesLoading = false;
        }),
        catchError((error: HttpErrorResponse) => {
          this._toastrService.error("Erreur lors du chargement des messages !");
          return throwError(() => error);
        })
      )
      .subscribe();

    this._isisChatService.comingChatMessage$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        map((comingMessage: IsisChatMessage) => {
          this._isisChatService.addChatMessageToCurrentList(comingMessage);
          this.chatMessageListUpdatedEmitter.emit(true);
        })
      )
      .subscribe();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  trackByChatMessageIdfFn(index: number, chatMessage: IsisChatMessage): string {
    return chatMessage.id;
  }
}
