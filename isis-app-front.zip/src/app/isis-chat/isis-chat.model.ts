import { FormControl } from "@angular/forms";
import { Delta } from "quill";

export interface IsisChatMessage {
  id?: string;
  idTemporary?: string;
  message?: Partial<Delta>;
  senderName?: string;
  senderUperId?: string;
  sendingTimestamp?: number;
  messageCounter?: number;
}

export interface IsisChatForm {
  isisChatEditorContentText: FormControl<Partial<Delta>>;
}

export interface IsisChatUnreadInfo {
  unreadMessages: number;
  lastReadMessageCounter: number;
}
