import { Component, OnInit, OnDestroy, Input, ViewChild } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { QuillEditorComponent, QuillModules } from "ngx-quill";
import { IsisChatForm } from "../isis-chat.model";
import { IsisChatService } from "../isis-chat.service";
import { takeUntil, Subject, tap } from "rxjs";
import { Delta } from "quill";
import "quill-emoji/dist/quill-emoji.js";

// TECH: see https://quilljs.com/docs/configuration/ for documentation on the rich editor text
@Component({
  selector: "app-isis-chat-form",
  templateUrl: "./isis-chat-form.component.html",
  styleUrls: ["./isis-chat-form.component.scss"],
})
export class IsisChatFormComponent implements OnInit, OnDestroy {
  @Input() maxFormHeight: string;
  @Input() chatBoxWidth: number;

  isisChatPlaceholder = "Saisissez ici votre message";
  isisChatEditorSanitized = true;
  isSendButtonDisabled = true;
  isisChatAllowedFormats: string[];
  isisChatEditorModules: QuillModules = {
    toolbar: [
      [
        "bold",
        "italic",
        "underline",
        "strike",
        { color: [] },
        { background: [] },
        "emoji",
        { header: [1, 2, 3, 4, 5, 6, false] },
        "clean",
      ],
    ],
    "emoji-toolbar": true,
    "emoji-shortname": true,
  };

  isisChatFG: FormGroup<IsisChatForm>;
  @ViewChild("editorComponent") editorComponent: QuillEditorComponent;

  private _currentTrimmedMessageContent: Partial<Delta>;
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(private _isisChatService: IsisChatService) {}

  ngOnInit(): void {
    this.isisChatFG = new FormGroup({
      isisChatEditorContentText: new FormControl(null),
    });
    this.isisChatAllowedFormats = this._isisChatService.isisChatAllowedFormats;

    this.isisChatFG
      .get("isisChatEditorContentText")
      .valueChanges.pipe(
        takeUntil(this._needUnsubscribe$),
        tap((editorContent: Partial<Delta>) => {
          this._currentTrimmedMessageContent =
            this._trimEditorContent(editorContent);
          this.isSendButtonDisabled = this._isSendButtonDisabled(
            this._currentTrimmedMessageContent
          );
        })
      )
      .subscribe();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  sendMessage(event?: KeyboardEvent): void {
    if (!this.isSendButtonDisabled) {
      const trimmedValue = this._trimEditorContent(
        this.isisChatFG.controls["isisChatEditorContentText"].getRawValue()
      );
      this._addSpecificFixForHeaders(trimmedValue);

      this._isisChatService.sendChatMessage({
        message: trimmedValue,
      });
      this.isisChatFG.controls["isisChatEditorContentText"].patchValue(null);
    } else {
      this._removeAdditionalEnter(event);
    }
  }

  addNewLineToEditor(event: KeyboardEvent): void {
    const selection = this.editorComponent.quillEditor.getSelection(true);
    this.editorComponent.quillEditor.insertText(selection.index, "\n");
    const editorElement = event.target as HTMLElement;
    this._scrollDownEditor(editorElement);
  }

  private _scrollDownEditor(editorElement: HTMLElement): void {
    if (editorElement) {
      editorElement.scrollBy({
        top: editorElement.scrollHeight,
        left: 0,
        behavior: "smooth",
      });
    }
  }

  private _removeAdditionalEnter(event: KeyboardEvent): void {
    if (event?.key === "Enter") {
      this.editorComponent.quillEditor.setContents(null);
    } else {
      // do nothing
    }
  }

  private _isSendButtonDisabled(editorContent: Partial<Delta>): boolean {
    const firstWord = editorContent?.ops[0]?.insert;
    return (
      !firstWord ||
      (editorContent?.ops?.length === 1 &&
        (typeof firstWord === "string" || firstWord instanceof String) &&
        firstWord.trim().length === 0)
    );
  }

  private _trimEditorContent(editorContent: Partial<Delta>): Partial<Delta> {
    if (!editorContent) return null;
    if (!editorContent.ops) return editorContent;

    const startContent = editorContent.ops[0].insert;
    const isStartContentIsString =
      typeof startContent === "string" || startContent instanceof String;
    const endContent = editorContent.ops[editorContent.ops.length - 1].insert;
    const isEndContentIsString =
      typeof endContent === "string" || endContent instanceof String;

    const trimmedEditorContent: Partial<Delta> = JSON.parse(
      JSON.stringify(editorContent)
    ); // allow a copy without keeping references

    if (isStartContentIsString) {
      trimmedEditorContent.ops[0].insert =
        trimmedEditorContent.ops[0].insert.trimStart();
    }

    if (isEndContentIsString) {
      trimmedEditorContent.ops[trimmedEditorContent.ops.length - 1].insert =
        trimmedEditorContent.ops[
          trimmedEditorContent.ops.length - 1
        ].insert.trimEnd();
    }
    return trimmedEditorContent;
  }

  private _addSpecificFixForHeaders(editorContent: Partial<Delta>): void {
    const lastOperationIndex = editorContent?.ops?.length - 1;
    if (
      lastOperationIndex > -1 &&
      editorContent?.ops[lastOperationIndex]?.attributes?.header
    ) {
      editorContent.ops[lastOperationIndex].insert = "\n";
    }
  }
}
