import {
  Component,
  AfterViewInit,
  OnInit,
  OnDestroy,
  ElementRef,
  Input,
  HostListener,
  ViewChild,
  Output,
  EventEmitter,
} from "@angular/core";
import { IsisChatService } from "../isis-chat.service";

const enum ResizeStatusEnum {
  OFF = 0,
  ON = 1,
}

@Component({
  selector: "app-isis-chat-box",
  templateUrl: "./isis-chat-box.component.html",
  styleUrls: ["./isis-chat-box.component.scss"],
})
export class IsisChatBoxComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() dragBoundaryParentClass: string;
  @Input() minEditorHeight: number;
  @Input() minWidth: number;
  @Input() minHeight: number;

  @Input()
  get isOpen(): boolean {
    return this._isOpen;
  }
  set isOpen(needOpen: boolean) {
    this._isOpen = needOpen;

    if (this._isOpen) {
      let asyncAction = setTimeout(() => {
        this._getChatBoxPosition();
      }, 0);
      asyncAction = null;
      this.scrollDown(this._isOpen);
    }
  }
  private _isOpen = false;

  @Output() needCloseChatBoxEmitter: EventEmitter<string> =
    new EventEmitter<string>();

  @ViewChild("chatBox") chatBox: ElementRef;

  isisChatContainerId = "isis-chat-messages-id";

  chatBoxWidth: number;
  chatBoxHeight: number;

  mousePos: { x: number; y: number };

  chatBoxPos: {
    left: number;
    top: number;
    right: number;
    bottom: number;
  };

  boxContainerPos: {
    left: number;
    top: number;
    right: number;
    bottom: number;
  };

  private _resizeStatus = ResizeStatusEnum.OFF;
  private _timeOutBeforeScroll;

  constructor(private _isisChatService: IsisChatService) {}

  ngOnInit(): void {
    this.chatBoxWidth = this.minWidth;
    this.chatBoxHeight = this.minHeight;
  }

  ngAfterViewInit(): void {
    this._getContainerPosition();
  }

  ngOnDestroy(): void {
    if (this._timeOutBeforeScroll) {
      clearTimeout(this._timeOutBeforeScroll);
    }
  }

  @HostListener("window:mousemove", ["$event"])
  onMouseMouse(event: MouseEvent): void {
    this.mousePos = { x: event.clientX, y: event.clientY };
    if (this._resizeStatus === ResizeStatusEnum.ON) {
      this._resizeChatBox();
    }
  }

  closeChatBox(): void {
    this.needCloseChatBoxEmitter.emit("close");
  }

  setResizeStatus(event: MouseEvent, status: number): void {
    if (status === 1) {
      event.stopPropagation();
    } else {
      this._getChatBoxPosition();
    }
    this._resizeStatus = status;
  }

  calculateAndSetFooterMaxHeight(): string {
    const formMaxHeight = this.chatBoxHeight * 0.7;
    const editorMaxHeightInpx = `${formMaxHeight - 10 - 40}px`;
    const quillEditorElements = document.getElementsByClassName("ql-editor");

    if (quillEditorElements?.[0]) {
      (quillEditorElements[0] as HTMLElement).style.maxHeight =
        editorMaxHeightInpx;
    }

    return `${formMaxHeight}px`;
  }

  calculateHeightMessagesBox(): string {
    return `${this.chatBoxHeight - this.minEditorHeight}px`;
  }

  scrollDown(isOpenChatBox: boolean): void {
    if (this._timeOutBeforeScroll) {
      clearTimeout(this._timeOutBeforeScroll);
    }
    this._timeOutBeforeScroll = setTimeout(() => {
      const scrollingContainer = document.getElementById(
        this.isisChatContainerId
      );
      if (scrollingContainer) {
        scrollingContainer.scrollBy({
          top: scrollingContainer.scrollHeight,
          left: 0,
          behavior: "auto", // has to be instantly
        });
        this._isisChatService.updateAutomaticScrollOfContainerFinished(
          isOpenChatBox
        );
      }
    }, 0);
  }

  private _resizeChatBox(): void {
    const diffX = this.chatBoxPos.right - this.mousePos.x;
    const diffContainerX = this.chatBoxPos.right - this.boxContainerPos.left;
    this.chatBoxWidth = Number(
      this.mousePos.x < this.chatBoxPos.left
        ? this.mousePos.x >= this.boxContainerPos.left
          ? diffX
          : diffContainerX
        : diffX > this.minWidth
        ? diffX
        : this.minWidth
    );
    const diffY = this.chatBoxPos.bottom - this.mousePos.y;
    const diffContainerY = this.chatBoxPos.bottom - this.boxContainerPos.top;
    this.chatBoxHeight = Number(
      this.mousePos.y < this.chatBoxPos.top
        ? this.mousePos.y >= this.boxContainerPos.top
          ? diffY
          : diffContainerY
        : diffY > this.minHeight
        ? diffY
        : this.minHeight
    );
  }

  private _getChatBoxPosition(): void {
    if (this.chatBox?.nativeElement) {
      const { left, top, right, bottom } =
        this.chatBox?.nativeElement.getBoundingClientRect() as {
          left: number;
          top: number;
          right: number;
          bottom: number;
        };
      this.chatBoxPos = { left, top, right, bottom };
    }
  }

  private _getContainerPosition(): void {
    const { left, top, right, bottom } = document
      .getElementsByClassName(this.dragBoundaryParentClass.slice(1))[0]
      .getBoundingClientRect();

    this.boxContainerPos = { left, top, right, bottom };
  }
}
