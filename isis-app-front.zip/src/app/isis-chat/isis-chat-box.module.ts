import { DragDropModule } from "@angular/cdk/drag-drop";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { MatBadgeModule } from "@angular/material/badge";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { QuillModule } from "ngx-quill";
import { IsisChatBoxComponent } from "./isis-chat-box/isis-chat-box.component";
import { IsisChatFormComponent } from "./isis-chat-form/isis-chat-form.component";
import { IsisChatMessageListComponent } from "./isis-chat-message-list/isis-chat-message-list.component";
import { IsisChatMessageComponent } from "./isis-chat-message/isis-chat-message.component";

@NgModule({
  declarations: [
    IsisChatBoxComponent,
    IsisChatMessageListComponent,
    IsisChatMessageComponent,
    IsisChatFormComponent,
  ],
  imports: [
    CommonModule,
    DragDropModule,
    MatIconModule,
    MatButtonModule,
    ReactiveFormsModule,
    QuillModule,
    MatBadgeModule,
  ],
  exports: [
    IsisChatBoxComponent,
    IsisChatMessageListComponent,
    IsisChatMessageComponent,
    IsisChatFormComponent,
  ],

  bootstrap: [IsisChatBoxComponent],
})
export class IsisChatBoxModule {
  getComponentType(): typeof IsisChatBoxComponent {
    return IsisChatBoxComponent;
  }
}
