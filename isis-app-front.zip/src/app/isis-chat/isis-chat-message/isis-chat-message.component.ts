import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import {
  IsisChatForm,
  IsisChatMessage,
  IsisChatUnreadInfo,
} from "../isis-chat.model";
import {
  delay,
  map,
  Observable,
  Subject,
  Subscription,
  take,
  takeUntil,
  tap,
  switchMap,
  of,
  catchError,
  throwError,
} from "rxjs";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisChatService } from "../isis-chat.service";
import { QuillModules } from "ngx-quill";
import { FormControl, FormGroup } from "@angular/forms";
import "quill-emoji/dist/quill-emoji.js";
import { ToastrService } from "ngx-toastr";
import { HttpErrorResponse } from "@angular/common/http";

@Component({
  selector: "app-isis-chat-message",
  templateUrl: "./isis-chat-message.component.html",
  styleUrls: ["./isis-chat-message.component.scss"],
})
export class IsisChatMessageComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy
{
  @Input() isisChatMessage: IsisChatMessage;
  @Input() boxMessagesContainerId: string;

  automaticScrollOfContainerFinished$: Observable<boolean>;

  isFromUser: boolean;
  isisChatEditorReadModules: QuillModules = {
    toolbar: [],
  };
  isisChatAllowedFormats: string[];
  isisChatEditorSanitized = true;
  isisChatMessageFG: FormGroup<IsisChatForm>;
  isEditorReadOnly = true;

  labels = {
    senderMe: "Moi",
    sendingInProgress: "Envoi en cours...",
  };
  isFlashing: boolean;

  private _flashingDurationInMs = 2500;
  private _lastReadChatMessageCounter: number;
  private _intersectionObserverSubscription: Subscription;
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _securityService: KeycloakSecurityService,
    private _isisChatService: IsisChatService,
    private _toastrService: ToastrService,
    private _cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.isisChatAllowedFormats = this._isisChatService.isisChatAllowedFormats;
    this.automaticScrollOfContainerFinished$ =
      this._isisChatService.automaticScrollOfContainerFinished$;
    this._isisChatService.currentUnreadInfo$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        map((unreadInfo: IsisChatUnreadInfo) => {
          this._lastReadChatMessageCounter = unreadInfo.lastReadMessageCounter;
          if (this._intersectionObserverSubscription) {
            this._subscribeToIntersectionObserverStreamIfNotRead();
          }
        })
      )
      .subscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.isisChatMessage?.currentValue) {
      this.isFromUser =
        changes.isisChatMessage.currentValue.senderUperId ===
        `u${this._securityService.getUser().uperId}`;
      this.isisChatMessageFG = new FormGroup({
        isisChatEditorContentText: new FormControl(
          changes.isisChatMessage.currentValue.message
        ),
      });
    }
  }

  ngAfterViewInit(): void {
    this._subscribeToIntersectionObserverStreamIfNotRead();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  private _isMessageReadByUser(chatMessage: IsisChatMessage): boolean {
    const isSendingMessage = Boolean(chatMessage.idTemporary);
    const currentUserUperId = `u${this._securityService.getUser().uperId}`;
    const isSenderUser = chatMessage.senderUperId === currentUserUperId;
    return (
      isSendingMessage ||
      isSenderUser ||
      chatMessage.messageCounter <= this._lastReadChatMessageCounter
    );
  }

  private _createIntersectionObserverAndObserve(): Observable<boolean> {
    const containerScrollingBox = document.getElementById(
      this.boxMessagesContainerId
    ) as Element;
    const chatMessageDiv = document.getElementById(
      this.isisChatMessage?.id
    ) as Element;

    const optionsForObserver: IntersectionObserverInit = {
      root: containerScrollingBox,
      rootMargin: "0px 0px 0px 0px",
      threshold: 0.75,
    };

    return new Observable<boolean>((subscriber) => {
      const intersectionObserver = new IntersectionObserver((entries) => {
        const { isIntersecting } = entries[0];
        subscriber.next(isIntersecting);
        if (isIntersecting) {
          intersectionObserver.disconnect();
        }
      }, optionsForObserver);

      intersectionObserver.observe(chatMessageDiv);

      return {
        unsubscribe() {
          intersectionObserver.disconnect();
        },
      };
    });
  }

  private _subscribeToIntersectionObserverStreamIfNotRead(): void {
    const isMessageRead = this._isMessageReadByUser(this.isisChatMessage);

    if (!isMessageRead) {
      if (this._intersectionObserverSubscription) {
        this._intersectionObserverSubscription.unsubscribe();
      }

      this._intersectionObserverSubscription =
        this.automaticScrollOfContainerFinished$
          .pipe(
            takeUntil(this._needUnsubscribe$),
            switchMap((isFinished: boolean) => {
              if (isFinished) {
                return this._createIntersectionObserverAndObserve().pipe(
                  takeUntil(this._needUnsubscribe$),
                  tap(() => {
                    this.isFlashing = true;
                    this._cdRef.markForCheck();
                  }),
                  delay(this._flashingDurationInMs),
                  switchMap((isVisibleInChatBox: boolean) => {
                    this.isFlashing = !isVisibleInChatBox;
                    this._cdRef.markForCheck();

                    if (isVisibleInChatBox) {
                      this._isisChatService
                        .readChatMessage(this.isisChatMessage)
                        .pipe(
                          takeUntil(this._needUnsubscribe$),
                          take(1),
                          catchError((error: HttpErrorResponse) => {
                            this._toastrService.error(
                              "Erreur lors de la lecture d'un message !"
                            );
                            return throwError(() => error);
                          })
                        )
                        .subscribe();
                    }
                    return of(isVisibleInChatBox);
                  })
                );
              } else {
                return of(false);
              }
            })
          )
          .subscribe();
    } else {
      if (this._intersectionObserverSubscription) {
        this._intersectionObserverSubscription.unsubscribe();
      }
      this.isFlashing = false;
    }
  }
}
