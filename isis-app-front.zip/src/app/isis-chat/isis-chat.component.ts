import {
  Component,
  createNgModuleRef,
  Injector,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewContainerRef,
} from "@angular/core";
import {
  Subject,
  Subscription,
  takeUntil,
  take,
  map,
  catchError,
  throwError,
} from "rxjs";
import { IsisChatService } from "./isis-chat.service";
import { IsisChatUnreadInfo } from "./isis-chat.model";
import { HttpErrorResponse } from "@angular/common/http";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-isis-chat",
  templateUrl: "./isis-chat.component.html",
  styleUrls: ["./isis-chat.component.scss"],
})
export class IsisChatComponent implements OnInit, OnDestroy {
  @Input() dragChatBoundaryParentClass?: string;

  chatBoxMinWidth = 353;
  chatBoxMinHeight = 400;
  minEditorHeight = 138;

  private _needUnsubscribe$ = new Subject<boolean>();

  isOpenChatBox = false;
  isChatBoxOpenAtLeastOnce = false;
  notReadCount: number;

  isisChatBoxSubscription: Subscription;
  @ViewChild("isisChatBoxComponent", { read: ViewContainerRef })
  isisChatBoxComponent!: ViewContainerRef;

  private _instanceChatBoxComponent: any; // TECH: don't use type to benefit chunk splitting.

  constructor(
    private _isisChatService: IsisChatService,
    private _injector: Injector,
    private _toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this._isisChatService.currentUnreadInfo$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        map((unreadInfo: IsisChatUnreadInfo) => {
          this.notReadCount = unreadInfo.unreadMessages;
          return unreadInfo;
        })
      )
      .subscribe();

    this._isisChatService
      .getUnreadMessagesInfo()
      .pipe(
        takeUntil(this._needUnsubscribe$),
        take(1),
        catchError((error: HttpErrorResponse) => {
          this._toastrService.error(
            "Erreur lors du chargement des messages non lus !"
          );
          return throwError(() => error);
        })
      )
      .subscribe();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
    if (this.isisChatBoxSubscription) {
      this.isisChatBoxSubscription.unsubscribe();
    }
  }

  async loadIsisChatBoxModuleAndComponent(): Promise<void> {
    const { IsisChatBoxModule } = await import("./isis-chat-box.module");
    const moduleRef = createNgModuleRef(IsisChatBoxModule, this._injector);
    const isisChatBoxComponent = moduleRef.instance.getComponentType();
    this.isisChatBoxComponent.clear();
    const { instance } = this.isisChatBoxComponent.createComponent(
      isisChatBoxComponent,
      {
        ngModuleRef: moduleRef,
      }
    );
    instance.dragBoundaryParentClass = this.dragChatBoundaryParentClass;
    instance.isOpen = this.isOpenChatBox;
    instance.minEditorHeight = this.minEditorHeight;
    instance.minWidth = this.chatBoxMinWidth;
    instance.minHeight = this.chatBoxMinHeight;
    this.isisChatBoxSubscription = instance.needCloseChatBoxEmitter.subscribe(
      () => {
        this.toggleChatBox();
      }
    );
    this._instanceChatBoxComponent = instance;
  }

  toggleChatBox(): void {
    if (!this.isChatBoxOpenAtLeastOnce) {
      this.isChatBoxOpenAtLeastOnce = true;
      this.loadIsisChatBoxModuleAndComponent();
    }
    this.isOpenChatBox = !this.isOpenChatBox;
    if (this._instanceChatBoxComponent) {
      this._instanceChatBoxComponent.isOpen = this.isOpenChatBox;
    }
  }
}
