import { Injectable } from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { WebsocketService } from "@app/service/notify/websocket.service";
import {
  BehaviorSubject,
  merge,
  shareReplay,
  map,
  Subject,
  Observable,
} from "rxjs";
import { IsisChatApiService } from "./isis-chat-api.service";
import { IsisChatMessage, IsisChatUnreadInfo } from "./isis-chat.model";

@Injectable({ providedIn: "root" })
export class IsisChatService {
  private _unreadInfoFromRestSubject: Subject<IsisChatUnreadInfo>;
  private _unreadInfoFromRest$: Observable<IsisChatUnreadInfo>;
  private _chatMessagesSubject: Subject<IsisChatMessage[]>;
  private _currentChatMessagesList: IsisChatMessage[];

  currentUnreadInfo$: Observable<IsisChatUnreadInfo>;
  comingChatMessage$: Observable<IsisChatMessage>;
  chatMessages$: Observable<IsisChatMessage[]>;

  private _automaticScrollOfContainerFinishedBSubject: BehaviorSubject<boolean>;
  automaticScrollOfContainerFinished$: Observable<boolean>;
  isisChatAllowedFormats: string[] = [
    "bold",
    "italic",
    "underline",
    "strike",
    "color",
    "background",
    "header",
    "emoji",
  ]; // TECH NOTES: specifically no script no image no video

  constructor(
    private _isisChatApiService: IsisChatApiService,
    private _websocketService: WebsocketService,
    private _securityService: KeycloakSecurityService
  ) {
    this._chatMessagesSubject = new Subject();
    this.chatMessages$ = this._chatMessagesSubject.asObservable();

    this._unreadInfoFromRestSubject = new Subject();
    this._unreadInfoFromRest$ = this._unreadInfoFromRestSubject.asObservable();

    this.currentUnreadInfo$ = merge(
      this._unreadInfoFromRest$,
      this._websocketService.unreadMessagesInfo$
    ).pipe(shareReplay(1));

    this.comingChatMessage$ = this._websocketService.comingChatMessage$;

    this._automaticScrollOfContainerFinishedBSubject =
      new BehaviorSubject<boolean>(false);
    this.automaticScrollOfContainerFinished$ =
      this._automaticScrollOfContainerFinishedBSubject.asObservable();
  }

  getAllMessages(): Observable<IsisChatMessage[]> {
    return this._isisChatApiService.getAllChatMessages().pipe(
      map((chatMessages: IsisChatMessage[]) => {
        this._updateCurrentMessagesList(chatMessages);
        return chatMessages;
      })
    );
  }

  getUnreadMessagesInfo(): Observable<IsisChatUnreadInfo> {
    return this._isisChatApiService
      .getUnreadMessagesInfo(`u${this._securityService.getUser().uperId}`)
      .pipe(
        map((unreadMessagesInfo: IsisChatUnreadInfo) => {
          this._unreadInfoFromRestSubject.next(unreadMessagesInfo);
          return unreadMessagesInfo;
        })
      );
  }

  sendChatMessage(isisChatMessageFragment: Partial<IsisChatMessage>): void {
    const senderUperId = `u${this._securityService.getUser().uperId}`;

    const messageToSend: IsisChatMessage = {
      ...isisChatMessageFragment,
      senderName: this._securityService.getUser().username,
      senderUperId: senderUperId,
      sendingTimestamp: Date.now(),
    };
    this.addChatMessageToCurrentList(messageToSend);
    this._websocketService.send(
      "/app/chatMessages",
      JSON.stringify(messageToSend)
    );
  }

  readChatMessage(
    isisChatMessageFragment: Partial<IsisChatMessage>
  ): Observable<void> {
    const readerUperId = `u${this._securityService.getUser().uperId}`;
    return this._isisChatApiService.notifyReadMessageByUser(
      readerUperId,
      isisChatMessageFragment.messageCounter
    );
  }

  updateAutomaticScrollOfContainerFinished(isFinished: boolean): void {
    this._automaticScrollOfContainerFinishedBSubject.next(isFinished);
  }

  private _updateCurrentMessagesList(
    updatedChatMessages: IsisChatMessage[]
  ): void {
    this._currentChatMessagesList = [...updatedChatMessages];
    this._chatMessagesSubject.next(this._currentChatMessagesList);
  }

  addChatMessageToCurrentList(isisChatMessage: IsisChatMessage): void {
    if (!isisChatMessage?.id) {
      this._updateCurrentMessagesList(
        this._addTemporaryMessageToList(isisChatMessage)
      );
    } else {
      this._updateCurrentMessagesList(
        this._addOrReplaceMessageInList(isisChatMessage)
      );
    }
  }

  private _addTemporaryMessageToList(
    isisChatMessage: IsisChatMessage
  ): IsisChatMessage[] {
    const messageToAdd: IsisChatMessage = {
      ...isisChatMessage,
      idTemporary: "idTemporary",
    };
    return this._currentChatMessagesList
      ? [...this._currentChatMessagesList, messageToAdd]
      : [messageToAdd];
  }

  private _addOrReplaceMessageInList(
    isisChatMessage: IsisChatMessage
  ): IsisChatMessage[] {
    const chatMessagesWithoutTemporaryMessage =
      this._currentChatMessagesList?.filter((chatMessage: IsisChatMessage) => {
        return (
          chatMessage.sendingTimestamp !== isisChatMessage.sendingTimestamp
        );
      });

    return chatMessagesWithoutTemporaryMessage
      ? [...chatMessagesWithoutTemporaryMessage, isisChatMessage]
      : [isisChatMessage];
  }
}
