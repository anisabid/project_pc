import { Injectable } from "@angular/core";

@Injectable({ providedIn: "root" })
export class IsisUtilsService {
  getStringValueOrUndefined(stringValue: string): string {
    return stringValue?.length ? stringValue : undefined;
  }

  getStringValueOrEmpty(stringValue: string): string {
    return stringValue?.length ? stringValue : "";
  }
}
