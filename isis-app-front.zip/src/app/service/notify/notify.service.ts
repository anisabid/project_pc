// created by Chamsoudine ALI at 20200122 17:22.
//
// Chamsoudine ALI - GFI Informatique
// https://github.com/ChamsII

import { Injectable } from "@angular/core";
import { Alarm, AlarmInProgressSource } from "@app/shared/models/alarm";
import { WebsocketService } from "./websocket.service";

@Injectable({
  providedIn: "root",
})
export class NotifyService {
  constructor(private _websocketService: WebsocketService) {}

  // TODO: refacto this service

  /**
   * Vérifie si l'utilisateur a bloqué une alarme en traitement et le libère
   * Notifie tous les utilisateurs du blockage de l'alarme ar l'utilisateur
   */
  sendAcknowledge(message): void {
    // TODO add type for message
    const alarm: Alarm = message.alarm;
    const _source: AlarmInProgressSource = {
      ...alarm._source,
      user: {
        username: message.user.username,
        uperId: message.user.uperId,
      },
    };
    const alarmInProgress: Alarm = { ...alarm, _source };
    this._websocketService.send(
      "/app/acknowladge",
      JSON.stringify(alarmInProgress)
    );
  }

  /**
   * Notifie les utilisateurs de la fin de traitement d'une alarme
   */
  sendEndAcknowledge(message): void {
    // TODO add type for message
    const alarm: Alarm = message.alarm;
    const _source: AlarmInProgressSource = {
      ...alarm._source,
      user: {
        username: message.user.username,
        uperId: message.user.uperId,
      },
    };
    const alarmInProgress: Alarm = { ...alarm, _source };
    this._websocketService.send(
      "/app/endAcknowladge",
      JSON.stringify(alarmInProgress)
    );
  }
}
