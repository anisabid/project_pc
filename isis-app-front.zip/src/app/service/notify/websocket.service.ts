import { Injectable } from "@angular/core";
import * as Stomp from "stompjs";
import { Observable, timer } from "rxjs";
import { EnvironmentService } from "@app/shared/services/environment/environment.service";
import { Alarm } from "@app/shared/models/alarm";
import {
  IsisChatMessage,
  IsisChatUnreadInfo,
} from "@app/isis-chat/isis-chat.model";
import { Subject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class WebsocketService {
  stompClient: any; // the stomp client (type doesn't exist) // see doc:  http://jmesnil.net/stomp-websocket/doc/
  notifiedAlarms: Alarm[];

  unreadMessagesInfo$: Observable<IsisChatUnreadInfo>;
  comingChatMessage$: Observable<IsisChatMessage>;

  private _unreadMessagesInfoSubject: Subject<IsisChatUnreadInfo>;
  private _comingChatMessageSubject: Subject<IsisChatMessage>;

  private _everyMinutes: Observable<number> = timer(0, 1000 * 60 * 1);
  private _disableWebsocketLog: boolean;

  constructor(private environmentService: EnvironmentService) {
    this.notifiedAlarms = [];
    this._disableWebsocketLog =
      this.environmentService.config.alarms__websocket__logs__disable;
    this._comingChatMessageSubject = new Subject();
    this._unreadMessagesInfoSubject = new Subject();
    this.comingChatMessage$ = this._comingChatMessageSubject.asObservable();
    this.unreadMessagesInfo$ = this._unreadMessagesInfoSubject.asObservable();
  }

  init(uperId: string): void {
    const socket = new WebSocket(
      `${this.environmentService.socketUrl}/greeting`
    );
    this.stompClient = Stomp.over(socket); // method return a StompClient (type doesn't exist)

    if (this._disableWebsocketLog) {
      this.stompClient.debug = null;
    }

    this.stompClient.connect(
      {},
      () => {
        this._subscribeToAcknowledgeTopic();
        this._subscribeToEndAcknowledgeTopic();
        this._subscribeToUnreadChatMessagesCount(uperId);
        this._subscribeToChatMessages();
      },
      () => {
        this.init(uperId);
      }
    );
    this._everyMinutes.subscribe(() => {
      this._sendHeartBeat("/app/heart", `client ${new Date().toUTCString()}`);
    });
  }

  private _subscribeToAcknowledgeTopic(): void {
    this.stompClient.subscribe("/topic/acknowladge", (stompFrame) => {
      const stompFrameBody = stompFrame?.body;
      if (stompFrameBody) {
        const alarmFromStomp: Alarm = JSON.parse(stompFrameBody).body; // due to additional headers in the stompBody
        if (alarmFromStomp._id) {
          this._replaceOrAddAlarmInNotifiedAlarms(alarmFromStomp);
        }
      }
    });
  }

  private _subscribeToEndAcknowledgeTopic(): void {
    this.stompClient.subscribe("/topic/endAcknowladge", (stompFrame) => {
      const stompFrameBody = stompFrame?.body;
      if (stompFrameBody) {
        const res = JSON.parse(stompFrameBody);
        if (res._id) {
          // when no headers inside stompBody
          const alarmFromStomp: Alarm = JSON.parse(stompFrameBody);
          this._replaceOrAddAlarmInNotifiedAlarms(alarmFromStomp);
        }

        if (res.body?._id) {
          // due to additional headers in the stompBody sometimes...
          const alarmFromStomp: Alarm = JSON.parse(stompFrameBody).body;
          this._replaceOrAddAlarmInNotifiedAlarms(alarmFromStomp);
        }
      }
    });
  }

  private _replaceOrAddAlarmInNotifiedAlarms(alarmFromStomp: Alarm): void {
    this.notifiedAlarms = [
      ...this.notifiedAlarms.filter((notifiedAlarm: Alarm) => {
        return alarmFromStomp._id !== notifiedAlarm._id;
      }),
      alarmFromStomp,
    ];
  }

  private _subscribeToUnreadChatMessagesCount(uperId: string): void {
    this.stompClient.subscribe(
      `/topic/unreadMessages/${uperId}`,
      (stompFrame) => {
        const stompFrameBody = stompFrame.body;
        if (stompFrameBody) {
          this._unreadMessagesInfoSubject.next(JSON.parse(stompFrameBody));
        }
      }
    );
  }

  private _subscribeToChatMessages(): void {
    this.stompClient.subscribe("/topic/chatMessages", (stompFrame) => {
      const stompFrameBody = stompFrame.body;
      if (stompFrameBody) {
        const res = JSON.parse(stompFrameBody);
        if (res.id) {
          // when no headers inside stompBody sometimes...
          this._comingChatMessageSubject.next(res);
        }

        if (res.body?.id) {
          // due to additional headers in the stompBody sometimes...
          this._comingChatMessageSubject.next(JSON.parse(stompFrameBody).body);
        }
      } else {
        this._comingChatMessageSubject.next(JSON.parse(stompFrame));
      }
    });
  }

  send(destination: string, body: string): void {
    this.stompClient.send(destination, {}, body);
  }

  private _sendHeartBeat(url: string, message: string): void {
    if (this.stompClient.connected) {
      this.stompClient.send(url, {}, message);
    }
  }
}
