import { TestBed } from "@angular/core/testing";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { NotifyService } from "./notify.service";
import { APP_CONFIG } from "@app/app.config";

export const appConfigForTest = {
  ciEnvironment: "default-localhost",
  isProduction: false,
  environmentName: "hors_prod_localhost",
  socketUrl:
    "ws://isis-spring-app-back-v2.isis-int.ctn1.pic.services.pack/api/v1",
  api: {
    schemes: "http://",
    host: "isis-spring-app-back-v2.isis-int.ctn1.pic.services.pack/",
    basePath: "api/v1/",
  },
  config: {
    alarms__cron__timer_init: 60000,
    alarms__cron__timer_loop: 60000,
    alarms__lock__timer_loop: 300,
    alarms__websocket__logs__disable: false,
  },
  keyCloakIsis: {
    url: "https://auth.pack.valentine.sfr.com/auth/",
    realm: "valentine",
    clientId: "isis-ihm",
  },
};

describe("NotifyService", () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: APP_CONFIG,
          useValue: appConfigForTest,
        },
      ],
    })
  );

  it("should be created", () => {
    const service: NotifyService = TestBed.inject(NotifyService);
    expect(service).toBeTruthy();
  });
});
