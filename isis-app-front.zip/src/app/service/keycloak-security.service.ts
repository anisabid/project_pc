import { Injectable } from "@angular/core";
import { KeycloakService } from "keycloak-angular";
import { WebsocketService } from "./notify/websocket.service";
import { Observable, first, map, lastValueFrom } from "rxjs";
import { EnvironmentService } from "@app/shared/services/environment/environment.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ErrorPageService } from "@app/shared/components/errorPage/error-page.service";
import { KeycloakProfile } from "keycloak-js";
import { ToastrService } from "ngx-toastr";
import { IsisRole, RegisteredUser } from "@app/shared/models/user";

@Injectable({
  providedIn: "root",
})
export class KeycloakSecurityService {
  private _loggedUser: RegisteredUser;
  accessErrorMessage = "Des droits sont nécessaires.";

  constructor(
    private _websocketService: WebsocketService,
    private _environmentService: EnvironmentService,
    private _http: HttpClient,
    private _errorPageService: ErrorPageService,
    private _toastrService: ToastrService,
    public readonly keycloakService: KeycloakService
  ) {}
  async init(): Promise<unknown> {
    return new Promise(async (resolve, reject) => {
      try {
        const authenticated = await this._initializeKeyCloak(
          this.keycloakService
        );

        if (!this._websocketService.stompClient && authenticated) {
          this._websocketService.init(`u${this.getUser().uperId}`);
        }

        resolve(authenticated);
      } catch (error: any) {
        const isIdentifiedKeycloakIssue = true;
        this._errorPageService.storeErrorAndNavigateToErrorPage(
          error,
          isIdentifiedKeycloakIssue
        );
        reject(error);
      }
    });
  }

  getUser(): RegisteredUser {
    return this._loggedUser;
  }

  hasRequiredRole(role: string): boolean {
    return this.keycloakService.isUserInRole(role);
  }

  logout(): void {
    this._loggedUser = null;
    this.keycloakService.logout();
    this._toastrService.info(
      "You have been successfully logged out",
      "Information"
    );
  }

  private _checkKeycloakAvaibility(): Observable<boolean> {
    const httpOptions = {
      headers: new HttpHeaders({ "Content-Type": "application/json" }),
      observe: "response" as const,
    };

    const keycloakRealmsToPing = `${this._environmentService.keyCloakIsis.url}realms/${this._environmentService.keyCloakIsis.realm}`;
    return this._http.get(keycloakRealmsToPing, httpOptions).pipe(
      first(),
      map(() => {
        return true;
      })
    );
  }

  private _initializeKeyCloak(kc: KeycloakService): Promise<unknown> {
    return new Promise(async (resolve, reject) => {
      try {
        await lastValueFrom(this._checkKeycloakAvaibility());
        await kc.init({
          config: {
            url: this._environmentService.keyCloakIsis.url,
            realm: this._environmentService.keyCloakIsis.realm,
            clientId: this._environmentService.keyCloakIsis.clientId,
          },
          initOptions: {
            onLoad: "login-required",
            checkLoginIframe: false,
          },
          loadUserProfileAtStartUp: true,
          bearerPrefix: "Bearer",
        });

        const userProfile: KeycloakProfile =
          await this.keycloakService.loadUserProfile();
        this._loggedUser = this._buildLoggedUserFromProfile(userProfile);

        resolve(true);
      } catch (error) {
        reject(error);
      }
    });
  }

  private _buildLoggedUserFromProfile(
    profile: KeycloakProfile
  ): RegisteredUser {
    return {
      uperId: profile["attributes"].LDAP_ID[0], // without "u"
      username: profile.username,
      email: profile.email,
      rolename: this._getMainIsisRole(this.keycloakService.getUserRoles()),
      givenName: profile.firstName,
    };
  }

  private _getMainIsisRole(userRoles: Array<string>): string {
    return userRoles.some((role) => role.toLowerCase() === IsisRole.admin)
      ? IsisRole.admin
      : userRoles.some((role) => role.toLowerCase() === IsisRole.supervisor)
      ? IsisRole.supervisor
      : userRoles.some((role) => role.toLowerCase() === IsisRole.isis_blackout)
      ? IsisRole.isis_blackout
      : IsisRole.norights;
  }
}
