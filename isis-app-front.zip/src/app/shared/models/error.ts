export interface IsisError {
  isisCode?: string;
  isisMessage: string;
}
