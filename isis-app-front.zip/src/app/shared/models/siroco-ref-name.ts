export interface SirocoRefName {
  id: string; //reference Siroco
  name?: string;
}
