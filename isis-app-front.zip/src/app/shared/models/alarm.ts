import {
  CustomTableItem,
  CustomTableRequestedPageMeta,
  CUSTOM_TABLE_PAGE_SIZE_OPTIONS,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";
import { BlackoutTypeEnum } from "./blackout";

export enum AlarmAvancedSearchPrefix {
  REF_BLACKOUT = "REF_blackout:",
  REF_SERVICE = "REF_service:",
}

export interface AlarmSearchCriteria extends CustomTableRequestedPageMeta {
  sgroup: string;
  stateValues?: string[];
  severityValues?: string[];
  advancedSearchValues?: string[];
  requestedRegroupings?: string[];
  alarmIdForGrouping?: string;
  datesValue?: { begin?: string; end?: string };
  blackoutId?: string;
  alarmIds?: string;
}

export const DEFAULT_ALARM_REQUESTED_PAGE_META: CustomTableRequestedPageMeta = {
  page: 0,
  size: CUSTOM_TABLE_PAGE_SIZE_OPTIONS[1],
  sortField: "origin_time",
  sortDirection: "desc",
};

export const DEFAULT_ALARM_SEARCH_CRITERIA: AlarmSearchCriteria = {
  ...DEFAULT_ALARM_REQUESTED_PAGE_META,
  sgroup: "SI",
};

export interface AlarmListFromApi {
  items: Array<Alarm>;
  count: number;
}

export interface UpdateAlarmResult {
  matchedCount: number;
  modifiedCount: number;
  upstertedId: any;
}

export interface AlarmTableItem extends Alarm, CustomTableItem {
  sfrServiceLevelCode?: string;
  appName?: string;
}

export interface Alarm {
  _id: string;
  key: string;
  sfr_operations: Array<any>;
  state: string;
  priority?: number;
  severite: string;
  message: string;
  objet_supervise: string;
  parametre: string;
  host: string;
  occurrences: Array<string>;
  dashboard_url: string;
  last_origin_time: number;
  arrival_time: number;
  last_arrival_time: number;
  origin_time: number;
  sfr_source: string;
  sfr_url_consigne: string;
  sfr_ack_user: string;
  sfr_ack_date: number;
  sfr_closed_user: string;
  sfr_closed_date?: number;
  sfr_ref_incident: string;
  sfr_ref_clarify: string;
  app_sfr_nom: string;
  sfr_visu_date: number;
  sfr_vsr: string;
  sfr_ref_mep: string;
  notification_level: string;
  sfr_SI: string;
  sfr_blackout?: string;
  sfr_regroupement: Array<string>;
  app_sfr_niveau_service: string;
  app_avalanche: string;
  app_environnement: string;
  app_parc: string;
  app_exploitant: string;
  app_ligne_service: string;
  bdd_ref_cluster: string;
  bdd_sfr_niveau_service: string;
  bdd_avalanche: string;
  bdd_environnement: string;
  bdd_parc: string;
  bdd_exploitant: string;
  bdd_applications_utilisatrices: string;
  bdd_application_proprietaire: string;
  bdd_ref_application_proprietaire: string;
  bdd_ref_applications_utilisatrices: string;
  blackouts: {
    eventReference: string;
    terminated: boolean;
    type: BlackoutTypeEnum | string;
    _id: string;
  }[];
  linkedBlackoutId?: string; // not from api but can be built
  res_criticite?: string;
  res_type?: string;
  srv_ref_cluster: string;
  srv_ref_SX: string;
  srv_ref_chassis: string;
  srv_ref_blade: string;
  srv_nom_bat: string;
  srv_nom_salle: string;
  srv_nom_allee: string;
  srv_sfr_niveau_service: string;
  srv_avalanche: string;
  srv_statut: string;
  srv_environnement: string;
  srv_parc: string;
  srv_liens_REF_APP: string;
  srv_liens_REF_BDD: string;
  srv_liens_REF_RESS: string;
  srv_liens_REF_Baie: string;
  applications_utilisatrices: string;
  application_proprietaire: string;
  ref_application_proprietaire: string;
  ref_applications_utilisatrices: string;
  en_service: string;
  sfr_info_sup: string;
  objet_class: string;
  id_siroco: string;
  consigne: string;
  code_app: string;
  objet_sup: string;
  lien_consigne: string;
  origine: string;
  domaine_supervision: string;
  sfr_repeat_count: string;
  sfr_em_LP: string;
  sfr_em_fonction: string;
  sfr_em_label: string;
  sfr_code_SSA: string;
  sfr_em_SSA: string;
  vtom_environnement: string;
  vtom_etat_job: string;
  vtom_nom_application: string;
  vtom_nom_job: string;
  vtom_serveur: string;
  vtom_serveur_client: string;
  sub_source: string;
  vtom_code_ssa: string;
  vtom_nom_date: string;
  vtom_etat_date: string;
  _source?: AlarmInProgressSource;
  expiration_time: number;
  extra_definitions: unknown;
  correlation_key: string;
  ticket_message: string;
  sfr_source_identifier: string;
}

export interface AlarmInProgressSource {
  in_progress?: boolean;
  user: {
    username: string;
    uperId: string; // more exactly, 'perId' instead of uperId
  };
}

export enum SfrServiceLevelEnum {
  PLATINUM = "1 - Platinium",
  GOLD = "2 - Gold",
  SILVER = "3 - Silver",
  COPPER = "4 - Copper",
}

export const SfrServiceLevelCodeRecord: Record<SfrServiceLevelEnum, string> = {
  "1 - Platinium": "PLATINUM",
  "2 - Gold": "GOLD",
  "3 - Silver": "SILVER",
  "4 - Copper": "COPPER",
};

export const SfrServiceLevelSortOrder: Record<SfrServiceLevelEnum, number> = {
  "1 - Platinium": 0,
  "2 - Gold": 1,
  "3 - Silver": 2,
  "4 - Copper": 3,
};

export enum ActionInfoLabelEnum {
  ACQUITTED_WITH_TICKET = "acquittement avec ticket",
  ACQUITTED_WITHOUT_TICKET = "acquittement sans ticket",
  CREATE_TICKET = "création de ticket",
  ACQUITTED_WITH_MEP = "acquittement avec mep",
  CLOSE = "fermeture",
}

export interface AlarmActionInfo {
  action: ActionInfoLabelEnum;
  sfr_ref_incident?: string;
  sfr_ref_mep?: string;
  information?: string;
}

export interface AlarmSfrOperation {
  timestamp: number;
  msg?: string;
  user_uperid: string;
  etat: string;
  action: ActionInfoLabelEnum;
  sfr_ref_incident?: string;
  sfr_ref_mep?: string;
}

export interface AlarmActionParametersToUpdate {
  state: string;
  sfr_operations?: AlarmSfrOperation[];
  sfr_closed_date?: number;
  sfr_closed_user?: string;
  sfr_ack_date?: number;
  sfr_ack_user?: string;
  sfr_ref_incident?: string;
  sfr_ref_mep?: string;
}
