export interface RegisteredUser {
  uperId: string; // without "u"
  username: string;
  email: string;
  rolename: string;
  givenName: string;
}

/**
 * These roles' names are related to Keycloak client for ihm-isis.
 * A user is part of a group. Each group has a specific mapping to some Realm roles and/or client role names.
 * (some of the Realm roles having a mapped client role name))
 */
export enum IsisRole {
  admin = "admin", // mapped to realm role "ISIS-ADMIN" which is a part of "isis_admin" group
  supervisor = "supervisor", // mapped to realm role "ISIS-SUPERVISOR" which is a part of "isis_supervisor" group
  isis_blackout = "isis_blackout", // is a part of "isis_blackout" group
  norights = "norights", //when user is logged but he isn't part of any group
}
