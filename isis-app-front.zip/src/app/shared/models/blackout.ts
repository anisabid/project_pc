import {
  CustomTableRequestedPageMeta,
  CUSTOM_TABLE_PAGE_SIZE_OPTIONS,
} from "@app/shared/components/custom-selectable-table-base/custom-selectable-table-base.model";

export interface Blackout {
  _id?: string;
  status?: BlackoutStatusEnum;
  type: BlackoutTypeEnum | string;
  repetitions?: { day: number; startHour?: number; endHour?: number }[];
  startDateTime: number;
  endDateTime: number;
  startRealDateTime?: number;
  endRealDateTime?: number;
  requesterUpperId?: string;
  lastUpdatedRequesterUpperId?: string;
  actor?: string;
  phoneActor?: string;
  eventReference: string;
  description: string;
  comment?: string;
  rules?: BlackoutRule[];
  alarmCount?: number;
}

export interface BlackoutPage {
  number: number;
  empty: boolean;
  content: Blackout[];
  numberOfElements: number;
  totalPages: number;
  size: number;
  totalElements: number;
}

export enum BlackoutStatusEnum {
  PREPARED = "PREPARED",
  IN_PROGRESS = "IN_PROGRESS",
  CLOSED = "CLOSED",
  CANCELLED = "CANCELLED",
}

export enum BlackoutTypeEnum {
  MEP = "MEP",
  INCIDENT = "INCIDENT",
  ORDONNANCEUR = "ORDONNANCEUR",
  REPETITIVE = "REPETITIVE",
}

export enum BlackoutRepetitiveDayEnum {
  MONDAY = "0",
  TUESDAY = "1",
  WEDNESDAY = "2",
  THURSDAY = "3",
  FRIDAY = "4",
  SATURDAY = "5",
  SUNDAY = "6",
}

export interface BlackoutRule {
  sfrRefClarify?: string;
  sfrRefClarifyName?: string;
  host?: string;
  hostName?: string;
  sfrSource?: string;
  parameter?: string;
  supervisedObject?: string;
  supervisionDomain?: string;
}

export interface BlackoutSearchCriteria extends CustomTableRequestedPageMeta {
  type?: string;
  status?: string;
  beginDate?: Date | string;
  endDate?: Date | string;
  fields?: string;
}

export const DEFAULT_BLACKOUT_SEARCH_CRITERIA: BlackoutSearchCriteria = {
  page: 0,
  size: CUSTOM_TABLE_PAGE_SIZE_OPTIONS[1],
  sortField: "startDateTime",
  sortDirection: "desc",
};
