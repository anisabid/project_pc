export class Group {
  all: number;
  blackout: number;
  acquitted_with_ticket: number;
  acquitted_with_mep: number;
  closed: number;
  acquitted_without_ticket: number;
  open: number;

  constructor(group?) {
    this.acquitted_with_mep = !group ? 0 : group.acquitted_with_mep;
    this.acquitted_with_ticket = !group ? 0 : group.acquitted_with_ticket;
    this.acquitted_without_ticket = !group ? 0 : group.acquitted_without_ticket;
    this.all = !group ? 0 : group.all;
    this.blackout = !group ? 0 : group.blackout;
    this.closed = !group ? 0 : group.closed;
    this.open = !group ? 0 : group.open;
  }
}

export class Groups {
  si: Group;
  vabfo: Group;

  constructor(groups?) {
    this.si = new Group(!groups ? null : groups.si);
    this.vabfo = new Group(!groups ? null : groups.vabfo);
  }
}
