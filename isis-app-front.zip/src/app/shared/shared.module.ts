import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
  NgxMatDateFormats,
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule,
  NGX_MAT_DATE_FORMATS,
} from "@angular-material-components/datetime-picker";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { MatBadgeModule } from "@angular/material/badge";
import { MatButtonModule } from "@angular/material/button";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { MatCardModule } from "@angular/material/card";
import {
  MatNativeDateModule,
  MatRippleModule,
  MAT_DATE_LOCALE,
} from "@angular/material/core";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatDialogModule } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatMenuModule } from "@angular/material/menu";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatRadioModule } from "@angular/material/radio";
import { MatSelectModule } from "@angular/material/select";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatSortModule } from "@angular/material/sort";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatTableModule } from "@angular/material/table";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatChipsModule } from "@angular/material/chips";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { PipesModule } from "./pipes/pipes.module";
import { ConfirmDialogComponent } from "./components/confirm-dialog/confirm-dialog.component";
import { TopBarComponent } from "./components/top-bar/top-bar.component";
import { DateTimeRangeSelectComponent } from "./components/date-time-range-select/date-time-range-select.component";
import { CustomFilterChipListComponent } from "./components/custom-filter-chip-list/custom-filter-chip-list.component";
import { CustomMultiSelectMenuComponent } from "./components/custom-multi-select-menu/custom-multi-select-menu.component";
import { CustomAdvancedSearchComponent } from "./components/custom-advanced-search/custom-advanced-search.component";
import { StandardLayoutComponent } from "./components/standard-layout/standard-layout.component";
import { CustomSelectableTableBaseComponent } from "./components/custom-selectable-table-base/custom-selectable-table-base.component";
import { ErrorPageComponent } from "./components/errorPage/error-page.component";
import { ScrollingModule } from "@angular/cdk/scrolling";
import { ToastrModule } from "ngx-toastr";
import { SimpleBreadcrumbComponent } from "./components/simple-breadcrumb/simple-breadcrumb.component";
import { SirocoRefNameAutocompleteComponent } from "./components/siroco-ref-name-autocomplete/siroco-ref-name-autocomplete.component";
import { NoResultBlockComponent } from "./components/no-result-block/no-result-block.component";
import { SimpleSelectionBaseComponent } from "./components/simple-selection-base/simple-selection-base.component";
import { IsisChatComponent } from "@app/isis-chat/isis-chat.component";

const CUSTOM_INTL_DATE_INPUT_FORMAT = {
  year: "numeric",
  month: "numeric",
  day: "numeric",
  hourCycle: "h23",
  hour: "2-digit",
  minute: "2-digit",
};

export const CUSTOM_DATE_FORMATS: NgxMatDateFormats = {
  parse: {
    dateInput: CUSTOM_INTL_DATE_INPUT_FORMAT,
  },
  display: {
    dateInput: CUSTOM_INTL_DATE_INPUT_FORMAT,
    monthYearLabel: { year: "numeric", month: "short" },
    dateA11yLabel: { year: "numeric", month: "long", day: "numeric" },
    monthYearA11yLabel: { year: "numeric", month: "long" },
  },
};

@NgModule({
  declarations: [
    ConfirmDialogComponent,
    TopBarComponent,
    CustomSelectableTableBaseComponent,
    DateTimeRangeSelectComponent,
    CustomAdvancedSearchComponent,
    CustomFilterChipListComponent,
    CustomMultiSelectMenuComponent,
    SimpleBreadcrumbComponent,
    SirocoRefNameAutocompleteComponent,
    StandardLayoutComponent,
    ErrorPageComponent,
    NoResultBlockComponent,
    SimpleSelectionBaseComponent,
    IsisChatComponent,
  ],
  imports: [
    RouterModule,
    CommonModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    MatButtonModule,
    MatTableModule,
    MatPaginatorModule,
    MatChipsModule,
    MatCheckboxModule,
    MatIconModule,
    MatInputModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatSortModule,
    MatTooltipModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatBadgeModule,
    MatMenuModule,
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSidenavModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatRadioModule,
    MatRippleModule,
    MatToolbarModule,
    ScrollingModule,
    ToastrModule.forRoot({
      timeOut: 4000,
      positionClass: "toast-top-right",
      preventDuplicates: true,
      closeButton: true,
    }),
  ],
  exports: [
    MatDatepickerModule,
    PipesModule,
    CustomSelectableTableBaseComponent,
    ConfirmDialogComponent,
    DateTimeRangeSelectComponent,
    CustomMultiSelectMenuComponent,
    StandardLayoutComponent,
    TopBarComponent,
    IsisChatComponent,
    CustomFilterChipListComponent,
    CustomAdvancedSearchComponent,
    SimpleBreadcrumbComponent,
    SirocoRefNameAutocompleteComponent,
    ErrorPageComponent,
    NoResultBlockComponent,
    SimpleSelectionBaseComponent,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    MatButtonModule,
    MatTableModule,
    MatPaginatorModule,
    MatChipsModule,
    MatCheckboxModule,
    MatIconModule,
    MatInputModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatSortModule,
    MatTooltipModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatBadgeModule,
    MatMenuModule,
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSidenavModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatRadioModule,
    MatRippleModule,
    MatToolbarModule,
    ScrollingModule,
    CommonModule,
  ],
  providers: [
    MatDatepickerModule,
    { provide: NGX_MAT_DATE_FORMATS, useValue: CUSTOM_DATE_FORMATS },
    { provide: MAT_DATE_LOCALE, useValue: "fr-FR" },
  ],
})
export class SharedModule {}
