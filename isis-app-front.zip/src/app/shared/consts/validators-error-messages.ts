export interface ValidatorsErrorMessages {
  REQUIRED: string;
  AT_LEAST_ONE_FIELD: string;
  START_DATE_BEFORE_END_DATE: string;
  START_HOUR_BEFORE_END_HOUR: string;
  PATTERN: string;
  MIN_LENGTH_REQUIRED: string;
}

export const constValidatorsErrorMessages: ValidatorsErrorMessages = {
  REQUIRED: "Merci de renseigner ce champ.",
  AT_LEAST_ONE_FIELD: "Merci de renseigner au moins un des champs.",
  START_DATE_BEFORE_END_DATE:
    "Les date et heure de fin ne peuvent être antérieures ou égales aux date et heure de début.",
  START_HOUR_BEFORE_END_HOUR:
    "L'heure de fin ne peut être antérieure ou égale à l'heure de début.",
  PATTERN: "Ce champ ne respecte pas le format attendu.",
  MIN_LENGTH_REQUIRED: "Le nombre de caractères est insuffisant.",
};
