export const constDefaultDateOnlyFormat = "dd-MM-yyyy";
export const constDefaultDateTimeFormat = "dd-MM-yyyy HH:mm";
