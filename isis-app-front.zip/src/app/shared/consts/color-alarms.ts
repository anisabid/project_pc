/**
 * Color Description
 */
export class ColorDescription {
  background: string;
  checkbox: string;
  color: string;
  code: string;
  icon: string;
  name: string;
  text_color: string;
  label: string;

  constructor(obj: Object = {}) {
    let params = {
      code: "",
      name: "",
      label: "",
      color: "",
      background: "",
      text_color: "",
      icon: "",
      checkbox: "",
    };
    Object.assign(params, obj);

    this.background = params.background;
    this.checkbox = params.checkbox;
    this.color = params.color;
    this.code = params.code;
    this.icon = params.icon;
    this.name = params.name;
    this.label = params.label;
    this.text_color = params.text_color;
  }
}

export enum AlarmStateEnum {
  ACQUITTED_WITH_TICKET = "ACQUITTED_WITH_TICKET",
  ACQUITTED_WITHOUT_TICKET = "ACQUITTED_WITHOUT_TICKET",
  ACQUITTED_WITH_MEP = "ACQUITTED_WITH_MEP",
  BLACKOUT = "BLACKOUT",
  CLOSED = "CLOSED",
  OPEN = "OPEN",
}

export enum AlarmSeverityEnum {
  CRITICAL = "CRITICAL",
  MAJOR = "MAJOR",
  WARNING = "WARNING",
  OK = "OK",
  INFO = "INFO",
  UNKNOWN = "UNKNOWN",
}

/**
 * Color States
 */
export interface ColorStates {
  ALL: ColorDescription;
  ACQUITTED_WITH_TICKET: ColorDescription;
  ACQUITTED_WITHOUT_TICKET: ColorDescription;
  ACQUITTED_WITH_MEP: ColorDescription;
  BLACKOUT: ColorDescription;
  CLOSED: ColorDescription;
  OPEN: ColorDescription;
}

/**
 * ConstColorStates Const
 */

export const ConstColorStates: ColorStates = {
  ALL: new ColorDescription({
    code: "ALL",
    name: "all",
    label: "Tous",
    color: "#FFFFFF",
    background: "#FFFFFF",
    text_color: "#000000",
    icon: "check_circle_outline",
    checkbox: "",
  }),
  ACQUITTED_WITH_TICKET: new ColorDescription({
    code: "ACQUITTED_WITH_TICKET",
    name: "With Ticket",
    label: "Acquittés avec ticket",
    color: "#EF5350",
    background: "#FFEBEE80",
    text_color: "#E53935",
    icon: "check_circle_outline",
    checkbox: "",
  }),
  ACQUITTED_WITHOUT_TICKET: new ColorDescription({
    code: "ACQUITTED_WITHOUT_TICKET",
    name: "Without Ticket",
    label: "Acquittés sans ticket",
    color: "#EF5350",
    background: "#FFEBEE80",
    text_color: "#E53935",
    icon: "check_circle_outline",
    checkbox: "",
  }),
  ACQUITTED_WITH_MEP: new ColorDescription({
    code: "ACQUITTED_WITH_MEP",
    name: "With MEP",
    label: "Acquittés avec MEP",
    color: "#EF5350",
    background: "#FFEBEE80",
    text_color: "#E53935",
    icon: "error_outline",
    checkbox: "",
  }),
  BLACKOUT: new ColorDescription({
    code: "BLACKOUT",
    name: "blackout",
    label: "Blackouts",
    color: "#78909C",
    background: "#ECEFF180",
    text_color: "#546E7A",
    icon: "block",
    checkbox: "",
  }),
  CLOSED: new ColorDescription({
    code: "CLOSED",
    name: "clos",
    label: "Clos",
    color: "#42A5F5",
    background: "#E3F2FD80",
    text_color: "#1E88E5",
    icon: "highlight_off",
    checkbox: "",
  }),
  OPEN: new ColorDescription({
    code: "OPEN",
    name: "open",
    label: "Ouverts",
    color: "#FFA726",
    background: "#FFF3E080",
    text_color: "#FB8C00",
    icon: "stop_circle",
    checkbox: "",
  }),
};

export type ColorBaseType = Record<string, ColorDescription>;

/**
 * Color Severity
 */
export interface ColorSeverity extends ColorBaseType {
  CRITICAL: ColorDescription;
  INFO: ColorDescription;
  MAJOR: ColorDescription;
  OK: ColorDescription;
  UNKNOWN: ColorDescription;
  WARNING: ColorDescription;
}

export const ConstColorSeverity: ColorSeverity = {
  OK: new ColorDescription({
    code: "OK",
    name: "ok",
    label: "Ok",
    color: "#4CAF50",
    background: "#f8fff9",
    text_color: "#fff",
    icon: "check_circle",
    checkbox: "#A5D6A7",
  }),
  CRITICAL: new ColorDescription({
    code: "CRITICAL",
    name: "critical",
    label: "Critical",
    color: "#FF1744",
    background: "#ffebeb",
    text_color: "#fff",
    icon: "highlight_off",
    checkbox: "#EF9A9A",
  }),
  MAJOR: new ColorDescription({
    code: "MAJOR",
    name: "major",
    label: "Major",
    color: "#FF9100",
    background: "#fff7ee",
    text_color: "#fff",
    icon: "error_outline",
    checkbox: "#FFAB91",
  }),
  WARNING: new ColorDescription({
    code: "WARNING",
    name: "warning",
    label: "Warning",
    color: "#ffd218",
    background: "#fffef3",
    text_color: "#fff",
    icon: "error_outline",
    checkbox: "#FFCC80",
  }),
  INFO: new ColorDescription({
    code: "INFO",
    name: "info",
    label: "Info",
    color: "#2979FF",
    background: "#eff5fb",
    text_color: "#fff",
    icon: "info",
    checkbox: "#81D4FA",
  }),
  UNKNOWN: new ColorDescription({
    code: "UNKNOWN",
    name: "unknown",
    label: "Unknown",
    color: "#78909C",
    background: "#f4f6f7",
    text_color: "#fff",
    icon: "help_outline",
    checkbox: "#B0BEC5",
  }),
};

export const ConstColorPriorities: ColorDescription[] = [
  new ColorDescription({
    label: "P1",
    background: "#670D00",
    text_color: "#FFFFFF",
  }),
  new ColorDescription({
    label: "P2",
    background: "#C30F00",
    text_color: "#FFFFFF",
  }),
  new ColorDescription({
    label: "P3",
    background: "#F01F00",
    text_color: "#FFFFFF",
  }),
  new ColorDescription({
    label: "P4",
    background: "#F58F4D",
    text_color: "#FFFFFF",
  }),
  new ColorDescription({
    label: "P5",
    background: "#FDBE0C",
    text_color: "#FFFFFF",
  }),
  new ColorDescription({
    label: "P6",
    background: "#FFDB9F",
    text_color: "#FFFFFF",
  }),
];
