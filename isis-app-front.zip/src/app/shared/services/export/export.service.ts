import { Injectable } from "@angular/core";

@Injectable({ providedIn: "root" })
export class ExportService {
  constructor() {}

  downloadFile(data, format, filename = "data") {
    if (format == "csv") {
      let csvData = this._convertToCSV(data);
      let blob = new Blob(["\ufeff" + csvData], {
        type: "text/csv;charset=utf-8;",
      });
      let dwldLink = document.createElement("a");
      let url = URL.createObjectURL(blob);
      dwldLink.setAttribute("href", url);
      dwldLink.setAttribute("download", filename + ".csv");
      dwldLink.style.visibility = "hidden";
      document.body.appendChild(dwldLink);
      dwldLink.click();
      document.body.removeChild(dwldLink);
    } else if (format == "text") {
      let textData = this._convertToText(data);
      let blob = new Blob(["\ufeff" + textData]);
      let dwldLink = document.createElement("a");
      let url = URL.createObjectURL(blob);
      dwldLink.setAttribute("href", url);
      dwldLink.setAttribute("download", filename + ".txt");
      dwldLink.style.visibility = "hidden";
      document.body.appendChild(dwldLink);
      dwldLink.click();
      document.body.removeChild(dwldLink);
    }
  }

  private _convertToCSV(objArray) {
    let data = typeof objArray !== "object" ? JSON.parse(objArray) : objArray;
    let header = "";
    Object.keys(data[0]).map((pr) => (header += pr + ";"));

    let str = "";
    data.forEach((row) => {
      let line = "";
      let columns =
        typeof row !== "object" ? JSON.parse(row) : Object.values(row);
      columns.forEach((column) => {
        if (line !== "") {
          line += ";";
        }
        if (typeof column === "object") {
          line += JSON.stringify(column);
        } else {
          line += column;
        }
      });
      str += line + "\r\n";
    });
    return header + "\r\n" + str;
  }

  private _convertToText(objArray) {
    let data = typeof objArray !== "object" ? JSON.parse(objArray) : objArray;
    let line = [];
    let element = "";
    console.log(data);
    data.forEach((row) => {
      for (const [key, value] of Object.entries(row)) {
        if (key == "_source") {
          line.push(
            `${key}:${JSON.stringify(
              value
            )}\r\n\r\n"----------------------------------------------------------------------------------------------------------------------------------"\r\n\r\n`
          );
        }
        if (typeof value === "object" && key != "_source") {
          line.push(`${key}:${JSON.stringify(value)}\r\n`);
        } else if (key != "_source") {
          line.push(`${key}:${value}\r\n`);
        }
      }
    });
    line.map((pr) => (element += pr));
    return element;
  }
}
