import { Injectable } from "@angular/core";
import { EnvironmentService } from "@app/shared/services/environment/environment.service";
import {
  IsisSpringAppBackV2ApiConfig,
  MoteurClarifyApiConfig,
} from "./apis-configs.models";

@Injectable({
  providedIn: "root",
})
export class ApiService {
  readonly isisSpringAppBackV2ApiConfig: IsisSpringAppBackV2ApiConfig;
  readonly moteurClarifyApiConfig: MoteurClarifyApiConfig;

  constructor(private _environmentService: EnvironmentService) {
    const isisSpringBackV2BaseApi =
      this._environmentService.isisSpringBackV2BaseApi;
    this.isisSpringAppBackV2ApiConfig = {
      apiBaseConfig: isisSpringBackV2BaseApi,
      basePath: `${isisSpringBackV2BaseApi.schemes}${isisSpringBackV2BaseApi.host}${isisSpringBackV2BaseApi.basePath}`,
      alarmsPath: "alarms",
      groupsPath: "alarms/groups",
      reglesPath: "groupingRules",
      rolesPath: "roles",
      rightsPath: "rights/v2",
      logsPath: "logs",
      canlockPath: "alarms/canLock",
      blackoutsPath: "blackouts",
      servicesPath: "alarms/services",
      chatMessagesPath: "chat-messages",
      heartbeatSourcesPath: "heartBeat",
      sirocoNameRefsPath: "siroco",
    };
    const moteurClarifyBaseApi = this._environmentService.moteurClarifyBaseApi;
    this.moteurClarifyApiConfig = {
      apiBaseConfig: moteurClarifyBaseApi,
      basePath: `${moteurClarifyBaseApi.schemes}${moteurClarifyBaseApi.host}${moteurClarifyBaseApi.basePath}`,
      ticketsPath: "clarify/tickets",
      notesPath: "clarify/notes",
    };
  }
}
