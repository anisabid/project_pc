import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map, Subject } from "rxjs";
import { ApiService } from "@app/shared/services/api/v2/api.service";
import { Groups } from "@app/shared/models/group";

@Injectable({
  providedIn: "root",
})
export class IsisService {
  onAlarmsRefresh: Subject<boolean> = new Subject();
  onGroupsChanged: Subject<Groups> = new Subject();

  private _groups: Groups = new Groups();

  constructor(
    private httpClient: HttpClient,
    private _apiService: ApiService
  ) {}

  getGroups(): Promise<Groups> {
    return new Promise((resolve, reject) => {
      const url = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.groupsPath}`;
      this.httpClient
        .get(url)
        .pipe(
          map((groups: Groups) => {
            this._groups = new Groups(groups);
            this.onGroupsChanged.next(this._groups);
            return groups;
          })
        )
        .subscribe({
          next: (groups: Groups) => resolve(groups),
          error: () => reject,
          complete: () => {
            // do nothing
          },
        });
    });
  }

  /**
   * Check if an selected alarm is in process
   * @param alarmIds represent concatenation of selected alarm _id in separated by ","
   * @returns {Promise<any>}
   */
  public checkAlarmInprogress(alarmIds: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const canLockBaseUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.canlockPath}`;
      this.httpClient.get(`${canLockBaseUrl}/${alarmIds}`).subscribe({
        next: (res) => resolve(res),
        error: () => reject,
        complete: () => {
          // do nothing
        },
      });
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------
  get groups(): Groups {
    return this._groups;
  }
}
