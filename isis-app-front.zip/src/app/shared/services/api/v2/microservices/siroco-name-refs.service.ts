import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { SirocoRefName } from "@app/shared/models/siroco-ref-name";
import { Observable } from "rxjs";
import { ApiService } from "@app/shared/services/api/v2/api.service";

@Injectable({ providedIn: "root" })
export class SirocoNameRefsService {
  private _sirocoNameRefsUrl: string;
  private _headers: HttpHeaders;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService
  ) {
    this._sirocoNameRefsUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.sirocoNameRefsPath}`;
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
  }

  getSirocoNameRefs(value?: string): Observable<SirocoRefName[]> {
    const parameters: HttpParams = new HttpParams().set("value", value);
    const httpOptions = {
      headers: this._headers,
      params: parameters,
    };
    return this._httpClient.get<SirocoRefName[]>(
      this._sirocoNameRefsUrl,
      httpOptions
    );
  }
}
