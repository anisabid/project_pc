import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "@app/shared/services/api/v2/api.service";

export interface ClarifyPayload {
  uperid: string;
  id_alarm: string;
  sfr_ref_incident?: string;
  message: string;
}

export interface ClarifyResponse {
  code_erreur?: string;
  message: string;
  retour: string;
  sfr_ref_incident?: string;
}

@Injectable({ providedIn: "root" })
export class ClarifyApiService {
  private _headers: HttpHeaders;
  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService
  ) {
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
  }

  createClarifyTicket(
    clarifyPayload: ClarifyPayload
  ): Observable<ClarifyResponse> {
    return this._requestClarify(
      `${this._apiService.moteurClarifyApiConfig.basePath}${this._apiService.moteurClarifyApiConfig.ticketsPath}`,
      clarifyPayload
    );
  }

  addClarifyNote(clarifyPayload: ClarifyPayload): Observable<ClarifyResponse> {
    return this._requestClarify(
      `${this._apiService.moteurClarifyApiConfig.basePath}${this._apiService.moteurClarifyApiConfig.notesPath}`,
      clarifyPayload
    );
  }

  private _requestClarify(
    url: string,
    clarifyPayload: ClarifyPayload
  ): Observable<ClarifyResponse> {
    const httpOptions = { headers: this._headers };
    return this._httpClient.post<ClarifyResponse>(
      url,
      clarifyPayload,
      httpOptions
    );
  }
}
