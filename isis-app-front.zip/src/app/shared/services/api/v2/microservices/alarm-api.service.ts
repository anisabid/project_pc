import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import {
  AlarmSeverityEnum,
  AlarmStateEnum,
} from "@app/shared/consts/color-alarms";
import {
  Alarm,
  AlarmListFromApi,
  AlarmSearchCriteria,
  DEFAULT_ALARM_REQUESTED_PAGE_META,
  DEFAULT_ALARM_SEARCH_CRITERIA,
  UpdateAlarmResult,
} from "@app/shared/models/alarm";
import { Observable, of, Subject, throwError, switchMap } from "rxjs";
import { ApiService } from "../api.service";
import { IsisError } from "@app/shared/models/error";

@Injectable({ providedIn: "root" })
export class AlarmApiService {
  private _baseAlarmsUrl: string;
  private _headers: HttpHeaders;
  allAlarmStateValues: string[];
  allAlarmSeverityValues: string[];

  private _onUpdatedAlarmSubject: Subject<boolean> = new Subject();
  onUpdatedAlarm$: Observable<boolean>;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService
  ) {
    this._baseAlarmsUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.alarmsPath}`;
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
    this.onUpdatedAlarm$ = this._onUpdatedAlarmSubject.asObservable();
    this.allAlarmStateValues = Object.keys(AlarmStateEnum).map(
      (key: string) => AlarmStateEnum[key]
    );
    this.allAlarmSeverityValues = Object.keys(AlarmSeverityEnum).map(
      (key: string) => AlarmSeverityEnum[key]
    );
  }

  getAlarmListFromApi(
    filterCriteria: AlarmSearchCriteria
  ): Observable<AlarmListFromApi> {
    const url = `${this._baseAlarmsUrl}${this._buildUrlWithFilterParams(
      filterCriteria
    )}`;
    const httpOptions = {
      headers: this._headers,
    };
    return this._httpClient.get<AlarmListFromApi>(url, httpOptions);
  }

  updateAlarms(
    alarmIdStringList: string,
    obj: Object = {}
  ): Observable<UpdateAlarmResult> {
    const httpOptions = {
      headers: new HttpHeaders({ "Content-Type": "application/json" }),
    };
    const url = `${this._baseAlarmsUrl}/${alarmIdStringList}`;

    return this._httpClient.put<UpdateAlarmResult>(url, obj, httpOptions).pipe(
      switchMap((updateAlarmResult: UpdateAlarmResult) => {
        if (updateAlarmResult.modifiedCount) {
          this._onUpdatedAlarmSubject.next(true);
          return of(updateAlarmResult);
        } else {
          const error: IsisError = {
            isisCode: "ERROR_UPDATE_ALARM",
            isisMessage: `La ou les alarme(s) ${alarmIdStringList} n'ont pas été mises à jour.`,
          };
          return throwError(() => error);
        }
      })
    );
  }

  private _buildUrlWithFilterParams(
    filterCriteria: AlarmSearchCriteria
  ): string {
    let url = `/?ssgroup=${
      filterCriteria?.sgroup
        ? filterCriteria?.sgroup
        : DEFAULT_ALARM_SEARCH_CRITERIA.sgroup
    }`;
    const sizePageCriteria = filterCriteria.size
      ? filterCriteria.size
      : DEFAULT_ALARM_REQUESTED_PAGE_META.size;
    url = `${url}&limit=${sizePageCriteria}`;
    const pageCriteria = filterCriteria.page
      ? filterCriteria.page
      : DEFAULT_ALARM_REQUESTED_PAGE_META.page;
    url = `${url}&offset=${sizePageCriteria * pageCriteria}`;
    const sortFieldCriteria = filterCriteria.sortField
      ? filterCriteria.sortField
      : DEFAULT_ALARM_REQUESTED_PAGE_META.sortField;
    url = `${url}&sort=${sortFieldCriteria}`;
    const sortDirectionCriteria = filterCriteria.sortDirection
      ? filterCriteria.sortDirection
      : DEFAULT_ALARM_REQUESTED_PAGE_META.sortDirection;
    url = `${url}&direction=${sortDirectionCriteria}`;
    const stateCriteria = filterCriteria.stateValues?.length
      ? filterCriteria.stateValues.toString()
      : this.allAlarmStateValues.toString();
    url = `${url}&state=${stateCriteria}`;

    if (filterCriteria.datesValue?.begin) {
      url = `${url}&beginDate=${new Date(
        filterCriteria.datesValue.begin
      ).getTime()}`;
    }
    if (filterCriteria.datesValue?.end) {
      url = `${url}&endDate=${new Date(
        filterCriteria.datesValue.end
      ).getTime()}`;
    }
    if (filterCriteria.severityValues?.length) {
      url = `${url}&severity=${filterCriteria.severityValues.toString()}`;
    }
    if (filterCriteria.advancedSearchValues?.length) {
      url = `${url}&fields=${filterCriteria.advancedSearchValues.toString()}`;
    }
    if (filterCriteria.blackoutId) {
      url = `${url}&blackoutid=${filterCriteria?.blackoutId}`;
    }
    if (filterCriteria.alarmIds) {
      url = `${url}&alarmIds=${filterCriteria?.alarmIds}`;
    }
    if (
      filterCriteria.requestedRegroupings?.length &&
      filterCriteria.alarmIdForGrouping?.length
    ) {
      url = `${url}&groupingRuleNames=${filterCriteria.requestedRegroupings.toString()}&alarmIdForGrouping=${
        filterCriteria.alarmIdForGrouping
      }`;
    }
    return url;
  }

  getAlarmsByKeyIncludingArchivedAlarms(alarmKey: string): Observable<Alarm[]> {
    const httpOptions = {
      headers: this._headers,
      params: new HttpParams().set("key", alarmKey),
    };

    return this._httpClient.get<Alarm[]>(
      `${this._baseAlarmsUrl}/archives`,
      httpOptions
    );
  }
}
