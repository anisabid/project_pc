import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import {
  Blackout,
  BlackoutPage,
  BlackoutSearchCriteria,
  DEFAULT_BLACKOUT_SEARCH_CRITERIA,
} from "@app/shared/models/blackout";
import { Observable, of, throwError, switchMap } from "rxjs";
import { ApiService } from "../api.service";
import { IsisError } from "@app/shared/models/error";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";

@Injectable({ providedIn: "root" })
export class BlackoutApiService {
  private _blackoutsUrl: string;
  private _headers: HttpHeaders;

  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService,
    private _securityService: KeycloakSecurityService
  ) {
    this._blackoutsUrl = `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.blackoutsPath}`;
    this._headers = new HttpHeaders({ "Content-Type": "application/json" });
  }

  createBlackout(blackout: Blackout): Observable<Blackout> {
    const httpOptions = { headers: this._headers };
    return this._httpClient.post<Blackout>(
      this._blackoutsUrl,
      blackout,
      httpOptions
    );
  }

  updateBlackout(blackout: Blackout): Observable<string> {
    const httpOptions = {
      headers: this._headers,
      responseType: "text" as const,
    };
    const url = `${this._blackoutsUrl}/${blackout._id}`;
    return this._httpClient.put(url, blackout, httpOptions);
  }

  updateAndReturnBlackout(blackout: Blackout): Observable<Blackout> {
    return this.updateBlackout(blackout).pipe(
      switchMap(() => {
        return this.getBlackoutById(blackout._id);
      })
    );
  }

  getBlackoutById(id: string): Observable<Blackout> {
    const httpOptions = {
      headers: this._headers,
    };
    const url = `${this._blackoutsUrl}/${id}`;
    return this._httpClient.get<Blackout[]>(url, httpOptions).pipe(
      switchMap((blackouts: Blackout[]) => {
        if (blackouts.length) {
          return of(blackouts[0]);
        } else {
          const isisError: IsisError = {
            isisCode: "NO_EXISTING_BLACKOUT",
            isisMessage: `Il n'existe pas de blackout avec l'identifiant ${id}.`,
          };
          return throwError(() => isisError);
        }
      })
    );
  }

  deleteBlackout(id: string): Observable<Blackout> {
    if (this._securityService.hasRequiredRole(IsisRole.admin)) {
      const httpOptions = {
        headers: this._headers,
      };
      return this._httpClient.delete<Blackout>(
        `${this._blackoutsUrl}/${id}`,
        httpOptions
      );
    } else {
      const isisError: IsisError = {
        isisCode: "ISIS_REQUIRED_ROLE",
        isisMessage: this._securityService.accessErrorMessage,
      };
      return throwError(() => isisError);
    }
    // Tech note: this method returns null when success.
  }

  getBlackoutPageByCriteria(
    criteria?: BlackoutSearchCriteria
  ): Observable<BlackoutPage> {
    const httpOptions = {
      headers: this._headers,
      params: this._buildHttpParamsForCriteria(criteria),
    };
    return this._httpClient.get<BlackoutPage>(this._blackoutsUrl, httpOptions);
  }

  private _buildHttpParamsForCriteria(
    criteria?: BlackoutSearchCriteria
  ): HttpParams {
    let parameters: HttpParams = new HttpParams().set(
      "page",
      criteria?.page
        ? criteria.page.toString()
        : DEFAULT_BLACKOUT_SEARCH_CRITERIA.page.toString()
    );

    parameters = parameters.append(
      "size",
      criteria?.size
        ? criteria.size.toString()
        : DEFAULT_BLACKOUT_SEARCH_CRITERIA.size.toString()
    );

    const sort =
      criteria?.sortField && criteria?.sortDirection
        ? `${criteria.sortField},${criteria.sortDirection}`
        : `${DEFAULT_BLACKOUT_SEARCH_CRITERIA.sortField},${DEFAULT_BLACKOUT_SEARCH_CRITERIA.sortDirection}`;
    parameters = parameters.append("sort", sort);

    if (criteria?.type) {
      parameters = parameters.append("type", criteria.type);
    }

    if (criteria?.status) {
      parameters = parameters.append("status", criteria.status);
    }

    if (criteria?.beginDate && criteria?.beginDate !== "") {
      parameters = parameters.append(
        "beginDate",
        new Date(criteria.beginDate).getTime().toString()
      );
    }

    if (criteria?.endDate && criteria?.endDate !== "") {
      parameters = parameters.append(
        "endDate",
        new Date(criteria.endDate).getTime().toString()
      );
    }

    if (criteria?.fields) {
      parameters = parameters.append("fields", criteria.fields);
    }

    return parameters;
  }
}
