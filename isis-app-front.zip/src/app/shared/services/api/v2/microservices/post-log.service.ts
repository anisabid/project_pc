import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { RegisteredUser } from "@app/shared/models/user";
import { Observable } from "rxjs";
import { ApiService } from "@app/shared/services/api/v2/api.service";

export interface LogMessage {
  action: string;
  key: string;
  user?: RegisteredUser;
  createdAt?: number;
}

export interface PostLogApiResponse {
  action: string;
  createdAt: string;
  key: string;
  id: string;
  user: Partial<RegisteredUser>;
}

export interface AttributesForLog {
  actionLog: string;
  keyLog?: string;
}

@Injectable({ providedIn: "root" })
export class PostLogService {
  constructor(
    private _httpClient: HttpClient,
    private _apiService: ApiService,
    private _securityService: KeycloakSecurityService
  ) {}

  postLog(message: LogMessage): Observable<PostLogApiResponse> {
    const fullMessageToLog: LogMessage = {
      ...message,
      user: this._securityService.getUser(),
      createdAt: Date.now(),
    };
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    };
    return this._httpClient.post<PostLogApiResponse>(
      `${this._apiService.isisSpringAppBackV2ApiConfig.basePath}${this._apiService.isisSpringAppBackV2ApiConfig.logsPath}`,
      fullMessageToLog,
      httpOptions
    );
  }
}
