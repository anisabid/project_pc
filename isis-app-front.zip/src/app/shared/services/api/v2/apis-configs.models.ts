import { Api } from "../../environment/environment.service";

export interface IsisSpringAppBackV2ApiConfig {
  readonly apiBaseConfig: Api;
  readonly basePath: string;
  readonly alarmsPath: string;
  readonly groupsPath: string;
  readonly reglesPath: string;
  readonly rolesPath: string;
  readonly rightsPath: string;
  readonly logsPath: string;
  readonly canlockPath: string;
  readonly blackoutsPath: string;
  readonly servicesPath: string;
  readonly chatMessagesPath: string;
  readonly heartbeatSourcesPath: string;
  readonly sirocoNameRefsPath: string;
}

export interface MoteurClarifyApiConfig {
  readonly apiBaseConfig: Api;
  readonly basePath: string;
  readonly notesPath: string;
  readonly ticketsPath: string;
}
