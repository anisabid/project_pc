import { Inject, Injectable } from "@angular/core";
import { AppConfig, APP_CONFIG } from "@app/app.config";

export interface Api {
  readonly schemes: string;
  readonly host: string;
  readonly basePath: string;
}

interface Config {
  readonly alarms__cron__timer_init: number;
  readonly alarms__cron__timer_loop: number;
  readonly alarms__lock__timer_loop: number;
  readonly alarms__websocket__logs__disable: boolean;
}

interface KeyCloakIsis {
  readonly url: string;
  readonly realm: string;
  readonly clientId: string;
}

@Injectable({
  providedIn: "root",
})
export class EnvironmentService {
  readonly keyCloakIsis: KeyCloakIsis;
  readonly isisSpringBackV2BaseApi: Api;
  readonly moteurClarifyBaseApi: Api;
  readonly config: Config;
  readonly socketUrl: string;

  constructor(@Inject(APP_CONFIG) private _appConfigFromCi: AppConfig) {
    this.socketUrl = this._appConfigFromCi.socketUrl;
    this.isisSpringBackV2BaseApi =
      this._appConfigFromCi.isisSpringBackV2BaseApi;
    this.moteurClarifyBaseApi = this._appConfigFromCi.moteurClarifyBaseApi;
    this.keyCloakIsis = this._appConfigFromCi.keyCloakIsis;
    this.config = this._appConfigFromCi.config;
  }
}
