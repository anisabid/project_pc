import { Injectable } from "@angular/core";
import { ToastrService } from "ngx-toastr";

@Injectable({ providedIn: "root" })
export class ErrorUtilsService {
  constructor(private _toastrService: ToastrService) {}

  /**
   * Choice the error message as a function of the error type then display it inside toaster.
   * @param error can be an HttpErrorResponse or an IsisError
   */
  manageThrowedError(error: any): void {
    const errorMessage = error.isisMessage ? error.isisMessage : error.message;
    this._toastrService.error(errorMessage);
  }
}
