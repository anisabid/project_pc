import { Injectable } from "@angular/core";

interface App {
  name: string;
  version: string;
}

@Injectable({
  providedIn: "root",
})
export class LocalStorageService {
  readonly _app: App;
  readonly item: string;
  readonly currentApp: App;

  constructor() {
    this.item = "ng_app";
    this.currentApp = {
      name: "ISIS",
      version: "11.1.0",
    };
  }

  check() {
    // Check ng-app
    if (!localStorage.getItem(this.item)) {
      this.update(false);
      localStorage.setItem(this.item, JSON.stringify(this.currentApp));
    } else {
      const ngAppItem = <App>JSON.parse(localStorage.getItem(this.item));
      // Check version
      if (ngAppItem.version !== this.currentApp.version) {
        this.update();
      }
    }
    const updatedNgAppItem = <App>JSON.parse(localStorage.getItem(this.item));
    console.log(updatedNgAppItem.name + " : " + updatedNgAppItem.version);
  }

  update(item = true) {
    if (item) {
      localStorage.removeItem(this.item);
    }
    localStorage.removeItem("filter_fg");
    localStorage.removeItem("columns_alarms");
    localStorage.removeItem("columns_alarms_known_errors");
    localStorage.removeItem("columns_seker");
    localStorage.removeItem("filter_seker");
    localStorage.removeItem("filter_services"); //TODO
    localStorage.removeItem("blackout_id");
    localStorage.removeItem("alarm_ids");
    localStorage.setItem(this.item, JSON.stringify(this.currentApp));
  }

  get app(): App {
    return this._app;
  }
}
