import {
  Component,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  EventEmitter,
} from "@angular/core";
import { constDefaultDateTimeFormat } from "@app/shared/consts/date-formats";

export interface CustomDateTimeRange {
  beginDateTime: Date | string;
  endDateTime: Date | string;
}

@Component({
  selector: "app-date-time-range-select",
  templateUrl: "./date-time-range-select.component.html",
  styleUrls: ["./date-time-range-select.component.scss"],
})
export class DateTimeRangeSelectComponent implements OnChanges {
  @Input() displayDateTimeRangeSelect: boolean;
  @Input() beginDate?: Date | string;
  @Input() endDate?: Date | string;

  labels = {
    closeButtonTooltip: "Fermer sans appliquer",
    validateButtonTooltip: "Valider",
    from: "Du",
    to: "Au",
    beginDatePlaceholder: "Date de début",
    endDatePlaceholder: "Date de fin",
  };
  format = {
    defaultDateTime: constDefaultDateTimeFormat,
  };

  displayDateTimeRange: boolean;
  currentBeginDateTime: Date | string = "";
  currentEndDateTime: Date | string = "";

  @Output() toggleDateTimeSelectEmitter: EventEmitter<boolean> =
    new EventEmitter();
  @Output() validateDateTimesEmitter: EventEmitter<CustomDateTimeRange> =
    new EventEmitter();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes?.displayDateTimeRangeSelect) {
      const value = changes.displayDateTimeRangeSelect.currentValue;
      this.displayDateTimeRange = value;
    }
    if (changes?.beginDate) {
      const value = changes.beginDate.currentValue;
      this.currentBeginDateTime = value && value !== "" ? new Date(value) : "";
    }
    if (changes?.endDate) {
      const value = changes.endDate.currentValue;
      this.currentEndDateTime = value && value !== "" ? new Date(value) : "";
    }
  }

  closeDateTimeRange(): void {
    this.currentBeginDateTime = this.beginDate ? new Date(this.beginDate) : "";
    this.currentEndDateTime = this.endDate ? new Date(this.endDate) : "";
    this.toggleDateTimeSelectEmitter.emit(false);
  }

  clearDateTime(inputName: string): void {
    if (inputName === "begin") {
      this.currentBeginDateTime = "";
    }
    if (inputName === "end") {
      this.currentEndDateTime = "";
    }
  }

  isDateTimeNotEmpty(dateTime: Date | string): boolean {
    return dateTime && dateTime !== "";
  }

  validateDateTimes(
    beginDateTime: Date | string,
    endDateTime: Date | string
  ): void {
    const selectedDateTimes: CustomDateTimeRange = {
      beginDateTime: beginDateTime,
      endDateTime: endDateTime,
    };
    this.validateDateTimesEmitter.emit(selectedDateTimes);
    this.closeDateTimeRange();
  }
}
