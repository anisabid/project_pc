import { ColorDescription } from "@app/shared/consts/color-alarms";

export interface CustomFilterChipItem {
  label: string;
  value: string;
  selectedOnInit: boolean;
  colorDescription: ColorDescription;
}
