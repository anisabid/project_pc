import { Injectable } from "@angular/core";
import { ColorBaseType } from "@app/shared/consts/color-alarms";
import { CustomFilterChipItem } from "./custom-filter-chip-list.model";

@Injectable({ providedIn: "root" })
export class CustomFilterChipListUtilsService {
  /**
   * Method to init or update the list of CustomFilterChipItems
   * @param enumKeys array of keys of an enum. examples: Object.keys(AlarmSeverityEnum), Object.keys(BlackoutStatusEnum)
   * @param constColorType const with ColorDescription for each enum key. examples: ConstColorSeverity
   * @param selectedItemsStringList list of selected enum keys, separated by ','
   * @returns CustomFilterChipItem[]
   *
   * Example:
   * const items:CustomFilterChipItems[] = initCustomFilterChipList(
   *    Object.keys(MinimalAlarmSeverityEnum),
   *    ConstColorSeverity,
   *    selectedKeysList
   *  );
   *
   */
  initCustomFilterChipList(
    enumKeys: string[],
    constColorType: ColorBaseType,
    selectedItemsStringList?: string
  ): CustomFilterChipItem[] {
    const selectedItems: string[] =
      selectedItemsStringList && selectedItemsStringList.trim() !== ""
        ? selectedItemsStringList.split(",")
        : [];
    return enumKeys.map((key: string) => {
      return <CustomFilterChipItem>{
        label: constColorType[key].label,
        value: key,
        colorDescription: constColorType[key],
        selectedOnInit: selectedItems.includes(key),
      };
    });
  }
}
