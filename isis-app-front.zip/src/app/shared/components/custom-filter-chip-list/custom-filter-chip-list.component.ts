import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { MatChip, MatChipList } from "@angular/material/chips";
import { CustomFilterChipItem } from "./custom-filter-chip-list.model";

@Component({
  selector: "app-custom-filter-chip-list",
  templateUrl: "./custom-filter-chip-list.component.html",
  styleUrls: ["./custom-filter-chip-list.component.scss"],
})
export class CustomFilterChipListComponent implements OnInit {
  @Input() isMultiple? = true;
  @Input() isDisabled? = false;
  @Input() availableFilterChipItems: CustomFilterChipItem[];
  @Output() selectedFilterChipItemsEmitter: EventEmitter<string[]> =
    new EventEmitter();

  currentCheckboxStates: boolean[];

  ngOnInit(): void {
    this.currentCheckboxStates = this.availableFilterChipItems.map((item) => {
      return item.selectedOnInit;
    });
  }

  toggleFilterChipItem(
    chip: MatChip,
    indexChip: number,
    filterChipList: MatChipList
  ): void {
    if (!this.isDisabled && (this.isMultiple || !chip.selected)) {
      chip.toggleSelected();
      if (this.isMultiple) {
        this.currentCheckboxStates[indexChip] =
          !this.currentCheckboxStates[indexChip];
      } else {
        this.currentCheckboxStates = this.currentCheckboxStates.map(
          (currentState: boolean, index: number) => {
            {
              const newSelectedState =
                index === indexChip
                  ? !currentState
                  : !currentState
                  ? currentState
                  : !currentState;
              return newSelectedState;
            }
          }
        );
      }
      this._emitSelectedChipItems(filterChipList);
    }
  }

  private _emitSelectedChipItems(chipList: MatChipList): void {
    if (chipList && chipList.chips) {
      const selectedChipItemValues: string[] = chipList.chips
        .filter((chip) => chip.selected)
        .map((chip) => chip.value);
      this.selectedFilterChipItemsEmitter.emit(selectedChipItemValues);
    }
  }
}
