import { COMMA, ENTER, TAB } from "@angular/cdk/keycodes";
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from "@angular/core";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { MatChipInputEvent } from "@angular/material/chips";

export interface AdvancedSearchValue {
  items: string[];
  justRemovedItem?: string;
  isCheckboxChecked?: boolean;
}

@Component({
  selector: "app-custom-advanced-search",
  templateUrl: "./custom-advanced-search.component.html",
  styleUrls: ["./custom-advanced-search.component.scss"],
})
export class CustomAdvancedSearchComponent implements OnChanges {
  @Input() advancedSearchItems: string[];
  @Input() displayAdvancedSearchInput: boolean;
  @Input() helpButtonTooltipLabel?: string;

  @Input() checkboxLabel?: string;
  @Input() isCheckboxChecked?: boolean;

  readonly separatorKeysCodes: number[] = [COMMA, TAB, ENTER];
  displayInput: boolean;
  currentAdvancedSearchItems: string[];
  currentCheckboxState: boolean;
  currentFieldInput = "";
  labels = {
    placeholder: "Saisir ici les mots-clés pour le filtre ...",
    validateButtonTooltip: "Valider",
    closeButtonTooltip: "Fermer sans appliquer",
  };

  @Output() toggleAdvancedSearchEmitter: EventEmitter<boolean> =
    new EventEmitter();
  @Output()
  validateAdvancedSearchItemsEmitter: EventEmitter<AdvancedSearchValue> = new EventEmitter();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes?.advancedSearchItems) {
      this.currentAdvancedSearchItems = [
        ...changes.advancedSearchItems.currentValue,
      ];
    }

    if (changes?.displayAdvancedSearchInput) {
      this.currentAdvancedSearchItems = [...this.advancedSearchItems];
      this.displayInput = changes.displayAdvancedSearchInput.currentValue;
    }

    if (changes?.isCheckboxChecked?.currentValue !== undefined) {
      this.currentCheckboxState = changes?.isCheckboxChecked?.currentValue;
    }
  }

  addCurrentSearchItem(event: MatChipInputEvent): void {
    if (event?.value?.trim() !== "") {
      this.currentAdvancedSearchItems.push(event.value);
      event.chipInput.clear();
    }
  }

  onRemoveCurrentSearchItem(index: number): void {
    this.currentAdvancedSearchItems.splice(index, 1);
  }

  onRemoveSearchItem(index: number): void {
    const itemToRemove = this.currentAdvancedSearchItems[index];
    this.onRemoveCurrentSearchItem(index);
    this.validateAdvancedSearchItems(itemToRemove);
  }

  validateAdvancedSearchItems(justRemovedItem?: string): void {
    this.validateAdvancedSearchItemsEmitter.emit({
      items: this.currentAdvancedSearchItems,
      justRemovedItem: justRemovedItem,
      isCheckboxChecked: Boolean(
        this.currentAdvancedSearchItems?.length && this.currentCheckboxState
      ),
    });
    this.closeAdvancedSearchInput();
  }

  closeAdvancedSearchInput(): void {
    this.currentAdvancedSearchItems = this.advancedSearchItems;
    this.currentCheckboxState = this.isCheckboxChecked;
    this.toggleAdvancedSearchEmitter.emit(false);
  }

  toggleCheckbox(event: MatCheckboxChange): void {
    this.currentCheckboxState = event.checked;
  }
}
