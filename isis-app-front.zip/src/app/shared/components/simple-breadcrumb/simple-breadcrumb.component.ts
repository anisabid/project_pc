import { ChangeDetectionStrategy, Component, Input } from "@angular/core";

export interface BreadcrumbItem {
  label: string;
  link?: string;
  active?: boolean;
}
@Component({
  selector: "app-simple-breadcrumb",
  templateUrl: "./simple-breadcrumb.component.html",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SimpleBreadcrumbComponent {
  @Input() breadcrumbItems: BreadcrumbItem[];
}
