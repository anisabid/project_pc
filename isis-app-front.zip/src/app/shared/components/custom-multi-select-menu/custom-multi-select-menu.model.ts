export interface CustomMultiSelectMenuConfig {
  isMenuTriggeredByIconButton: boolean;
  triggerButtonNameOrLabel: string;
  triggerButtonTooltip?: string;
  withApplyButton: boolean;
  withSelectAllButton: boolean;
  withScrollBar?: boolean;
  selectAllButtonLabel?: string;
  theme: CustomMultiSelectMenuTheme;
}

export interface CustomMenuSelectItem {
  label: string;
  value: string;
  selectedOnInit: boolean;
}

export enum CustomMultiSelectMenuTheme {
  STANDARD = "custom-standard-theme",
  BLUE = "custom-blue-theme",
  SMALL_BLACK = "custom-small-black-theme",
}
