import { SelectionModel } from "@angular/cdk/collections";
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from "@angular/core";
import {
  CustomMenuSelectItem,
  CustomMultiSelectMenuConfig,
} from "./custom-multi-select-menu.model";

@Component({
  selector: "app-custom-multi-select-menu",
  templateUrl: "./custom-multi-select-menu.component.html",
  styleUrls: ["./custom-multi-select-menu.component.scss"],
})
export class CustomMultiSelectMenuComponent implements OnChanges {
  @Input() availableSelectItems: CustomMenuSelectItem[];
  @Input() customMultiSelectMenuConfig: CustomMultiSelectMenuConfig;

  customMenuLabels = {
    apply: "Appliquer",
  };

  selection: SelectionModel<CustomMenuSelectItem>;
  mostLongItemLabel: string;

  @Output() closedMultiSelectMenuEmitter: EventEmitter<string> =
    new EventEmitter(true);
  @Output() validateItemsEmitter: EventEmitter<string[]> = new EventEmitter(
    true
  );
  @Output() selectedValuesWhenOpeningEmitter: EventEmitter<string[]> =
    new EventEmitter();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.availableSelectItems) {
      const items = changes.availableSelectItems.currentValue;
      const selectedItemsOnInit = items.filter((item) => {
        return item.selectedOnInit;
      });
      this.mostLongItemLabel = this._getMostLongSelectItem(items);
      this.selection = new SelectionModel(true, selectedItemsOnInit);
    }
  }

  private _getMostLongSelectItem(selectItems: CustomMenuSelectItem[]): string {
    return selectItems.reduce(
      (
        previousItem: CustomMenuSelectItem,
        currentItem: CustomMenuSelectItem
      ) => {
        return previousItem.label.length > currentItem.label.length
          ? previousItem
          : currentItem;
      }
    ).label;
  }

  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numItems = this.availableSelectItems.length;
    return numSelected === numItems;
  }

  toggleAllItems(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.availableSelectItems.forEach((item) =>
          this.selection.select(item)
        );
    if (!this.customMultiSelectMenuConfig.withApplyButton) {
      this.validateSelection();
    }
  }

  toggleItem(item: any): void {
    this.selection.toggle(item);
    if (!this.customMultiSelectMenuConfig.withApplyButton) {
      this.validateSelection();
    }
  }

  onClosedMenu(event: any): void {
    if (this.customMultiSelectMenuConfig.withApplyButton) {
      this.closedMultiSelectMenuEmitter.emit("closed");
    }
  }

  onOpenMenu(): void {
    this.selectedValuesWhenOpeningEmitter.emit(this._getSelectedValues());
  }

  validateSelection(event?: any): void {
    this.validateItemsEmitter.emit(this._getSelectedValues());
  }

  private _getSelectedValues(): string[] {
    return [...this.selection.selected].map((item) => {
      return item.value;
    });
  }
}
