import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from "@angular/core";
import { ControlContainer, FormControl, FormGroup } from "@angular/forms";
import { MatAutocomplete } from "@angular/material/autocomplete";
import { SirocoSearchMetaData } from "@app/seker/blackout-details/blackout-details.model";
import { constValidatorsErrorMessages } from "@app/shared/consts/validators-error-messages";
import { SirocoRefName } from "@app/shared/models/siroco-ref-name";
import { Observable, Subject, takeUntil } from "rxjs";
import { SirocoRefNameAutocompleteService } from "./siroco-ref-name-autocomplete.service";

export interface SirocoRefNameSubFormValue {
  sirocoRefNameAuto?: SirocoRefName | string;
  sirocoRef?: string;
  sirocoName?: string;
}

export interface SirocoRefNameSubForm {
  sirocoRefNameAuto: FormControl<SirocoRefName | string>;
  sirocoRef: FormControl<string>;
  sirocoName?: FormControl<string>;
}

@Component({
  selector: "app-siroco-ref-name-autocomplete",
  templateUrl: "./siroco-ref-name-autocomplete.component.html",
  styleUrls: ["./siroco-ref-name-autocomplete.component.scss"],
})
export class SirocoRefNameAutocompleteComponent implements OnInit, OnDestroy {
  @Input() formInputAppearance: "outline" | "fill" = "outline";
  @Input() formInputLabel = "";
  @Input() formInputId: string;
  @Output() autocompleteTouchedEmitter: EventEmitter<boolean> =
    new EventEmitter<boolean>();

  linkedAutocomplete: MatAutocomplete;
  autocompleteStyleClasses =
    "custom-thick-scrollbar siroco-ref-name__autocomplete";
  sirocoSearchingMeta: SirocoSearchMetaData = {
    inputId: "",
    isProcessing: false,
    message: "",
  };
  sirocoRefNameOptions$: Observable<SirocoRefName[]>;
  errorMessages = constValidatorsErrorMessages;
  private _needUnsubscribe$ = new Subject<boolean>();

  constructor(
    private _sirocoRefNameAutocompleteService: SirocoRefNameAutocompleteService,
    public controlContainer: ControlContainer
  ) {}

  ngOnInit(): void {
    this._sirocoRefNameAutocompleteService.sirocoSearchProcessingMetaData$
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((sirocoSearchMetaData: SirocoSearchMetaData) => {
        this.sirocoSearchingMeta = sirocoSearchMetaData;
      });

    this.sirocoRefNameOptions$ = (
      this.controlContainer.control as FormGroup<SirocoRefNameSubForm>
    )
      .get("sirocoRefNameAuto")
      .valueChanges.pipe(
        this._sirocoRefNameAutocompleteService.autocompleteOptionsSearchOperator(
          this.formInputId
        )
      );
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  onAutocompleteInput(event: InputEvent): void {
    const value = (event.target as HTMLInputElement).value;
    const startTrimedValue = value ? value.trimStart() : value;

    this._updateFormFromStringValue(startTrimedValue);
  }

  private _updateFormFromStringValue(stringValue: string): void {
    const subformGroup = this.controlContainer
      .control as FormGroup<SirocoRefNameSubForm>;

    const sirocoRefName: SirocoRefName =
      this._sirocoRefNameAutocompleteService.extractSirocoRefAndNameFromStringAutocompletevalue(
        stringValue
      );
    subformGroup.get("sirocoRefNameAuto").patchValue(stringValue);
    subformGroup.get("sirocoRef").patchValue(sirocoRefName?.id);
    subformGroup.get("sirocoName").patchValue(sirocoRefName?.name);
  }

  onAutocompleteBlur(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    const endTrimedValue = value ? value.trimEnd() : value;
    this._updateFormFromStringValue(endTrimedValue);
    this.clearMessageIfNeededWhenBlur(value);

    this.autocompleteTouchedEmitter.emit(true);
    (
      this.controlContainer.control as FormGroup<SirocoRefNameSubForm>
    ).markAllAsTouched();
  }

  protected clearMessageIfNeededWhenBlur(inputValue: string): void {
    const needClearMessage =
      this.sirocoSearchingMeta.message !== "" &&
      this.sirocoSearchingMeta.inputId === this.formInputId &&
      (!inputValue || inputValue.trim().length === 0);
    if (needClearMessage) {
      this.sirocoSearchingMeta.message = "";
    }
  }

  onAutocompleteOptionSelected(): void {
    const elementInput = document.getElementById(this.formInputId);
    if (elementInput) {
      elementInput.focus();
      elementInput.blur();
    }
  }

  displayAutoCompleteWithFn(option: SirocoRefName | string): string {
    return (option as SirocoRefName)?.id?.length &&
      (option as SirocoRefName)?.name?.length
      ? `${(option as SirocoRefName).name} (${(option as SirocoRefName).id})`
      : (option as SirocoRefName)?.id?.length
      ? (option as SirocoRefName).id
      : (option as string);
  }

  getErrorMessage(): string {
    const subformGroup = this.controlContainer
      .control as FormGroup<SirocoRefNameSubForm>;
    if (subformGroup.controls["sirocoRefNameAuto"].errors?.pattern) {
      return this.errorMessages.PATTERN;
    }
    return null;
  }
}
