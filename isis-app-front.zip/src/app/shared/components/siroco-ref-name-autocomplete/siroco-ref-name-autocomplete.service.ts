import { Injectable } from "@angular/core";
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
} from "@angular/forms";
import { SirocoSearchMetaData } from "@app/seker/blackout-details/blackout-details.model";
import { SirocoRefName } from "@app/shared/models/siroco-ref-name";
import { SirocoNameRefsService } from "@app/shared/services/api/v2/microservices/siroco-name-refs.service";
import {
  BehaviorSubject,
  catchError,
  debounceTime,
  filter,
  Observable,
  of,
  OperatorFunction,
  pipe,
  switchMap,
} from "rxjs";
import { SirocoRefNameSubForm } from "./siroco-ref-name-autocomplete.component";

@Injectable({ providedIn: "root" })
export class SirocoRefNameAutocompleteService {
  sirocoRefNamePatternDisplay = new RegExp(".*[(][A-Z]{3}[0-9]{4,}[)]");
  sirocoRefPattern = new RegExp("^[A-Z]{3}[0-9]{4,}$");

  private _isSirocoSearchProcessingBehaviorSubject: BehaviorSubject<SirocoSearchMetaData> =
    new BehaviorSubject({ inputId: "", isProcessing: false, message: "" });
  sirocoSearchProcessingMetaData$: Observable<SirocoSearchMetaData>;

  constructor(private _sirocoRefNamesService: SirocoNameRefsService) {
    this.sirocoSearchProcessingMetaData$ =
      this._isSirocoSearchProcessingBehaviorSubject.asObservable();
  }

  autocompleteOptionsSearchOperator(
    inputId?: string
  ): OperatorFunction<string | SirocoRefName, SirocoRefName[]> {
    return pipe(
      debounceTime(500),
      filter((value: string | SirocoRefName) =>
        this._canSearchForAutocomplete(value)
      ),
      switchMap((value: string | SirocoRefName) => {
        const valueToSearch = this._getValueToSearch(value);
        return valueToSearch
          ? this._searchSirocoRefNames(`*${valueToSearch}*`, inputId)
          : of([]);
      })
    );
  }

  getAutocompleteInputValue(
    sirocoRef: string,
    sirocoName?: string
  ): SirocoRefName {
    if (!sirocoRef || sirocoRef.trim().length === 0) {
      return null;
    }

    if (!sirocoName || sirocoName.trim().length === 0) {
      return <SirocoRefName>{
        id: sirocoRef,
      };
    }

    return <SirocoRefName>{
      id: sirocoRef,
      name: this._manageDeprecatedPatternForSirocoName(sirocoRef, sirocoName),
    };
  }

  extractSirocoRefAndNameFromStringAutocompletevalue(
    autocompleteStringValue: string
  ): SirocoRefName {
    if (!autocompleteStringValue || autocompleteStringValue.length === 0) {
      return null;
    }
    if (this.sirocoRefNamePatternDisplay.test(autocompleteStringValue)) {
      const splits = autocompleteStringValue.trim().split("(");
      return <SirocoRefName>{
        id: splits[1].trim().replace("(", "").replace(")", ""),
        name: splits[0].trim(),
      };
    } else {
      return <SirocoRefName>{ id: autocompleteStringValue.trim() };
    }
  }
  /**
   * To manage deprecated pattern already registered in backend side
   * (ex: sirocoName with 'ISIS (APP2495)' instead of 'ISIS')
   */
  private _manageDeprecatedPatternForSirocoName(
    sirocoRef: string,
    sirocoName: string
  ): string {
    if (this.sirocoRefNamePatternDisplay.test(sirocoName)) {
      const splits = sirocoName.trim().split("(");
      return splits[0].trim();
    } else {
      return sirocoRef !== sirocoName ? sirocoName : "";
    }
  }

  private _canSearchForAutocomplete(value: string | SirocoRefName): boolean {
    const isSirocoRefNameOption = !!(value as SirocoRefName).id;
    const isMinimumLength =
      !isSirocoRefNameOption &&
      Boolean(value) &&
      (value as string).trim().length > 2;
    return isMinimumLength || isSirocoRefNameOption;
  }

  private _getValueToSearch(value: string | SirocoRefName): string {
    const isSirocoRefNameOption = !!(value as SirocoRefName).id; // ex: {id: 'APP2495', name: 'ISIS', obj_type: 'Application'}
    return isSirocoRefNameOption
      ? (value as SirocoRefName).id
      : (value as string)?.includes(" (")
      ? (value as string).split(" (")[0].trim()
      : (value as string).trim();
  }

  private _searchSirocoRefNames(
    value: string,
    inputId: string
  ): Observable<SirocoRefName[]> {
    this._isSirocoSearchProcessingBehaviorSubject.next({
      inputId: inputId,
      isProcessing: true,
      message: "",
    });
    return this._sirocoRefNamesService.getSirocoNameRefs(value).pipe(
      switchMap((sirocoRefNames: SirocoRefName[]) => {
        const noResultMessage =
          sirocoRefNames.length === 0 ? "Pas de résultat." : "";
        this._isSirocoSearchProcessingBehaviorSubject.next({
          inputId: inputId,
          isProcessing: false,
          message: noResultMessage,
        });
        return sirocoRefNames.length > 999
          ? of(sirocoRefNames.slice(0, 999))
          : of(sirocoRefNames);
      }),
      catchError(() => {
        this._isSirocoSearchProcessingBehaviorSubject.next({
          inputId: inputId,
          isProcessing: false,
          message: "Recherche en erreur !",
        });
        return of([]);
      })
    );
  }

  buildSirocoRefNameFormGroup(
    needPatternValidation: boolean
  ): FormGroup<SirocoRefNameSubForm> {
    return new FormGroup<SirocoRefNameSubForm>(
      {
        sirocoRefNameAuto: new FormControl(""),
        sirocoRef: new FormControl(""),
        sirocoName: new FormControl(""),
      },
      {
        validators: [this._sirocoRefPatternRequired(needPatternValidation)],
      }
    );
  }

  private _sirocoRefPatternRequired(needValidation = false): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (!control) return null;
      if (!needValidation) return null;

      const formGroup = control as FormGroup<SirocoRefNameSubForm>;
      const sirocoRefFormControl = formGroup.controls["sirocoRef"];
      const sirocoRefFormControlValue = sirocoRefFormControl.value;
      const autocompleteFormControl = formGroup.controls["sirocoRefNameAuto"];

      const noValue =
        !sirocoRefFormControlValue || sirocoRefFormControlValue === "";
      const isValid =
        noValue || this.sirocoRefPattern.test(sirocoRefFormControlValue);

      if (isValid) {
        autocompleteFormControl.setErrors(null);
        return null;
      } else {
        const error: ValidationErrors = {
          pattern: {
            requiredPattern: "^[A-Z]{3}[0-9]{4,}$",
            actualValue: sirocoRefFormControlValue,
          },
        };
        autocompleteFormControl.setErrors(error);
        return error;
      }
    };
  }
}
