import { Component, Input } from "@angular/core";

@Component({
  selector: "app-no-result-block",
  templateUrl: "no-result-block.component.html",
  styleUrls: ["./no-result-block.component.scss"],
})
export class NoResultBlockComponent {
  @Input() message = "Aucun résultat !";
  @Input() displayMessage: boolean;
}
