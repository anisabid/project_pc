import { Injectable } from "@angular/core";
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
} from "@angular/material/dialog";
import {
  ConfirmDialogModel,
  ConfirmDialogComponent,
} from "./confirm-dialog.component";

@Injectable({
  providedIn: "root",
})
export class ConfirmDialogService {
  private dialogRef: MatDialogRef<ConfirmDialogComponent>;
  private dialogConfig: MatDialogConfig;
  constructor(public matDialog: MatDialog) {
    this.dialogConfig = new MatDialogConfig();
  }

  public confirm(title: string, message: string): Promise<boolean> {
    this.dialogConfig.width = "700px";
    this.dialogConfig.autoFocus = false;
    this.dialogConfig.data = new ConfirmDialogModel(title, message);
    this.dialogRef = this.matDialog.open(
      ConfirmDialogComponent,
      this.dialogConfig
    );

    return new Promise((resolve, reject) => {
      this.dialogRef.afterClosed().subscribe({
        next: (result) => resolve(result),
        error: (error) => reject(error),
        complete: () => {
          // do nothing
        },
      });
    });
  }
}
