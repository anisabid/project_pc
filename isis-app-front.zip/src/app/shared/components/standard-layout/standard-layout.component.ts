import { Component, OnInit } from "@angular/core";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";

@Component({
  selector: "app-standard-layout",
  templateUrl: "./standard-layout.component.html",
  styleUrls: ["./standard-layout.component.scss"],
})
export class StandardLayoutComponent implements OnInit {
  displayIsisChat = false;
  constructor(private _securityService: KeycloakSecurityService) {}

  ngOnInit(): void {
    this.displayIsisChat =
      this._securityService.hasRequiredRole(IsisRole.supervisor) ||
      this._securityService.hasRequiredRole(IsisRole.admin);
  }
}
