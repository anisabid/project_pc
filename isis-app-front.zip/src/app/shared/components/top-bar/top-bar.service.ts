import { Injectable } from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { IsisRole } from "@app/shared/models/user";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { BehaviorSubject, Observable, filter, map } from "rxjs";
import { TopBarConfig } from "./top-bar.model";

@Injectable({
  providedIn: "root",
})
export class TopBarService {
  private _selectedRegroupingsSubject: BehaviorSubject<string[]> =
    new BehaviorSubject([]);
  private _selectedRegroupings: string[] = [];
  availableRegroupings: string[] = [];
  alarmIdForGrouping: string;
  private _currentUrlBehaviorSubject: BehaviorSubject<string> =
    new BehaviorSubject("");
  currentUrl$: Observable<string>;

  constructor(
    private isisService: IsisService,
    private _securityService: KeycloakSecurityService,
    private _router: Router
  ) {
    this._router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        map((event: NavigationEnd) => {
          this._currentUrlBehaviorSubject.next(event.urlAfterRedirects);
          return event.url;
        })
      )
      .subscribe();
    this.currentUrl$ = this._currentUrlBehaviorSubject.asObservable();
  }

  /**
   * Resolver
   *
   * @returns {Observable<any> | Promise<any> | any}
   */
  resolve(): Observable<any> | Promise<any> | any {
    return new Promise((resolve, reject) => {
      Promise.all([this.isisService.getGroups()]).then(() => {
        resolve(true);
      }, reject);
    });
  }

  isAdmin(): boolean {
    return this._securityService.hasRequiredRole(IsisRole.admin);
  }

  initTopBarConfig(currentUrl: string): TopBarConfig {
    const isRegroupings = currentUrl.includes("regroupings");
    const isKnownErrors = currentUrl.includes("known-errors");
    const isRegroupingsOrKnownErrors = isRegroupings || isKnownErrors;
    return {
      displayRegroupingFilters:
        isRegroupings &&
        Boolean(this.availableRegroupings.length) &&
        Boolean(this.alarmIdForGrouping),
      displayMenuGroup:
        (currentUrl.includes("alarms") && !isRegroupingsOrKnownErrors) ||
        currentUrl.includes("administration"),
      displayAdministration: this.isAdmin(),
      displayDeconnexion: !isRegroupingsOrKnownErrors,
      displayMenuGroupWithoutItems:
        currentUrl.includes("inhibitions") ||
        currentUrl.includes("sources/home") ||
        (currentUrl.includes("services") &&
          !currentUrl.includes("administration")),
      displaySekerModuleAccess: !isRegroupingsOrKnownErrors,
      displayServicesModuleAccess: !isRegroupingsOrKnownErrors,
      diplaySourcesModuleAccess: true,
      title: this._getTopBarTitle(currentUrl),
    };
  }

  private _getTopBarTitle(currentUrl: string): string {
    return currentUrl.includes("regroupings")
      ? "REGROUPEMENT"
      : currentUrl.includes("known-errors")
      ? "ERREURS CONNUES"
      : "";
  }

  onSelectedRegroupingsChanged(): Observable<string[]> {
    return this._selectedRegroupingsSubject.asObservable();
  }

  updateSelectedRegroupings(selectedRegroupings: string[]): void {
    this._selectedRegroupings = selectedRegroupings;
    this._selectedRegroupingsSubject.next(selectedRegroupings);
  }

  clearSelectedRegroupings(): void {
    if (this._selectedRegroupings && this._selectedRegroupings.length) {
      this.updateSelectedRegroupings([]);
    } else {
      // do nothing
    }
  }

  get selectedRegroupings(): string[] {
    return this._selectedRegroupings;
  }
}
