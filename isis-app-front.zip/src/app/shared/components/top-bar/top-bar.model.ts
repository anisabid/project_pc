export interface TopBarConfig {
  displayRegroupingFilters: boolean;
  displayMenuGroup: boolean;
  displayMenuGroupWithoutItems: boolean;
  displayAdministration: boolean;
  displayDeconnexion: boolean;
  displaySekerModuleAccess: boolean;
  displayServicesModuleAccess: boolean;
  diplaySourcesModuleAccess: boolean;
  title?: string;
}

export enum AppUrlRadicalEnum {
  ALARMS_SI = "alarms/si",
  ALARMS_VABFO = "alarms/vabfo",
  INHIBITIONS = "inhibitions/",
  SERVICES = "services/",
  ADMINISTRATION = "administration/",
  SOURCES = "sources/",
}
