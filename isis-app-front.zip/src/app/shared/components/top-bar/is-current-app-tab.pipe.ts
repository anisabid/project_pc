import { Pipe, PipeTransform } from "@angular/core";
import { AppUrlRadicalEnum } from "./top-bar.model";

@Pipe({
  name: "isCurrentAppTab",
})
export class IsCurrentAppTagPipe implements PipeTransform {
  transform(
    currentUrlValue: string,
    appUrlRadicalEnum: AppUrlRadicalEnum
  ): boolean {
    return currentUrlValue?.includes(appUrlRadicalEnum);
  }
}
