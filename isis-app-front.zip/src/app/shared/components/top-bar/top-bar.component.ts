import { Component, OnDestroy, OnInit } from "@angular/core";
import { MatChip, MatChipList } from "@angular/material/chips";
import { Router } from "@angular/router";
import { Groups } from "@app/shared/models/group";
import { IsisService } from "@app/shared/services/api/v2/microservices/isis.service";
import { Subject, takeUntil, tap } from "rxjs";
import { TopBarService } from "./top-bar.service";
import { AppUrlRadicalEnum, TopBarConfig } from "./top-bar.model";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { RegisteredUser } from "@app/shared/models/user";
import { SourcesService } from "@app/sources/sources.service";

@Component({
  selector: "app-top-bar",
  templateUrl: "./top-bar.component.html",
  styleUrls: ["./top-bar.component.scss"],
})
export class TopBarComponent implements OnInit, OnDestroy {
  currentUser: RegisteredUser = null;
  groups: Groups = new Groups();
  topBarConfig: TopBarConfig;
  displaySourcesKoButton: boolean;
  graySourceKoButton: boolean;
  currentUrl: string;
  isAdmin = false;
  appUrlRadicalEnum = AppUrlRadicalEnum;
  private _needUnsubscribe$ = new Subject<boolean>();

  topBarLabels = {
    buttons: {
      SI: "SI",
      VABFO: "VABFO",
      INHIBITIONS: "INHIBITIONS",
      SERVICES: "SERVICES",
      ADMIN: "Administration",
      SOURCES: "Sources",
    },
    tooltips: {
      sources: "Voir la disponibilité des sources",
    },
    states: {
      ALL: "TOUS",
      OPEN: "Ouverts",
      ACK_WITH_TICKET: "Acquittés avec ticket",
      ACK_WITH_MEP: "Acquittés avec MEP",
      ACK_WITHOUT_TICKET: "Acquittés sans ticket",
      BLACKOUTS: "Blackouts",
      CLOSED: "Clos",
    },
    admin: {
      ROLES: "Rôles",
      RIGHTS: "Droits",
      RULES: "Regroupements",
      SERVICES: "Services",
      DELAYS: "Temporisations",
    },
    deconnexion: " Se déconnecter",
  };

  constructor(
    private isisService: IsisService,
    public topBarService: TopBarService,
    private _router: Router,
    private _sourcesService: SourcesService,
    private _securityService: KeycloakSecurityService
  ) {}

  ngOnInit(): void {
    this.currentUser = this._securityService.getUser();
    this.isAdmin = this.topBarService.isAdmin();
    this.isisService.onGroupsChanged
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((groups: Groups) => (this.groups = groups));
    this.topBarService.currentUrl$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap((url: string) => {
          this.currentUrl = url;
          this.topBarConfig = this.topBarService.initTopBarConfig(url);
        })
      )
      .subscribe();

    this._sourcesService.sourcesIsisError$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap(() => {
          this.displaySourcesKoButton = true;
          this.graySourceKoButton = true;
        })
      )
      .subscribe();

    // TECH NOTE : never catchError atLeastOneSourceKO$ else it will break polling
    this._sourcesService.atLeastOneSourceKO$
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap((isOneSourceKo: boolean) => {
          this.displaySourcesKoButton = isOneSourceKo;
          this.graySourceKoButton = false;
        })
      )
      .subscribe();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  logout(): void {
    this._securityService.logout();
  }

  toggleRegroupingFilterChip(chip: MatChip): void {
    chip.toggleSelected();
  }

  updateSelectedRegroupings(chipList: MatChipList): void {
    const selectedRegroupingFilters = chipList.chips
      .filter((chip) => chip.selected)
      .map((chip) => chip.value);
    this.topBarService.updateSelectedRegroupings(selectedRegroupingFilters);
  }

  navigateToPage(url: string): void {
    this._router.navigate([url]);
  }
}
