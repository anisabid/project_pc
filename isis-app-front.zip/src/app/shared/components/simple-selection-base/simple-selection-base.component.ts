import { SelectionModel } from "@angular/cdk/collections";
import { Component } from "@angular/core";

@Component({
  selector: "app-simple-selection-base",
  template: "",
})
export class SimpleSelectionBaseComponent<T> {
  selection = new SelectionModel<T>(true, []);

  isAllSelected(modelList: T[]): boolean {
    return this.selection.selected.length === modelList?.length;
  }

  toggleAllItems(modelList: T[]): void {
    this.isAllSelected(modelList)
      ? this.selection.clear()
      : modelList.forEach((modelItem: T) => this.selection.select(modelItem));
  }

  selectItem(item: T): void {
    this.selection.toggle(item);
  }
}
