import { ColorDescription } from "@app/shared/consts/color-alarms";

export const CUSTOM_TABLE_PAGE_SIZE_OPTIONS: number[] = [20, 30, 50, 100];

export enum ColumnTypeEnum {
  DATE_TIME = "DATE_TIME",
  BADGE = "BADGE",
  TEXT = "TEXT",
  LONG_TEXT = "LONG_TEXT",
  LONG_TEXT_SIZE_FIXED = "LONG_TEXT_SIZE_FIXED",
  NUMBER = "NUMBER",
  ACTIONS = "ACTIONS",
  CUSTOM = "CUSTOM",
}

export interface CustomTableColumn {
  referenceId: string;
  label: string;
  tooltip?: string;
  width: string;
  type: ColumnTypeEnum;
  isSelectable: boolean;
  isSortable?: boolean;
  selectedByDefault?: boolean; // if no storage
}

export interface CustomTableItem {
  colorDescription?: ColorDescription;
}

export interface CustomTablePage {
  customTableItems: CustomTableItem[];
  page?: number; // mandatory if pagination from backend
  size?: number; // mandatory if pagination from backend
  numberOfElements?: number; // mandatory if pagination from backend
  totalPages?: number;
  totalElements?: number; // mandatory if pagination from backend
}

export interface CustomTableRequestedPageMeta {
  page?: number;
  size?: number;
  sortField?: string;
  sortDirection?: string;
}
