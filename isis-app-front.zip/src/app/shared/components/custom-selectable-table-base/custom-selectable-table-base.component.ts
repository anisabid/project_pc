import { SelectionModel } from "@angular/cdk/collections";
import {
  AfterViewInit,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
  EventEmitter,
  SimpleChanges,
  Component,
} from "@angular/core";
import { MatPaginator, PageEvent } from "@angular/material/paginator";
import { MatSort, Sort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { constDefaultDateOnlyFormat } from "@app/shared/consts/date-formats";
import { merge, Subject, map, takeUntil, of } from "rxjs";
import {
  CustomTableColumn,
  ColumnTypeEnum,
  CustomTablePage,
  CustomTableItem,
  CUSTOM_TABLE_PAGE_SIZE_OPTIONS,
  CustomTableRequestedPageMeta,
} from "./custom-selectable-table-base.model";

@Component({
  selector: "app-custom-selectable-table-base",
  template: "",
})
export class CustomSelectableTableBaseComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy
{
  columns: CustomTableColumn[];
  displayedColumnRefIds: string[];
  columnTypeEnum = ColumnTypeEnum;
  labels = {
    DATA_LOADING: "Nous procédons au chargement des données...",
    NO_RESULTS: "Aucun résultat !",
  };
  noResults: boolean;
  selection = new SelectionModel(true, []);
  format = {
    defaultDateOnly: constDefaultDateOnlyFormat,
  };
  stickyTableHeader = false;

  @Input() customTableId: string;
  @Input() withSelection: boolean;
  @Input() withAutomaticSorting?: boolean;
  @Input() withAutomaticPagination?: boolean;
  @Input() withoutPagination?: boolean;
  @Input() availableColumns: CustomTableColumn[];
  @Input() selectedColumnRefIds: string[];
  @Input() customTablePage: CustomTablePage;
  @Input() isLoadingResults = false;

  customTableDataSource: MatTableDataSource<CustomTableItem> =
    new MatTableDataSource();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  pageSizeOptions = CUSTOM_TABLE_PAGE_SIZE_OPTIONS;
  pageSize = CUSTOM_TABLE_PAGE_SIZE_OPTIONS[1];
  pageLength = 0;

  @ViewChild(MatSort) sort: MatSort;

  @Output() pageChangedEmitter: EventEmitter<CustomTableRequestedPageMeta> =
    new EventEmitter(true);
  @Output() selectedItemsEmitter: EventEmitter<CustomTableItem[]> =
    new EventEmitter(true);

  needUnsubscribe$ = new Subject<boolean>();

  ngOnInit(): void {
    window.addEventListener("scroll", this.scroll, true);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.withAutomaticPagination) {
      this.pageSizeOptions = null;
      this.pageSize = CUSTOM_TABLE_PAGE_SIZE_OPTIONS[1];
    }

    if (changes.availableColumns && changes.availableColumns.currentValue) {
      this.columns = changes.availableColumns.currentValue;
    }

    if (changes.selectedColumnRefIds) {
      const displayedSelectColumn = this.withSelection ? ["select"] : [];
      this.displayedColumnRefIds = displayedSelectColumn.concat(
        this.columns
          .filter((column: CustomTableColumn) => {
            return changes.selectedColumnRefIds.currentValue
              ? changes.selectedColumnRefIds.currentValue.includes(
                  column.referenceId
                ) || !column.isSelectable
              : !column.isSelectable || Boolean(column.selectedByDefault);
          })
          .map((column: CustomTableColumn) => {
            return column.referenceId;
          })
      );
    }

    if (changes.customTablePage && changes.customTablePage.currentValue) {
      if (this.withSelection) {
        this.selection.clear();
        this._emitSelectedItems();
      }
      const newPage: CustomTablePage = changes.customTablePage.currentValue;
      this.noResults = !newPage.customTableItems.length;

      if (!this.withAutomaticPagination) {
        this.pageSize = newPage.size;
        this.pageLength = newPage.totalElements;
        if (this.paginator) {
          this.paginator.pageIndex = newPage.page;
        }
      }

      this.customTableDataSource.data = newPage.customTableItems;
    }
  }

  ngAfterViewInit(): void {
    if (this.withAutomaticSorting) {
      this.customTableDataSource.sort = this.sort;
    }

    if (this.withAutomaticPagination) {
      this.customTableDataSource.paginator = this.paginator;
    }

    const sort$ = this.withAutomaticSorting
      ? of(null)
      : this.sort.sortChange.pipe(
          map((sorting: Sort) => {
            const hasSortingActive = sorting.active && sorting.direction;
            const newRequestedSort: CustomTableRequestedPageMeta = {
              page: 0,
              sortField: hasSortingActive ? sorting.active : undefined,
              sortDirection: hasSortingActive ? sorting.direction : undefined,
            };
            this.paginator.pageIndex = 0;
            return newRequestedSort;
          })
        );

    const page$ =
      this.withoutPagination || this.withAutomaticPagination
        ? of(null)
        : this.paginator.page.pipe(
            map((page: PageEvent) => {
              if (page.pageSize !== this.pageSize) {
                this.pageSize = page.pageSize;
              }
              const newRequestedPage: CustomTableRequestedPageMeta = {
                page: page.pageIndex,
                size: page.pageSize,
              };
              return newRequestedPage;
            })
          );

    merge(sort$, page$)
      .pipe(takeUntil(this.needUnsubscribe$))
      .subscribe((requestedPage) => {
        this.pageChangedEmitter.emit(requestedPage);
      });
  }

  ngOnDestroy(): void {
    this.needUnsubscribe$.next(true);
    this.needUnsubscribe$.complete();
    window.removeEventListener("scroll", this.scroll, true);
  }

  scroll = (): void => {
    this.stickyTableHeader =
      document.getElementById(this.customTableId).scrollTop > 70;
  };

  getCellValueToDisplay(
    customTableItem: CustomTableItem,
    referenceIdColumn: string
  ): string | number {
    return customTableItem[`${referenceIdColumn}`];
  }

  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numRows = this.customTableDataSource.data.length;
    return numSelected === numRows;
  }

  toggleAllItems(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.customTableDataSource.data.forEach((row) =>
          this.selection.select(row)
        );
    this._emitSelectedItems();
  }

  toggleItem(item: CustomTableItem): void {
    this.selection.toggle(item);
    this._emitSelectedItems();
  }

  identifyColumnByReferenceId(
    index: number,
    column: CustomTableColumn
  ): string {
    return column.referenceId;
  }

  isNotTimeOnly(value: number | string): boolean {
    return typeof value === "number";
  }

  private _emitSelectedItems(): void {
    const selectedItems: CustomTableItem[] = [...this.selection.selected];
    this.selectedItemsEmitter.emit(selectedItems);
  }
}
