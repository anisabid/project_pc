import { Injectable } from "@angular/core";
import { CustomMenuSelectItem } from "../custom-multi-select-menu/custom-multi-select-menu.model";
import { CustomTableColumn } from "./custom-selectable-table-base.model";

@Injectable({ providedIn: "root" })
export class CustomSelectableTableBaseService {
  initAvailableColumnSelectItems(
    availableColumns: CustomTableColumn[],
    columnLocalStorageName: string
  ): CustomMenuSelectItem[] {
    const selectedColumnsFromStorage: string[] =
      this.getSelectedColumnsFromStorage(columnLocalStorageName);

    return availableColumns
      .filter((column: CustomTableColumn) => {
        return column.isSelectable;
      })
      .map((column: CustomTableColumn) => {
        return <CustomMenuSelectItem>{
          label: column.label,
          value: column.referenceId,
          selectedOnInit: selectedColumnsFromStorage
            ? selectedColumnsFromStorage.includes(column.referenceId)
            : column.selectedByDefault,
        };
      });
  }

  getSelectedColumnsFromStorage(columnLocalStorageName: string): string[] {
    return localStorage.getItem(columnLocalStorageName)
      ? JSON.parse(localStorage.getItem(columnLocalStorageName))
      : null;
  }

  updateSelectedColumnsIntoLocalStorage(
    selectedColumnRefIds: string[],
    columnLocalStorageName: string
  ): void {
    localStorage.setItem(
      columnLocalStorageName,
      JSON.stringify(selectedColumnRefIds)
    );
  }
}
