import { HttpErrorResponse } from "@angular/common/http";
import { Component, OnDestroy, OnInit } from "@angular/core";
import {
  ActivatedRoute,
  ActivationEnd,
  ParamMap,
  Router,
} from "@angular/router";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { Subject, takeUntil, tap } from "rxjs";
import { ErrorPageService } from "./error-page.service";

@Component({
  selector: "app-error-page",
  templateUrl: "./error-page.component.html",
  styleUrls: ["./error-page.component.scss"],
})
export class ErrorPageComponent implements OnInit, OnDestroy {
  labels = {
    goBackButton: "HOMEPAGE",
    message: {
      auth: {
        generic:
          "Nous rencontrons un souci avec le service d'authentification Keycloak.",
        guideBegin:
          "Veuillez réessayer. Si le problème persiste, merci de contacter l' équipe",
        guideContact: " !Infras-agiles <Infras-agiles@sfr.com>.",
      },
      isis: {
        generic: "La page que vous demandez est temporairement indisponible.",
        guideBeginLine1:
          "Veuillez réessayer. Si le problème persiste, merci de créer un TT à IN_DSI_PRD_ING_OUTIL_ISIS",
        guideBeginLine2: "et veuillez contacter : ",
        guideHo: "  - en HO : ",
        guideContactHo: "!Admin-isis <admin-isis@sfr.com>",
        guideHno: "  - en HNO : ",
        guideContactHno:
          "les équipes d'astreinte et !Admin-isis <admin-isis@sfr.com>",
      },
      technicalInformationTitle:
        "Information(s) technique(s) concernant l'erreur : ",
    },
  };

  errorCode: string;
  isAuthentTeam: boolean;
  technicalInformationLevel1: string;
  technicalInformationLevel2: string;
  private _storedError: HttpErrorResponse;

  private _needUnsubscribe$ = new Subject<boolean>();
  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _errorPageService: ErrorPageService,
    private _keycloakSecurityService: KeycloakSecurityService
  ) {
    this._router.events
      .pipe(takeUntil(this._needUnsubscribe$))
      .subscribe((event) => {
        if (event instanceof ActivationEnd) {
          const isBrowserRefresh = !this._router.navigated;
          if (isBrowserRefresh) {
            this.navigateToIsisHomePage();
          }
        }
      });
  }

  ngOnInit(): void {
    this._route.paramMap
      .pipe(
        takeUntil(this._needUnsubscribe$),
        tap((params: ParamMap) => {
          this.errorCode = params.get("code");
          this._storedError = this._errorPageService.getStoredError();
          this.technicalInformationLevel1 = this._getTechnicalInformationLevel1(
            this._storedError
          );
          this.technicalInformationLevel2 = this._getTechnicalInformationLevel2(
            this._storedError
          );
          this.isAuthentTeam = this._errorPageService.isKeycloakIssue();
          this._errorPageService.clearError();
        })
      )
      .subscribe();
  }

  ngOnDestroy(): void {
    this._needUnsubscribe$.next(true);
    this._needUnsubscribe$.complete();
  }

  getTitle(code?: string): string {
    return code ? `Oups - ${code}` : "Oups !";
  }

  private _getTechnicalInformationLevel1(error?: HttpErrorResponse): string {
    return error?.message;
  }

  private _getTechnicalInformationLevel2(error?: HttpErrorResponse): string {
    try {
      if (!!error?.error) {
        return JSON.stringify(error.error);
      } else {
        return null;
      }
    } catch (error: any) {
      // to avoid issue due to stringify
      return null;
    }
  }

  async navigateToIsisHomePage(): Promise<void> {
    console.log("ISIS: Clear storage before app reloading...");
    localStorage.clear();
    if (this.isAuthentTeam) {
      console.log("ISIS: Attempt to join Keycloak...");
      await this._keycloakSecurityService.init();
    }
    console.log("ISIS: Attempt to go to the homepage...");
    this._router.navigate(["/alarms/si/all"]);
  }
}
