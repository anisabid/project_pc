import { HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";

@Injectable({ providedIn: "root" })
export class ErrorPageService {
  private _storedHttpError: any;
  private _isIdentifiedKeycloakIssue: boolean;
  constructor(private _router: Router) {}

  storeErrorAndNavigateToErrorPage(
    error: any,
    isIdentifiedKeycloakIssue = false
  ): void {
    const errorCode = (!isIdentifiedKeycloakIssue && error?.status) ?? null;
    this._storedHttpError = error;
    this._isIdentifiedKeycloakIssue = isIdentifiedKeycloakIssue;
    this.navigateToErrorPage(errorCode);
  }

  navigateToErrorPage(errorCode: string | number): void {
    const urlToNavigate = errorCode ? `/error/${errorCode}` : "/error";
    this._router.navigate([urlToNavigate]);
  }

  clearError(): void {
    this._storedHttpError = null;
    this._isIdentifiedKeycloakIssue = false;
  }

  isKeycloakIssue(): boolean {
    return this._isIdentifiedKeycloakIssue;
  }

  getStoredError(): HttpErrorResponse {
    return this._storedHttpError;
  }
}
