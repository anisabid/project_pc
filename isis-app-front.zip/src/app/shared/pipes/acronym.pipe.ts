import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "acronym",
})
export class AcronymPipe implements PipeTransform {
  transform(value: string): string {
    const acronym = value ? value.match(/\b(?!EXT)\b(\w)/g).join("") : "";
    return acronym.toLocaleUpperCase();
  }
}
