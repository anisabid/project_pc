import { NgModule } from "@angular/core";
import { AcronymPipe } from "./acronym.pipe";
import { StatePipe } from "./state.pipe";
import { SeverityPipe } from "./severity.pipe";
import { TruncatePipe } from "./truncate.pipe";
import { DatePipe } from "@angular/common";
import { TooltipMessagePriorityPipe } from "./tooltip-messages/tooltip-message-priority.pipe";
import { SfrRefIncidentUrlPipe } from "./sfr-ref-incident-url.pipe";
import { ServiceLevelBadgeClassPipe } from "./service-level-badge-class.pipe";
import { TooltipMessageRegroupingPipe } from "./tooltip-messages/tooltip-message-regrouping.pipe";
import { TooltipMessageConsigneUrlPipe } from "./tooltip-messages/tooltip-message-consigne-url.pipe";
import { TooltipMessageKnownErrorsPipe } from "./tooltip-messages/tooltip-message-known-errors.pipe";
import { IsCurrentAppTagPipe } from "../components/top-bar/is-current-app-tab.pipe";

@NgModule({
  declarations: [
    AcronymPipe,
    IsCurrentAppTagPipe,
    SeverityPipe,
    StatePipe,
    TruncatePipe,
    SfrRefIncidentUrlPipe,
    ServiceLevelBadgeClassPipe,
    TooltipMessageRegroupingPipe,
    TooltipMessagePriorityPipe,
    TooltipMessageConsigneUrlPipe,
    TooltipMessageKnownErrorsPipe,
  ],
  imports: [],
  exports: [
    AcronymPipe,
    IsCurrentAppTagPipe,
    SeverityPipe,
    StatePipe,
    TruncatePipe,
    SfrRefIncidentUrlPipe,
    ServiceLevelBadgeClassPipe,
    TooltipMessagePriorityPipe,
    TooltipMessageRegroupingPipe,
    TooltipMessageConsigneUrlPipe,
    TooltipMessageKnownErrorsPipe,
  ],
  providers: [DatePipe],
})
export class PipesModule {}
