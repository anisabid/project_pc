import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "serviceLevelBadgeClass",
})
export class ServiceLevelBadgeClassPipe implements PipeTransform {
  transform(
    serviceLevelCode: "PLATINUM" | "GOLD" | "SILVER" | "COPPER",
    typeBadge: "hexagon" | "oblong"
  ): string {
    return typeBadge === "hexagon"
      ? `sfr-badge-${typeBadge}-in2--${serviceLevelCode}`
      : `sfr-badge-oblong--${serviceLevelCode}`;
  }
}
