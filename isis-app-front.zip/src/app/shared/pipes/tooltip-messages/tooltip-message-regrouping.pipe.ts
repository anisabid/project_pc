import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "tooltipMessageRegrouping",
})
export class TooltipMessageRegroupingPipe implements PipeTransform {
  transform(sfrRegroupement: string[] | string): string {
    return sfrRegroupement &&
      Array.isArray(sfrRegroupement) &&
      sfrRegroupement.length
      ? `Regroupements ${sfrRegroupement.join(" - ")}`
      : "Pas de regroupement";
  }
}
