import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "tooltipMessageKnownErrors",
})
export class TooltipMessageKnownErrorsPipe implements PipeTransform {
  transform(hasKnownErrors: boolean): string {
    return hasKnownErrors ? "Erreurs connues" : "Pas d'erreur connue";
    // NOTE: Case 'no known errors' not yet implemented on backend-side
  }
}
