import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "tooltipMessagePriority",
})
export class TooltipMessagePriorityPipe implements PipeTransform {
  transform(priority: string): string {
    if (!priority || priority.length === 0) {
      return null;
    }
    return `Priorité ${priority}`;
  }
}
