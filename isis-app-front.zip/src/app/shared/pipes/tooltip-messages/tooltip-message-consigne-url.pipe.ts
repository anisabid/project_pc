import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "tooltipMessageConsigneUrl",
})
export class TooltipMessageConsigneUrlPipe implements PipeTransform {
  transform(sfrUrlConsign: string): string {
    return sfrUrlConsign?.length ? "Consigne" : "Pas de consigne";
  }
}
