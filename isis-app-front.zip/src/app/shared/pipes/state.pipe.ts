import { Pipe, PipeTransform } from "@angular/core";
import {
  ConstColorStates,
  ColorDescription,
} from "@app/shared/consts/color-alarms";

@Pipe({
  name: "state",
})
export class StatePipe implements PipeTransform {
  private state: ColorDescription;
  private response: any;

  /**
   * Transform
   *
   * @param value
   * @param {string} desc
   * @returns {any}
   */
  transform(value: string, desc: string): any {
    switch (value.toUpperCase()) {
      case ConstColorStates.ALL.code.toUpperCase():
        this.state = ConstColorStates.ALL;
        break;
      case ConstColorStates.ACQUITTED_WITH_TICKET.code.toUpperCase():
        this.state = ConstColorStates.ACQUITTED_WITH_TICKET;
        break;
      case ConstColorStates.ACQUITTED_WITHOUT_TICKET.code.toUpperCase():
        this.state = ConstColorStates.ACQUITTED_WITHOUT_TICKET;
        break;
      case ConstColorStates.ACQUITTED_WITH_MEP.code.toUpperCase():
        this.state = ConstColorStates.ACQUITTED_WITH_MEP;
        break;
      case ConstColorStates.BLACKOUT.code.toUpperCase():
        this.state = ConstColorStates.BLACKOUT;
        break;
      case ConstColorStates.CLOSED.code.toUpperCase():
        this.state = ConstColorStates.CLOSED;
        break;
      case ConstColorStates.OPEN.code.toUpperCase():
        this.state = ConstColorStates.OPEN;
        break;
      default:
        this.state = new ColorDescription();
    }
    switch (desc.toLowerCase()) {
      case "code":
        this.response = this.state.code;
        break;
      case "background":
        this.response = this.state.background;
        break;
      case "color":
        this.response = this.state.color;
        break;
      case "name":
        this.response = this.state.name;
        break;
      case "label":
        this.response = this.state.label;
        break;
      case "text_color":
        this.response = this.state.text_color;
        break;
      case "icon":
        this.response = this.state.icon;
        break;
      default:
        this.response = this.state.color;
    }
    return this.response;
  }
}
