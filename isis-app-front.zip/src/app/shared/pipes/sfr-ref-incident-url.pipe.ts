import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "sfrRefIncidentUrl",
})
export class SfrRefIncidentUrlPipe implements PipeTransform {
  transform(sfrRefIncident: string): string {
    return `https://mysearch.private.sfr.com/plugin?plugin=ClarifyTT_TR&id=${sfrRefIncident}`;
  }
}
