import { Pipe, PipeTransform } from "@angular/core";
import {
  ConstColorSeverity,
  ColorDescription,
} from "@app/shared/consts/color-alarms";

@Pipe({
  name: "severity",
})
export class SeverityPipe implements PipeTransform {
  private severity: ColorDescription;
  private response: any;

  /**
   * Transform
   *
   * @param value
   * @param {string} desc
   * @returns {any}
   */
  transform(value: string, desc: string): any {
    switch (value.toUpperCase()) {
      case ConstColorSeverity.CRITICAL.code.toUpperCase():
        this.severity = ConstColorSeverity.CRITICAL;
        break;
      case ConstColorSeverity.INFO.code.toUpperCase():
        this.severity = ConstColorSeverity.INFO;
        break;
      case ConstColorSeverity.MAJOR.code.toUpperCase():
        this.severity = ConstColorSeverity.MAJOR;
        break;
      case ConstColorSeverity.OK.code.toUpperCase():
        this.severity = ConstColorSeverity.OK;
        break;
      case ConstColorSeverity.WARNING.code.toUpperCase():
        this.severity = ConstColorSeverity.WARNING;
        break;
      case ConstColorSeverity.UNKNOWN.code.toUpperCase():
        this.severity = ConstColorSeverity.UNKNOWN;
        break;
      default:
        this.severity = new ColorDescription({ background: "#fff" });
    }
    switch (desc.toLowerCase()) {
      case "code":
        this.response = this.severity.code;
        break;
      case "background":
        this.response = this.severity.background;
        break;
      case "color":
        this.response = this.severity.color;
        break;
      case "name":
        this.response = this.severity.name;
        break;
      case "label":
        this.response = this.severity.label;
        break;
      case "text_color":
        this.response = this.severity.text_color;
        break;
      case "icon":
        this.response = this.severity.icon;
        break;
      default:
        this.response = this.severity.color;
    }
    return this.response;
  }
}
