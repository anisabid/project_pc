// created by Chamsoudine ALI at 20200110 19:09.
//
// Chamsoudine ALI - GFI Informatique
// https://github.com/ChamsII

import { BrowserModule } from "@angular/platform-browser";
import { NgModule, APP_INITIALIZER, Inject, ErrorHandler } from "@angular/core";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { SharedModule } from "@app/shared/shared.module";
import { ErrorInterceptor } from "./auth-helper/error.interceptor";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { KeycloakSecurityService } from "./service/keycloak-security.service";
import { KeycloakAngularModule } from "keycloak-angular";
import {
  ApmErrorHandler,
  ApmModule,
  ApmService,
} from "@elastic/apm-rum-angular";
import { AppConfig, APP_CONFIG } from "./app.config";

export function kcFactory(kcsecurity: KeycloakSecurityService) {
  return (): Promise<boolean> => {
    return new Promise(async (resolve) => {
      try {
        await kcsecurity.init();
        resolve(true);
      } catch (error) {
        resolve(false); // to allow initializing the app and display eventually error page
      }
    });
  };
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    ApmModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    KeycloakAngularModule,
    SharedModule,
    BrowserAnimationsModule,
  ],
  providers: [
    ApmService,
    {
      provide: APP_INITIALIZER,
      deps: [KeycloakSecurityService],
      useFactory: kcFactory,
      multi: true,
    },
    {
      provide: ErrorHandler,
      useClass: ApmErrorHandler,
    },
    //{ provide: APP_INITIALIZER , deps:[WebsocketService] , useFactory:socketFactory , multi:true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(@Inject(APP_CONFIG) config: AppConfig, service: ApmService) {
    if (config.ciEnvironment === "staging" || config.ciEnvironment === "prod") {
      try {
        service.init({
          serviceName: "isis-app-front",
          serverUrl: config.apmRUM?.serverUrl ? config.apmRUM?.serverUrl : "",
          environment: config.ciEnvironment,
          breakdownMetrics: true,
          distributedTracing: true,
          distributedTracingOrigins: [
            `${window.location.origin}`,
            `${config.isisSpringBackV2BaseApi.schemes}${config.isisSpringBackV2BaseApi.host}`.slice(
              0,
              -1
            ),
            `${config.moteurClarifyBaseApi.schemes}${config.moteurClarifyBaseApi.host}`.slice(
              0,
              -1
            ),
          ],
          propagateTracestate: true,
          serviceVersion: "11.1.0",
        });
      } catch (error) {
        // do nothing
      }
    }
  }
}
