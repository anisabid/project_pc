import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from "@angular/common/http";
import { Observable, throwError, catchError } from "rxjs";
import { KeycloakSecurityService } from "@app/service/keycloak-security.service";
import { ErrorPageService } from "@app/shared/components/errorPage/error-page.service";

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private keycloakSecurityService: KeycloakSecurityService,
    private _errorPageService: ErrorPageService
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error) => {
        if (error.status === 401) {
          /*
                // auto logout if 401 response returned from api
                this.loginService.logout();
                // location.reload(true);
                this.router.navigate(['/login']);
                */
          console.log("token not vaid 401");
          this.keycloakSecurityService.keycloakService.login();
        }

        console.log("err : ");

        if (error.status === 503) {
          this._errorPageService.navigateToErrorPage(503);
          return throwError(() => error);
        }

        if (
          error.status !== 401 &&
          (request.url.includes("api/v1/alarms/?ssgroup") ||
            request.url.includes("api/v1/alarms/groups") ||
            request.url.includes("api/v1/auth"))
        ) {
          this._errorPageService.storeErrorAndNavigateToErrorPage(error);
          return throwError(() => error);
        }

        return throwError(() => error);
      })
    );
  }
}
