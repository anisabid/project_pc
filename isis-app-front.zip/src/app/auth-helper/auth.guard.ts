import { Injectable } from "@angular/core";
import {
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
} from "@angular/router";
import { KeycloakAuthGuard } from "keycloak-angular";
import { KeycloakSecurityService } from "../service/keycloak-security.service";

@Injectable({ providedIn: "root" })
export class AuthGuard extends KeycloakAuthGuard {
  constructor(
    protected router: Router,
    protected keycloakSecurityService: KeycloakSecurityService
  ) {
    super(router, keycloakSecurityService.keycloakService);
  }

  async isAccessAllowed(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean | UrlTree> {
    if (!this.authenticated) {
      await this.keycloakAngular.login({
        redirectUri: `${window.location}${state.url} `,
      });
      return;
    }

    return true;
  }
}
