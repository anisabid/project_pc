# Plan de MEP ISIS FRONT

## Steps

1) **Tag new prod and migration version**

In this step be sure you already have a Tag from `prod` and `migration` stable version of the corresponding branches.

Else create [new Tag](https://gitlab.pic.services.prod/isis/isis-app-front/-/tags/new) from `prod` and `migration` branches.

When you create new Tag add description of Changelog 


2) **Check version of your localstorage service**

If the model of localstorage is updated, then check you are changed the value of version in file [localstorage](https://gitlab.pic.services.prod/isis/isis-app-front/-/blob/migration/src/app/shared/services/localstorage/localstorage.ts)
and make sure it is different from value in prod branche.

3) **Test Build**

In your local machine test the build with the prod configuration.

`npm run prod`

4) **Check size of modules**

5) **Test application in Pack**


## Build

1) **Merge prod**

Merge branche migration to prod [creat New merge request](https://gitlab.pic.services.prod/isis/isis-app-front/-/merge_requests/new)


> If the build is successful


## Deploy

> The deployment in production is manual

1) **Deploy TP - Trappes **

click [the second button](https://gitlab.pic.services.prod/isis/isis-app-front/-/pipelines?page=1&scope=all&ref=prod)

3) **Deploy HR - Achères **

click [the third button](https://gitlab.pic.services.prod/isis/isis-app-front/-/pipelines?page=1&scope=all&ref=prod)


