import { CommonRequestError } from '../models/common-request-error.model';

/**
 * Common Request Error Type
 */
export enum CommonErrorType {
  NETWORK_ERROR = 'NETWORK_ERROR',
  ERROR_404 = 'ERROR_404',
  ERROR_400 = 'ERROR_400',
  ERROR_401 = 'ERROR_401',
  ERROR_403 = 'ERROR_403',
  ERROR_500 = 'ERROR_500',
}

/**
 * Common Request Error Description
 */
export enum CommonErrorDescription {
  NETWORK_ERROR = 'Problème Réseau',
  ERROR_404 = '404 Introuvable',
  ERROR_400 = 'paramètres invalides',
  ERROR_401 = 'Accès non autorisé',
  ERROR_403 = 'Accès refusé',
  ERROR_500 = 'Problème Serveur',
}

/**
 * Common Request Error List
 */
export const commonRequestErrors: CommonRequestError[] = [
  {
    type: CommonErrorType.NETWORK_ERROR,
    label: CommonErrorDescription.NETWORK_ERROR,
  },
  {
    type: CommonErrorType.ERROR_404,
    label: CommonErrorDescription.ERROR_404,
  },
  {
    type: CommonErrorType.ERROR_400,
    label: CommonErrorDescription.ERROR_400,
  },
  {
    type: CommonErrorType.ERROR_401,
    label: CommonErrorDescription.ERROR_401,
  },
  {
    type: CommonErrorType.ERROR_403,
    label: CommonErrorDescription.ERROR_403,
  },
  {
    type: CommonErrorType.ERROR_500,
    label: CommonErrorDescription.ERROR_500,
  },
];
