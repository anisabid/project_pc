import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { EndpointService } from '../endpoint.service';
interface HttpResponseType {
  isPcOwner: string;
  login: string;
}
@Injectable({
  providedIn: 'root',
})
export class LoginMicroServices {
  private _endpoint: EndpointService;
  constructor(
    private httpClient: HttpClient,
    private environmentService: EnvironmentService,
    private urlHelperService: UrlHelperService
  ) {
    this._endpoint = new EndpointService('login');

    this._endpoint.items.post =
      '?user_name=${user}&user_password=${password}&access=${access}';
  }

  get endpoint(): EndpointService {
    return this._endpoint;
  }

  postLogin(obj: Object = {}): Observable<HttpResponse<HttpResponseType>> {
    const params = {
      '${user}': obj['user'] ? obj['user'].toString() : '',
      '${password}': obj['password'] ? obj['password'].toString() : '',
      '${access}': obj['access'] ? obj['access'].toString() : '',
    };
    let path: string = this.urlHelperService.transformParameters(
      this._endpoint.items.post,
      params
    );
    if (this.environmentService.options.mock.data.login) {
      path = this._endpoint.toMock(path);
    }
    return this.httpClient
      .post(path, null, { observe: 'response' as 'body' })
      .pipe(
        map((result: HttpResponse<HttpResponseType>) => {
          return result;
        })
      );
  }

  getUrlAutoLogin(obj: Object = {}): string {
    const params = {
      '${access}': obj['access'] ? '&access=' + obj['access'].toString() : '',
    };
    return this.urlHelperService.transformParameters(
      this.environmentService.config.modules.login.urlAutoLogin,
      params
    );
  }
}
