import { ContentObserver } from '@angular/cdk/observers';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { Api } from './api.model';

export interface Methods {
  get: any;
  post: any;
  put: any;
  patch: any;
  delete: any;
}

class Collection {
  private _path: string;
  private _get: string;
  private _post: string;
  private _put: string;
  private _patch: string;
  private _delete: string;

  constructor(val: string = '') {
    this._path = val;
    this.get = this.post = this.put = this.patch = this.delete = '';
  }

  private joinPath(...args: string[]) {
    return args.map((pathPart) => pathPart.replace(/(^\/|\/$)/g, '')).join('/');
  }

  get get(): string {
    return this._get;
  }

  set get(val: string) {
    this._get = this.joinPath(this._path, val);
  }

  get post(): string {
    return this._post;
  }

  set post(val: string) {
    this._post = this.joinPath(this._path, val);
  }

  get put(): string {
    return this._put;
  }

  set put(val: string) {
    this._put = this.joinPath(this._path, val);
  }

  get patch(): string {
    return this._patch;
  }

  set patch(val: string) {
    this._patch = this.joinPath(this._path, val);
  }

  get delete(): string {
    return this._delete;
  }

  set delete(val: string) {
    this._delete = this.joinPath(this._path, val);
  }
}

export class EndpointService {
  private _api: Api;
  private _apiMock: Api;
  private _path: string;
  private _items: Collection;
  private _item: Collection;

  private environmentService: EnvironmentService;

  constructor(path: string) {
    this.environmentService = new EnvironmentService();
    this._api = new Api(this.environmentService.api);
    this._apiMock = new Api(this.environmentService.options.mock.api);

    if (path) {
      this.path = path;
      this._items = new Collection(this.path);
      this._item = new Collection(this.path);
    }
  }

  public toMock(val: string): string {
    val = val.replace(
      this._api.schemes + this._api.host + this._api.basePath,
      this._apiMock.schemes + this._apiMock.host + this._apiMock.basePath
    );
    return val;
  }

  get base(): string {
    return this._api.schemes + this._api.host + this._api.basePath;
  }

  get path(): string {
    return this._path;
  }

  set path(val: string) {
    this._path = this._api.schemes + this._api.host + this._api.basePath + val;
  }

  get items(): Collection {
    return this._items;
  }

  get item(): Collection {
    return this._item;
  }

  get toString(): string {
    return this._path;
  }
}
