import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { locale as localFrench } from '@shared/i18n/fr';

export interface Locale {
  lang: string;
  data: Object;
}

export class Locale {
  lang: string;
  data: Object;

  constructor(locale: Locale) {
    this.lang = locale.lang;
    this.data = locale.data;
  }
}

@Injectable({
  providedIn: 'root',
})
export class TranslationLoaderService {
  /**
   * Constructor
   *
   * @param {TranslateService} translateService
   */
  constructor(private translateService: TranslateService) {
    // Set the global translations
    this.loadTranslations(localFrench);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * Load translations
   *
   * @param {Locale} args
   */
  public loadTranslations(...args: Locale[]): void {
    const locales = [...args];

    locales.forEach((locale) => {
      // use setTranslation() with the third argument set to true
      // to append translations instead of replacing them
      this.translateService.setTranslation(locale.lang, locale.data, true);
    });
  }

  public instant(
    key: string | Array<string>,
    interpolateParams?: Object
  ): string | any {
    return this.translateService.instant(key, interpolateParams);
  }

  public translate(
    key: string | Array<string>,
    interpolateParams?: Object
  ): string | any {
    return this.translateService.instant(key, interpolateParams);
  }
}
