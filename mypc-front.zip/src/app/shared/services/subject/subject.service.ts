import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class subjectService {
  // Quickview Toggle
  private _onPerfectScrollbarToggleChanged = new Subject();
  public onPerfectScrollbarToggleChanged = this._onPerfectScrollbarToggleChanged.asObservable();
}
