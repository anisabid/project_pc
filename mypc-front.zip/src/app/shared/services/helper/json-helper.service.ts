/**
 * @description Convert and recover complex Object
 */

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class JsonHelperService {
  constructor() {}

  /**
   * Convert complex Map Object to json
   *
   * @example JSON.stringify([val], this.jsonHelperService.replacer)
   * @param key
   * @param value
   * @returns
   */
  public replacer(key: any, value: any) {
    if (value instanceof Map) {
      return {
        dataType: 'Map',
        value: Array.from(value.entries()),
      };
    } else {
      return value;
    }
  }

  /**
   * Recover json to complex Map Object
   *
   * @example <[Model]>JSON.parse(localStorage.getItem([name]), this.jsonHelperService.reviver)
   * @param key
   * @param value
   * @returns
   */
  public reviver(key: any, value: any) {
    if (typeof value === 'object' && value !== null) {
      if (value.dataType === 'Map') {
        return new Map(value.value);
      }
    }
    return value;
  }
}
