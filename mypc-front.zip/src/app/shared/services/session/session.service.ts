import { Injectable } from '@angular/core';
import { JwtService } from '@app/core/services/jwt.service';
import { Session, User } from '@shared/models/user';

@Injectable({
  providedIn: 'root',
})
export class SessionService {
  private _session: Session;

  constructor(private jwtService: JwtService) {
    this.init();
  }

  public init() {
    this._session =
      this.jwtService.getInfos() && this.jwtService.isValidInfos()
        ? new Session(this.jwtService.getInfos())
        : null;
  }

  set session(data: any) {
    this._session = new Session(data);
  }

  get session(): Session {
    return this._session;
  }

  get user(): User {
    return this._session.user;
  }
}
