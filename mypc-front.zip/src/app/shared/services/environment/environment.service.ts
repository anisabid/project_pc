import { Injectable } from '@angular/core';
import { Params } from '@angular/router';
import { environment } from '@environments/environment';

export interface Environment {
  access: EnvironmentAccess;
  api: EnvironmentApi;
  backOffice: EnvironmentBackOffice;
  config: EnvironmentConfig;
  iframe: EnvironmentIframe;
  integration: boolean;
  options?: EnvironmentOptions;
  production: boolean;
}
export interface EnvironmentMock {
  api: EnvironmentApi;
  data: any;
}

export interface EnvironmentLocalStorage {
  catalogs?: string;
  clearAfterLogout: Array<string>;
  jwt?: string;
  sidebar?: string;
  requestsPreviousSearch?: string;
  clearAfterUpdateAppVersion?: Array<string>;
}

export interface EnvironmentLocalCookies {
  clearAfterLogout: string | Array<string>;
}

export interface EnvironmentOptions {
  localCookies: EnvironmentLocalCookies;
  localStorage: EnvironmentLocalStorage;
  mock: EnvironmentMock;
}

export interface EnvironmentBackOffice {
  baseUrl: string;
}

export interface EnvironmentApi {
  basePath: string;
  host: string;
  paths: Object;
  schemes: string;
}

export interface EnvironmentIframe {
  baseUrl: string;
  baseUrlMyAssistance: string;
}

export interface EnvironmentConfig {
  defaultNavigate: string;
  modules: EnvironmentConfigModules;
  snackBarDuration: number;
}

export interface EnvironmentConfigModules {
  dashboard: EnvironmentConfigDashboard;
  layoutSidebar: any;
  login: EnvironmentConfigLogin;
  logout: EnvironmentConfigLogout;
  requests: EnvironmentConfigRequests;
}
export interface EnvironmentConfigDashboard {
  widgets: EnvironmentConfigDashboardWidgets;
  workflow: EnvironmentConfigDashboardWorkflow;
}

export interface EnvironmentConfigLogin {
  disableLogout: boolean;
  mergeLogin: boolean;
  onlyAutoLogin: boolean;
  onlyManualLogin: boolean;
  urlAutoLogin?: string;
  snackBarErrorDuration: number;
}

export interface EnvironmentConfigLogout {
  duration: number;
  path: EnvironmentConfigLogoutPath;
  autoRedirectToLogin: boolean;
}

export interface EnvironmentConfigLogoutPath {
  myPc: string;
  myAssistance: string;
}

export interface EnvironmentConfigRequests {
  myApprovals: EnvironmentConfigRequestsMyApprovals;
  myRequests: EnvironmentConfigRequestsMyRequests;
  advancedFilter: EnvironmentConfigRequestsAdvancedFilter;
}

export interface EnvironmentConfigRequestsMyApprovals {}

export interface EnvironmentConfigRequestsMyRequests {}

export interface EnvironmentConfigRequestsAdvancedFilter {
  validation: EnvironmentConfigRequestsAdvancedFilterValidation;
  rollBack: boolean;
  reset: boolean;
}

export interface EnvironmentConfigRequestsAdvancedFilterValidation {
  global: boolean;
  partial: boolean;
}

export interface EnvironmentConfigDashboardWidgets {
  faq: any;
  notifications: any;
  requests: any;
}

export interface EnvironmentConfigDashboardWorkflow {
  genericIncident: EnvironmentConfigDashboardWorkflowGenericIncident;
}

export interface EnvironmentConfigDashboardWorkflowGenericIncident {
  name: string;
  formId: string;
}

export interface EnvironmentAccess {
  map: EnvironmentAccessMap;
  mapEqual: string;
  lockApp: EnvironmentAccessLockApp;
  redirect?: EnvironmentAccessRedirect;
}

export interface EnvironmentAccessMap {
  default: string;
  internet: string;
  intranet: string;
}

export interface EnvironmentAccessLockApp {
  enable: boolean;
  dateBegin: string | number;
  dateEnd: string | number;
}

export interface EnvironmentAccessRedirect {
  partner: EnvironmentAccessRedirectPartner;
}

export interface EnvironmentAccessRedirectPartner {
  enable: boolean;
  url: string;
}

@Injectable({
  providedIn: 'root',
})
export class EnvironmentService {
  private readonly _access: EnvironmentAccess;
  private readonly _api: EnvironmentApi;
  private readonly _backOffice: EnvironmentBackOffice;
  private readonly _config: EnvironmentConfig;
  private readonly _environment: Environment;
  private readonly _iframe: EnvironmentIframe;
  private readonly _integration: boolean;
  private readonly _options: EnvironmentOptions;
  private readonly _production: boolean;

  constructor() {
    this._environment = environment;
    this._access = this.environment.access;
    this._api = this.environment.api;
    this._backOffice = this.environment.backOffice;
    this._config = this.environment.config;
    this._iframe = this.environment.iframe;
    this._integration = this.environment.integration;
    this._options = this.environment.options;
    this._production = this.environment.production;
  }

  public accessEnvironment(params?: Params): string {
    if (!this.production && params?.access) {
      return params.access;
    } else {
      return this.getAccessEnvironmentId();
    }
  }

  get api(): EnvironmentApi {
    return this._api;
  }

  get backOffice(): EnvironmentBackOffice {
    return this._backOffice;
  }

  get environment(): Environment {
    return this._environment;
  }

  get options(): EnvironmentOptions {
    return this._options;
  }

  get production(): boolean {
    return this._production;
  }

  get iframe(): EnvironmentIframe {
    return this._iframe;
  }

  get config(): EnvironmentConfig {
    return this._config;
  }

  get access(): EnvironmentAccess {
    return this._access;
  }

  get integration(): boolean {
    return this._integration;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private
  // -----------------------------------------------------------------------------------------------------

  private getAccessEnvironmentId(): string {
    for (const key in this.access.map) {
      const value = this.access.map[key];
      if (
        key.toString().trim() === window.location[this.access.mapEqual].trim()
      ) {
        return value;
      }
    }
    return this.access.map.default;
  }
}
