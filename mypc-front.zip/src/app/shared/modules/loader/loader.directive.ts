import { Directive, Renderer2, ElementRef, Input } from '@angular/core';
import { LoaderService, LoaderState } from './loader.service';

@Directive({
  selector: '[loader]',
})
export class LoaderDirective {
  @Input() loader: string;

  readonly className: string;

  constructor(private renderer: Renderer2, private elementRef: ElementRef, private loaderService: LoaderService) {
    this.className = 'loader';

    this.loaderService.onLoading.subscribe((state: LoaderState) => {
      state.show ? this.addClass() : this.removeClass();
    });
  }

  addClass(): void {
    this.renderer.addClass(this.elementRef.nativeElement, this.className);
  }

  removeClass(): void {
    this.renderer.removeClass(this.elementRef.nativeElement, this.className);
  }
}
