import { Component } from '@angular/core';
import { Subject } from 'rxjs';

import { LoaderService, LoaderState } from './../loader.service';

@Component({
  selector: 'loader-overlay',
  templateUrl: './overlay.component.html',
  styleUrls: ['./overlay.component.scss'],
})
export class LoaderOverlayComponent {
  color = 'primary';
  mode = 'indeterminate';
  value = 50;
  isLoading: Subject<LoaderState>;

  constructor(private loaderService: LoaderService) {
    setTimeout(() => {
      this.isLoading = this.loaderService.onLoading;
    });
  }
}
