import { Component, Input, ViewEncapsulation } from '@angular/core';
import { NavigationItem } from '@shared/models/navigation';

@Component({
  selector: 'sfr-navigation-icon',
  templateUrl: './navigation-icon.component.html',
  styleUrls: ['./navigation-icon.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { class: 'sfr-navigation-icon' },
})
export class NavigationIconComponent {
  @Input() sfrColor: string;
  @Input() sfrData: NavigationItem;
  @Input() sfrClass: string;
  constructor() {
    this.sfrColor = '';
    this.sfrData = null;
    this.sfrClass = '';
  }
}
