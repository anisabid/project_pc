import { Injectable } from '@angular/core';
import { ApiService } from '@shared/services/api/v2/api.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { BehaviorSubject, Subject } from 'rxjs';
import { SidebarConfigModel } from './sidebar.model';

@Injectable({
  providedIn: 'root',
})
export class SidebarService {
  private _sidebarConfig: SidebarConfigModel;
  private _localStorageSideBarId: string;
  public onSidebarToggleChanged: BehaviorSubject<any>;
  public onItemClick: Subject<string>;

  constructor(private environmentService: EnvironmentService, private apiService: ApiService) {
    this.onItemClick = new Subject();
    this._localStorageSideBarId = this.environmentService.options.localStorage.sidebar;
    !localStorage.getItem(this._localStorageSideBarId) ? this.setLocalStorage(new SidebarConfigModel()) : this.getLocalStorage();
    this.onSidebarToggleChanged = new BehaviorSubject(this._sidebarConfig.toggle);
  }

  public getLocalStorage(): SidebarConfigModel {
    this._sidebarConfig = new SidebarConfigModel(JSON.parse(localStorage.getItem(this._localStorageSideBarId)));
    return this._sidebarConfig;
  }

  public setLocalStorage(val?: SidebarConfigModel) {
    if (val) {
      localStorage.setItem(this._localStorageSideBarId, JSON.stringify(val));
      this.getLocalStorage();
    }
  }

  public getAvatar(uPerId: string): Promise<string> {
    return new Promise((resolve, reject) => {
      this.apiService.users.getAvatar({ uPerId: uPerId }).subscribe((result: { avatar: string }) => {
        resolve(result.avatar);
      }, reject);
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Set methods
  // -----------------------------------------------------------------------------------------------------
  set toggle(val: boolean) {
    if (this._sidebarConfig.toggle !== val) {
      this._sidebarConfig.toggle = val;
      this.setLocalStorage(this._sidebarConfig);
      this.onSidebarToggleChanged.next(this._sidebarConfig.toggle);
    }
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Get methods
  // -----------------------------------------------------------------------------------------------------
  get toggle(): boolean {
    return this._sidebarConfig.toggle;
  }

  get sidebarConfig(): SidebarConfigModel {
    return this._sidebarConfig;
  }
}
