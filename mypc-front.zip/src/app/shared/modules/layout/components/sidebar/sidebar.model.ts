export class SidebarConfigModel {
  toggle: boolean;

  constructor(val?: any) {
    this.toggle = !val ? true : val.toggle;
  }
}
