import { CommonModule } from '@angular/common';
import { ContentModule } from './components/content/content.module';
import { DefaultLayoutComponent } from './components/templates/default/default-layout.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SidebarModule } from './components/sidebar/sidebar.module';
import { TranslateModule } from '@ngx-translate/core';
import { UiLayoutComponent } from './components/templates/ui/ui-layout.component';
import { NavigationIconModule } from './components/navigation-icon/navigation-icon.module';

@NgModule({
  declarations: [DefaultLayoutComponent, UiLayoutComponent],
  imports: [RouterModule, CommonModule, ContentModule, SidebarModule, TranslateModule, FlexLayoutModule, NavigationIconModule],
  exports: [DefaultLayoutComponent, UiLayoutComponent, TranslateModule, NavigationIconModule],
})
export class LayoutModule {}
