import {
  Directive,
  ElementRef,
  Input,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import { SessionService } from '@shared/services/session/session.service';

@Directive({
  selector: '[toggleMedia]',
})
export class ToggleMediaDirective {
  constructor(
    private element: ElementRef,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private sessionService: SessionService
  ) {}

  @Input()
  set toggleMedia(val: boolean) {
    if (val !== undefined) {
      if (val) {
        this.updateView(this.sessionService.session.user.isMedia);
      } else {
        this.updateView(!this.sessionService.session.user.isMedia);
      }
    } else {
      this.updateView(true);
    }
  }

  private updateView(display: boolean) {
    if (display) {
      this.displayView();
    } else {
      this.hideView();
    }
  }

  private hideView() {
    this.viewContainer.clear();
  }

  private displayView() {
    this.viewContainer.createEmbeddedView(this.templateRef);
  }
}
