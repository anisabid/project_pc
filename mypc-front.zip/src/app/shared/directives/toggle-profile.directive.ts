import {
  Directive,
  ElementRef,
  Input,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import { SessionService } from '@shared/services/session/session.service';
import { NavigationItem } from '../models/navigation';
/**
 * @description 
 * <ng-container
      *toggleProfile="{
        media: item.accessMedia,
        partner: item.accessPartner
      }"
    >...</ng-container>
 */

interface toggleProfileValue {
  media: boolean;
  partner: boolean;
  item?: NavigationItem;
}

@Directive({
  selector: '[toggleProfile]',
})
export class ToggleProfileDirective {
  constructor(
    private element: ElementRef,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private sessionService: SessionService
  ) {}

  @Input()
  set toggleProfile(val: toggleProfileValue) {
    if (!this.isUndefinedValue(val)) {
      this.updateView(
        (val.media === undefined
          ? true
          : val.media === false
          ? !this.sessionService.session.user.isMedia
          : this.sessionService.session.user.isMedia) &&
          (val.partner === undefined
            ? true
            : val.partner === false
            ? !this.sessionService.session.user.isPartner
            : this.sessionService.session.user.isPartner)
      );
    } else {
      this.updateView(true);
    }
  }

  private updateView(display: boolean) {
    if (display) {
      this.displayView();
    } else {
      this.hideView();
    }
  }

  private hideView() {
    this.viewContainer.clear();
  }

  private displayView() {
    this.viewContainer.createEmbeddedView(this.templateRef);
  }

  private isUndefinedValue(val: toggleProfileValue): boolean {
    return (
      val == undefined || (val.media == undefined && val.partner == undefined)
    );
  }
}
