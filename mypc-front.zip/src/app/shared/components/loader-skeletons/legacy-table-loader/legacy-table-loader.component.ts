import { Component, Input, OnInit } from '@angular/core';
import { ArrayTitle } from '@app/shared/models/array-title.model';

@Component({
  selector: 'sfr-legacy-table-loader',
  templateUrl: './legacy-table-loader.component.html',
  styleUrls: ['./legacy-table-loader.component.scss'],
})
export class LegacyTableLoaderComponent implements OnInit {
  @Input() arraySize: number;
  @Input() titles: ArrayTitle[];
  @Input() scrollable = false;
  chips = false;

  tableSkeleton: null[];
  actions: null[];

  constructor() {}

  ngOnInit() {
    this.tableSkeleton = Array(this.arraySize).fill(null);
    const actionsCount = this.titles.find(
      (title: ArrayTitle) => title.column === 'actions'
    )?.count;
    this.actions = Array(actionsCount ? actionsCount : 2).fill(null);
  }
}
