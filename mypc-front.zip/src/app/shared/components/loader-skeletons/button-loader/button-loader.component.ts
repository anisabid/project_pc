import { Component, Input } from '@angular/core';

@Component({
  selector: 'sfr-button-loader',
  templateUrl: './button-loader.component.html',
})
export class ButtonLoaderComponent {
  @Input()
  width = 134;
  @Input()
  height = 43;

  get getWidth(): string {
    return `${this.width}px`;
  }
  get getHeight(): string {
    return `${this.height}px`;
  }
}
