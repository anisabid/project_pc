import { Component, Input, OnInit } from '@angular/core';

import { MatLegacyTableDataSource as MatTableDataSource } from '@angular/material/legacy-table';
import { ArrayTitle } from '@app/shared/models/array-title.model';

@Component({
  selector: 'sfr-table-loader',
  templateUrl: './table-loader.component.html',
  styleUrls: ['./table-loader.component.scss'],
})
export class TableLoaderComponent implements OnInit {
  @Input() arraySize: number;
  @Input() titles: ArrayTitle[];
  @Input() displayedColumns: string[];
  @Input() scrollable = false;

  tableSkeleton: null[];
  actions: null[];
  public dataSkeleton: MatTableDataSource<object>;

  constructor() {}

  ngOnInit() {
    this.tableSkeleton = Array(this.arraySize).fill(null);
    this.dataSkeleton = new MatTableDataSource(this.tableSkeleton);
    const actionsCount = this.titles.find(
      (title: ArrayTitle) => title.column === 'actions'
    )?.count;
    this.actions = Array(actionsCount ? actionsCount : 2).fill(null);
  }
}
