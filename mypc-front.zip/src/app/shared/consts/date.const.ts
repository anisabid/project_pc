import { MatDateFormats } from '@angular/material/core';

export const ConstDateFormatFr: MatDateFormats = {
  parse: {
    dateInput: 'dd/MM/YYYY',
  },
  display: {
    dateInput: 'dd/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'dd/MM/YYYY',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export const ConstDateFormatBack = 'dd/MM/YYYY HH:mm';
export const ConstDateFormatFront = 'dd/MM/YYYY HH:mm';
export const ConstDateFormatLocaleId = 'fr-FR';
