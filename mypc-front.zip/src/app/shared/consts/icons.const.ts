import {Icons} from "@shared/models/icons";

/**
 *  Icons
 *  todo add icons
 */
export interface icons {
    BULLHORN: string;
    CALENDAR: string;
    CHECK: string;
    BELL: string;
    CHECK_SQUARE: string;
    COGS: string;
    COMMENTS: string;
    EXCLAMATION: string;
    FILE: string;
    FILE_TEXT: string;
    FORWARD: string;
    GROUP: string;
    HOURGLASS: string;
    INBOX: string;
    IFE_RING: string;
    PAUSE: string;
    PLAY_CIRCLE: string;
    SQUARE: string;
    REFRESH: string;
    THUMBS_UP: string;
    TIMES: string;
    TIMES_CIRCLE: string;
    BAN: string;
    Archive: string;
}

/**
 * ConstIcons Const
 */

export const ConstIcons = {
    TIMES: new Icons({
        code: 'fa fa-times',
        translate: 'i18n.icon.time',
    }),

    BAN: new Icons({
        code: 'fa fa-ban',
        translate: 'i18n.icon.ban',
    }),

    COMMENTS: new Icons({
        code: 'fa fa-comments-o',
        translate: 'i18n.icon.comment',

    }),
    THUMBS_UP: new Icons({
        code: 'fa fa-thumbs-o-up',
        translate: 'i18n.icon.thumbs',

    }),

    INBOX: new Icons({
        code: 'fa fa-inbox',
        translate: 'i18n.icon.inbox',

    }),

    ARCHIVE: new Icons({
        code: 'fa fa-archive',
        translate: 'i18n.icon.archive',

    }),

    CALENDAR: new Icons({
        code: "fa fa-calendar",
        translate: 'i18n.icon.calendar',

    }),

    CHECK_SQUARE: new Icons({
        code: 'fa fa-check-square-o',
        translate: 'i18n.icon.check_square',

    }),
    FILE: new Icons({
        code: 'fa fa-file-o',
        translate: 'i18n.icon.file',

    })

};
