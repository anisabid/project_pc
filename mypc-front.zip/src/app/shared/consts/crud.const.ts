export interface CRUD {
  CREATE: string;
  READ: string;
  UPDATE: string;
  DELETE: string;
}

export enum EnumCRUD {
  CREATE = 'create',
  READ = 'read',
  UPDATE = 'update',
  DELETE = 'delete',
}

export const ConstCRUD: CRUD = {
  CREATE: EnumCRUD.CREATE,
  READ: EnumCRUD.READ,
  UPDATE: EnumCRUD.UPDATE,
  DELETE: EnumCRUD.DELETE,
};
