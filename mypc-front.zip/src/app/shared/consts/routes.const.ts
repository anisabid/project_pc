interface SecureRoutesPath {
  PATH: string;
  AUTOLOGIN: string;
  LOGIN: string;
  LOGOUT: string;
}

interface DashboardRoutesPath {
  PATH: string;
  HOME: ConfigRoutePath;
  OFFICE_SECURITY: ConfigRoutePath;
}

interface ExtraRoutesPath {
  SOON: ConfigRoutePath;
}

interface ConfigRoutePath {
  PATH: string;
  ROUTE?: string;
}

interface RoutesPath {
  ADMINISTRATION: string;
  APPLICATIONS: string;
  AUTOLOGIN: string;
  DASHBOARD: DashboardRoutesPath;
  DEFAULT: string;
  DELEGATIONS: string;
  EXTRA: ExtraRoutesPath;
  LOGIN: string;
  LOGOUT: string;
  PORTAL: string;
  PROFILE: string;
  REQUESTS: string;
  SECURE: SecureRoutesPath;
}

export const ConstRoutesPath: RoutesPath = {
  ADMINISTRATION: 'administration',
  APPLICATIONS: 'applications',
  AUTOLOGIN: 'secure/autologin',
  DASHBOARD: {
    PATH: 'dashboard',
    HOME: {
      PATH: 'home',
      ROUTE: 'dashboard/home',
    },
    OFFICE_SECURITY: {
      PATH: 'office-security',
      ROUTE: 'dashboard/office-security',
    },
  },
  DEFAULT: 'dashboard/home',
  DELEGATIONS: 'delegations',
  EXTRA: {
    SOON: {
      PATH: 'soon',
      ROUTE: 'soon',
    },
  },
  LOGIN: 'secure/login',
  LOGOUT: 'secure/logout',
  PORTAL: 'portal',
  PROFILE: 'profile',
  REQUESTS: 'requests',
  SECURE: {
    PATH: 'secure',
    AUTOLOGIN: 'autologin',
    LOGIN: 'login',
    LOGOUT: 'logout',
  },
};
