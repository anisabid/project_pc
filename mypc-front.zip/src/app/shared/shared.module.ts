import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatLegacyAutocompleteModule as MatAutocompleteModule } from '@angular/material/legacy-autocomplete';
import { MatNativeDateModule } from '@angular/material/core';
import { MatLegacyOptionModule as MatOptionModule } from '@angular/material/legacy-core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatIconModule } from '@angular/material/icon';
import { MatLegacySelectModule as MatSelectModule } from '@angular/material/legacy-select';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { ButtonLoaderComponent } from './components/loader-skeletons/button-loader/button-loader.component';
import { ChipsLoaderComponent } from './components/loader-skeletons/chips-loader/chips-loader.component';
import { LegacyTableLoaderComponent } from './components/loader-skeletons/legacy-table-loader/legacy-table-loader.component';
import { LoaderSkeletonComponent } from './components/loader-skeletons/loader-skeleton/loader-skeleton.component';
import { TableLoaderComponent } from './components/loader-skeletons/table-loader/table-loader.component';
import { TextLoaderComponent } from './components/loader-skeletons/text-loader/text-loader.component';
import { PageComponent } from './components/page/page.component';
import { SnackBarComponent } from './components/snack-bar/snack-bar.component';
import { SoonComponent } from './components/soon/soon.component';
import { DirectivesModule } from './directives/directives.module';
import { LayoutModule } from './modules/layout/layout.module';
import { LoaderModule } from './modules/loader/loader.module';
import { MaterialModule } from './modules/material/material.module';
import { SnackBarMessageModule } from './modules/snack-bar-message/snack-bar-message.module';
import { PipesModule } from './pipes/pipes.module';

@NgModule({
  declarations: [
    ConfirmDialogComponent,
    PageComponent,
    SnackBarComponent,
    SoonComponent,
    LoaderSkeletonComponent,
    ButtonLoaderComponent,
    ChipsLoaderComponent,
    TableLoaderComponent,
    TextLoaderComponent,
    LegacyTableLoaderComponent,
  ],
  imports: [
    CommonModule,
    DirectivesModule,
    FlexLayoutModule,
    FormsModule,
    LayoutModule,
    LoaderModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MaterialModule,
    MatIconModule,
    MatNativeDateModule,
    MatOptionModule,
    MatSelectModule,
    PerfectScrollbarModule,
    PipesModule,
    ReactiveFormsModule,
    RouterModule,
    SnackBarMessageModule,
    TranslateModule,
  ],
  exports: [
    ConfirmDialogComponent,
    DirectivesModule,
    FlexLayoutModule,
    LayoutModule,
    LoaderModule,
    MaterialModule,
    PageComponent,
    PerfectScrollbarModule,
    PipesModule,
    SnackBarMessageModule,
    SoonComponent,
    TranslateModule,
    LoaderSkeletonComponent,
    ButtonLoaderComponent,
    ChipsLoaderComponent,
    TableLoaderComponent,
    TextLoaderComponent,
    LegacyTableLoaderComponent,
  ],
  providers: [DatePipe],
})
export class SharedModule {}
