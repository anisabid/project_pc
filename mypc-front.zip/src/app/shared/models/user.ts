import { ConstUserProfile } from '../consts/user-profiles.const';

class SessionUniverse {
  id: string;
  label: string;

  constructor(data?: any) {
    this.id = !data ? null : data.universe_id;
    this.label = !data ? null : data.universe_label;
  }
}

class SessionAccess {
  read: Array<string>;
  write: Array<string>;

  constructor(data?: any) {
    this.read = !data
      ? null
      : data?.limited_acces?.map((element: string) => {
          return element.trim().toUpperCase();
        });
    this.write = !data
      ? null
      : data?.limited_acces_w?.map((element: string) => {
          return element.trim().toUpperCase();
        });
  }

  public hasAccessTo(data?: string | Array<string>, all?: boolean): boolean {
    let hasAccess: boolean = true;
    let accessAll = all === undefined ? true : all;

    if (data) {
      if (Array.isArray(data)) {
        if (accessAll) {
          data.forEach((element) => {
            if (this.read.indexOf(element.trim().toUpperCase()) === -1) {
              hasAccess = false;
            }
          });
        } else {
          hasAccess = this.hasMinimumAccessTo(data);
        }
      } else {
        hasAccess = this.read.indexOf(data.trim().toUpperCase()) !== -1;
      }
    }
    return hasAccess;
  }

  // Check if the user has at least one permission among the permissions
  public hasMinimumAccessTo(data?: Array<string>): boolean {
    let hasAccess: boolean = false;
    if (data) {
      hasAccess = data.some((element) =>
        this.read.includes(element.trim().toUpperCase())
      );
    }
    return hasAccess;
  }
}

export class User {
  email: string;
  firstName: string;
  fullName: string;
  groups: Map<string, string>;
  id: string;
  lastName: string;
  location: string;
  perId: string;
  uPerId: string;
  isMedia: boolean;
  isPartner: boolean;
  isDefault: boolean;
  profile: string;

  constructor(data?: any) {
    this.email = !data ? null : data.user_email;
    this.firstName = !data ? null : data.user_firstname;
    this.fullName = !data ? null : data.user_displayname;
    this.groups = !data ? null : this.mapGroup(data?.user_group);
    this.id = !data ? null : data.user_id;
    this.lastName = !data ? null : data.user_lastname;
    this.location = !data ? null : data.user_loc;
    this.perId = !data ? null : data.user_perid;
    this.uPerId = !data ? null : data.user_uperid;
    this.isMedia = !data
      ? false
      : parseInt(data.USER_MEDIA) === 0
      ? false
      : true;
    this.isPartner = !data
      ? false
      : parseInt(data.PS_P_USER_PARTEN) === 0
      ? false
      : true;
    this.isDefault = !data
      ? true
      : parseInt(data.PS_P_USER_PARTEN) === 0 && parseInt(data.USER_MEDIA) === 0
      ? true
      : false;

    this.profile = this.getProfile();
  }

  private getProfile(): string {
    if (this.isMedia) {
      return ConstUserProfile.MEDIA;
    }
    if (this.isPartner) {
      return ConstUserProfile.PARTNER;
    }
    return ConstUserProfile.DEFAULT;
  }

  private mapGroup?(data?): Map<string, string> {
    let map = new Map<string, string>();
    if (data) {
      data = JSON.parse(data);
      for (var value in data) {
        map.set(value, data[value]);
      }
    }
    return map;
  }
}

export class Session {
  access: SessionAccess;
  id: string;
  universe: SessionUniverse;
  user: User;

  constructor(data?: any) {
    this.access = !data ? null : new SessionAccess(data.session);
    this.id = !data ? null : data.session_id;
    this.universe = !data ? null : new SessionUniverse(data.session);
    this.user = !data ? null : new User(data.session);
  }
}

export class UserSearch {
  aui: string;
  id: string;
  name: string;
  uperid: string;

  constructor(data?: any) {
    this.aui = !data ? null : data.user_aui;
    this.id = !data ? null : data.user_id;
    this.name = !data ? null : data.user_name;
    this.uperid = !data ? null : data.user_uperid;
  }
}

/**
 * User Search Result
 */
export interface UserSearchResult {
  users: UserSearchList;
}

/**
 * User Search List
 */
export interface UserSearchList {
  data: UserSearch[];
  limit: number;
  offset: number;
  total: number;
  totalPage: number;
}

export class LoginForm {
  userName: string;
  password: string;

  constructor(data?: any) {
    this.userName = !data ? null : data.userName;
    this.password = !data ? null : data.password;
  }
}
