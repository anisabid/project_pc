export class ActionEvent {
  key: string;
  value: any;
  component?: string;

  constructor(data?: any) {
    this.key = !data ? null : data.key.toLowerCase();
    this.value = !data ? null : data.value;
    this.component = !data ? null : data.component.toLowerCase();
  }
}
