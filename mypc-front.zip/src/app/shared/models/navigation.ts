import { EnumNavigationItemType } from '../consts/navigation.const';
import { EnumUrlTarget } from '../consts/url-target.const';

export class NavigationItemUrlConfig {
  haveJwt?: boolean;
  haveOriginRecast?: boolean;
  haveUrlPrefixToBackOffice?: boolean;
  isFrame?: boolean;
  hash?: string;

  constructor(data: Object = {}) {
    let obj = {
      haveJwt: true,
      haveOriginRecast: true,
      haveUrlPrefixToBackOffice: true,
      isFrame: true,
      hash: null,
    };
    Object.assign(obj, data);
    this.haveJwt = obj.haveJwt;
    this.haveOriginRecast = obj.haveOriginRecast;
    this.haveUrlPrefixToBackOffice = obj.haveUrlPrefixToBackOffice;
    this.isFrame = obj.isFrame;
    this.hash = obj.hash;
  }
}

export class NavigationItem {
  id: string;
  type: EnumNavigationItemType;
  title?: string;
  translate?: string;
  iconName?: string;
  iconClass?: string;
  hidden?: boolean;
  custom?: boolean;
  url?: string;
  url_target?: EnumUrlTarget;
  url_parameters?: any;
  url_config?: NavigationItemUrlConfig;
  classes?: string;
  exactMatch?: boolean;
  externalUrl?: boolean;
  openInNewTab?: boolean;
  function?: any;
  expand?: boolean;
  status?: boolean;
  edit?: boolean;
  deleted?: boolean;
  badge?: {
    title?: string;
    translate?: string;
    bg?: string;
    fg?: string;
  };
  children?: Array<NavigationItem>;
  access?: string | Array<string>;
  accessAllGranted?: boolean;
  ngIf?: string;
  accessMedia?: boolean;
  accessPartner?: boolean;
}

export class NavigationItems {
  profile?: NavigationItem;
  profileMenu?: Array<NavigationItem>;
  menu: Array<NavigationItem>;
  footer?: {
    header?: {
      translate?: string;
    };
    menu?: Array<NavigationItem>;
  };
}
