import { EnumUrlTarget } from '@shared/consts/url-target.const';

/**
 * Bus Iframe Data
 */
export class BusIframe {
  actions: Array<string>;
  uri: BusIframeUri;

  constructor(data: any) {
    this.actions = !data || !data.actions ? [] : data.actions;
    this.uri = !data ? null : new BusIframeUri(data.uri);
  }

  public hasAction(action: string): boolean {
    return this.actions.indexOf(action) !== -1;
  }
}

class BusIframeUri {
  redirect: string;
  target: string;

  constructor(data: any) {
    this.redirect = !data || !data.redirect ? null : data.redirect;
    this.target = !data || !data.target ? EnumUrlTarget.SELF : data.target;
  }
}
