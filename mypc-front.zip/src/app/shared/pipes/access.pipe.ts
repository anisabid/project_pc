import { Pipe, PipeTransform } from '@angular/core';
import { SessionService } from '@shared/services/session/session.service';

/**
 * Access Pipe is a structural pipe allow displaying content based on the value of
 * an expression coerced to boolean come from 'SessionService' service from method
 * hasAccessTo 'SessionService.session.access.hasAccessTo'
 *
 * Simple use case with shorthand syntax:
 *
 * ```
 * <div *ngIf="[lisOfAccess] | access">Content to render when condition is true.</div>
 * ```
 *
 * Simple use case with possession argument:
 *
 * ```
 * <div *ngIf="[lisOfAccess] | access : 'has'">Content to render when condition is true.</div>
 * ```
 *
 * By default we check if listOfAccess has access but if you want to test the
 * opposite case i.e. notHaveAccess use argument possession equal to `not-have`
 *
 * ```
 * <div *ngIf="[lisOfAccess] | access : 'not-have'">Content to render when condition is true.</div>
 * ```
 *
 */

@Pipe({
  name: 'hasAccess',
})
export class AccessPipe implements PipeTransform {
  constructor(private sessionService: SessionService) {}
  /**
   * Transform
   *
   * @param value
   * @param {any} possession 'has' | 'not-have'
   * @returns {any}
   */
  transform(
    value: string | Array<string>,
    possession: string = 'has',
    requiredAll: boolean = true
  ): boolean {
    if (value) {
      if (possession.toUpperCase() === 'not-have') {
        return !this.sessionService.session.access.hasAccessTo(
          value,
          requiredAll
        );
      }
      return this.sessionService.session.access.hasAccessTo(value, requiredAll);
    }
  }
}
