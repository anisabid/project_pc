import { Pipe, PipeTransform } from '@angular/core';
import { StringHelperService } from '../services/helper/string-helper.service';

@Pipe({
  name: 'acronym',
})
export class AcronymPipe implements PipeTransform {
  constructor(private stringHelperService: StringHelperService) {}
  /**
   * Transform
   *
   * @param value
   * @param {string[]} args
   * @returns {any}
   */
  transform(value: any, type: string = '*', ignoreAccent: boolean = false): any {
    let acronym: string = '';
    switch (type.toUpperCase()) {
      case 'USER':
        acronym = value ? value.match(/\b(?!EXT)\b(\w)/g).join('') : '';
        break;
      default:
        acronym = value
          ? ignoreAccent
            ? this.stringHelperService
                .clearAccents(value)
                .match(/\b(\w)/g)
                .join('')
            : value.match(/\b(\w)/g).join('')
          : '';
    }

    return acronym.toUpperCase();
  }
}
