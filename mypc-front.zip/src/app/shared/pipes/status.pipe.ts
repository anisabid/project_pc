import { Pipe, PipeTransform } from '@angular/core';
import { ConstStatutes } from '@shared/consts/statutes.const';
import { Status } from '@shared/models/status';

@Pipe({
  name: 'status',
})
export class StatusPipe implements PipeTransform {
  private status: Status;
  private response: any;

  /**
   * Transform
   *
   * @param value
   * @param {string} desc
   * @returns {any}
   */
  transform(value: string, desc: string): any {
    if (value) {
      switch (value.toUpperCase()) {
        case ConstStatutes.DRAFT.code.toUpperCase():
          this.status = ConstStatutes.DRAFT;
          break;
        case ConstStatutes.WAITING_MANAGER_APPROVAL_N1.code.toUpperCase():
          this.status = ConstStatutes.WAITING_MANAGER_APPROVAL_N1;
          break;
        case ConstStatutes.WAITING_MANAGER_APPROVAL_N2.code.toUpperCase():
          this.status = ConstStatutes.WAITING_MANAGER_APPROVAL_N2;
          break;
        case ConstStatutes.WAITING_FUNCTIONNAL_APPROVAL_N1.code.toUpperCase():
          this.status = ConstStatutes.WAITING_FUNCTIONNAL_APPROVAL_N1;
          break;
        case ConstStatutes.REJECTED.code.toUpperCase():
          this.status = ConstStatutes.REJECTED;
          break;
        case ConstStatutes.FINISHED.code.toUpperCase():
          this.status = ConstStatutes.FINISHED;
          break;
        case ConstStatutes.IN_PROGRESS.code.toUpperCase():
          this.status = ConstStatutes.IN_PROGRESS;
          break;
        case ConstStatutes.WAITING.code.toUpperCase():
          this.status = ConstStatutes.WAITING;
          break;
        case ConstStatutes.A_TRAITER.code.toUpperCase():
          this.status = ConstStatutes.A_TRAITER;
          break;
        case ConstStatutes.RELAUNCH.code.toUpperCase():
          this.status = ConstStatutes.RELAUNCH;
          break;
        case ConstStatutes.FROZEN.code.toUpperCase():
          this.status = ConstStatutes.FROZEN;
          break;
        case ConstStatutes.CLAIMED.code.toUpperCase():
          this.status = ConstStatutes.CLAIMED;
          break;
        case ConstStatutes.PLANNED.code.toUpperCase():
          this.status = ConstStatutes.PLANNED;
          break;
        case ConstStatutes.CANCELED.code.toUpperCase():
          this.status = ConstStatutes.CANCELED;
          break;
        case ConstStatutes.DONE.code.toUpperCase():
          this.status = ConstStatutes.DONE;
          break;
        case ConstStatutes.ESCALATION.code.toUpperCase():
          this.status = ConstStatutes.ESCALATION;
          break;
        default:
          this.status = new Status();
      }

      switch (desc.toLowerCase()) {
        case 'background':
          this.response = this.status.background;
          break;
        case 'code':
          this.response = this.status.code;
          break;
        case 'color':
          this.response = this.status.color;
          break;
        case 'icon':
          this.response = this.status.icon;
          break;
        case 'label':
          this.response = this.status.label;
          break;
        case 'name':
          this.response = this.status.name;
          break;
        case 'text_color':
          this.response = this.status.text_color;
          break;
        case 'translate':
          this.response = this.status.translate;
          break;
        default:
          this.response = this.status.color;
      }
      return this.response;
    }
    return null;
  }
}
