import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { locale as localFrench } from '@app/i18n/fr';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { Subscription } from 'rxjs';
import {
  LoaderService,
  LoaderState,
} from '@shared/modules/loader/loader.service';
import { LocalStorageService } from '@shared/services/localstorage/localstorage.service';
import { AppUpdateService } from './core/services/app-update.service';
@Component({
  selector: 'sfr-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  show: boolean = false;
  private subscription: Subscription = new Subscription();
  constructor(
    private translateService: TranslateService,
    private translationLoaderService: TranslationLoaderService,
    private loaderService: LoaderService,
    private localStorageService: LocalStorageService,
    private appUpdateService: AppUpdateService
  ) {
    this.localStorageService.check();
    this.appUpdateService.checkUpdate();

    // Add languages
    this.translateService.addLangs(['en', 'fr']);

    // Set the default language
    this.translateService.setDefaultLang('fr');

    // Set the global translations
    this.translationLoaderService.loadTranslations(localFrench);

    // Use a language
    this.translateService.use('fr');
  }
  // tslint:disable-next-line:typedef
  ngOnInit() {
    this.subscription = this.loaderService.onLoading.subscribe(
      (state: LoaderState) => {
        this.show = state.show;
        // this.changeDetector.detectChanges();
      }
    );
  }
  // tslint:disable-next-line:typedef
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
