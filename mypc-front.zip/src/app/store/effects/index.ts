import { RouterEffects } from './router.effect';
/**
 * Effects Array
 */
export const effects: any[] = [RouterEffects];
/**
 * Effects Export
 */
export * from './router.effect';
