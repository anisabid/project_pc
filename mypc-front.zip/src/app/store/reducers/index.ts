import * as fromRouter from '@ngrx/router-store';

import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import { Params, RouterStateSnapshot } from '@angular/router';

/**
 * Router State Interface
 */
export interface RouterStateUrl {
  /**
   * URL
   */
  url: string;
  /**
   * Query Parameters
   */
  queryParams: Params;
  /**
   * Parameters
   */
  params: Params;
}

/**
 * State Interface
 */
export interface RouterState {
  /**
   * Router Reducer
   */
  router: fromRouter.RouterReducerState<RouterStateUrl>;
}

/**
 * Reducers List
 */
export const reducers: ActionReducerMap<RouterState> = {
  router: fromRouter.routerReducer,
};

/**
 * Router State Selector
 */
export const selectRouterState =
  createFeatureSelector<fromRouter.RouterReducerState<RouterStateUrl>>(
    'routerStore'
  );

/**
 * Router default Selectors
 */
export const {
  selectCurrentRoute, // select the current route
  selectQueryParams, // select the current route query params
  selectQueryParam, // factory function to select a query param
  selectRouteParams, // select the current route params
  selectRouteParam, // factory function to select a route param
  selectRouteData, // select the current route data
  selectUrl, // select the current url
} = fromRouter.getSelectors(selectRouterState);

/**
 * Custom Route Serializer
 */
export class CustomSerializer
  implements fromRouter.RouterStateSerializer<RouterStateUrl>
{
  /**
   * Serialize Function
   */

  serialize(routerState: RouterStateSnapshot): RouterStateUrl {
    let route = routerState.root;

    let params = {};
    while (route.firstChild) {
      params = {
        ...params,
        ...route.params,
      };
      route = route.firstChild;
    }

    const {
      url,
      root: { queryParams },
    } = routerState;

    return { url, params, queryParams };
  }
}
