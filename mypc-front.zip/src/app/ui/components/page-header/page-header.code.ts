export const CODE_HEADER = {
  C_01: `<div class="page-header">
  <div fxLayout="row" fxLayoutAlign="space-between center">
    <div class="page-header-left">
      <div fxLayout="row" fxLayoutAlign="start center">
        <div class="page-header-breadcrumb">
          <div class="item">Mon profil & ressources</div>
        </div>
      </div>
    </div>
    <div class="page-header-right"></div>
  </div>
</div>`,
  C_02: `<div class="page-header">
  <div fxLayout="row" fxLayoutAlign="space-between center">
    <div class="page-header-left">
      <div fxLayout="row" fxLayoutAlign="start center">
        <div class="page-header-breadcrumb">
          <div class="item">Mes Demandes</div>
        </div>
      </div>
    </div>
    <div class="page-header-right">
      <div fxLayout="row" fxLayoutAlign="end center">
        <div class="page-header-search" fxLayout="row" fxLayoutAlign="end stretch">
          <input class="form-control" fxFlex type="text" placeholder="Recherchez par, id, type de demande, date, etc.." />
          <div class="form-separator"></div>
          <button class="form-search" fxFlex="36px">
            <mat-icon color="primary">search</mat-icon>
          </button>
        </div>
        <button mat-button class="mat-button-border ml-12">
          <div fxLayout="row" fxLayoutAlign="space-around center">
            <mat-icon color="primary" class="pr-4">history</mat-icon>
            <span class="label">Historique</span>
          </div>
        </button>
        <button mat-stroked-button mat-flat-button class="mat-flat-button-border ml-12">
          <div fxLayout="row" fxLayoutAlign="space-around center">
            <mat-icon color="primary" class="pr-4">post_add</mat-icon>
            <span class="label">Faire une demande</span>
          </div>
        </button>
      </div>
    </div>
  </div>
</div>`,
  C_03: `<div class="page-header">
  <div fxLayout="row" fxLayoutAlign="space-between center">
    <div class="page-header-left">
      <div fxLayout="row" fxLayoutAlign="start center">
        <button mat-icon-button>
          <mat-icon>arrow_back</mat-icon>
        </button>

        <div class="page-header-breadcrumb">
          <div class="item">Mes boites aux lettres génériques</div>
        </div>
      </div>
    </div>
    <div class="page-header-right">
      <button
        mat-stroked-button
        mat-flat-button
        class="mat-flat-button-border"
      >
        <div fxLayout="row" fxLayoutAlign="space-around center">
          <mat-icon color="primary">note_add</mat-icon>
          <span class="label">Créer une boite aux lettres</span>
        </div>
      </button>
    </div>
  </div>
</div>`,
};
