import { Component, OnInit } from '@angular/core';
import { CODE_HEADER } from './page-header.code';

@Component({
  selector: 'sfr-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.scss'],
})
export class PageHeaderComponent implements OnInit {
  public CODE_HEADER = CODE_HEADER;
  constructor() {}

  ngOnInit(): void {}
}
