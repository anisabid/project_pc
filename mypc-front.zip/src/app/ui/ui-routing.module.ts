import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageHeaderComponent } from './components/page-header/page-header.component';

import { UiComponent } from './ui.component';

const routes: Routes = [
  { path: '', component: UiComponent },
  {
    path: 'page',
    children: [
      {
        path: 'header',
        component: PageHeaderComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UiRoutingModule {}
