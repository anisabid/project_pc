import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConstRoutesPathDelegations } from './delegation.model';
import { DelegationsComponent } from './delegations.component';
import { DelegationsService } from './delegations.service';

const routes: Routes = [
  {
    path: '',
    component: DelegationsComponent,
    children: [
      {
        path: ConstRoutesPathDelegations.I_GAVE,
        component: DelegationsComponent,
        resolve: {
          data: DelegationsService,
        },
      },
      {
        path: ConstRoutesPathDelegations.GIVEN_TO_ME,
        component: DelegationsComponent,
        resolve: {
          data: DelegationsService,
        },
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: ConstRoutesPathDelegations.DEFAULT,
      },
    ],
  },
  {
    path: ':idDelegate',
    component: DelegationsComponent,
    children: [
      {
        path: ConstRoutesPathDelegations.I_GAVE,
        component: DelegationsComponent,
        resolve: {
          data: DelegationsService,
        },
      },
      {
        path: ConstRoutesPathDelegations.GIVEN_TO_ME,
        component: DelegationsComponent,
        resolve: {
          data: DelegationsService,
        },
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: ConstRoutesPathDelegations.DEFAULT,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DelegationRoutingModule {}
