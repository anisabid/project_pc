import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RequestTitleService {
  public titleSubject = new Subject<string>();
  public statusCode = new Subject<string>();

  constructor() {}

  sendTitle(data) {
    this.titleSubject.next(data);
  }
  sendStatus(data) {
    this.statusCode.next(data);
  }
}
