interface RequestsRoutesPath {
  REQUESTS: string;
  APPROVALS: string;
  LIFECYCLE: string;
  ORIGIN_FORM: string;
}

interface RequestTypePath {
  HISTORY: string;
}

export enum EnumRequestsRoutesPath {
  REQUESTS = 'my-requests',
  APPROVALS = 'my-approvals',
  LIFECYCLE = 'cycle-life',
  ORIGIN_FORM = 'origin-form',
}

export enum EnumRequestTypePath {
  HISTORY = 'history',
}

export const ConstRequestsRoutesPath: RequestsRoutesPath = {
  REQUESTS: EnumRequestsRoutesPath.REQUESTS,
  APPROVALS: EnumRequestsRoutesPath.APPROVALS,
  LIFECYCLE: EnumRequestsRoutesPath.LIFECYCLE,
  ORIGIN_FORM: EnumRequestsRoutesPath.ORIGIN_FORM,
};

export const ConstRequestTypePath: RequestTypePath = {
  HISTORY: EnumRequestTypePath.HISTORY,
};
