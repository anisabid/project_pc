export class RequestParam {
  item_id: string;
  chg_nb?: string;
  form_id?: string;
  object_id?: number;
  object_nom?: string;
  type_item?: string;

  constructor(data?: any) {
    if (typeof data === 'string') {
      data = JSON.parse(data);
    }
    this.item_id = !data?.item_id ? null : data.item_id;
    this.chg_nb = !data?.chg_nb ? null : data.chg_nb;
    this.form_id = !data?.form_id ? null : data.form_id;
    this.object_id = !data?.object_id ? null : data.object_id;
    this.object_nom = !data?.object_nom ? null : data.object_nom;
    this.type_item = !data?.type_item ? null : data.type_item;
  }
}
