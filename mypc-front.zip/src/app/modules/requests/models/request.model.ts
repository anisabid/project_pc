import { RequestParam } from './request-param.model';

export class Request {
  benef_uperid: string;
  beneficiaire: string;
  bur_beneficiaire: string;
  change: Array<string>;
  changes: string;
  ctner1: string;
  ctner2: string;
  date_create: string;
  date_modif: string;
  date_prev: string;
  emet_uperid: string;
  emetteur: string;
  etat_status: string;
  grpEnChg: string;
  mail_beneficiaire: string;
  mob_beneficiaire: string;
  object: string;
  paramItem: RequestParam;
  req_id: string;
  resume: string;
  severite: string;
  site_beneficiaire: string;
  status_code: string;
  status: string;
  step_code: string;
  tel_beneficiaire: string;
  type: string;
  userEnChg: string;
  constructor(data?: any) {
    this.benef_uperid = !data?.benef_uperid ? null : data.benef_uperid;
    this.beneficiaire = !data?.beneficiaire ? null : data.beneficiaire;
    this.bur_beneficiaire = !data?.bur_beneficiaire
      ? null
      : data.bur_beneficiaire;
    this.change = !data?.change ? null : data.change;
    this.changes = !data?.changes ? null : data.Changes;
    this.ctner1 = !data?.ctner1 ? null : data.ctner1;
    this.ctner2 = !data?.ctner2 ? null : data.ctner2;
    this.date_create = !data?.date_create ? null : data.date_create;
    this.date_modif = !data?.date_modif ? null : data.date_modif;
    this.date_prev = !data?.date_prev ? null : data.date_prev;
    this.emet_uperid = !data?.emet_uperid ? null : data.emet_uperid;
    this.emetteur = !data?.emetteur ? null : data.emetteur;
    this.etat_status = !data?.etat_status ? null : data.etat_status;
    this.grpEnChg = !data?.grpEnChg ? null : data.grpEnChg;
    this.mail_beneficiaire = !data?.mail_beneficiaire
      ? null
      : data.mail_beneficiaire;
    this.mob_beneficiaire = !data?.mob_beneficiaire
      ? null
      : data.mob_beneficiaire;
    this.object = !data?.object ? null : data.object;
    this.paramItem = !data?.paramItem ? null : new RequestParam(data.paramItem);
    this.req_id = !data?.req_id ? null : data.req_id;
    this.resume = !data?.resume ? null : data.resume;
    this.severite = !data?.severite ? null : data.severite;
    this.site_beneficiaire = !data?.site_beneficiaire
      ? null
      : data.site_beneficiaire;
    this.status_code = !data?.status_code ? null : data.status_code;
    this.status = !data?.status ? null : data.status;
    this.step_code = !data?.step_code ? null : data.step_code;
    this.tel_beneficiaire = !data?.tel_beneficiaire
      ? null
      : data.tel_beneficiaire;
    this.type = !data?.type ? null : data.type;
    this.userEnChg = !data?.userEnChg ? null : data.userEnChg;
  }
}
