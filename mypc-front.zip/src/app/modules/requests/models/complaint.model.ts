/**
 * Complaint Model
 */
export class Complaint {
  wf_status: number;
  lmd: string;
  comment: string;
  tmotif: string;
  forceTransition: string;
  typeitem: number;

  constructor(
    wf_status: number,
    lmd: string,
    comment: string,
    tmotif: string,
    forceTransition: string,
    typeitem: number
  ) {
    this.wf_status = wf_status;
    this.lmd = lmd;
    this.comment = comment;
    this.tmotif = tmotif;
    this.forceTransition = forceTransition;
    this.typeitem = typeitem;
  }
}

/**
 * Complaint Response Model
 */
export interface ComplaintResponse {
  action: ComplaintResponseBody;
}

/**
 * Complaint Response Body Model
 */
export interface ComplaintResponseBody {
  chg_id: string;
  close_form: number;
  insert_histo: string;
  lmd: string;
  msg: string;
  success: string;
  updategroup: string;
}
