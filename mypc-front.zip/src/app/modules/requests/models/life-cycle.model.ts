/**
 * Life-cycle Model
 */
export interface LifeCycle {
  actions: LifeCycleActionItem[];
  changes: LifeCycleChange[];
  resume: LifeCycleSummary;
  status: LifeCycleStatus[];
}

/**
 * Life-cycle Action Item Model
 */
export interface LifeCycleActionItem {
  class_action: string;
  icon_action: string;
  id_action: string;
  libelle_btn: string;
  motif_data: any[];
  trans_comment: string;
  trans_comment_tech: string;
  trans_motif: string;
}

/**
 * Life-cycle Action Model
 */
export interface LifeCycleAction {
  vfile: any;
  user_comment: string;
  wf_status: number;
  lmd: string;
}

/**
 * Life-cycle Change Model
 */
export interface LifeCycleChange {
  change_id: string;
  change_lmd: number;
  change_num: string;
  comment: any[];
  date_prev: any;
  etat: string;
  form_id: string;
  object_id: number;
  object_nom: string;
  reclamation: boolean;
  req_num: string;
  resume: string;
  show_reclamation: boolean;
  sla_id: number;
  sla_libelle: string;
  status_code: string;
  trans: LifeCycleTrans[];
}

/**
 * Life-cycle Comment Model
 */
export interface LifeCycleComment {
  comment: string;
  date_comment: string;
  pj_comment: string;
  root_pj: string;
  user_name: string;
  user_uperid: string;
}

/**
 * Life-cycle Status Model
 */
export interface LifeCycleStatus {
  dossier: string;
  etape_code: string;
  group_charge: string;
  group_id: string;
  id_status: string;
  id_workflow: string;
  list_users: string[];
  lmd: string;
  status: string;
  status_code: string;
  validator_name: string;
  current_step: boolean;
  sub_status: LifeCycleSubStatus[];
  comments: LifeCycleComment[];
  WFbouton: string;
  user_charge: string;
}

/**
 * Life-cycle Sub-status Model
 */
export interface LifeCycleSubStatus {
  status_code: string;
  id_status: string;
  child_group: string;
  group_id_child: string;
}

/**
 *  Summary Model
 */
export interface LifeCycleSummary {
  SLA: string;
  benificiaire_name: string;
  created_date: string;
  demandeur_name: string;
  etape_code: string;
  lmd: string;
  object: string;
  req_id: string;
  status_code: string;
  updated_date: string;
}

/**
 * Life-cycle Trans Model
 */
export interface LifeCycleTrans {
  acteur: string;
  action: string;
  date: string;
  notenum: string;
  piece_jointe: string;
  trans_comment: string;
}
