import { Component } from '@angular/core';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './../../../i18n/fr';

@Component({
  selector: 'sfr-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.scss'],
})
export class LifeCycleComponent {
  constructor(private translationLoaderService: TranslationLoaderService) {
    this.translationLoaderService.loadTranslations(localFrench);
  }
}
