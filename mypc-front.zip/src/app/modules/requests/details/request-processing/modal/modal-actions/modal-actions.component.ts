import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA, MatLegacyDialogRef as MatDialogRef } from '@angular/material/legacy-dialog';
import { MatLegacySnackBar as MatSnackBar, MatLegacySnackBarConfig as MatSnackBarConfig } from '@angular/material/legacy-snack-bar';
import { SnackBarComponent } from '@shared/components/snack-bar/snack-bar.component';
import { User } from '@shared/models/user';
import { SessionService } from '@shared/services/session/session.service';
import { RequestsService } from '@app/modules/requests/services/requests.service';

@Component({
  selector: 'sfr-modal-actions',
  templateUrl: './modal-actions.component.html',
  styleUrls: ['./modal-actions.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ModalActionsComponent implements OnInit {
  public user: User;
  action;
  dateUpdate;
  idRequest;
  public actionFG: UntypedFormGroup;
  public show = false;
  public showMotif = false;

  configSuccess: MatSnackBarConfig = {
    duration: 3500,
    horizontalPosition: 'right',
    verticalPosition: 'top',
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ModalActionsComponent>,
    private requestsService: RequestsService,
    private sessionService: SessionService,
    private formBuilder: UntypedFormBuilder,
    private snackBar: MatSnackBar
  ) {
    this.user = this.sessionService.user;
  }

  ngOnInit(): void {
    this.actionFG = this.actionFormInit();
    this.action = this.data.action;
    this.idRequest = this.data.idRequest;
    this.dateUpdate = this.data.dateUpdate;
  }

  isValidAction(action) {
    if (action == 'Valider') {
      return true;
    }
    return false;
  }

  checkValidatorComment(comment, controls) {
    if (comment !== '0') {
      if (comment == '1') {
        this.show = false;
        return 'facultatif';
      }
      if (comment == '2') {
        this.actionFG.controls[controls].setValidators([Validators.required]);
        this.actionFG.controls[controls].updateValueAndValidity();
        this.show = true;
        return 'Obligatoire';
      }
    }
  }

  checkValidatorMotif(motif) {
    if (motif == '0') {
      this.showMotif = false;
      return 'facultatif';
    }
    if (motif == '1') {
      this.actionFG.controls['trans_motif'].setValidators([
        Validators.required,
      ]);
      this.actionFG.controls['trans_motif'].updateValueAndValidity();
      this.showMotif = true;
      return 'Obligatoire';
    }
  }

  actionFormInit(): UntypedFormGroup {
    const formGroup = this.formBuilder.group({
      motif: [''],
      trans_comment: [''],
      trans_comment_tech: [''],
    });
    return formGroup;
  }

  sendAction() {
    // todo add service Post
    const idDemande = localStorage.getItem('idRequest');
    const formData = new FormData();
    formData.append('wf_status', this.action.id_action);
    formData.append(
      'technical_comment',
      this.actionFG.get('trans_comment_tech').value
    );
    formData.append('user_comment', this.actionFG.get('trans_comment').value);
    formData.append('tmotif', this.actionFG.get('motif').value);
    formData.append('lmd', this.dateUpdate);
    this.requestsService
      .postActionLifeCycle(idDemande, formData)
      .subscribe((result) => {
        if (result.success) {
          this.configSuccess.panelClass = 'style-success';
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              msg: 'Modifications enregistrées avec succès !',
              icon: 'check',
            },
            ...this.configSuccess,
          });
          location.reload();
        }
        if (!result.success) {
          this.configSuccess.panelClass = 'style-error';
          this.snackBar.openFromComponent(SnackBarComponent, {
            data: {
              msg: 'Erreur de connexion, merci de renouveler votre demande.',
              icon: 'close',
            },
            ...this.configSuccess,
          });
        }
      });
  }
}
