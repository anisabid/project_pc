import { Component, Inject, OnInit } from '@angular/core';
import {
  AbstractControl,
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { MatLegacyDialogRef as MatDialogRef, MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA } from '@angular/material/legacy-dialog';
import { LifeCycleComplaintActions } from '@app/modules/requests/store';
import { Store } from '@ngrx/store';

@Component({
  selector: 'sfr-modal-complaint',
  templateUrl: './modal-complaint.component.html',
  styleUrls: ['./modal-complaint.component.scss'],
})
export class ModalComplaintComponent implements OnInit {
  change: any;
  public complaintForm: UntypedFormGroup;

  /**
   * Constructor
   * @param data Form Data
   * @param dialogRef Dialog Ref
   * @param formBuilder Form Builder
   * @param store NgRx Store
   */
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ModalComplaintComponent>,
    private formBuilder: UntypedFormBuilder,
    private store: Store
  ) {}

  /**
   * Init Function
   */
  ngOnInit(): void {
    this.change = this.data.change;
    this.complaintForm = this.createForm();
  }

  /**
   * Create Complaint Form
   */
  createForm(): UntypedFormGroup {
    return this.formBuilder.group({
      complaintDescription: ['', Validators.required],
    });
  }

  /**
   * Submit Complaint
   */
  submitComplaint(): void {
    if (this.complaintForm.valid && this.complaintDescription?.value !== '') {
      this.store.dispatch(
        LifeCycleComplaintActions.AddComplaintRequest({
          changeID: this.change.change_id,
          comment: this.complaintDescription.value,
        })
      );
      this.dialogRef.close();
    }
  }

  /**
   * Get Complaint Description
   */
  get complaintDescription(): AbstractControl {
    return this.complaintForm.get('complaintDescription');
  }
}
