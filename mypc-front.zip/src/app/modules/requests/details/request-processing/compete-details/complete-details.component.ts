import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { BusIframe } from '@shared/models/bus-iframe';
import { Observable, Subscription } from 'rxjs';
import { LifeCycle } from '@requestsModule/models/life-cycle.model';
import { lifeCycleSelectors } from '@app/modules/requests/store';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { ActionTypeService } from '@app/modules/requests/services/action-type.service';

@Component({
  selector: 'sfr-complete-details',
  templateUrl: './complete-details.component.html',
  styleUrls: ['./complete-details.component.scss'],
})
export class CompleteDetailsComponent implements OnInit, OnDestroy {
  private subscription: Subscription = new Subscription();

  /**
   * Selected Life-cycle Observable
   */
  public selectedLifeCycle$: Observable<LifeCycle>;

  constructor(
    private store: Store,
    private router: Router,
    private actionTypeService: ActionTypeService
  ) {}

  ngOnInit(): void {
    this.getLifeCycle();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle() {
    this.selectedLifeCycle$ = this.store.select(
      lifeCycleSelectors.selectSelectedRequest
    );
  }

  @HostListener('window:message', ['$event'])
  onMessage(event) {
    try {
      const jsonParse = JSON?.parse(event.data);
      const data: BusIframe = new BusIframe(jsonParse);
      if (data && data.actions) {
        if (data.hasAction('CLOSE_MATDIALOG')) {
          // traitement
          this.reloadCurrentRoute();
        }
      }
    } catch (ex) {
      // console.error(ex);
    }
  }

  /**
   * Reload Current Route
   */
  reloadCurrentRoute(): void {
    this.actionTypeService.reloadCurrentRoute(this.router.url);
  }

  /**
   * On Destroy
   */
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
