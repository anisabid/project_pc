import { Component, Input } from '@angular/core';
import { MatLegacyDialog as MatDialog, MatLegacyDialogConfig as MatDialogConfig } from '@angular/material/legacy-dialog';
import { ModalUsersComponent } from '@app/modules/requests/details/request-processing/modal/modal-users/modal-users.component';
import { RequestQueryActions } from '@app/modules/requests/enums/request-query-actions.enum';
import { LifeCycle } from '@app/modules/requests/models/life-cycle.model';
import { lifeCycleSelectors } from '@app/modules/requests/store';
import { Store } from '@ngrx/store';
import { User } from '@shared/models/user';
import { SessionService } from '@shared/services/session/session.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'sfr-stepper-life-cycle',
  templateUrl: './stepper-life-cycle.component.html',
  styleUrls: ['./stepper-life-cycle.component.scss'],
})
export class StepperLifeCycleComponent {
  public validator = '';
  public user: User;
  public dateValidator = '';

  /**
   * Selected Life-cycle Observable
   */
  public selectedLifeCycle$: Observable<LifeCycle>;

  /**
   * Constructor
   * @param matDialog Material Dialog
   * @param sessionService Session Service
   */
  constructor(
    private matDialog: MatDialog,
    private sessionService: SessionService,
    private store: Store
  ) {
    this.user = this.sessionService.user;
    this.getLifeCycle();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle() {
    this.selectedLifeCycle$ = this.store.select(
      lifeCycleSelectors.selectSelectedRequest
    );
  }

  /**
   * Open Users List in a new Dialog
   * @param users User list
   */
  public selectAction(users: String[]): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.width = '30vw';
    dialogConfig.minHeight = '12vw';
    dialogConfig.data = {
      users: users,
    };
    this.matDialog.open(ModalUsersComponent, dialogConfig);
  }

  /**
   * Check if Step is in Progress
   * @param current_step current Step
   */
  public isStepInProgress(current_step: boolean | undefined): boolean {
    return !!current_step;
  }

  /**
   * Checks if the Step is Marked as Done
   * @param WFbouton Workflow Button
   * @param current_step current Step
   */
  public isStepDone(
    WFbouton: string,
    current_step: boolean | undefined
  ): boolean {
    return !WFbouton && !current_step;
  }

  /**
   * Get Arrow Position Icon
   * @param show determines show/hide mode
   */
  getArrowPosition(show: boolean): string {
    return show ? 'keyboard_arrow_up' : 'keyboard_arrow_down';
  }

  /**
   * Checks if canceled sub-status exists
   * @param subStatus Sub-status
   */
  isCanceledSubStatus(subStatus): boolean {
    let isCanceled = false;
    if (subStatus) {
      for (let i = 0; i < subStatus.length; i++) {
        if (subStatus[i].status_code === 'canceled') {
          isCanceled = true;
          this.validator = subStatus[i].validator_child;
          this.dateValidator = subStatus[i].date_validator_child;
        }
      }
      return isCanceled;
    }
  }

  /**
   * Check If Step Is Current Or Disabled
   * @param statusItem Status Item
   */
  public checkIfStepIsCurrentOrDisabled(statusItem: any): boolean {
    return (
      (!this.isStepDone(statusItem.WFbouton, statusItem.current_step) &&
        !this.isStepInProgress(statusItem.current_step)) ||
      this.isStepInProgress(statusItem.current_step)
    );
  }

  /**
   * Check If Step Is Draft
   * @param stepCode Step Code
   */
  public checkIfDraftStatus(stepCode: string): boolean {
    return stepCode === 'draft';
  }
}
