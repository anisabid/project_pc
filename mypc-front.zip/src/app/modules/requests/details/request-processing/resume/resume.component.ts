import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { Observable } from 'rxjs';
import { LifeCycle } from '../../../models/life-cycle.model';
import { lifeCycleSelectors } from '../../../store';
import { locale as localFrench } from '../../../i18n/fr';

@Component({
  selector: 'sfr-resume',
  templateUrl: './resume.component.html',
  styleUrls: ['./resume.component.scss'],
})
export class ResumeComponent implements OnInit {
  /**
   * Selected Life-cycle Observable
   */
  public selectedLifeCycle$: Observable<LifeCycle>;

  constructor(
    private translationLoaderService: TranslationLoaderService,
    private store: Store
  ) {
    this.translationLoaderService.loadTranslations(localFrench);
  }
  ngOnInit(): void {
    this.getLifeCycle();
  }

  /**
   * Get Life Cycle
   */
  getLifeCycle(): void {
    this.selectedLifeCycle$ = this.store.select(
      lifeCycleSelectors.selectSelectedRequest
    );
  }
}
