import { HttpErrorResponse } from '@angular/common/http';
import { createAction, props } from '@ngrx/store';
import { SearchFilter } from '../../advanced-filter/advanced-filter.model';
import { RequestList } from '../../models/request-list.model';

// Load Request List
/**
 * Load Request List Action Type
 */
export const LOAD_REQUEST_LIST = '[Requests] Load Request List';
/**
 * Load Request List Fail Action Type
 */
export const LOAD_REQUEST_LIST_FAIL = '[Requests] Load Request List Fail';
/**
 * Load Request List Success Action Type
 */
export const LOAD_REQUEST_LIST_SUCCESS = '[Requests] Load Request List Success';

/**
 * Load Request List Action
 */
export const LoadRequestList = createAction(
  LOAD_REQUEST_LIST,
  props<{
    action?: string;
    limit?: number;
    offset?: number;
    filter?: SearchFilter;
  }>()
);

/**
 * Load Request List Success Action
 */
export const LoadRequestListSuccess = createAction(
  LOAD_REQUEST_LIST_SUCCESS,
  props<{
    requestList: RequestList;
  }>()
);

/**
 * Load Request List Fail Action
 */
export const LoadRequestListFail = createAction(
  LOAD_REQUEST_LIST_FAIL,
  props<{ error: HttpErrorResponse }>()
);
