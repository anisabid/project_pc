// Load Life-Cycle

import { HttpErrorResponse } from '@angular/common/http';
import { createAction, props } from '@ngrx/store';
import { RequestQueryActions } from '../../enums/request-query-actions.enum';
import { LifeCycle } from '../../models/life-cycle.model';

/**
 * Load Life-Cycle Action
 */
export const LoadLifeCycle = createAction(
  '[Requests] Load Life-Cycle',
  props<{
    action: RequestQueryActions;
    requestId: string;
  }>()
);

/**
 * Load Life-Cycle Success Action
 */
export const LoadLifeCycleSuccess = createAction(
  '[Requests] Load Life-Cycle Success',
  props<{ lifeCycle: LifeCycle }>()
);

/**
 * Load Life-Cycle Fail Action
 */
export const LoadLifeCycleFail = createAction(
  '[Requests] Load Life-Cycle Fail',
  props<{ error?: HttpErrorResponse }>()
);
