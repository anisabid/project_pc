// Add Complaint

import { HttpErrorResponse } from '@angular/common/http';
import { createAction, props } from '@ngrx/store';
import { ComplaintResponseBody } from '../../models/complaint.model';

/**
 * Add Complaint Action
 */
export const AddComplaintRequest = createAction(
  '[Requests] Add Complaint',
  props<{
    changeID: number;
    comment: string;
  }>()
);

/**
 * Add Complaint Success Action
 */
export const AddComplaintRequestSuccess = createAction(
  '[Requests] Add Complaint Success',
  props<{ complaint: ComplaintResponseBody }>()
);

/**
 * Add Complaint Fail Action
 */
export const AddComplaintRequestFail = createAction(
  '[Requests] Add Complaint Fail',
  props<{ error?: HttpErrorResponse }>()
);
