// Add Life-Cycle Action

import { HttpErrorResponse } from '@angular/common/http';
import { createAction, props } from '@ngrx/store';
import { ActionResponseBody } from '../../models/action-response.model';

/**
 * Add Life-Cycle Action
 */
export const AddLifeCycleAction = createAction(
  '[Requests] Add Life-Cycle Action',
  props<{
    request_id: string;
    body: any;
  }>()
);

/**
 * Add Life-Cycle Action Success Action
 */
export const AddLifeCycleActionSuccess = createAction(
  '[Requests] Add Life-Cycle Action Success',
  props<{ action: ActionResponseBody }>()
);

/**
 * Add Life-Cycle Action Fail Action
 */
export const AddLifeCycleActionFail = createAction(
  '[Requests] Add Life-Cycle Action Fail',
  props<{ error?: HttpErrorResponse }>()
);
