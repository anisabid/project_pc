import { createSelector } from '@ngrx/store';
import { requestListPagination } from '../../models/request-list.model';
import * as fromFeature from '../reducers';
import * as fromRequestReducers from '../reducers/request.reducer';

/**
 * Select Request State
 */
export const selectRequestState = createSelector(
  fromFeature.selectRequestModuleState,
  (state: fromFeature.RequestModuleState) => state.requests
);

/**
 * Select Request Entities
 */
export const selectRequestEntities = createSelector(
  selectRequestState,
  fromRequestReducers.getRequestsEntities
);

/**
 * Select Request List
 */
export const selectRequestList = createSelector(
  selectRequestState,
  fromRequestReducers.selectRequest
);

/**
 * Select Request Loaded
 */
export const selectIfRequestListLoaded = createSelector(
  selectRequestState,
  fromRequestReducers.getRequestsLoaded
);

/**
 * Select Request Loaded
 */
export const selectIfRequestListLoading = createSelector(
  selectRequestState,
  fromRequestReducers.getRequestsLoading
);

/**
 * Select Request List Pagination Parameters
 */
export const selectRequestListPaginationParameters = createSelector(
  selectRequestState,
  ({ limit, offset, total, totalPage }): requestListPagination => {
    return {
      limit,
      offset,
      total,
      totalPage,
    };
  }
);
