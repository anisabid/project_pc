import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import * as fromRequestServices from '@requestsModule/services';
import * as fromRoot from '@app/store';
import { SnackBarMessageService } from '@app/shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@app/shared/services/errors/common-errors.service';
import { ActionTypeService } from '../../services/action-type.service';
import { Store } from '@ngrx/store';
import { LifeCycleComplaintActions } from '../actions';
import { catchError, first, map, switchMap } from 'rxjs/operators';
import { ComplaintResponseBody } from '../../models/complaint.model';
import { HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { RouterStateUrl } from '@app/store';
/**
 * Life-cycle Complaint Effects
 */
@Injectable()
export class LifeCycleComplaintEffects {
  /**
   * Constructor
   * @param actions$ action
   * @param requestService Requests Service
   * @param snackBarMessageService Material SnackBar Message Service
   * @param commonErrorsService Common Request Error Service
   */
  constructor(
    private actions$: Actions,
    private requestService: fromRequestServices.RequestsService,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService,
    private actionTypeService: ActionTypeService,
    private store: Store
  ) {}

  /**
   * Add Life-cycle Complaint
   */
  addComplaint$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleComplaintActions.AddComplaintRequest),
      switchMap(({ changeID, comment }) =>
        this.requestService.postComplaintRequest(changeID, comment).pipe(
          map((complaintResponse: ComplaintResponseBody) => {
            if (complaintResponse?.success === 'true') {
              return LifeCycleComplaintActions.AddComplaintRequestSuccess({
                complaint: complaintResponse,
              });
            }
            return LifeCycleComplaintActions.AddComplaintRequestFail({});
          }),
          catchError((error: HttpErrorResponse) =>
            of(LifeCycleComplaintActions.AddComplaintRequestFail({ error }))
          )
        )
      )
    );
  });

  /**
   * Add Life-cycle Complaint Success
   */
  addComplaintSuccess$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleComplaintActions.AddComplaintRequestSuccess),
      switchMap(() => {
        this.snackBarMessageService.success({
          message: 'Votre réclamation a été envoyée avec succès !',
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      }),
      map((action) => {
        let currentUrl: string = '';

        this.store
          .select(fromRoot.selectRouterState)
          .pipe(first())
          .subscribe((routerState) => {
            const state: RouterStateUrl = (routerState as any).router.state;
            currentUrl = state.url;
          });

        this.actionTypeService.reloadCurrentRoute(currentUrl);

        return action;
      })
    );
  });

  /**
   * Life-cycle Complaint Error handler ...
   */
  addComplaintFail$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleComplaintActions.AddComplaintRequestFail),
      switchMap(({ error }) => {
        const err = error
          ? this.commonErrorsService.getCommonRequestError(error)
          : "Echec d'envoi de réclamation";

        // ... you can check the payload here to show different messages
        // like if error.statusCode === 501 etc.
        this.snackBarMessageService.error({
          message: err,
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      }),
      map((action) => {
        let currentUrl: string = '';

        this.store
          .select(fromRoot.selectRouterState)
          .pipe(first())
          .subscribe((routerState) => {
            const state: RouterStateUrl = (routerState as any).router.state;
            currentUrl = state.url;
          });

        this.actionTypeService.reloadCurrentRoute(currentUrl);

        return action;
      })
    );
  });
}
