import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SnackBarMessageService } from '@app/shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@app/shared/services/errors/common-errors.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import * as fromRequestServices from '@requestsModule/services';
import * as fromRoot from '@app/store';

import { of } from 'rxjs';
import { catchError, first, map, switchMap } from 'rxjs/operators';
import { CommentResponseBody } from '../../models/comment.model';
import { LifeCycleCommentActions } from '../actions';
import { Store } from '@ngrx/store';
import { RouterStateUrl } from '@app/store';

import { ActionTypeService } from '../../services/action-type.service';

/**
 * Life-cycle Comment Effects
 */
@Injectable()
export class LifeCycleCommentEffects {
  /**
   * Constructor
   * @param actions$ action
   * @param requestService Requests Service
   * @param snackBarMessageService Material SnackBar Message Service
   * @param commonErrorsService Common Request Error Service
   */
  constructor(
    private actions$: Actions,
    private requestService: fromRequestServices.RequestsService,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService,
    private actionTypeService: ActionTypeService,
    private store: Store
  ) {}

  /**
   * Add Life-cycle Comment
   */
  addComment$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleCommentActions.AddComment),
      switchMap(({ request_id, body }) =>
        this.requestService.postAddCommentLifeCycle(request_id, body).pipe(
          map((commentResponse: CommentResponseBody) => {
            if (commentResponse?.success === 'true') {
              return LifeCycleCommentActions.AddCommentSuccess({
                action: commentResponse,
              });
            }
            return LifeCycleCommentActions.AddCommentFail({});
          }),
          catchError((error: HttpErrorResponse) =>
            of(LifeCycleCommentActions.AddCommentFail({ error }))
          )
        )
      )
    );
  });

  /**
   * Add Life-cycle Comment Success
   */
  addCommentSuccess$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleCommentActions.AddCommentSuccess),
      switchMap(() => {
        this.snackBarMessageService.success({
          message: 'Votre commentaire a été envoyé avec succès !',
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      }),
      map((action) => {
        let currentUrl: string = '';

        this.store
          .select(fromRoot.selectRouterState)
          .pipe(first())
          .subscribe((routerState) => {
            const state: RouterStateUrl = (routerState as any).router.state;
            currentUrl = state.url;
          });

        this.actionTypeService.reloadCurrentRoute(currentUrl);

        return action;
      })
    );
  });

  /**
   * Life-cycle Comment Error handler ...
   */
  addCommentFail$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LifeCycleCommentActions.AddCommentFail),
      switchMap(({ error }) => {
        const err = error
          ? this.commonErrorsService.getCommonRequestError(error)
          : "Echec d'envoi du commentaire";

        // ... you can check the payload here to show different messages
        // like if error.statusCode === 501 etc.
        this.snackBarMessageService.error({
          message: err,
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      }),
      map((action) => {
        let currentUrl: string = '';

        this.store
          .select(fromRoot.selectRouterState)
          .pipe(first())
          .subscribe((routerState) => {
            const state: RouterStateUrl = (routerState as any).router.state;
            currentUrl = state.url;
          });

        this.actionTypeService.reloadCurrentRoute(currentUrl);

        return action;
      })
    );
  });
}
