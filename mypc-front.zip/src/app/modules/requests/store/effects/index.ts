import { RequestEffects } from './request.effects';
import { LifeCycleEffects } from './life-cycle.effects';
import { LifeCycleCommentEffects } from './life-cycle-comment.effects';
import { LifeCycleActionEffects } from './life-cycle-action.effects';
import { LifeCycleComplaintEffects } from './life-cycle-complaint.effects';

/**
 * Effects Array
 */
export const effects: any[] = [
  RequestEffects,
  LifeCycleEffects,
  LifeCycleCommentEffects,
  LifeCycleActionEffects,
  LifeCycleComplaintEffects,
];
/**
 * Effects Export
 */
export * from './request.effects';
export * from './life-cycle.effects';
export * from './life-cycle-comment.effects';
export * from './life-cycle-action.effects';
export * from './life-cycle-complaint.effects';
