import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SnackBarMessageService } from '@app/shared/modules/snack-bar-message/snack-bar-message.service';
import { CommonErrorsService } from '@app/shared/services/errors/common-errors.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import * as fromRequestServices from '@requestsModule/services';
import * as fromRequestActions from '@requestsModule/store/actions/request.actions';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { RequestList } from '../../models/request-list.model';

/**
 * Request Effects
 */
@Injectable()
export class RequestEffects {
  /**
   * Constructor
   * @param actions$ action
   * @param requestService Requests Service
   * @param snackBarMessageService Material SnackBar Message Service
   * @param commonErrorsService Common Request Error Service
   */
  constructor(
    private actions$: Actions,
    private requestService: fromRequestServices.RequestsService,
    private snackBarMessageService: SnackBarMessageService,
    private commonErrorsService: CommonErrorsService
  ) {}

  /**
   * Load Request List
   */
  loadRequestList$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(fromRequestActions.LoadRequestList),
      switchMap(({ action, limit, offset, filter }) =>
        this.requestService.getRequests(action, limit, offset, filter).pipe(
          map((requestList: RequestList) =>
            fromRequestActions.LoadRequestListSuccess({ requestList })
          ),
          catchError((error: HttpErrorResponse) =>
            of(fromRequestActions.LoadRequestListFail(error))
          )
        )
      )
    );
  });

  /**
   * Request Error handler ...
   */
  loadRequestListFail$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(fromRequestActions.LoadRequestListFail),
      switchMap(({ error }) => {
        // ... you can check the payload here to show different messages
        // like if error.statusCode === 501 etc.
        this.snackBarMessageService.error({
          message: this.commonErrorsService.getCommonRequestError(error),
          action: null,
          duration: 2000,
        });

        // remap to noop Action if no state needs to be updated.
        // or for example on 401 Errors dispatch a re-login action etc.
        return of({ type: 'noop' });
      })
    );
  });
}
