import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import * as fromRequests from './request.reducer';
import * as fromLifeCycle from './life-cycle.reducer';

/**
 * Requests Module States
 */
export interface RequestModuleState {
  requests: fromRequests.RequestStateEntity;
  lifeCycle: fromLifeCycle.LifeCycleStateEntity;
}

/**
 * Reducers List
 */
export const reducers: ActionReducerMap<RequestModuleState> = {
  requests: fromRequests.RequestReducer,
  lifeCycle: fromLifeCycle.LifeCycleReducer,
};

/**
 * Select Requests Module State
 */
export const selectRequestModuleState =
  createFeatureSelector<RequestModuleState>('RequestModule');
