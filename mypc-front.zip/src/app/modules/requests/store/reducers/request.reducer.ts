import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { createReducer, on } from '@ngrx/store';
import { Request } from '../../models/request.model';
import * as fromRequestActions from '../actions/request.actions';

/**
 * Request State
 */
export interface RequestStateEntity extends EntityState<Request> {
  /**
   * Data
   */
  data: Request[];
  /**
   * Loaded
   */
  loaded: boolean;
  /**
   * Loading
   */
  loading: boolean;

  /**
   * Limit
   */
  limit: number;
  /**
   * Offset
   */
  offset: number;
  /**
   * Total
   */
  total: number;
  /**
   * Total Page
   */
  totalPage: number;
}

/**
 * Request Adapter
 */
export const RequestAdapter: EntityAdapter<Request> =
  createEntityAdapter<Request>({
    selectId: (request) => request.req_id,
    sortComparer: false,
  });

/**
 * Request initial State
 */
export const initialState: RequestStateEntity = RequestAdapter.getInitialState({
  data: [],
  loaded: false,
  loading: false,
  limit: 0,
  offset: 0,
  total: 0,
  totalPage: 0,
});

/**
 * Request Selectors
 *
 * RequestAdapters created with @ngrx/entity generate
 * commonly used selector functions including
 * getting all ids in the record set, a dictionary
 * of the records by id, an array of records and
 * the total number of records. This reduces boilerplate
 * in selecting records from the entity state.
 */
export const {
  selectIds: selectRequestIds,
  selectEntities: selectRequestEntities,
  selectAll: selectRequest,
  selectTotal: selectTotalRequest,
} = RequestAdapter.getSelectors();

/**
 * Request reducer
 */
export const RequestReducer = createReducer(
  initialState,
  on(
    fromRequestActions.LoadRequestList,
    (state): RequestStateEntity => ({
      ...state,
      loading: true,
    })
  ),

  on(fromRequestActions.LoadRequestListSuccess, (state, { requestList }) =>
    RequestAdapter.setAll(requestList.data, {
      ...state,
      limit: +requestList.limit,
      offset: requestList.offset,
      total: requestList.total,
      totalPage: requestList.totalPage,
      loading: false,
      loaded: true,
    })
  ),

  on(
    fromRequestActions.LoadRequestListFail,
    (state): RequestStateEntity => ({
      ...state,
      ...initialState,
    })
  )
);

/**
 * get Request Entities
 * @param state Request State
 */
export const getRequestsEntities = (state: RequestStateEntity) => state.data;
/**
 * get Request Loading
 * @param state Request State
 */
export const getRequestsLoading = (state: RequestStateEntity) => state.loading;
/**
 * get Request Loaded
 * @param state Request State
 */
export const getRequestsLoaded = (state: RequestStateEntity) => state.loaded;
/**
 * get Request Limit
 * @param state Request State
 */
export const getRequestLimit = (state: RequestStateEntity) => state.limit;
/**
 * get Request Offset
 * @param state Request State
 */
export const getRequestOffset = (state: RequestStateEntity) => state.offset;

/**
 * get Request Total
 * @param state Request State
 */
export const getRequestTotal = (state: RequestStateEntity) => state.total;
/**
 * get Request Total Page
 * @param state Request State
 */
export const getRequestTotalPage = (state: RequestStateEntity) =>
  state.totalPage;
