import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RequestsRoutingModule } from './requests-routing.module';
import { SharedModule } from '@shared/shared.module';
import { ListComponent } from './list/list.component';
import { MyRequestsComponent } from './list/my-requests/my-requests.component';
import { MyApprovalsComponent } from './list/my-approvals/my-approvals.component';
import { MatLegacyProgressSpinnerModule as MatProgressSpinnerModule } from '@angular/material/legacy-progress-spinner';
import { ModalActionComponent } from './list/modal/modal-action/modal-action.component';
import { MatLegacyPaginatorModule as MatPaginatorModule } from '@angular/material/legacy-paginator';
import { ResumeComponent } from './details/request-processing/resume/resume.component';
import { DetailsComponent } from './details/details.component';
import { LifeCycleComponent } from './details/request-processing/life-cycle/life-cycle.component';
import { MatLegacyTabsModule as MatTabsModule } from '@angular/material/legacy-tabs';
import { StepperLifeCycleComponent } from './details/request-processing/stepper-life-cycle/stepper-life-cycle.component';
import { ChangesComponent } from './details/request-processing/changes/changes.component';
import { AdvancedFilterModule } from './advanced-filter/advanced-filter.module';
import { ModalUsersComponent } from './details/request-processing/modal/modal-users/modal-users.component';
import { ModalActionsComponent } from './details/request-processing/modal/modal-actions/modal-actions.component';
import { OriginFormComponent } from './details/request-processing/origin-form/origin-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CommentComponent } from './details/request-processing/comment/comment.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { MatExpansionModule } from '@angular/material/expansion';
import { ModalComplaintComponent } from './details/request-processing/modal/modal-complaint/modal-complaint.component';
import { StoreModule } from '@ngrx/store';
import { effects, reducers } from './store';
import { EffectsModule } from '@ngrx/effects';
import { CompleteDetailsComponent } from './details/request-processing/compete-details/complete-details.component';

@NgModule({
  declarations: [
    ListComponent,
    MyRequestsComponent,
    MyApprovalsComponent,
    ModalActionComponent,
    ResumeComponent,
    DetailsComponent,
    LifeCycleComponent,
    StepperLifeCycleComponent,
    ChangesComponent,
    ModalUsersComponent,
    ModalActionsComponent,
    CompleteDetailsComponent,
    OriginFormComponent,
    CommentComponent,
    ModalComplaintComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RequestsRoutingModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatTabsModule,
    AdvancedFilterModule,
    ReactiveFormsModule,
    ScrollingModule,
    MatExpansionModule,
    StoreModule.forFeature('RequestModule', reducers),
    EffectsModule.forFeature(effects),
  ],
})
export class RequestsModule {}
