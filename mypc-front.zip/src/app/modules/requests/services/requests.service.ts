import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EndpointService } from '@shared/services/api/v2/endpoint.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';
import { Observable, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { SearchFilter } from '../advanced-filter/advanced-filter.model';
import { RequestQueryActions } from '../enums/request-query-actions.enum';
import {
  ActionResponse,
  ActionResponseBody,
} from '../models/action-response.model';
import { CommentResponse, CommentResponseBody } from '../models/comment.model';
import {
  Complaint,
  ComplaintResponse,
  ComplaintResponseBody,
} from '../models/complaint.model';
import { LifeCycle } from '../models/life-cycle.model';
import { RequestList } from '../models/request-list.model';
import { RequestQueryParams } from '../models/request-query-params.model';
import { RequestResult } from '../models/request-result.model';

@Injectable({
  providedIn: 'root',
})
export class RequestsService {
  private _isLoading: boolean;
  private _endpointRequests: EndpointService;
  private _endpointLifeCycle: EndpointService;
  private _endpointComplaintRequest: EndpointService;
  private _endpointNote: EndpointService;

  /**
   * Constructor
   * @param datePipe Date Pipe
   * @param urlHelperService Url Helper Service
   * @param httpClient Http Client
   * @param environmentService Environment Service
   */
  constructor(
    private datePipe: DatePipe,
    private urlHelperService: UrlHelperService,
    private httpClient: HttpClient,
    private environmentService: EnvironmentService
  ) {
    this._endpointRequests = new EndpointService('requests');
    this._endpointRequests.items.get = '';

    this._endpointLifeCycle = new EndpointService('requests');
    this._endpointLifeCycle.item.get = '${demand_id}/cycle_form?${action}';
    this._endpointLifeCycle.item.post = '${demand_id}/cycle_form/action/submit';

    this._endpointComplaintRequest = new EndpointService('requests');
    this._endpointComplaintRequest.item.post =
      '${changeId}/cycle_form/reclamation';

    this._endpointNote = new EndpointService('requests');
    this._endpointNote.item.post = '${demand_id}/cycle_form/note/new';
  }

  /**
   * Get isLoading
   */
  get isLoading(): boolean {
    return this._isLoading;
  }

  /**
   * Set isLoading
   * @param value Value
   */
  set isLoading(value: boolean) {
    this._isLoading = value;
  }

  /**
   * Get/Search Request List
   * @param action Action
   * @param limit Limit
   * @param offset offset
   * @param filter Filter
   */
  public getRequests(
    action?: string,
    limit?: number,
    offset?: number,
    filter?: SearchFilter
  ): Observable<RequestList> {
    let params = new RequestQueryParams(action, limit, offset);
    if (filter) {
      params = { ...params, ...filter };
    }
    let path: string = this.urlHelperService.addParameters(
      this._endpointRequests.items.get,
      params
    );

    if (this.environmentService.options.mock.data.requests) {
      path = this._endpointRequests.toMock(path);
    }

    return this.httpClient
      .get<RequestResult>(path)
      .pipe(
        switchMap((requestResult: RequestResult) =>
          of(requestResult.requests as RequestList)
        )
      );
  }

  /**
   * Get Request Life Cycle
   * @param action action
   * @param requestId Request ID
   */
  public getLifeCycle(
    action: RequestQueryActions,
    requestId: string
  ): Observable<LifeCycle> {
    const urlFilter = this._endpointLifeCycle.item.get;
    const path: string = urlFilter
      .replace('${action}', action.toString() === '' ? '' : 'action=' + action)
      .replace('${demand_id}', requestId);

    return this.httpClient
      .get<RequestResult>(path)
      .pipe(
        switchMap((requestResult: RequestResult) =>
          of(requestResult.requests as LifeCycle)
        )
      );
  }

  /**
   * Send Complaint
   * @param changeID Change ID
   * @param comment Comment
   */
  public postComplaintRequest(
    changeID: number,
    comment: string
  ): Observable<ComplaintResponseBody> {
    const status = 56;
    const modificationDate = this.datePipe
      .transform(Date.now(), 'dd/MM/yyyy HH:mm:ss')
      .toString();
    const motif = '';
    const forceTransition = 'yes';
    const itemType = 2;
    const complaintObject = new Complaint(
      status,
      modificationDate,
      comment,
      motif,
      forceTransition,
      itemType
    );
    const urlFilter = this._endpointComplaintRequest.item.post;
    const path: string = urlFilter.replace('${changeId}', changeID.toString());

    return this.httpClient
      .post<RequestResult>(path, complaintObject)
      .pipe(
        switchMap((requestResult: RequestResult) =>
          of((requestResult.requests as ComplaintResponse).action)
        )
      );
  }

  /**
   * Post Life-cycle Action
   * @param demand_id Request ID
   * @param body Action Body
   */
  public postActionLifeCycle(
    demand_id: string,
    body: FormData
  ): Observable<ActionResponseBody> {
    const urlFilter = this._endpointLifeCycle.item.post;
    const path: string = urlFilter.replace('${demand_id}', demand_id);

    return this.httpClient.post<RequestResult>(path, body).pipe(
      switchMap((requestResult: RequestResult) => {
        return of((requestResult.requests as ActionResponse).action);
      })
    );
  }

  /**
   * Post Comment Life-Cycle Action
   * @param requestId Request ID
   * @param body Comment Body
   */
  postAddCommentLifeCycle(
    requestId: string,
    body: FormData
  ): Observable<CommentResponseBody> {
    const urlFilter = this._endpointNote.item.post;
    const path: string = urlFilter.replace('${demand_id}', requestId);

    return this.httpClient
      .post<RequestResult>(path, body)
      .pipe(
        switchMap((requestResult: RequestResult) =>
          of((requestResult.requests as CommentResponse).note)
        )
      );
  }

  /**
   * Get Full File URL
   * @param filePath Relative file path
   */
  getFullFileURL(filePath: string): string {
    return this.urlHelperService.toBackOffice(filePath);
  }
}
