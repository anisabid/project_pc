/**
 * Data Type Enum
 */
export enum DataType {
  NOTE,
  ACTION,
}
