import { Component, Input, OnInit } from '@angular/core';
import { MatLegacyDialog as MatDialog, MatLegacyDialogConfig as MatDialogConfig } from '@angular/material/legacy-dialog';
import { ResetPasswordComponent } from '../modal/reset-password/reset-password.component';
@Component({
  selector: 'sfr-reset-password-item',
  templateUrl: './reset-password-item.component.html',
  styleUrls: ['./reset-password-item.component.scss'],
})
export class ResetPasswordItemComponent implements OnInit {
  @Input() url: string;
  @Input() name: string;
  constructor(private matDialog: MatDialog) {}

  ngOnInit(): void {}

  openPopUp(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'sfr-dialog';
    dialogConfig.width = '50vw';
    dialogConfig.height = '70vh';
    dialogConfig.data = { url: this.url };
    this.matDialog.open(ResetPasswordComponent, dialogConfig);
  }
}
