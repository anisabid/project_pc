export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        password: {
          name: 'Réinitialisation mot de passe',
          global: {},
          modal: {
            title: 'Réinitialisation mot de passe',
          },
        },
      },
    },
  },
};
