import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResetPasswordComponent } from './modal/reset-password/reset-password.component';
import { ResetPasswordItemComponent } from './reset-password-item/reset-password-item.component';
import { MatLegacyDialogModule as MatDialogModule } from '@angular/material/legacy-dialog';
import { TranslateModule } from '@ngx-translate/core';
import { MaterialModule } from '@shared/modules/material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  declarations: [ResetPasswordComponent, ResetPasswordItemComponent],
  imports: [CommonModule, MaterialModule, MatDialogModule, TranslateModule, FlexLayoutModule],
  exports: [ResetPasswordItemComponent],
})
export class PasswordModule {}
