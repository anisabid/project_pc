import {
  Component,
  ElementRef,
  Inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  MatLegacyDialogRef as MatDialogRef,
  MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA,
} from '@angular/material/legacy-dialog';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from '../../i18n/fr';

@Component({
  selector: 'sfr-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
})
export class ResetPasswordComponent implements OnInit {
  public url: SafeResourceUrl;
  @ViewChild('sfrParentIframe') sfrParentIframe: ElementRef;
  @ViewChild('sfrIframe') sfrIframe: ElementRef;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private translationLoaderService: TranslationLoaderService,
    public dialogRef: MatDialogRef<ResetPasswordComponent>,
    private domSanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.translationLoaderService.loadTranslations(localFrench);
    this.url = this.domSanitizer.bypassSecurityTrustResourceUrl(this.data.url);
  }
  resizeIframe() {
    if (this.sfrIframe) {
      this.sfrIframe.nativeElement.style.height =
        this.sfrParentIframe.nativeElement.offsetHeight + 'px';
    }
  }
}
