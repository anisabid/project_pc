import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginGuard } from '@app/core/guards/login.guard';
import { ConstRoutesPath } from '@shared/consts/routes.const';

const routes: Routes = [
  {
    path: ConstRoutesPath.SECURE.LOGIN,
    canActivate: [LoginGuard],
    loadChildren: () =>
      import('./login/login.module').then((m) => m.LoginModule),
  },
  {
    path: ConstRoutesPath.SECURE.AUTOLOGIN,
    canActivate: [LoginGuard],
    loadChildren: () =>
      import('./autologin/autologin.module').then((m) => m.AutologinModule),
  },
  {
    path: ConstRoutesPath.SECURE.LOGOUT,
    loadChildren: () =>
      import('./logout/logout.module').then((m) => m.LogoutModule),
  },
  {
    path: '**',
    redirectTo: ConstRoutesPath.SECURE.LOGIN,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class secureRoutingModule {}
