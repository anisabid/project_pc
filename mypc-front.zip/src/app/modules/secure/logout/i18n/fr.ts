export const locale = {
  lang: 'fr',
  data: {
    i18n: {
      module: {
        logout: {
          login: 'Connexion',
          logout_in_progress: 'Déconnexion en cours...',
          messages: {
            expired_session: 'Votre session a expirée.',
          },
        },
      },
    },
  },
};
