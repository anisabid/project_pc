import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutologinComponent } from './autologin.component';
import { AutologinRoutingModule } from './autologin-routing.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [AutologinComponent],
  imports: [
    CommonModule,
    AutologinRoutingModule,
    FlexLayoutModule,
    SharedModule,
  ],
})
export class AutologinModule {}
