import {
  Component,
  ElementRef,
  HostListener,
  Inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatLegacyDialogRef as MatDialogRef, MAT_LEGACY_DIALOG_DATA as MAT_DIALOG_DATA } from '@angular/material/legacy-dialog';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { EnumCatalogs } from '@shared/consts/catalog.const';
import { BusIframe } from '@shared/models/bus-iframe';
import { Catalog, CatalogAction } from '@shared/models/catalog';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';

interface modalActionData {
  action?: CatalogAction;
  catalog?: Catalog;
  requestType: string;
}
@Component({
  selector: 'sfr-modal-action',
  templateUrl: './modal-action.component.html',
  styleUrls: ['./modal-action.component.scss'],
})
export class ModalActionComponent implements OnInit {
  @ViewChild('iframe') iframe: ElementRef;
  public action: CatalogAction;
  public catalog: Catalog;
  public title: string;
  public requestType: string;
  public iFrameUrl: SafeResourceUrl;
  public iFrameDisplay: boolean;
  public srcdoc: string;
  public src: SafeResourceUrl;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ModalActionComponent>,
    private urlHelperService: UrlHelperService,
    private environmentService: EnvironmentService,
    private domSanitizer: DomSanitizer
  ) {
    this.iFrameDisplay = false;
  }

  ngOnInit(): void {
    this.title = this.data.action
      ? this.data.action.name
      : this.data.catalog
      ? this.environmentService.config.modules.dashboard.workflow
          .genericIncident.name
      : '';
    this.requestType = this.data.requestType;
    this.src = this.domSanitizer.bypassSecurityTrustResourceUrl(
      this.urlHelperService.toBackOffice(this.url)
    );
  }

  @HostListener('window:message', ['$event'])
  onMessage(event: any) {
    const data: BusIframe = new BusIframe(JSON.parse(event.data));
    if (data && data.actions) {
      if (data.hasAction('CLOSE_MATDIALOG')) {
        this.dialogRef.close(data.hasAction('ROLLBACK'));
      }
    }
  }

  get url(): string {
    this.action = <CatalogAction>this.data.action;

    let url = '';
    if (this.action) {
      url =
        this.environmentService.iframe.baseUrl +
        '?p=ps/new_form&action=' +
        this.action.id +
        '&ctner=' +
        this.action.ctnerId;
      if (this.requestType.toUpperCase() === EnumCatalogs.ESUP.toUpperCase()) {
        url = this.urlHelperService.toJwt(
          this.environmentService.iframe.baseUrlMyAssistance +
            '?origin=refonte&module=E-SUPPORT&ctnerid=0' +
            '&formId=' +
            this.action.formId +
            '&name=' +
            this.action.name +
            '&token='
        );
      }
    } else {
      this.catalog = <Catalog>this.data.catalog;
      if (this.catalog) {
        url = this.urlHelperService.toJwt(
          this.environmentService.iframe.baseUrlMyAssistance +
            '?origin=refonte&module=E-SUPPORT&ctnerid=0' +
            '&formId=' +
            this.environmentService.config.modules.dashboard.workflow
              .genericIncident.formId +
            '&name=' +
            this.environmentService.config.modules.dashboard.workflow
              .genericIncident.name +
            '&token='
        );
      }
    }

    return url;
  }
}
