import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sfr-widget-faq',
  templateUrl: './widget-faq.component.html',
  styleUrls: ['./widget-faq.component.scss']
})
export class WidgetFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
