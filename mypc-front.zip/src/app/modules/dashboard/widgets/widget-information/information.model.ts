export class Information {
  success: boolean;
  message: String;
  constructor(data?: any, fromApi: boolean = true) {
    if (data?.message) {
      this.message = '<div>' + data.message + '</div>';
    }
    this.success = !data?.success ? null : data.success;
  }
}
