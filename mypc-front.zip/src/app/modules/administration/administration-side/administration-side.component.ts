import { Component, OnInit } from '@angular/core';
import { JwtService } from '@app/core/services/jwt.service';
import { EnumAccess } from '@shared/consts/access.const';
import {
  ConstNavigationItemType,
  EnumNavigationItemType,
  NavigationItemType,
} from '@shared/consts/navigation.const';
import { EnumUrlTarget } from '@shared/consts/url-target.const';
import { NavigationItem } from '@shared/models/navigation';
import { UrlHelperService } from '@shared/services/helper/url-helper.service';

@Component({
  selector: 'sfr-administration-side',
  templateUrl: './administration-side.component.html',
  styleUrls: ['./administration-side.component.scss'],
})
export class AdministrationSideComponent implements OnInit {
  public menuSide: NavigationItem;
  public constNavigationItemType: NavigationItemType;
  constructor(
    private jwtService: JwtService,
    private urlHelperService: UrlHelperService
  ) {
    this.constNavigationItemType = ConstNavigationItemType;
  }

  ngOnInit(): void {
    this.menuSide = {
      id: 'administration-super-admin',
      type: EnumNavigationItemType.GROUP,
      translate: 'i18n.module.administration.items.super-admin',
      iconClass: 'icon-confidential',
      access: [
        EnumAccess.ADMIN,
        EnumAccess.ADMIN_SOCLE,
        EnumAccess.ADMIN_FORM_EDITOR,
        EnumAccess.ADMIN_MAPPING,
        EnumAccess.ADMIN_SPE_WORKFLOW,
      ],
      children: [
        {
          id: 'administration-super-admin-e-kiosk',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.e-kiosk',
          iconName: 'desktop_windows',
          url: this.urlHelperService.toBackOffice('ekiosquev2/'),
          url_target: EnumUrlTarget.BLANK,
        },
        {
          id: 'administration-super-admin-my-assistance',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.my-assistance',
          iconName: 'headset_mic',
          url: this.urlHelperService.toBackOffice('myAssistance/'),
          url_target: EnumUrlTarget.POPUP,
        },
        {
          id: 'administration-super-admin-assistance-editor',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.assistance-editor',
          iconName: 'support_agent',
          url: this.urlHelperService.toBackOffice('myAssistance/editor/'),
          url_target: EnumUrlTarget.BLANK,
        },
        {
          id: 'administration-super-admin-database-comparison',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.database-comparison',
          iconName: 'storage',
          url: this.urlHelperService.toBackOffice(
            'mypc/tools/compareBDD_All.php'
          ),
          url_target: EnumUrlTarget.BLANK,
        },
        {
          id: 'administration-super-admin-extract-buroco',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.extract-buroco',
          iconName: 'get_app',
          url: this.urlHelperService.toBackOffice(
            'mypc/data/pc/in/GEF_BUROCO.csv'
          ),
          url_target: EnumUrlTarget.BLANK,
        },
        /*
        {
          id: 'administration-super-admin-partners',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.partners',
          iconName: 'group',
          url: this.urlHelperService.toBackOffice('mypc/index.php?p=ps/admin_socle_new'),
        },
        {
          id: 'administration-super-admin-update-users',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.update-users',
          iconName: 'recent_actors',
          url: this.urlHelperService.toBackOffice('mypc/index.php?p=ps/admin_socle_new'),
        },
        */
        {
          id: 'administration-super-admin-container-duplication',
          type: EnumNavigationItemType.ITEM,
          translate: 'i18n.module.administration.items.container-duplication',
          iconName: 'scanner',
          url: this.urlHelperService.toBackOffice(
            'mypc/tools/adm_duplicate_ctner.php'
          ),
          url_target: EnumUrlTarget.BLANK,
        },
      ],
    };
  }

  public isPopupTarget(item: NavigationItem): boolean {
    return item.url_target === EnumUrlTarget.POPUP;
  }

  openPopup(url: string) {
    window.open(url, 'popup', 'width=600,height=600');
  }
}
