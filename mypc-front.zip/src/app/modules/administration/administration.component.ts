import { Component, OnInit } from '@angular/core';
import { Access, ConstAccess } from '@shared/consts/access.const';
import { TranslationLoaderService } from '@shared/services/translation/translation-loader.service';
import { locale as localFrench } from './i18n/fr';

@Component({
  selector: 'sfr-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss'],
})
export class AdministrationComponent implements OnInit {
  public constAccess: Access;
  constructor(private translationLoaderService: TranslationLoaderService) {
    this.translationLoaderService.loadTranslations(localFrench);
    this.constAccess = ConstAccess;
  }

  ngOnInit(): void {}
}
