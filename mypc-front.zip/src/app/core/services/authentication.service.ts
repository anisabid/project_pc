import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginForm } from '@shared/models/user';
import { JwtService } from '@core/services/jwt.service';
import { ApiService } from '@shared/services/api/v2/api.service';
import { CookieService } from '@shared/services/cookie/cookie.service';
import { EnvironmentService } from '@shared/services/environment/environment.service';
import { LocalStorageService } from '@shared/services/localstorage/localstorage.service';
import { HttpParameterCodec } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  constructor(
    private jwtService: JwtService,
    private apiService: ApiService,
    private environmentService: EnvironmentService,
    private cookieService: CookieService,
    private activatedRoute: ActivatedRoute,
    private localStorageService: LocalStorageService
  ) {}

  login(user: LoginForm, access?: string) {
    return this.apiService.login.postLogin({
      user: this.encodeLoginData(user.userName),
      password: this.encodeLoginData(user.password),
      access: access,
    });
  }

  autoLogin(access?: string) {
    window.location.href = this.apiService.login.getUrlAutoLogin({
      access: access,
    });
  }

  interceptTokenFromQueryParams(): void {
    if (this.activatedRoute.snapshot.queryParams?.token) {
      this.jwtService.putJwtInLocalStorage(
        this.activatedRoute.snapshot.queryParams?.token
      );
    }
  }

  isLoggedIn(): boolean {
    return !!this.jwtService.getInfos();
  }

  isValidInfos(): boolean {
    return this.jwtService.isValidInfos();
  }

  isSessionExpired(): boolean {
    return this.jwtService.isTokenExpired();
  }

  logout(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      Promise.all([this.logoutApi(), this.logoutClear()]).then(() => {
        resolve(true);
      }, reject);
    });
  }

  logoutApi(): Promise<any> {
    return this.apiService.logout.postLogout().toPromise();
  }

  logoutClear(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.jwtService.removeJwtFromLocalStorage();
      this.clearLocalStorage();
      this.clearCookie();
      resolve(true);
    });
  }

  clearLocalStorage() {
    this.localStorageService.clear(
      this.environmentService.options.localStorage.clearAfterLogout
    );
  }

  clearCookie() {
    if (
      <string>this.environmentService.options.localCookies.clearAfterLogout ===
      '*'
    ) {
      this.cookieService.deleteAll();
    } else {
      (<Array<string>>(
        this.environmentService.options.localCookies.clearAfterLogout
      )).forEach((element) => {
        try {
          this.cookieService.delete(element);
        } catch (error) {
          console.error(error);
        }
      });
    }
  }

  /**
   * Encode Login Data
   * @param data Data
   */
  encodeLoginData(data: string): string {
    return data ? btoa(data) : undefined;
  }
}
