import { Injectable } from '@angular/core';
import { EnvironmentService } from '@shared/services/environment/environment.service';

@Injectable({
  providedIn: 'root',
})
export class AccessService {
  constructor(private environmentService: EnvironmentService) {}

  lockAppAccess(): boolean {
    if (!this.environmentService.access.lockApp.enable) {
      return false;
    } else {
      if (
        this.environmentService.access.lockApp.dateEnd &&
        new Date(this.environmentService.access.lockApp.dateEnd) < new Date()
      ) {
        return false;
      }

      if (
        this.environmentService.access.lockApp.dateBegin &&
        new Date() < new Date(this.environmentService.access.lockApp.dateBegin)
      ) {
        return false;
      }

      return true;
    }
    return this.environmentService.access.lockApp.enable;
  }
}
