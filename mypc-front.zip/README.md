# MYPC - Refonte Front-end

![Angular](https://img.shields.io/badge/angular-%23DD0031.svg?style=for-the-badge&logo=angular&logoColor=white)
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)
![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white)
![SASS](https://img.shields.io/badge/SASS-hotpink.svg?style=for-the-badge&logo=SASS&logoColor=white)
![RxJS](https://img.shields.io/badge/rxjs-%23B7178C.svg?style=for-the-badge&logo=reactivex&logoColor=white)
![Material UI](https://img.shields.io/badge/materialui-%230081CB.svg?style=for-the-badge&logo=material-ui&logoColor=white)

#### This Project represents the new Front-End of "MyPC" Angular application with new architecture and new design

## 🔧 Utils

- UI [Sources files](https://globaltelko.sharepoint.com/:f:/r/sites/RefonteERGOMyPC/Shared%20Documents/General/livrable%20final%20INETUM?csf=1&web=1&e=KwsCcG)
- UI [Xd Adobe](https://xd.adobe.com/view/9ae6db0c-c390-43fe-a74e-cff1257f82a5-cfb5/?fullscreen&hints=off)
- JIRA Project [MYPC - REFONTE - SCRUM](https://jira.private.sfr.com/secure/RapidBoard.jspa?rapidView=771&projectKey=MYPC&view=planning.nodetail&selectedIssue=MYPC-132&issueLimit=100)
- GIT Front-End [MYPC Front](https://gitlab.pic.services.prod/outils/mypc-front)
- GIT Back-End [MYPC BackOffice](https://gitlab.pic.services.prod/outils/mypc-backoffice)

## 🧱 Environments

- Dev
  - [https://mypcv2.pfv.private.sfr.com](https://mypcv2.pfv.private.sfr.com)
  - [http://10.144.16.140:8081/](http://10.144.16.140:8081/)
- QA / PACK
  - [https://mypcv2.pfv.private.sfr.com](https://mypcv2.pfv.private.sfr.com)
  - [http://su12213.phys.pack:8081/](http://su12213.phys.pack:8081/)

## 🚨 Rules

If you wish to collaborate in this project you should respect the following rules :

- After pushing your branch into the project you should submit for a merge request. Changes should be investigated by the project manager before being merged to master [Merge Request](https://gitlab.pic.services.prod/mypc/mypc-front/-/merge_requests).
- Any working branch should be referenced by the task job issued from Jira.
- Merge requests should contain a clear description of changes have been made.

## ⚡ Prerequisites

The project have dependencies that require Node 16, NPM 8 or higher [NodeJS](https://nodejs.org/en/) version.

Git is used as distributed version control system [Git](https://git-scm.com/)

## Table of Contents

- [Installation](#🚧-installation)
- [Starting the development server](#🏃‍♂️-starting-the-development-server)
- [Building the Project](#🔨-building-the-project)
- [Code scaffolding](#🏗-code-scaffolding)
- [NgRx](#🔄-ngrx)
- [Testing](#🧪-testing)
- [Documentation](#📖-documentation)
- [Further help](#🆘-further-help)

## 🚧 Installation

**BEFORE YOU INSTALL:** please read the [prerequisites](#prerequisites)

**Clone the project to working directory**

```bash
git clone https://gitlab.pic.services.prod/mypc/mypc-front.git
cd mypc-front
```

## 🏃‍♂️ Starting the development server

The development server is mapped automatically via the docker container networking publishing the server app by default in the [localhost:4202](http://localhost:4202).

The app will automatically reload if you change any of the source files.
Just run

### **With proxy `dev` config**

```bash
npm run start:dev
```

For run server with mock server, Run `npm run start:dev` then the mock server running on `3000` port and the app server running on `4202` port.

### **With proxy `pack` config**

```bash
npm run start:pack
```

## 🔨 Building the Project

Run

```bash
npm run build-dev
```

to build the project on local machine using the `dev` configuration. The build artifacts will be stored in the `dist/` directory.

Run

```bash
npm run build-pack
```

to build the project to the **Pack Config job**. This command use `pack` server URL.

Run

```bash
npm run build-prod
```

to build the project to the **Prod Config job**. This command use `prod` server URL.

Run

```bash
npm run build-perf
```

to build the project to the **Perf Config job**. This command use `perf` server URL.

## 🏗 Code scaffolding

You can use the `ng generate` (or just `ng g`) command to generate Angular components:
You can find all possible blueprints in the table below:

| Scaffold                                                                    | Usage                             |
| --------------------------------------------------------------------------- | --------------------------------- |
| [Component](https://github.com/angular/angular-cli/wiki/generate-component) | `ng g component my-new-component` |
| [Directive](https://github.com/angular/angular-cli/wiki/generate-directive) | `ng g directive my-new-directive` |
| [Pipe](https://github.com/angular/angular-cli/wiki/generate-pipe)           | `ng g pipe my-new-pipe`           |
| [Service](https://github.com/angular/angular-cli/wiki/generate-service)     | `ng g service my-new-service`     |
| [Class](https://github.com/angular/angular-cli/wiki/generate-class)         | `ng g class my-new-class`         |
| [Guard](https://github.com/angular/angular-cli/wiki/generate-guard)         | `ng g guard my-new-guard`         |
| [Interface](https://github.com/angular/angular-cli/wiki/generate-interface) | `ng g interface my-new-interface` |
| [Enum](https://github.com/angular/angular-cli/wiki/generate-enum)           | `ng g enum my-new-enum`           |
| [Module](https://github.com/angular/angular-cli/wiki/generate-module)       | `ng g module my-module`           |

angular-cli will add reference to `components`, `directives` and `pipes` automatically in the `app.module.ts`. If you need to add this references to another custom module, follow this steps:

1. `ng g module new-module` to create a new module
2. call `ng g component new-module/new-component`
   This should add the new `component`, `directive` or `pipe` reference to the `new-module` you've created.

## 🔄 NgRx

### **What is NgRx?** 🤔

NgRx is a framework for building reactive applications in Angular. NgRx provides libraries for:

- Managing global and local state.
- Isolation of side effects to promote a cleaner component architecture.
- Entity collection management.
- Integration with the Angular Router.
- Developer tooling that enhances developer experience when building many different types of applications.

### **Installed Packages** 📦

- `@ngrx/store` - including reducers, actions, selectors
- `@ngrx/effects` - for implementation of side effects like http requests, logging, notifications,...
- `@ngrx/entity` - for CRUD operations
- `@ngrx/data` - for simplifying management of entity data while reducing the amount of explicitness.
- `@ngrx/router-store` - to connect the Angular Router to @ngrx/store
- `@ngrx/store-devtools` - to enable a powerful time-travelling debugger.

### **Further help** 📚

To get more help about Ngrx, check out [NgRx's official documentation](https://ngrx.io/) website.

## 🧪 Testing

### **Running unit tests**

Tests will execute after a build is executed via [Karma](https://karma-runner.github.io), and it will automatically watch your files for changes

```bash
ng test
```

Following the test result is ensured in the generated reports file.

### **Running end-to-end tests**

Run

```bash
ng e2e
```

to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## 📖 Documentation

You can generate the Project's documentation with [compodoc](https://compodoc.app/) using the following command, inside the running container

```bash
npm run compodoc:build-and-serve
```

### Technical documentation

- [Files Structure](./md/files-structure.md)
- [Mock](./md/mock.md)
- [Form](./md/form.md)
- [i18n](./md/i18n.md)

### Swagger

- Pack [http://mypc.pfv.private.sfr.com/swagger-editor-master/](http://mypc.pfv.private.sfr.com/swagger-editor-master/)
- Dev [http://10.144.16.140:8081/swagger-editor-master/](http://10.144.16.140:8081/swagger-editor-master/)

## 🆘 Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
