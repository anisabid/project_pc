const LOGIN = require("./db/login.json");
const REQUESTS_REQUESTS = require("./db/requests&action=requests.json");
const REQUESTS_ACTIONS = require("./db/requests&action=actions.json");
const CATALOG = require("./db/catalog.json");

module.exports = () => ({
  login: LOGIN,
  requests_requests: REQUESTS_REQUESTS,
  requests_actions: REQUESTS_ACTIONS,
  catalog: CATALOG,
});
